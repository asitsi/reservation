import React, { useCallback, useEffect, useState } from "react"
import { useSelector } from "react-redux"
import { catchError, map, of } from "rxjs"

import { EventStatus, EventType, unAttendEvent } from "convose-lib/users-list"
import { attendEvent } from "convose-lib/users-list/dao"
import { selectMyUuid, selectToken } from "convose-lib/user"
import { ChatUser } from "convose-lib/chat"
import { modalAlertRef } from "../../../RootConvoseAlert"

import {
  EventName,
  EventDate,
  EventAttendButton,
  EventHost,
  EventAttendees,
} from "../../EventCard"
import {
  EventNameContainer,
  OngoingEventUsersInCallContainer,
  TitleHostContainer,
  UpcomingEventBottomContainer,
  UpcomingEventContainer,
  UpcomingEventDateHostContainer,
  UpcomingEventTitle,
} from "./Styled"
import { UsersInCall } from "../UsersInCall"

type EventBoxType = {
  event: EventType
  isOnGoing: boolean
  participants?: ChatUser[]
  joinCallButton?: React.ReactNode
}

const UpcomingEventComponent: React.FC<EventBoxType> = ({
  event,
  isOnGoing,
  joinCallButton,
  participants,
}) => {
  const token = useSelector(selectToken)
  const myUuid = useSelector(selectMyUuid)
  const [attendStatus, setAttendStatus] = useState<EventStatus>("not_attending")

  useEffect(() => {
    setAttendStatus(event.status)
  }, [event.status])

  const handleOnAttendPress = useCallback(() => {
    if (attendStatus === "attending") {
      unAttendEvent(token, event.id)
        .pipe(
          map(() => {
            setAttendStatus("not_attending")
          }),
          catchError(() => {
            setAttendStatus("not_attending")
            setTimeout(() => {
              setAttendStatus("attending")
            }, 50)
            modalAlertRef?.show({
              title: "Leaving event failed",
              description:
                "We couldn't process your request, Please try again later.",
              buttons: [
                {
                  title: "OK",
                },
              ],
            })
            return of()
          })
        )
        .subscribe()
    } else {
      attendEvent(token, event.id)
        .pipe(
          map(() => {
            setAttendStatus("attending")
          }),
          catchError(() => {
            setAttendStatus("attending")
            setTimeout(() => {
              setAttendStatus("not_attending")
            }, 50)
            modalAlertRef?.show({
              title: "Attending event failed",
              description:
                "We couldn't process your request, Please try again later.",
              buttons: [
                {
                  title: "OK",
                },
              ],
            })
            return of()
          })
        )
        .subscribe()
    }
  }, [attendStatus, event.id, token])
  return (
    <UpcomingEventContainer>
      {isOnGoing && !!participants && !!participants.length && (
        <OngoingEventUsersInCallContainer>
          <UsersInCall
            isGroup
            avatarCountToShow={2}
            participants={participants}
            avatarBgColorCode="main.chatBoxBackground"
            showRing
          />
        </OngoingEventUsersInCallContainer>
      )}
      <TitleHostContainer>
        <UpcomingEventTitle>
          {isOnGoing ? `ONGOING EVENT BY` : `UPCOMING EVENT BY`}
        </UpcomingEventTitle>
        <EventHost creator={event.creator} title="" addColonAtTheEndOfName />
      </TitleHostContainer>
      <EventNameContainer>
        <EventName name={event.name} numberOfLines={3} />
      </EventNameContainer>
      <UpcomingEventBottomContainer>
        <UpcomingEventDateHostContainer>
          <EventDate date={event.date} time={event.time} />
          <EventAttendees
            attendees={event.attendees}
            title="going"
            showAttendeesFirst
            attendeesCount={event.attendees_count}
          />
        </UpcomingEventDateHostContainer>
        {event?.creator?.uuid !== myUuid && !isOnGoing && (
          <EventAttendButton
            isAttending={attendStatus === "attending"}
            onPress={handleOnAttendPress}
            useMainTextColor
          />
        )}
        {isOnGoing && !!joinCallButton && joinCallButton}
      </UpcomingEventBottomContainer>
    </UpcomingEventContainer>
  )
}

export const UpcomingEvent = React.memo(UpcomingEventComponent)
