import React from "react"
import {
  StatusBar,
  Platform,
  ActivityIndicator,
  View,
  StyleSheet,
} from "react-native"
import { Provider } from "react-redux"
import { NavigationContainer } from "@react-navigation/native"
import { PersistGate } from "redux-persist/integration/react"
import { GestureHandlerRootView } from "react-native-gesture-handler"

import { hasMigratedFromAsyncStorage, migrateFromAsyncStorage } from "./storage"
import { MainView } from "./convose-app/components"
import { configureStore } from "./convose-lib/store"
import { navigationRef } from "./convose-app/RootNavigation"

const styles = StyleSheet.create({
  gestureHandlerRootViewStyle: { flex: 1 },
  migratingContainerStyle: { justifyContent: "center", alignItems: "center" },
})

const App: React.FC = () => {
  const [hasMigrated, setHasMigrated] = React.useState(
    hasMigratedFromAsyncStorage
  )
  React.useEffect(() => {
    Platform.OS === "android" && StatusBar.setTranslucent(true)
  }, [])
  React.useEffect(() => {
    if (!hasMigratedFromAsyncStorage) {
      requestAnimationFrame(async () => {
        try {
          await migrateFromAsyncStorage()
          setHasMigrated(true)
        } catch (e) {
          // console.log(JSON.stringify({ e }, null, 2))
          setHasMigrated(true)
        }
      })
    }
  }, [])
  if (!hasMigrated) {
    // show loading indicator while app is migrating storage...
    return (
      <View style={styles.migratingContainerStyle}>
        <ActivityIndicator color="black" />
      </View>
    )
  }
  const { store, persistor } = configureStore()
  return (
    <GestureHandlerRootView style={styles.gestureHandlerRootViewStyle}>
      <Provider store={store}>
        <PersistGate loading={null} persistor={persistor}>
          <NavigationContainer ref={navigationRef}>
            <MainView />
          </NavigationContainer>
        </PersistGate>
      </Provider>
    </GestureHandlerRootView>
  )
}

export default App
