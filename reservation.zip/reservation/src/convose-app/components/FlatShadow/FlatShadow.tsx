import React, { FC, PropsWithChildren } from "react"
import { ViewStyle } from "react-native"

import { ShadowWrapper } from "./Styled"

type Props = {
  borderRadius?: number
  widthPercentage?: number
  style?: ViewStyle
}
const FlatShadowComponent: FC<PropsWithChildren<Props>> = ({
  children,
  style,
  borderRadius = 0,
  widthPercentage = 0,
}) => {
  return (
    <ShadowWrapper
      borderRadius={borderRadius}
      widthPercentage={widthPercentage}
      style={style}
    >
      {children}
    </ShadowWrapper>
  )
}

export const FlatShadow = React.memo(FlatShadowComponent)
