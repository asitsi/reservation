import React, { useCallback } from "react"
import { SlideInDown, SlideOutDown } from "react-native-reanimated"

import { color } from "convose-styles"
import { Routes } from "convose-lib/router"
import {
  Footer,
  FooterItemWrapper,
  FooterText,
  FooterItem,
  StyledMoonSvg,
  StyledPrivacySvg,
  StyledInfoSvg,
  StyledIcon,
} from "./styled"
import { ExitSvg } from "../../../assets/svg/Exit"
import { TrashSvg } from "../../../assets/svg/Trash"
import * as RootNavigation from "../../RootNavigation"

type ProfileFooterProps = {
  readonly isGuest: boolean
  readonly changeTheme: () => void
  readonly logOut: () => void
  readonly deleteAccount: () => void
  readonly onMyAccountInfoPress: () => void
  readonly closeSettings: (callback?: () => void) => void
}

const ProfileFooterComponent: React.FunctionComponent<ProfileFooterProps> = ({
  isGuest,
  changeTheme,
  logOut,
  deleteAccount,
  onMyAccountInfoPress,
  closeSettings,
}) => {
  const onImprintPress = useCallback(() => {
    closeSettings(() =>
      RootNavigation.navigate(Routes.WebView, {
        url: "https://www.convose.com/imprint",
        title: "Imprint",
      })
    )
  }, [closeSettings])
  const onPrivacyPolicyPress = useCallback(() => {
    closeSettings(() =>
      RootNavigation.navigate(Routes.WebView, {
        url: "https://www.convose.com/privacy",
        title: "Privacy",
      })
    )
  }, [closeSettings])
  const onAboutPress = useCallback(() => {
    RootNavigation.goBack()
    RootNavigation.navigate(Routes.WebView, {
      url: "https://www.convose.com/about",
      title: "About",
    })
  }, [])
  return (
    <Footer entering={SlideInDown} exiting={SlideOutDown}>
      {!isGuest && (
        <FooterItemWrapper onPress={onMyAccountInfoPress}>
          <FooterItem>
            <StyledInfoSvg height={24} />
            <FooterText>My account info</FooterText>
          </FooterItem>
          <StyledIcon name="chevron-forward-outline" size={24} />
        </FooterItemWrapper>
      )}
      <FooterItemWrapper onPress={changeTheme}>
        <FooterItem>
          <StyledMoonSvg height={24} />
          <FooterText>Dark Mode</FooterText>
        </FooterItem>
        <StyledIcon name="chevron-forward-outline" size={24} />
      </FooterItemWrapper>
      <FooterItemWrapper onPress={onAboutPress}>
        <FooterItem>
          <StyledInfoSvg height={24} />
          <FooterText>About</FooterText>
        </FooterItem>
      </FooterItemWrapper>
      <FooterItemWrapper onPress={onImprintPress}>
        <FooterItem>
          <StyledInfoSvg height={24} />
          <FooterText>Imprint</FooterText>
        </FooterItem>
      </FooterItemWrapper>
      <FooterItemWrapper onPress={onPrivacyPolicyPress}>
        <FooterItem>
          <StyledPrivacySvg height={24} />
          <FooterText>Privacy Policy</FooterText>
        </FooterItem>
      </FooterItemWrapper>
      {!isGuest && (
        <FooterItemWrapper onPress={logOut}>
          <FooterItem>
            <ExitSvg height={24} color={color.red} />
            <FooterText color={color.red}>Logout</FooterText>
          </FooterItem>
        </FooterItemWrapper>
      )}
      {!isGuest && (
        <FooterItemWrapper onPress={deleteAccount}>
          <FooterItem>
            <TrashSvg height={24} color={color.red} />
            <FooterText color={color.red}>Delete my account</FooterText>
          </FooterItem>
        </FooterItemWrapper>
      )}
    </Footer>
  )
}
// ProfileFooterComponent.whyDidYouRender = {
//   logOnDifferentValues: false,
//   customName: "ProfileFooterComponent",
//   diffNameColor: "red",
// }
export const ProfileFooter = React.memo(ProfileFooterComponent)
