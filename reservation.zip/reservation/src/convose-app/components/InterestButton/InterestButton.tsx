/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable eqeqeq */
import * as React from "react"
import { ViewStyle } from "react-native"
import { trigger } from "react-native-haptic-feedback"

import {
  getInterestNameWithDetails,
  InterestLocation,
  UserInterest,
} from "convose-lib/interests"
import { DEFAULT_HIT_SLOP, LONG_PRESS_DURATION } from "convose-lib/utils"
import { DEFAULT_INTEREST_SIZE, ThemeType } from "convose-styles"
import { withTheme } from "styled-components"

import {
  ButtonWrapperView,
  IconButton,
  Label,
  LoadingSpinner,
  LevelRatingContainer,
  LevelRating,
  LabelLevelContainer,
  DeleteButtonContainer,
  IconWrapper,
  EmptyContainer,
  SecondaryBlueCloseIcon,
} from "./Styled"
import { InterestIcon } from "../InterestIcon"

type InterestButtonProps = {
  readonly interest: UserInterest
  readonly onDelete?: (interest: UserInterest) => void
  readonly onPress?: (interest: UserInterest) => void
  readonly onLongPress?: (interest: UserInterest) => void
  readonly disabled?: boolean
  readonly interestLocation: InterestLocation
  readonly size?: number
  readonly deleteSuccess?: (interest: UserInterest) => void
  readonly theme: ThemeType
  readonly addBorder?: boolean
  readonly transparentBackground?: boolean
  readonly wrapperStyle?: ViewStyle
  readonly iconSize?: number
  readonly iconWrapperStyle?: ViewStyle
  readonly useSemiBoldFont?: boolean
  readonly backgroundColorCode?: string
}

type LocalState = {
  deleting: boolean
}

class InterestButtonComponent extends React.Component<
  InterestButtonProps,
  LocalState
> {
  constructor(props: InterestButtonProps) {
    super(props)
    this.state = {
      deleting: false,
    }
  }

  shouldComponentUpdate(
    nextProps: Readonly<InterestButtonProps>,
    nextState: Readonly<LocalState>
  ): boolean {
    const { interest, onPress, disabled, onDelete } = this.props
    const { deleting } = this.state
    return (
      interest.name !== nextProps.interest.name ||
      interest.level !== nextProps.interest.level ||
      deleting !== nextState.deleting ||
      onPress !== nextProps.onPress ||
      onDelete !== nextProps.onDelete ||
      disabled !== nextProps.disabled
    )
  }

  componentWillUnmount() {
    const { deleteSuccess, interest } = this.props
    const { deleting } = this.state
    if (deleting && deleteSuccess != undefined) {
      deleteSuccess(interest)
    }
  }

  private getIconSize = (): number => {
    const { size } = this.props
    return size ? size * 2.5 : DEFAULT_INTEREST_SIZE * 2.5
  }

  private checkHasRating = (): boolean => {
    const { interest } = this.props
    return !(interest.level === null || interest.level === 0)
  }

  private readonly renderRating = () => {
    const { interest, interestLocation } = this.props
    const notHasRating = !this.checkHasRating()
    if (notHasRating) {
      return null
    }
    return (
      <LevelRatingContainer>
        {Array(interest.level)
          .fill(1)
          .map((_, index) => (
            // eslint-disable-next-line react/no-array-index-key
            <LevelRating key={index} location={interestLocation} />
          ))}
      </LevelRatingContainer>
    )
  }

  private readonly renderDeleteIcon = () => {
    const { disabled, size, iconSize, addBorder } = this.props
    if (disabled && addBorder) {
      return (
        <DeleteButtonContainer>
          <EmptyContainer size={size} />
        </DeleteButtonContainer>
      )
    }
    return (
      !disabled && (
        <DeleteButtonContainer>
          <IconButton
            onPress={this.handleOnDelete}
            onLongPress={this.handleLongPress}
            delayLongPress={LONG_PRESS_DURATION}
            hitSlop={DEFAULT_HIT_SLOP}
            size={size}
          >
            <SecondaryBlueCloseIcon height={iconSize || this.getIconSize()} />
          </IconButton>
        </DeleteButtonContainer>
      )
    )
  }

  private readonly handleOnDelete = () => {
    const { interest, onDelete } = this.props
    this.setState({ deleting: true })
    if (onDelete) {
      onDelete(interest)
    }
  }

  private readonly handleOnPress = () => {
    requestAnimationFrame(() => {
      const { onPress, interest } = this.props
      onPress && onPress(interest)
    })
  }

  private readonly handleLongPress = () => {
    requestAnimationFrame(() => {
      const { onLongPress, interest } = this.props
      if (onLongPress) {
        onLongPress(interest)
        trigger("impactLight", {
          enableVibrateFallback: true,
        })
      }
    })
  }

  public render(): React.ReactNode {
    const {
      disabled,
      interest,
      interestLocation,
      size,
      theme,
      addBorder,
      transparentBackground,
      wrapperStyle,
      iconSize,
      useSemiBoldFont,
      backgroundColorCode,
      // eslint-disable-next-line react-perf/jsx-no-new-object-as-prop
      iconWrapperStyle = { marginLeft: 2 },
    } = this.props
    const { deleting } = this.state
    const interestName = getInterestNameWithDetails(interest.name).name

    const hasRating = this.checkHasRating()
    return (
      <ButtonWrapperView
        onPress={this.handleOnPress}
        onLongPress={this.handleLongPress}
        delayLongPress={LONG_PRESS_DURATION}
        hitSlop={DEFAULT_HIT_SLOP}
        size={size}
        disabled={disabled}
        addBorder={addBorder}
        transparentBackground={transparentBackground}
        backgroundColorCode={backgroundColorCode}
        style={wrapperStyle}
      >
        <IconWrapper style={iconWrapperStyle}>
          <InterestIcon
            imageUrl={interest?.avatar}
            name={interest.name}
            color={interest.color}
            size={iconSize}
          />
        </IconWrapper>
        <LabelLevelContainer
          location={interestLocation}
          useSemiBoldFont={useSemiBoldFont}
        >
          <Label
            location={interestLocation}
            ellipsizeMode="tail"
            hitSlop={DEFAULT_HIT_SLOP}
            numberOfLines={1}
            size={size}
            hasRating={hasRating}
            useSemiBoldFont={useSemiBoldFont}
          >
            {interestName.replace(/\s+$/, "")}
          </Label>
          {this.renderRating()}
        </LabelLevelContainer>
        {deleting ? (
          <LoadingSpinner color={theme.mainBlue} size={22} />
        ) : (
          this.renderDeleteIcon()
        )}
      </ButtonWrapperView>
    )
  }
}

type Props = Omit<InterestButtonProps, "theme">
export const InterestButton: React.FunctionComponent<Props> = React.memo(
  withTheme(InterestButtonComponent)
)
