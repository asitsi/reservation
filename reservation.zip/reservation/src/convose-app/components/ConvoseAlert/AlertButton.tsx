import React from "react"

import { Button, ButtonLabel } from "./Styled"

export type ButtonType = {
  title: string
  onPress?: () => void
  type?: "default" | "cancel" | "warning" | undefined
  // eslint-disable-next-line react/no-unused-prop-types
  keepAlertOpenAfterPress?: boolean
}
type Props = ButtonType & { isLast?: boolean }
export const AlertButton: React.FunctionComponent<Props> = ({
  title,
  onPress,
  type,
  isLast,
}) => {
  return (
    <Button
      onPress={onPress}
      isCancel={type === "cancel"}
      isWarning={type === "warning"}
      isLast={isLast}
    >
      <ButtonLabel isCancel={type === "cancel"}>{title}</ButtonLabel>
    </Button>
  )
}
