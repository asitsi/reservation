import styled from "styled-components/native"
import { Props } from "convose-styles"
import { IndicatorLocations } from "./types"

type IndicatorProps = {
  location: IndicatorLocations
  isRing: boolean
  bgColor: string
}
type PartialProps = Partial<Props> & Partial<IndicatorProps>
export const getLocationSize = (
  location?: IndicatorLocations,
  isRing?: boolean,
  isOfflineRing?: boolean
) => {
  if (location === "chat") {
    if (isRing) {
      return 15
    }
    if (isOfflineRing) {
      return 4
    }
    return 10
  }
  if (location === "chatMenu") {
    if (isRing) {
      return 34
    }
    if (isOfflineRing) {
      return 8
    }
    return 20
  }
  if (isRing) {
    return 22
  }
  if (isOfflineRing) {
    return 6
  }
  return 14
}
const calculateMeasurements = (props: PartialProps) => {
  const { location, isRing } = props
  const initialSize = getLocationSize(location, isRing)
  const getSize = () => {
    if (!isRing) {
      return initialSize
    }
    return getLocationSize(location, isRing)
  }
  const size = getSize()
  return `height: ${size}px;
  width: ${size}px;
  border-radius: ${size / 2}px;
  `
}
const getBorderColor = (
  props: Props & { bgColor: string; location: string }
): string => {
  if (props.bgColor) {
    if (props.bgColor === "chatBoxBackground") {
      return props.theme.main.chatBoxBackground
    }
    return props.bgColor
  }
  switch (props.location) {
    case "chatBox":
      return props.theme.main.background
    case "inbox":
      return props.theme.statusBar
    default:
      return props.theme.main.background
  }
}
const positionCalculator = (props: IndicatorProps) => {
  if (props.location === "inbox") {
    return -3
  }
  if (props.location === "chatBoxNear") {
    return 3
  }
  if (props.location === "chatMenu") {
    return 13
  }
  return 0
}
export const IndicatorContainer = styled.View`
  position: absolute;
  bottom: ${positionCalculator}px;
  right: ${positionCalculator}px;
  justify-content: center;
  align-items: center;
`
export const IndicatorBackground = styled.View`
  ${calculateMeasurements}
`
export const IndicatorRing = styled.View`
  background-color: ${getBorderColor};
  ${calculateMeasurements}
  justify-content: center;
  align-items: center;
`
export const RingContainer = styled.View`
  position: absolute;
  bottom: ${positionCalculator}px;
  right: ${positionCalculator}px;
  justify-content: center;
  align-items: center;
  justify-items: center;
  flex-direction: row;
  height: ${(props: { size: number }) => props.size}px;
  border-radius: ${(props: { size: number }) => props.size}px;
  aspect-ratio: 1;
  background-color: ${(props: Props & { color?: string }) =>
    props.color || props.theme.main.background};
`
