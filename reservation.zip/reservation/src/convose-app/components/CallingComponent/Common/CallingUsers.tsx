/* eslint-disable react-perf/jsx-no-new-object-as-prop, complexity */
import React, { useMemo } from "react"
import { Platform, ViewStyle } from "react-native"
import FastImage from "react-native-fast-image"
import { uniqBy, isEqual } from "lodash"
import { connect } from "react-redux"

import { CallSignal, JoinCall, Peer, selectJoinCall } from "convose-lib/calling"
import { ChatUser } from "convose-lib/chat"
import { sendHandRaiseRequest } from "convose-lib/users-list/dao"
import { addExtraNumberForMobileToAgoraUuid } from "convose-lib/calling/utils"
import { ScrollView } from "react-native-gesture-handler"
import {
  checkIsSpeakerOn,
  iSharedScreenPeer,
  adjustRecordingSignalVolume,
  State,
} from "convose-lib"
import { Routes } from "convose-lib/router"
import { HandRaiseTypes } from "convose-lib/users-list/dto"
import { Uuid } from "convose-lib/user"
import {
  UsersListAction,
  selectRequestedAndAcceptedRaisedHands,
} from "convose-lib/users-list"

import { convoseAlertRef } from "../../../RootConvoseAlert"
import { OutgoingCallAnimation } from "./OutgoingCallAnimation"
import {
  HandRaiseButton,
  HandRaiseSpeakingButton,
  MuteButton,
  VideoButton,
} from "./Buttons"
import {
  CallingEffectContainer,
  IsCallingContainer,
  IsCallingText,
  ProfileUsernameContainer,
  ProfileUsernameTouchable,
  SharedScreenIconContainer,
  styles,
  Username,
  UsernameContainer,
  UsersScrollContainer,
} from "./Styled"
import { VideoCallView } from "./VideoCallComponent"
import { ProfileWrapper } from "./ProfileWrapper"
import { SharedScreenSvg } from "../../../../assets/svg/call"
import * as RootNavigation from "../../../RootNavigation"
import { CallingUsersContainer } from "./DimensionDependComponents/CallingUsersContainer"
import { CallingUsersProps } from "../dto"
import { GetGroupCallParticipants } from "../GetGroupCallParticipants"
import { Profile } from "./ProfileWithLoading"
import { Skeleton } from "../../Skeleton"

// import { allUsers } from "../testUsers"

const loadingUsernameStyle: ViewStyle = {
  width: 55,
  height: 10,
  borderRadius: 10,
  marginTop: 5,
}

// eslint-disable-next-line @typescript-eslint/no-var-requires
const defaultAvatarImage = require("../../../../assets/Icons/avatar.png")

const isIos = Platform.OS === "ios"

const REMOTE_USER_BUTTON_SIZE = 27
const REMOTE_USER_BUTTON_BORDER_SIZE = 2

type MuteRemoteUserProps = {
  isMuted: boolean
  username: string
  agoraUuid: number
  isGroup: boolean
  muteRemoteUser: (muteCommand: string, name: string) => void
  preventMute: boolean
}
const MuteRemoteUser: React.FC<MuteRemoteUserProps> = ({
  agoraUuid,
  isGroup,
  isMuted,
  muteRemoteUser,
  username,
  preventMute,
}) => {
  const [isLoading, setLoading] = React.useState(false)
  React.useEffect(() => {
    if (isMuted && isLoading) {
      setLoading(false)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isMuted])
  const isDisabled = useMemo(
    () => isMuted || !isGroup || preventMute,
    [isGroup, isMuted, preventMute]
  )
  const muteUser = (): void => {
    if (isDisabled) {
      return
    }
    convoseAlertRef?.show({
      title: `Mute ${username}`,
      description: `Are you sure you want to mute ${username} for everyone? They can report you for misusing this option.`,
      canDismiss: true,
      buttons: [
        {
          title: "Yes, mute",
          onPress: () => {
            setLoading(true)
            muteRemoteUser(`${CallSignal.muted}  ${agoraUuid}`, username || " ")
          },
        },
        {
          title: "No, don't mute",
          type: "cancel",
        },
      ],
    })
  }
  return (
    <MuteButton
      isAudioEnabled={!isMuted}
      onPress={muteUser}
      size={REMOTE_USER_BUTTON_SIZE}
      iconSize={15}
      defaultBackgroundOnMute
      viewStyle={styles.muteButtonStyle}
      noBorderOnMuted
      isLoading={isLoading}
      borderOnUnmute
      borderSize={REMOTE_USER_BUTTON_BORDER_SIZE}
      hasHitSlop={!isDisabled}
      disabled={isDisabled}
    />
  )
}

type ChatUserInCall = ChatUser &
  Peer & {
    raiseHandStatus?: HandRaiseTypes
  }
const LOADING_UUID = "loading_uuid"
const emptyChatUser: ChatUser = {
  avatar: {
    url: defaultAvatarImage,
    default_avatar: defaultAvatarImage,
    display: defaultAvatarImage,
    small: defaultAvatarImage,
    thumb: defaultAvatarImage,
  },
  background_theme_color: "black",
  dark_background_color: "black",
  email: "sample@sample.com",
  id: NaN,
  interests: [],
  is_guest: true,
  last_seen: new Date(),
  permissions: {
    blocked: false,
  },
  theme_color: "black",
  username: "Loading",
  uuid: LOADING_UUID,
}

const isChatUserInCall = (
  item: ChatUserInCall | undefined
): item is ChatUserInCall => {
  return !!item
}
const isChatUserWithoutProfile = (
  item: ChatUserInCall
): item is ChatUserInCall => {
  return item.uuid === LOADING_UUID
}
const getPeerDefaultValues = (uuid: number): Peer => ({
  agoraUuid: Number(uuid),
  rawAgoraUuid: Number(uuid),
  isMuted: true,
  isVideoEnabled: false,
  isActive: false,
  isAudience: true,
  muteStateChangeTime: 0,
  isSpeaking: false,
})
const findUser = (id: number) => (user: ChatUser) => user.id === id
function getUser(
  id: number,
  participants: ChatUser[],
  audience?: ChatUser[]
): ChatUser | null {
  const userInParticipants = participants.find(findUser(id))
  if (userInParticipants) {
    return userInParticipants
  }
  if (!audience) {
    return null
  }
  return audience.find(findUser(id)) || null
}
type OnProfilePressType = {
  myUuid: string
  user: ChatUserInCall
  isGroup: boolean
  isGroupAdmin: boolean
  chatChannel: string
  isSharedScreen: boolean
  setVideoCallFullScreenUid?: (videoCallFullScreenUid: number | null) => void
}
const onProfilePress =
  ({
    chatChannel,
    isGroup,
    isGroupAdmin,
    isSharedScreen,
    myUuid,
    setVideoCallFullScreenUid,
    user,
  }: OnProfilePressType) =>
  (): void => {
    if (myUuid === user.uuid) {
      return
    }
    if (isSharedScreen && !!setVideoCallFullScreenUid) {
      setVideoCallFullScreenUid(user.rawAgoraUuid)
      return
    }
    if (!isGroup) {
      return
    }
    RootNavigation.navigate(Routes.UserProfile, {
      chatUserId: user.uuid,
      myUuid,
      canBlock: isGroupAdmin,
      chatChannel,
    })
  }

const LOUD_MIC_VOLUME = 400
const NORMAL_MIC_VOLUME = 100

const getRaisedHandStatus = (
  requested: Array<Uuid>,
  accepted: Array<Uuid>,
  uuid: Uuid
): HandRaiseTypes | undefined => {
  if (requested.find((id) => id === uuid)) {
    return "request_handraise"
  }
  if (accepted.find((id) => id === uuid)) {
    return "accepted_handraise"
  }
  return undefined
}

const mapHandRaise =
  (requested: Array<Uuid>, accepted: Array<Uuid>) => (user: ChatUserInCall) => {
    const raiseHandStatus = getRaisedHandStatus(requested, accepted, user.uuid)
    return {
      ...user,
      raiseHandStatus,
    }
  }

type StateToProps = {
  requested: Array<Uuid>
  accepted: Array<Uuid>
  joinCall: JoinCall
}
type DispatchToProps = {
  getMultipleParticipantProfilesWithIds: (
    ids: number[],
    channel: string
  ) => void
}

type CallingEffectProps = {
  isGroup: boolean
  connecting: boolean
}
const CallingEffect: React.FC<CallingEffectProps> = ({
  isGroup,
  connecting,
}) => {
  const getText = () => {
    if (connecting) {
      return "Connecting...."
    }
    if (isGroup) {
      return `Waiting for others to join the call...`
    }
    return `Calling...`
  }
  return (
    <IsCallingContainer>
      <CallingEffectContainer>
        <OutgoingCallAnimation />
      </CallingEffectContainer>
      <IsCallingText numberOfLine={2}>{getText()}</IsCallingText>
    </IsCallingContainer>
  )
}

type Props = CallingUsersProps & StateToProps & DispatchToProps

class CallingUsersComponent extends React.Component<Props> {
  public currentVolume = NORMAL_MIC_VOLUME

  // to prevent multiple profile request without using state
  public requestedIdsForProfile: number[] = []

  componentDidMount(): void {
    this.applyMicFix()
  }

  componentDidUpdate(
    prevProps: Readonly<Props>
    // ,prevState: Readonly<StateType>
  ): void {
    const { audioSetting, participants } = this.props
    if (
      !isEqual(prevProps.participants, participants) &&
      this.requestedIdsForProfile.length
    ) {
      // to prevent multiple profile request without using state
      this.checkResultOfRequestedProfiles()
    }
    // to fix issue: "in a call, if my speaker is on and I am talking, as soon as someone else unmute, my voice is unclear but if the other user mute, my voice is clear again."
    if (
      isIos &&
      (prevProps.audioSetting.isAudioEnabled !== audioSetting.isAudioEnabled ||
        prevProps.audioSetting.speakerMode !== audioSetting.speakerMode)
    ) {
      this.applyMicFix()
    }
  }

  checkResultOfRequestedProfiles = () => {
    const { participants } = this.props
    this.requestedIdsForProfile = this.requestedIdsForProfile.filter(
      (id) => !participants.find((user) => user.id === id)
    )
  }

  // eslint-disable-next-line class-methods-use-this
  applyMicFix = () => {
    // if (!isIos) {
    // adjustRecordingSignalVolume(NORMAL_MIC_VOLUME)
    //   return
    // }
    const { audioSetting } = this.props
    if (
      audioSetting.isAudioEnabled &&
      checkIsSpeakerOn(audioSetting.speakerMode) &&
      this.currentVolume !== LOUD_MIC_VOLUME
    ) {
      adjustRecordingSignalVolume(LOUD_MIC_VOLUME)
      this.currentVolume = LOUD_MIC_VOLUME
    } else if (this.currentVolume !== NORMAL_MIC_VOLUME) {
      adjustRecordingSignalVolume(NORMAL_MIC_VOLUME)
      this.currentVolume = NORMAL_MIC_VOLUME
    }
  }

  getMissingParticipantsInCall = (ids: number[]) => {
    // to prevent multiple profile request without using state
    if (isEqual(ids, this.requestedIdsForProfile) || !ids.length) {
      return
    }
    this.requestedIdsForProfile = ids

    const { getMultipleParticipantProfilesWithIds, channel } = this.props
    getMultipleParticipantProfilesWithIds(ids, channel)
  }

  getPeersArray = (): Peer[] => {
    const { peers } = this.props
    return [...peers.values()]
  }

  getMyPeer = (): Peer => {
    const { me, audioSetting } = this.props
    return {
      agoraUuid: me.id,
      isMuted: !audioSetting.isAudioEnabled,
      isVideoEnabled: audioSetting.isVideoEnabled,
      isActive: true,
      isSpeaking: audioSetting.isSpeaking,
      rawAgoraUuid: addExtraNumberForMobileToAgoraUuid(me.id),
      muteStateChangeTime: audioSetting.muteStateChangeTime,
    }
  }

  getUsersInCall = (): ChatUserInCall[] => {
    const { peers, participants, groupInfo, isGroup, me, requested, accepted } =
      this.props
    const { audience } = groupInfo

    const myPeer: Peer = this.getMyPeer()

    const peersArray = this.getPeersArray()

    const peerUsers: ChatUserInCall[] = peersArray
      .map((peer) => {
        const user = getUser(peer.agoraUuid, participants, [...audience])
        if (!user) {
          return {
            ...peer,
            ...emptyChatUser,
          }
        }

        return { ...user, ...peer } as ChatUserInCall
      })
      .filter(isChatUserInCall)
    const peerUserWithoutInfo = peerUsers.filter(isChatUserWithoutProfile)
    if (peerUserWithoutInfo.length) {
      this.getMissingParticipantsInCall(
        peerUserWithoutInfo.map((peer) => peer.agoraUuid)
      )
    }
    if (!isGroup) {
      return uniqBy([{ ...me, ...myPeer }, ...peerUsers], "rawAgoraUuid").map(
        mapHandRaise(requested, accepted)
      )
    }

    const audienceUsers: ChatUserInCall[] = audience
      .filter((user) => user.uuid !== me.uuid)
      .map((user) => {
        const foundAgoraUser = peers.find((peer) => peer.agoraUuid === user.id)
        if (foundAgoraUser) {
          // user is in peerUsers
          return undefined
        }
        const agoraUser = getPeerDefaultValues(user.id)
        return {
          ...user,
          ...agoraUser,
        }
      })
      .filter(isChatUserInCall)
    // console.log(JSON.stringify(audienceUsers, null, 2))
    return uniqBy(
      [{ ...me, ...myPeer }, ...peerUsers, ...audienceUsers],
      "rawAgoraUuid"
    ).map(mapHandRaise(requested, accepted))
  }

  onHandRaisePress = (userUuid: string) => () => {
    requestAnimationFrame(() => {
      const { me, isGroupAdmin, channel } = this.props
      const { username, uuid } = me
      if (isGroupAdmin) {
        sendHandRaiseRequest({
          chatId: channel,
          content: "accepted_handraise",
          message_type: "permission",
          sender: uuid,
          username,
          to: userUuid,
        })
      }
    })
  }

  onHandRaiseSpeakingPress = (userUuid: string) => () => {
    requestAnimationFrame(() => {
      const { me, isGroupAdmin, channel } = this.props
      const { username, uuid } = me
      if (isGroupAdmin) {
        sendHandRaiseRequest({
          chatId: channel,
          content: "rejected_handraise",
          message_type: "permission",
          sender: uuid,
          username,
          to: userUuid,
        })
      }
    })
  }

  renderUsersInCall = () => {
    const { isHide } = this.props
    if (isHide) {
      return null
    }
    const {
      isLandscape,
      me,
      videoCallFullScreenUid,
      isGroup,
      isGroupAdmin,
      channel,
      setVideoCallFullScreenUid,
      muteRemoteUser,
      isHandRaiseEnabled,
      joinCall,
    } = this.props

    const { connecting } = joinCall
    const usersInCall = this.getUsersInCall()
    const unMutedUsers = usersInCall.filter(
      (user) => !user.isMuted || user.isVideoEnabled
    )
    const mutedUsers = usersInCall
      .filter((user) => user.isMuted && !user.isVideoEnabled)
      .sort(
        (a, b) => (b.muteStateChangeTime || 0) - (a.muteStateChangeTime || 0)
      )
    const uniqKey = isLandscape ? "uuid" : "rawAgoraUuid"
    const allUsers = uniqBy([...unMutedUsers, ...mutedUsers], uniqKey).filter(
      (user) => user.rawAgoraUuid
    )
    return (
      <>
        {allUsers.map((user) => {
          const isMe = user.agoraUuid === me.id
          const isNotFullscreenPeer =
            user.rawAgoraUuid &&
            user.rawAgoraUuid !== videoCallFullScreenUid &&
            !(isMe && videoCallFullScreenUid === 0)
          const showVideoCallView =
            isNotFullscreenPeer && user.isVideoEnabled && user.agoraUuid
          const isSharedScreen = iSharedScreenPeer(user.rawAgoraUuid)
          const { raiseHandStatus } = user
          const enableViewHandRaiseButtons =
            isGroupAdmin || user.uuid === me.uuid
          return (
            <ProfileUsernameContainer
              key={user.rawAgoraUuid}
              isLandscape={isLandscape}
            >
              <ProfileUsernameTouchable
                onPress={onProfilePress({
                  myUuid: me.uuid,
                  user,
                  isGroup,
                  isGroupAdmin,
                  chatChannel: channel,
                  isSharedScreen,
                  setVideoCallFullScreenUid,
                })}
              >
                <ProfileWrapper
                  isVideoCallMode={!!showVideoCallView}
                  isActive={!!(user.isSpeaking && !user.isMuted)}
                  isSharedScreen={isSharedScreen}
                >
                  {showVideoCallView ? (
                    <VideoCallView
                      channel={channel}
                      agoraId={user.rawAgoraUuid}
                      isLocal={isMe}
                      style={styles.profileVideo}
                    />
                  ) : (
                    <Profile
                      source={
                        user?.avatar && user.avatar.url
                          ? {
                              uri: user.avatar.url,
                              priority: FastImage.priority.low,
                            }
                          : undefined
                      }
                      defaultSource={defaultAvatarImage}
                      resizeMode={FastImage.resizeMode.contain}
                      isLoading={user.uuid === LOADING_UUID}
                    />
                  )}
                  {/* {user.isNotConnected && <UserIsNotConnectedToAgora />} */}
                </ProfileWrapper>
                {!isLandscape && (
                  <UsernameContainer>
                    {isSharedScreen && (
                      <SharedScreenIconContainer>
                        <SharedScreenSvg color={user.theme_color} height={16} />
                      </SharedScreenIconContainer>
                    )}
                    {user.uuid === LOADING_UUID ? (
                      <Skeleton style={loadingUsernameStyle} />
                    ) : (
                      <Username
                        color={user.theme_color}
                        adjustsFontSizeToFit
                        numberOfLines={1}
                      >
                        {user.username || " "}
                      </Username>
                    )}
                  </UsernameContainer>
                )}
              </ProfileUsernameTouchable>
              {!isLandscape && !isSharedScreen && (
                <MuteRemoteUser
                  agoraUuid={user.agoraUuid}
                  isGroup={isGroup}
                  isMuted={!!user.isMuted}
                  muteRemoteUser={muteRemoteUser}
                  username={user.username}
                  preventMute={isHandRaiseEnabled && !isGroupAdmin}
                />
              )}

              {raiseHandStatus && raiseHandStatus === "request_handraise" && (
                <HandRaiseButton
                  onPress={this.onHandRaisePress(user.uuid)}
                  isHandRaised={enableViewHandRaiseButtons}
                  isLoading={false}
                  viewStyle={styles.handButtonStyle}
                  size={REMOTE_USER_BUTTON_SIZE}
                  iconSize={15}
                  borderOnHandRaised
                  borderSize={REMOTE_USER_BUTTON_BORDER_SIZE}
                  defaultBackgroundOnOffMode={!enableViewHandRaiseButtons}
                  noBorder
                />
              )}
              {raiseHandStatus && raiseHandStatus === "accepted_handraise" && (
                <HandRaiseSpeakingButton
                  onPress={this.onHandRaiseSpeakingPress(user.uuid)}
                  isSpeaking={enableViewHandRaiseButtons}
                  viewStyle={styles.handButtonStyle}
                  size={REMOTE_USER_BUTTON_SIZE}
                  iconSize={15}
                  borderOnHandRaised={enableViewHandRaiseButtons}
                  borderSize={REMOTE_USER_BUTTON_BORDER_SIZE}
                  defaultBackgroundOnOffMode={!enableViewHandRaiseButtons}
                  noBorder
                />
              )}
              {user.isVideoEnabled && !isLandscape && !isSharedScreen && (
                <VideoButton
                  isVideoEnabled
                  viewStyle={styles.videoButtonStyle}
                  size={REMOTE_USER_BUTTON_SIZE}
                  iconSize={15}
                  borderOnCameraOn
                  borderSize={REMOTE_USER_BUTTON_BORDER_SIZE}
                />
              )}
            </ProfileUsernameContainer>
          )
        })}
        {allUsers.length <= 1 && !isLandscape && !isHide && (
          <CallingEffect isGroup={isGroup} connecting={connecting} />
        )}
      </>
    )
  }

  handleScrollRef = (ref: ScrollView) => {
    const { setUserScrollRef } = this.props
    setUserScrollRef && setUserScrollRef(ref)
  }

  handleOnScrollBeginDrag = () => {
    const { onUserScrollBeginDrag } = this.props
    onUserScrollBeginDrag && onUserScrollBeginDrag()
  }

  handleOnScrollEndDrag = () => {
    const { onUserScrollEndDrag } = this.props
    onUserScrollEndDrag && onUserScrollEndDrag()
  }

  render(): React.ReactNode {
    const { isLandscape, channel, participants } = this.props
    return (
      <CallingUsersContainer
        horizontal={!isLandscape}
        showsHorizontalScrollIndicator={false}
        ref={this.handleScrollRef}
        onScrollBeginDrag={this.handleOnScrollBeginDrag}
        onScrollEndDrag={this.handleOnScrollEndDrag}
        isLandscape={isLandscape}
      >
        {/* TODO temp fix for participants in call */}
        <GetGroupCallParticipants
          channel={channel}
          participants={participants}
          peers={this.getPeersArray()}
        />
        <UsersScrollContainer
          isLandscape={isLandscape}
          onStartShouldSetResponder={() => true}
        >
          {this.renderUsersInCall()}
        </UsersScrollContainer>
      </CallingUsersContainer>
    )
  }
}

const mapStateToProps = (
  state: State,
  ownProps: CallingUsersProps
): StateToProps => {
  return {
    ...selectRequestedAndAcceptedRaisedHands(ownProps.channel)(state),
    joinCall: selectJoinCall(state),
  }
}
const mapDispatchToProps: DispatchToProps = {
  getMultipleParticipantProfilesWithIds:
    UsersListAction.getMultipleParticipantProfilesWithIds,
}
export const CallingUsers = React.memo(
  connect(mapStateToProps, mapDispatchToProps)(CallingUsersComponent)
)
