import React from "react"
import { Pressable, ViewStyle } from "react-native"
import { useTheme } from "styled-components"
import Ionicons from "react-native-vector-icons/Ionicons"
import Entypo from "react-native-vector-icons/Entypo"

import { DEFAULT_HIT_SLOP } from "convose-lib/utils"
import { PressableButtonContent, StyledButton } from "./Styled"

type PropsType = {
  readonly onPress?: () => void
  readonly size: number
  readonly style?: ViewStyle
}
type SvgButtonProps = PropsType & {
  readonly iconComponent: JSX.Element
}
type IconButtonProps = PropsType & {
  readonly name: string
  readonly iconColor?: string
  readonly iconType?: "Ionicons" | "Entypo"
}

export const SvgButton: React.FC<SvgButtonProps> = ({
  iconComponent,
  onPress,
  style,
  size,
}) => {
  const theme = useTheme()
  return (
    <StyledButton
      onPress={onPress}
      disabled={!onPress}
      hitSlop={DEFAULT_HIT_SLOP}
      style={style}
      size={size}
      underlayColor={theme.buttonOnPress}
    >
      {iconComponent}
    </StyledButton>
  )
}
export const IconButton: React.FC<IconButtonProps> = ({
  name,
  onPress,
  size,
  iconColor,
  iconType = "Ionicons",
  style,
}) => {
  const theme = useTheme()
  const Icon = iconType === "Ionicons" ? Ionicons : Entypo
  const defaultIconColor = iconColor || theme.mainBlue
  return (
    <StyledButton
      onPress={onPress}
      disabled={!onPress}
      hitSlop={DEFAULT_HIT_SLOP}
      style={style}
      size={size}
      underlayColor={theme.buttonOnPress}
    >
      <Icon name={name} size={size} color={defaultIconColor} />
    </StyledButton>
  )
}
type PressableIconButtonProps = IconButtonProps & {
  containerStyle?: ViewStyle
  withHitSlop?: boolean
}
export const PressableIconButton: React.FC<PressableIconButtonProps> = ({
  name,
  onPress,
  size,
  iconColor,
  iconType = "Ionicons",
  containerStyle,
  withHitSlop,
}) => {
  const theme = useTheme()
  const Icon = iconType === "Ionicons" ? Ionicons : Entypo
  const defaultIconColor = iconColor || theme.mainBlue
  const handelOnPress = () => {
    requestAnimationFrame(() => {
      onPress && onPress()
    })
  }
  return (
    <Pressable
      onPress={handelOnPress}
      disabled={!onPress}
      hitSlop={withHitSlop ? DEFAULT_HIT_SLOP : undefined}
      // eslint-disable-next-line react-perf/jsx-no-new-object-as-prop, react-perf/jsx-no-new-array-as-prop
      style={[
        {
          justifyContent: "center",
          alignItems: "center",
          paddingHorizontal: 5,
        },
        containerStyle,
      ]}
    >
      {({ pressed }) => {
        return (
          <PressableButtonContent
            pressedBg={pressed ? theme.buttonOnPress : "transparent"}
          >
            <Icon name={name} size={size} color={defaultIconColor} />
          </PressableButtonContent>
        )
      }}
    </Pressable>
  )
}
