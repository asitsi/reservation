import { TouchableOpacity, View, Text } from "react-native"
import styled from "styled-components"
import Animated from "react-native-reanimated"

import { appHeaderHeight, font, Props } from "convose-styles"
import { BlueMaterialIndicator } from "../MaterialIndicator"

const CONTAINER_PADDING = "15px"

export const MaxCharAlertText = styled(Text)`
  color: ${(props: Props) => props.theme.profile.alert};
  font-family: ${font.semiBold};
  font-size: 10px;
  line-height: 16px;
  margin-left: 10px;
`
export const NameInputAndAlertContainer = styled(View)`
  align-items: flex-start;
  width: 100%;
`
export const Header = styled(Animated.View)`
  height: ${appHeaderHeight}px;
  width: 100%;
  background: ${(props: Props) => props.theme.main.background};
  flex-direction: row;
  justify-content: flex-start;
  align-items: center;
  padding-horizontal: ${CONTAINER_PADDING};
`

export const AvatarWrapper = styled(TouchableOpacity)`
  z-index: 10;
  margin-right: 15px;
  width: 75px;
`
export const LoadingSpinner = styled(BlueMaterialIndicator)`
  margin-right: 15px;
  margin-left: 15px;
`
