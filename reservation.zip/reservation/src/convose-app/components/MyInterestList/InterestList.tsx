import React, { useEffect, useImperativeHandle } from "react"
import { LayoutChangeEvent, LayoutRectangle, ViewStyle } from "react-native"
import Animated, {
  FadeOut,
  LinearTransition,
  ZoomIn,
  ZoomOut,
  interpolate,
  useAnimatedStyle,
  useSharedValue,
  withDelay,
  withTiming,
} from "react-native-reanimated"

import { InterestLocation, UserInterest } from "convose-lib"
import { MY_INTEREST_SIZE, downShadow } from "convose-styles"

import { InterestButton } from "../InterestButton"
import { InterestsListContainer } from "./styled"
import { InterestSortingOnboarding } from "./InterestSortingOnboarding"

const layout = LinearTransition.damping(18).duration(50).springify()

const iconWrapperStyle: ViewStyle = {
  marginLeft: 3,
}
const interestWrapperStyle: ViewStyle = {
  marginBottom: 7,
  marginTop: 0,
  marginLeft: 0,
}

const INTEREST_ICON_SIZE = 27

type AnimatedInterestButtonType = {
  interest: UserInterest
  onDelete: (interest: UserInterest) => void
  openRatingWheel: (interest: UserInterest) => void
  deleteSuccess: () => void
  longPressInterest: (position: LayoutRectangle) => void
  isSorting: boolean
}
const AnimatedInterestButton: React.FC<AnimatedInterestButtonType> = ({
  interest,
  deleteSuccess,
  longPressInterest,
  onDelete,
  openRatingWheel,
  isSorting,
}) => {
  const position = React.useRef<LayoutRectangle>({
    height: 0,
    width: 0,
    x: 0,
    y: 0,
  })
  const opacity = useSharedValue(1)
  const style = useAnimatedStyle(() => ({
    opacity: opacity.value,
  }))
  useEffect(() => {
    if (isSorting) {
      opacity.value = 0
    } else {
      opacity.value = withDelay(50, withTiming(1, { duration: 50 }))
    }
  }, [isSorting, opacity])
  const onLongPress = () => {
    longPressInterest(position.current)
  }
  return (
    <Animated.View
      style={style}
      onLayout={(layoutEvent: LayoutChangeEvent) => {
        position.current = layoutEvent.nativeEvent.layout
      }}
      entering={ZoomIn}
      exiting={ZoomOut}
      layout={layout}
    >
      <InterestButton
        size={MY_INTEREST_SIZE}
        interestLocation={InterestLocation.MyInterests}
        interest={interest}
        addBorder
        backgroundColorCode="main.background"
        iconSize={INTEREST_ICON_SIZE}
        iconWrapperStyle={iconWrapperStyle}
        wrapperStyle={interestWrapperStyle}
        onDelete={onDelete}
        onPress={openRatingWheel}
        deleteSuccess={deleteSuccess}
        onLongPress={onLongPress}
      />
    </Animated.View>
  )
}

type Props = {
  interests: UserInterest[]
  onDelete: (interest: UserInterest) => void
  openRatingWheel: (interest: UserInterest) => void
  deleteSuccess: () => void
  longPressInterest: (interest: UserInterest) => void
  onboarded: boolean
  sortInterestOnBoarded: () => void
}
export type InterestListRef = {
  sortingFinished: () => void
}
const animationDuration = 700
const InterestListComponent = React.forwardRef<InterestListRef, Props>(
  (
    {
      interests,
      deleteSuccess,
      onDelete,
      openRatingWheel,
      longPressInterest,
      onboarded,
      sortInterestOnBoarded,
    },
    ref
  ) => {
    const moving = useSharedValue<LayoutRectangle>({
      height: 0,
      width: 0,
      x: 0,
      y: 0,
    })
    const isMoving = useSharedValue(0)

    const [selectedInterest, setSelectedInterest] =
      React.useState<UserInterest | null>(null)

    const showSortingOnboarding = React.useMemo(() => {
      return !onboarded && interests.length >= 6
    }, [onboarded, interests.length])

    const style = useAnimatedStyle(() => ({
      position: "absolute",
      left: moving.value.x,
      top: moving.value.y,
      zIndex: 1,
      ...downShadow,
      shadowOpacity: interpolate(isMoving.value, [0, 1], [0, 0.2]),
      transform: [
        {
          rotate: `${interpolate(isMoving.value, [0, 1], [0, -5])}deg`,
        },
      ],
    }))

    const handleLongPressInterest =
      (interest: UserInterest, index: number) =>
      (position: LayoutRectangle) => {
        if (index === 0) {
          return
        }
        if (showSortingOnboarding) {
          sortInterestOnBoarded()
        }
        moving.value = position
        setTimeout(() => {
          setSelectedInterest(interest)
          longPressInterest(interest)
          isMoving.value = withTiming(1, { duration: 100 })
          moving.value = withTiming(
            {
              ...moving.value,
              x: 0,
              y: 0,
            },
            { duration: animationDuration },
            () => {
              isMoving.value = withTiming(0, { duration: 100 })
            }
          )
        }, 100)
      }

    const sortingFinished = () => {
      setSelectedInterest(null)
    }

    useImperativeHandle(ref, () => ({
      sortingFinished,
    }))

    return (
      <InterestsListContainer layout={layout}>
        {interests.map((interest, index) => {
          return (
            <AnimatedInterestButton
              key={interest.id}
              isSorting={interest.id === selectedInterest?.id}
              interest={interest}
              onDelete={onDelete}
              openRatingWheel={openRatingWheel}
              deleteSuccess={deleteSuccess}
              longPressInterest={handleLongPressInterest(interest, index)}
            />
          )
        })}
        {showSortingOnboarding && (
          <InterestSortingOnboarding dismiss={sortInterestOnBoarded} />
        )}
        {selectedInterest && (
          <Animated.View style={style} exiting={FadeOut.duration(250)}>
            <InterestButton
              interest={selectedInterest}
              size={MY_INTEREST_SIZE}
              interestLocation={InterestLocation.MyInterests}
              addBorder
              backgroundColorCode="main.background"
              iconSize={INTEREST_ICON_SIZE}
              iconWrapperStyle={iconWrapperStyle}
              wrapperStyle={interestWrapperStyle}
            />
          </Animated.View>
        )}
      </InterestsListContainer>
    )
  }
)
export const InterestList = React.memo(InterestListComponent)
