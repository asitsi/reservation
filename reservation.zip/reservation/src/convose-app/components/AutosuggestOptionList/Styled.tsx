import { Image, ScrollView, StyleSheet, View } from "react-native"
import styled from "styled-components"

import { CenteredText, color, font, Props } from "convose-styles"
import Svg from "react-native-svg"

export const styles = StyleSheet.create({
  scrollContainer: {
    flexDirection: "column",
    justifyContent: "flex-start",
    alignItems: "center",
  },
})
export const AutosuggestOptionListFooterContainer = styled(View)`
  margin-top: 15px;
  margin-bottom: 5px;
`

export const FlatListWrapper = styled(View)`
  background: ${(props: Props) =>
    props.theme.interests.autocompleteList.background};
  flex: 1;
  z-index: 200;
  elevation: 20000;
`

export const EmptyListScrollView = styled(ScrollView)`
  background-color: ${(props: Props) =>
    props.theme.interests.autocompleteList.newInterestBackground};
  flex: 1;
  position: absolute;
  width: 100%;
`
export const EmptyListContainer = styled(View)`
  background-color: ${(props: Props) =>
    props.theme.interests.autocompleteList.newInterestBackground};
  flex: 1;
`

export const StyledImage = styled(Image)`
  width: 200px;
  height: 150px;
`
export const NewInterestContainer = styled.View`
  margin-bottom: 15px;
`
export const NewInterestForeground = styled.View`
  position: absolute;
  right: 0px;
  bottom: -8px;
`

export const Title = styled(CenteredText)`
  font-size: 20px;
  color: ${(props: Props) => props.theme.main.text};
  text-align: left;
  font-family: ${font.semiBold};
  margin-bottom: 8px;
`

export const InfoText = styled(Title)`
  font-size: 15px;
  font-family: ${font.light};
  padding: 0 15%;
  padding-bottom: 5px;
`

export const FlatListSeparator = styled(View)`
  background: ${color.interests.autocompleteList.background};
  height: 5px;
  width: 100%;
`
export const StyledSvg = styled(Svg)`
  align-self: flex-end;
  transform: rotate(20deg) scale(1.3) scaleX(-1);
  margin-right: 25px;
  margin-top: -15px;
  margin-bottom: 10px;
`
export const InitialLoadingContainer = styled.View`
  position: absolute;
  left: 0px;
  right: 0px;
  height: 100%;
  justify-content: center;
  align-items: center;
`
