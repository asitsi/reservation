import React from "react"
import Animated, {
  LinearTransition,
  ZoomIn,
  useAnimatedStyle,
} from "react-native-reanimated"

import { MessageActionType } from "convose-lib/chat"
import {
  OptionIcon,
  OptionTitle,
  OptionsContainer,
  StyledTouchableOpacity,
} from "./Styled"

const layout = LinearTransition.damping(20).duration(150).springify().delay(150)

type OptionType = MessageActionType & { isLast?: boolean; index: number }
const Option: React.FC<OptionType> = ({
  ioniconName,
  onPress,
  title,
  disable,
  isLast,
  index,
  warn,
}) => {
  const style = useAnimatedStyle(() => ({
    width: "100%",
  }))

  return (
    <Animated.View
      layout={layout}
      style={style}
      entering={ZoomIn.delay(index * 20)
        .springify(100)
        .damping(12)}
    >
      <StyledTouchableOpacity
        onPress={onPress}
        disabled={disable}
        isLast={isLast}
      >
        <OptionTitle disable={disable} warn={warn}>
          {title}
        </OptionTitle>
        <OptionIcon
          name={ioniconName}
          size={23}
          disable={disable}
          warn={warn}
        />
      </StyledTouchableOpacity>
    </Animated.View>
  )
}

type Props = {
  actions: MessageActionType[]
}
const OptionsComponent: React.FC<Props> = ({ actions }) => {
  const style = useAnimatedStyle(() => ({}))
  return (
    <OptionsContainer style={style} layout={layout}>
      {actions.map((action, index) => (
        <Option
          // eslint-disable-next-line react/jsx-props-no-spreading
          {...action}
          index={index}
          key={action.title}
          isLast={index + 1 === actions.length}
        />
      ))}
    </OptionsContainer>
  )
}

export const Options = React.memo(OptionsComponent)
