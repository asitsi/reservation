import React from "react"
import { Svg, Path } from "react-native-svg"
import { SvgProps } from "./types"
import { getRatio, getWidth } from "./utils"

const defaultHeight = 36
const defaultWidth = 16
const ratio = getRatio(defaultHeight, defaultWidth)

export const SwipeUpSkipCallSvg: React.FunctionComponent<SvgProps> = ({
  height,
  color,
}) => {
  const svgHeight = height || defaultHeight
  const svgWidth = height ? getWidth(ratio, height) : defaultWidth
  return (
    <Svg width={svgWidth} height={svgHeight} viewBox="0 0 16 36" fill="none">
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M12.1412 10.279C13.0216 11.2403 14.5357 11.2403 15.4161 10.279C16.1946 9.42889 16.1946 8.12414 15.4161 7.27405L9.39807 0.702629C8.522 -0.253997 7.00801 -0.230478 6.16202 0.7529L0.531488 7.29784C-0.194065 8.14122 -0.17463 9.39453 0.576721 10.215C1.47433 11.1951 3.02932 11.1584 3.87972 10.1369L7.51357 5.77213C7.63964 5.6207 7.87016 5.61526 8.00322 5.76056L12.1412 10.279Z"
        fill={color || "white"}
      />
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M12.1412 23.279C13.0216 24.2403 14.5357 24.2403 15.4161 23.279C16.1946 22.4289 16.1946 21.1241 15.4161 20.2741L9.39807 13.7026C8.522 12.746 7.00801 12.7695 6.16202 13.7529L0.531488 20.2978C-0.194065 21.1412 -0.17463 22.3945 0.576721 23.215C1.47433 24.1951 3.02932 24.1584 3.87972 23.1369L7.51357 18.7721C7.63964 18.6207 7.87016 18.6153 8.00322 18.7606L12.1412 23.279Z"
        fill={color || "white"}
      />
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M12.1412 35.279C13.0216 36.2403 14.5357 36.2403 15.4161 35.279C16.1946 34.4289 16.1946 33.1241 15.4161 32.2741L9.39807 25.7026C8.522 24.746 7.00801 24.7695 6.16202 25.7529L0.531488 32.2978C-0.194065 33.1412 -0.17463 34.3945 0.576721 35.215C1.47433 36.1951 3.02932 36.1584 3.87972 35.1369L7.51357 30.7721C7.63964 30.6207 7.87016 30.6153 8.00322 30.7606L12.1412 35.279Z"
        fill={color || "white"}
      />
    </Svg>
  )
}
