import React, { useEffect } from "react"
import { TouchableWithoutFeedback } from "react-native"
import {
  useSharedValue,
  useAnimatedStyle,
  interpolateColor,
  interpolate,
  withTiming,
} from "react-native-reanimated"

import { RatingLevel } from "convose-lib"
import { color } from "convose-styles"
import {
  KnowledgeLevelBubble,
  KnowledgeLevelContainer,
  KnowledgeLevelTitle,
  KnowledgeLevelTitleContainer,
} from "./Style"

type Props = {
  active: boolean
  title: string
  readonly changeLevel: (level: RatingLevel) => void
  level: RatingLevel
  selectedLevel: RatingLevel
}
export const KnowledgeLevel: React.FunctionComponent<Props> = ({
  active,
  title,
  changeLevel,
  level,
  selectedLevel,
}) => {
  const activeOffset = useSharedValue(active ? 1 : 0)
  const style = useAnimatedStyle(() => ({
    width: interpolate(activeOffset.value, [0, 1], [40, 45]),
    marginHorizontal: interpolate(activeOffset.value, [0, 1], [2.5, 0]),
    backgroundColor: interpolateColor(
      activeOffset.value,
      [0, 1],
      [color.blue_transparent, color.green]
    ),
  }))
  const textStyle = useAnimatedStyle(() => ({
    top: interpolate(activeOffset.value, [0, 1], [45, 47.5]),
  }))

  useEffect(() => {
    activeOffset.value = withTiming(active ? 1 : 0, {
      duration: 200,
    })
  }, [active, activeOffset])

  const onChangeLevelPress = () => {
    changeLevel(level)
  }
  return (
    <TouchableWithoutFeedback onPress={onChangeLevelPress}>
      <KnowledgeLevelContainer>
        <KnowledgeLevelBubble style={style} />
        <KnowledgeLevelTitleContainer style={textStyle}>
          <KnowledgeLevelTitle active={level === selectedLevel}>
            {title}
          </KnowledgeLevelTitle>
        </KnowledgeLevelTitleContainer>
      </KnowledgeLevelContainer>
    </TouchableWithoutFeedback>
  )
}
