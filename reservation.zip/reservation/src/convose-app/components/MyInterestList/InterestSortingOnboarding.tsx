import React from "react"
import {
  EntryAnimationsValues,
  ExitAnimationsValues,
  withDelay,
  withTiming,
} from "react-native-reanimated"

import { defaultShadows } from "convose-styles"

import {
  CloseAndShapesContainer,
  CloseButton,
  EmptyBox,
  EmptyBoxContainer,
  SortingDescription,
  SortingOnboardingBox,
  SortingOnboardingBoxPointer,
  SortingOnboardingContainer,
  StyledIcon,
} from "./styled"

const boxes = [
  { width: 68, color: "#FF7979" },
  { width: 98, color: "#59EC56" },
  { width: 109, color: "#F2F54B" },
  { width: 68, color: "#F4AA41" },
]
const InterestBoxes: React.FC = () => {
  return (
    <EmptyBoxContainer>
      {boxes.map((box, index) => (
        <EmptyBox
          // eslint-disable-next-line react/no-array-index-key
          key={`${index}-key`}
          width={box.width}
          isLast={index === boxes.length - 1}
          color={box.color}
        />
      ))}
    </EmptyBoxContainer>
  )
}

type Props = {
  dismiss: () => void
}
function CustomEnteringAnimation(targetValues: EntryAnimationsValues) {
  "worklet"

  const duration = 200
  const delay = 500
  const animations = {
    originX: withDelay(
      delay,
      withTiming(targetValues.targetOriginX, { duration })
    ),
    originY: withDelay(
      delay,
      withTiming(targetValues.targetOriginY, { duration })
    ),
    transform: [{ scale: withDelay(delay, withTiming(1, { duration })) }],
  }
  const initialValues = {
    originX: -(targetValues.targetWidth / 2),
    originY: +10,
    transform: [{ scale: 0 }],
  }

  return {
    initialValues,
    animations,
  }
}
function CustomExitingAnimation(targetValues: ExitAnimationsValues) {
  "worklet"

  const duration = 200
  const animations = {
    originX: withTiming(-targetValues.currentWidth / 2 + 10, { duration }),
    originY: withTiming(+10, { duration }),
    transform: [{ scale: withTiming(0, { duration }) }],
  }
  const initialValues = {
    originX: targetValues.currentOriginX,
    originY: targetValues.currentOriginY,
    transform: [{ scale: 1 }],
  }

  return {
    initialValues,
    animations,
  }
}
const InterestSortingOnboardingComponent: React.FC<Props> = ({ dismiss }) => {
  return (
    <SortingOnboardingContainer
      entering={CustomEnteringAnimation}
      exiting={CustomExitingAnimation}
    >
      <SortingOnboardingBoxPointer />
      <SortingOnboardingBox style={defaultShadows}>
        <CloseAndShapesContainer>
          <InterestBoxes />
          <CloseButton onPress={dismiss} hitSlop={20}>
            <StyledIcon name="close" size={25} />
          </CloseButton>
        </CloseAndShapesContainer>
        <SortingDescription>
          Long press interests to prioritize & see more people with those
          interests.
        </SortingDescription>
      </SortingOnboardingBox>
    </SortingOnboardingContainer>
  )
}

export const InterestSortingOnboarding = React.memo(
  InterestSortingOnboardingComponent
)
