import {
  Easing,
  LinearTransition,
  SlideInDown,
  SlideOutDown,
} from "react-native-reanimated"
import { SLIDE_DURATION } from "./constants"

export const SlideInEntering = SlideInDown.duration(SLIDE_DURATION).easing(
  Easing.bezier(0, 0.55, 0.45, 1)
)
export const SlideOutExiting = SlideOutDown.duration(SLIDE_DURATION)
export const layout = LinearTransition.damping(20).springify()
