import React from "react"
import { Svg, Path } from "react-native-svg"
import { SvgProps } from "../../svg/types"
import { getRatio, getWidth } from "../../svg/utils"

const defaultHeight = 24
const defaultWidth = 20
const ratio = getRatio(defaultHeight, defaultWidth)

export const AppleIcon: React.FC<SvgProps> = ({ color, height = 24 }) => {
  const svgHeight = height || defaultHeight
  const svgWidth = height ? getWidth(ratio, height) : defaultWidth
  return (
    <Svg width={svgWidth} height={svgHeight} viewBox="0 0 20 24" fill="none">
      <Path
        d="M16.3295 13.3392C15.6707 9.98093 18.8175 8.01132 18.8175 8.01132C18.8175 8.01132 17.5915 6.21453 15.531 5.75229C13.4715 5.28904 12.4407 5.86783 11.412 6.30193C10.3822 6.7371 9.86838 6.7371 9.86838 6.7371C8.38236 6.7371 7.29605 5.14329 4.46478 5.86889C2.51424 6.36752 0.460884 8.64841 0.0898891 11.3707C-0.281105 14.094 0.519484 17.5689 2.06306 20.262C3.60664 22.9572 5.17904 23.9701 6.29508 23.9993C7.41116 24.0274 8.52519 23.1894 9.86838 22.9853C11.2126 22.7833 12.0399 23.4788 13.3584 23.8546C14.6718 24.2294 15.1322 23.8817 16.6449 22.5783C18.1618 21.2749 19.5348 17.5367 19.5348 17.5367C19.5348 17.5367 16.9882 16.6996 16.3295 13.3392Z"
        fill={color || "black"}
      />
      <Path
        d="M13.3828 3.47609C14.9552 2.11189 14.4226 0 14.4226 0C14.4226 0 12.2145 0.32999 10.735 1.64047C9.25667 2.95191 9.50139 5.02324 9.50139 5.02324C9.50139 5.02324 11.8103 4.83941 13.3828 3.47609Z"
        fill={color || "black"}
      />
    </Svg>
  )
}
