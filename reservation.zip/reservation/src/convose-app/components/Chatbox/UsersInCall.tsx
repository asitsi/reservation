import React from "react"

import { ChatUser } from "convose-lib/chat"
import { JoinCallDescription } from "./JoinCallDescription"
import { CallUsersTail } from "../CallUsersTail"
import { JoinCallUsersDescriptionContainer } from "./Styled"

type Props = {
  participants: ChatUser[]
  isGroup: boolean
  avatarCountToShow: number
  avatarBgColorCode?: string
  noAvatarBg?: boolean
  showRing?: boolean
  ringColor?: string
  ringColorCode?: string
}
const UsersInCallComponent: React.FC<Props> = ({
  isGroup,
  avatarCountToShow,
  participants,
  avatarBgColorCode,
  noAvatarBg,
  showRing,
  ringColor,
  ringColorCode,
}) => {
  return (
    <JoinCallUsersDescriptionContainer>
      <JoinCallDescription isGroup={isGroup} />
      {isGroup && (
        <CallUsersTail
          participants={participants}
          avatarCountToShow={avatarCountToShow}
          showUsersCount
          size={30}
          noAvatarBg={noAvatarBg}
          showRing={showRing}
          avatarBgColorCode={avatarBgColorCode}
          ringColor={ringColor}
          ringSize={3}
          ringColorCode={ringColorCode}
        />
      )}
    </JoinCallUsersDescriptionContainer>
  )
}

export const UsersInCall = React.memo(UsersInCallComponent)
