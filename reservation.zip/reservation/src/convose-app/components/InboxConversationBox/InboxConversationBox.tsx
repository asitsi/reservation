/* eslint-disable react/jsx-props-no-spreading, camelcase, no-nested-ternary, @typescript-eslint/no-explicit-any, complexity */
import * as React from "react"
import { connect } from "react-redux"
import { differenceInHours, differenceInYears, format } from "date-fns"
import { ZoomIn, ZoomOut } from "react-native-reanimated"

import {
  CHAT_MESSAGE_TIME_FORMAT,
  CHAT_MESSAGE_DATE_FORMAT,
  ChatSummary,
  ChatUser,
  MessageType,
  UserStatus,
  ChatType,
  setCallStatusMessage,
  ParticipantsListObject,
  CHAT_MESSAGE_DATE_FORMAT_WITH_YEAR,
  ReplyMessageType,
  ChatAction,
} from "convose-lib/chat"
import { Routes } from "convose-lib/router"
import { State } from "convose-lib/store"
import { CallSignal, selectCallingChannel } from "convose-lib/calling"
import { selectParticipants } from "convose-lib/users-list"
import { selectMyThemeColor, selectMyUuid } from "convose-lib/user"
import { selectIsDarkMode } from "convose-lib/app"
import Swipeable from "react-native-gesture-handler/Swipeable"
import { StyleSheet, TouchableOpacity } from "react-native"
import { color } from "convose-styles"
import { TrashSvg } from "../../../assets/svg/Trash"
import {
  BadgeView,
  Body,
  InboxContainer,
  MediaMessageContainer,
  Section,
  TextMessage,
  TouchableWrapper,
  Username,
  GroupUserName,
  GroupTextWrapper,
  DateComponent,
  StyledIcon,
  SHADOW_BORDER_RADIUS,
  AvatarBackground,
  WaveButtonContainer,
} from "./Styled"
import { Avatar, GroupAvatar } from "../../components/Avatar"
import { IconBadge } from "../../components/IconBadge"
import { PresenceIndicator } from "../../components/PresenceIndicator"
import { RejoinCallingButton } from "../../components/Header"
import * as RootNavigation from "../../RootNavigation"
// eslint-disable-next-line import/no-relative-packages
import { replaceMentionValues } from "../../../../self-maintained-packages/react-native-controlled-mentions/src"
import { FlatShadow } from "../FlatShadow"
import { Skeleton } from "../Skeleton"
import { WaveButton, useWaveButton } from "../WaveButton"
import { DeleteChatButton } from "../Inbox/Styled"

type SizeType = "small" | "medium"

const getAvatarSize = (size?: SizeType) => (size === "small" ? 30 : 50)
const getInboxContainerPadding = (size?: SizeType) =>
  size === "small" ? 10 : undefined
const getAvatarContainerSize = (size?: SizeType) => getAvatarSize(size) * 1.48

type CommonProps = {
  readonly size?: SizeType
  readonly transparentBackground?: boolean
}
type PropsType = {
  readonly chatSummary: ChatSummary
  readonly hideDate?: boolean
  readonly hideOnlineIndicator?: boolean
  readonly forceDefaultTextColor?: boolean
  readonly useDefaultBackgroundForGroups?: boolean
  readonly cardView?: boolean
  readonly delayOnTouchResponseInMs?: number
  readonly onTouchEnd?: () => void
}

type StateToProps = {
  readonly myUuid: string
  readonly myThemeColor: string
  readonly participants: ParticipantsListObject | null
  readonly callingChannel: string
  readonly isDarkMode: boolean | null
}
type DispatchToProps = {
  archiveChats: (chatChannel: string[]) => void
}

type allProps = PropsType & StateToProps & CommonProps & DispatchToProps
const renderParticipantAvatar = (user: ChatUser, avatarSize: number) => {
  return (
    <Avatar
      height={avatarSize}
      userAvatar={user && user?.avatar ? user?.avatar : undefined}
      showRing={!user?.avatar?.default_avatar}
      bgColor="background"
    />
  )
}

const renderBadge = (
  unreadCount: number,
  inbox_read: boolean,
  canRejoinCall: boolean,
  isWave: boolean,
  cardView?: boolean
) => {
  if (canRejoinCall || isWave) {
    return null
  }
  return (
    unreadCount > 0 && (
      <BadgeView cardView={cardView}>
        <IconBadge
          fontSize={11}
          height={22}
          inboxIndicator={!inbox_read}
          text={`${unreadCount}`}
          width={22}
          useMainBlue
        />
      </BadgeView>
    )
  )
}
type WaveType = {
  chatChannel: string
  message: ReplyMessageType
  size?: SizeType
}
const Wave: React.FC<WaveType> = ({ chatChannel, message, size }) => {
  const { onPress } = useWaveButton(chatChannel, message)
  return (
    <WaveButtonContainer>
      <WaveButton
        onDisappeared={onPress}
        isWaveBack
        size={size === "small" ? 35 : 40}
      />
    </WaveButtonContainer>
  )
}
type ShadowContainerProps = {
  cardView?: boolean
}
const ShadowContainer: React.FC<
  React.PropsWithChildren<ShadowContainerProps>
> = ({ cardView, children }) => {
  if (cardView) {
    return (
      <FlatShadow widthPercentage={95} borderRadius={SHADOW_BORDER_RADIUS}>
        {children}
      </FlatShadow>
    )
  }
  // eslint-disable-next-line react/jsx-no-useless-fragment
  return <>{children}</>
}
const getDate = (createdAt: Date) => {
  const now = Date.now()
  if (differenceInYears(now, createdAt) > 0) {
    return format(createdAt, CHAT_MESSAGE_DATE_FORMAT_WITH_YEAR)
  }
  if (differenceInHours(now, createdAt) < 24) {
    return format(createdAt, CHAT_MESSAGE_TIME_FORMAT)
  }
  return format(createdAt, CHAT_MESSAGE_DATE_FORMAT)
}
export class InboxConversationBoxComponent extends React.PureComponent<allProps> {
  public timeout?: ReturnType<typeof setTimeout> | null = null

  componentDidMount(): void {
    const { delayOnTouchResponseInMs } = this.props
    if (delayOnTouchResponseInMs) {
      this.timeout = setTimeout(() => {
        this.timeout = null
      }, delayOnTouchResponseInMs)
    }
  }

  componentWillUnmount(): void {
    if (this.timeout) {
      clearTimeout(this.timeout)
      this.timeout = null
    }
  }

  private readonly getChatUser = () => {
    try {
      const { chatSummary } = this.props
      const { participants, type } = chatSummary
      const [receiverIndex] = Object.keys(participants)
      let user = participants[receiverIndex]

      if (type === ChatType.Group) {
        user = {
          ...user,
          username: chatSummary ? chatSummary.group_name || "Group" : "Group",
          theme_color: "SystemDefault",
        }
      }
      return user
    } catch (error) {
      return null
    }
  }

  public readonly rejoinCall = (): void => {
    this.runConversation(true)()
  }

  private readonly runConversation =
    (forRejoinCallParam?: boolean) => (): void => {
      requestAnimationFrame(() => {
        if (this.timeout) {
          return
        }
        const { chatSummary, callingChannel, onTouchEnd } = this.props
        const { channel } = chatSummary
        const forRejoinCall =
          forRejoinCallParam && (!callingChannel || callingChannel === channel)
        const chatUser = this.getChatUser()
        onTouchEnd && onTouchEnd()
        RootNavigation.navigate(Routes.Chat, {
          channel,
          chatUser,
          forRejoinCall,
        })
      })
    }

  private readonly wrapWithUserName = (elem: JSX.Element) => {
    const {
      chatSummary,
      participants,
      myUuid,
      myThemeColor,
      // forceDefaultTextColor,
    } = this.props

    const userName = chatSummary.last_message.sender_username
    const senderUuid = chatSummary.last_message.sender_uuid
    const sender =
      senderUuid === myUuid
        ? { theme_color: myThemeColor }
        : participants
        ? participants[senderUuid]
        : chatSummary.participants[senderUuid]
    // const systemColor = forceDefaultTextColor ? undefined : "SystemDefault"
    // const senderThemeColor = sender ? sender.theme_color : systemColor
    const senderThemeColor = sender ? sender.theme_color : "SystemDefault"
    if (
      chatSummary.type === ChatType.Group &&
      userName !== MessageType.System &&
      userName
    ) {
      return (
        <GroupTextWrapper>
          <GroupUserName
            adjustsFontSizeToFit
            numberOfLines={1}
            color={senderThemeColor}
          >
            {userName}:
          </GroupUserName>
          {elem}
        </GroupTextWrapper>
      )
    }
    return elem
  }

  // RENDER FUNCTIONS
  // eslint-disable-next-line complexity
  private readonly renderParticipantsHeaders = (
    user: ChatUser,
    forceHideDate: boolean
  ) => {
    const { chatSummary, size, forceDefaultTextColor, cardView } = this.props
    const {
      last_message: { created_at },
      type,
    } = chatSummary
    const isGroup = type === ChatType.Group
    const systemColor = forceDefaultTextColor ? undefined : "SystemDefault"
    const theme_color =
      user && user.theme_color ? user.theme_color : systemColor
    const themeColorToUse =
      isGroup && forceDefaultTextColor ? undefined : theme_color
    const username = user && user.username ? user.username : ""
    const { hideDate } = this.props
    const fontSize = size === "small" ? 16 : 18

    return (
      <>
        <Username
          ellipsizeMode="tail"
          fontSize={fontSize}
          color={themeColorToUse}
          numberOfLines={1}
        >
          {username}
        </Username>
        {!forceHideDate && !hideDate && (
          <DateComponent cardView={cardView}>
            {getDate(created_at)}
          </DateComponent>
        )}
      </>
    )
  }

  private readonly getUnreadCountAndType = () => {
    const { chatSummary } = this.props
    if (!chatSummary || typeof chatSummary !== "object") {
      return {
        count: 0,
        type: ChatType.OneToOne,
        inbox_read: true,
      }
    }
    const count = chatSummary.unread ? chatSummary.unread.count || 0 : 0
    const type = chatSummary.type || ChatType.OneToOne
    const inbox_read = chatSummary.unread
      ? chatSummary.unread.inbox_read || false
      : false
    return {
      count,
      type,
      inbox_read,
    }
  }

  private readonly renderTextMessage = (message: string) => {
    const { size, forceDefaultTextColor } = this.props
    const { count, type } = this.getUnreadCountAndType()
    const isGroup = type === ChatType.Group
    const fontSize = size === "small" ? 13 : 16
    return (
      <TextMessage
        fontSize={fontSize}
        newMessage={count > 0}
        isGroup={isGroup}
        numberOfLines={1}
        forceDefaultTextColor={forceDefaultTextColor}
      >
        {replaceMentionValues(
          message,
          ({ name }: { name: string }) => `@${name}`
        )}
      </TextMessage>
    )
  }

  private readonly renderIconMessage = (name: string, label: string) => {
    const { size, forceDefaultTextColor } = this.props
    const iconSize = size === "small" ? 16 : 20
    return (
      <MediaMessageContainer>
        <StyledIcon
          name={name}
          size={iconSize}
          forceDefaultTextColor={forceDefaultTextColor}
        />
        {this.renderTextMessage(label)}
      </MediaMessageContainer>
    )
  }

  private readonly renderWaveMessage = () => {
    const { chatSummary, myUuid } = this.props
    const getText = () => {
      if (chatSummary.last_message.reply_to_id) {
        if (chatSummary.last_message.sender_uuid === myUuid) {
          return "You waved back"
        }
        return "Waved back"
      }
      if (chatSummary.last_message.sender_uuid === myUuid) {
        return "You waved"
      }
      return "Waved at you"
    }
    return this.renderTextMessage(getText())
  }

  private readonly renderMessage = () => {
    const { chatSummary, myUuid } = this.props
    const callStatusMessage =
      chatSummary.last_message.message_type === MessageType.Call
        ? setCallStatusMessage(
            chatSummary.last_message.content,
            chatSummary.last_message.sender_username,
            chatSummary.type === ChatType.Group,
            chatSummary.last_message.sender_uuid === myUuid,
            chatSummary.last_message.action
          )
        : null
    switch (chatSummary.last_message.message_type) {
      case MessageType.Deleted:
      case MessageType.Text:
      case MessageType.System:
        return this.wrapWithUserName(
          this.renderTextMessage(chatSummary.last_message.content)
        )
      case MessageType.Audio:
        return this.wrapWithUserName(
          this.renderIconMessage("mic", "Audio Message")
        )
      case MessageType.Video:
        return this.wrapWithUserName(this.renderIconMessage("film", "Video"))
      case MessageType.Image:
        return this.wrapWithUserName(this.renderIconMessage("image", "Image"))
      case MessageType.Call:
        // eslint-disable-next-line no-case-declarations
        const userName = chatSummary.last_message.sender_username
        // eslint-disable-next-line no-case-declarations
        const missedCall =
          chatSummary.last_message.action === CallSignal.missedCall
        if (missedCall) {
          return this.renderTextMessage(
            callStatusMessage
              ? `${callStatusMessage[0]} from ${userName}`
              : "Tap to see call status"
          )
        }

        return this.renderTextMessage(
          callStatusMessage ? callStatusMessage[0] : "Tap to see call status"
        )
      case MessageType.Wave:
        return this.renderWaveMessage()
      default:
        return undefined
    }
  }

  private renderRightActions = () => {
    return (
      <TouchableOpacity onPress={this.deleteChats}>
        <DeleteChatButton>
          <TrashSvg height={20} color={color.white} />
        </DeleteChatButton>
      </TouchableOpacity>
    )
  }

  private deleteChats = () => {
    const { archiveChats, chatSummary } = this.props
    const { channel } = chatSummary
    archiveChats([channel])
  }

  public render(): React.ReactNode {
    const {
      chatSummary,
      size,
      hideOnlineIndicator,
      isDarkMode,
      useDefaultBackgroundForGroups,
      cardView,
      transparentBackground,
      myUuid,
    } = this.props
    const {
      is_in_call,
      participants,
      avatar = null,
      call_users,
      last_message,
      channel,
    } = chatSummary
    const { count, type: groupType, inbox_read } = this.getUnreadCountAndType()
    const user = this.getChatUser()
    if (!user) {
      return null
    }
    const isGroup = groupType === ChatType.Group
    const bgColor = (() => {
      if (isGroup) {
        if (useDefaultBackgroundForGroups) {
          return "default"
        }
        return undefined
      }
      if (isDarkMode) {
        return user?.dark_background_color
      }
      return user?.background_theme_color
    })()
    const canRejoinCall = isGroup && is_in_call && !!call_users
    const avatarSize = getAvatarSize(size)
    const inboxContainerPadding = getInboxContainerPadding(size)
    const avatarContainerSize = getAvatarContainerSize(size)
    const isOnline = !!(
      user &&
      user.status &&
      user.status === UserStatus.Online
    )
    const isWave =
      last_message?.message_type === MessageType.Wave &&
      last_message.sender_uuid !== myUuid &&
      !last_message.reply_to_id
    return (
      <ShadowContainer cardView={cardView}>
        <Swipeable renderRightActions={this.renderRightActions}>
          <InboxContainer
            padding={inboxContainerPadding}
            pointerEvents="box-none"
            // bgColor={bgColor}
            cardView={cardView}
            entering={ZoomIn.duration(100)}
            exiting={ZoomOut.duration(100)}
            transparentBackground={transparentBackground}
          >
            <TouchableWrapper
              onPress={this.runConversation()}
              style={({ pressed }: { pressed: boolean }) => ({
                opacity: pressed ? 0.5 : 1,
              })}
            >
              <AvatarBackground bgColor={bgColor} size={avatarContainerSize}>
                <PresenceIndicator
                  hideOnlineIndicator={hideOnlineIndicator || isGroup}
                  isOnline={isOnline}
                  location="inbox"
                  offlineIndicatorColorCode="main.background"
                >
                  {isGroup ? (
                    <GroupAvatar
                      participants={
                        participants ? Object.values(participants) : undefined
                      }
                      size={avatarSize}
                      showRing
                      bgColor="background"
                      avatar={avatar}
                    />
                  ) : (
                    renderParticipantAvatar(user, avatarSize)
                  )}
                </PresenceIndicator>
              </AvatarBackground>
              <Section>
                <Body>
                  <Section>
                    {this.renderParticipantsHeaders(
                      user,
                      canRejoinCall || isWave
                    )}
                  </Section>
                  <Section>
                    {this.renderMessage()}
                    {renderBadge(
                      count,
                      inbox_read,
                      canRejoinCall,
                      isWave,
                      cardView
                    )}
                  </Section>
                </Body>
                {canRejoinCall && RejoinCallingButton(this.rejoinCall)}
                {!canRejoinCall && isWave && (
                  <Wave
                    chatChannel={channel}
                    size={size}
                    // eslint-disable-next-line react-perf/jsx-no-new-object-as-prop
                    message={{
                      reply_to_id: last_message.uuid,
                      reply_to_message: last_message.content,
                      reply_to_message_type: last_message.message_type,
                      reply_to_user_id: last_message.sender,
                      reply_to_username: last_message.sender_username,
                    }}
                  />
                )}
              </Section>
            </TouchableWrapper>
          </InboxContainer>
        </Swipeable>
      </ShadowContainer>
    )
  }
}

const mapStateToProps = (state: State, ownProps: PropsType): StateToProps => ({
  myUuid: selectMyUuid(state),
  myThemeColor: selectMyThemeColor(state),
  participants: selectParticipants(ownProps.chatSummary?.channel)(state),
  callingChannel: selectCallingChannel(state),
  isDarkMode: selectIsDarkMode(state),
})

// InboxConversationBoxComponent.whyDidYouRender = {
//   logOnDifferentValues: false,
//   customName: "InboxConversationBoxComponent",
//   diffNameColor: "red",
// }

const styles = StyleSheet.create({
  iconSkeleton: {
    width: "100%",
    aspectRatio: 1,
  },
  nameSkeleton: {
    width: "30%",
    height: "50%",
    borderRadius: 16,
  },
  messageSkeleton: {
    width: "70%",
    height: "50%",
    borderRadius: 16,
  },
  avatarBackground: {
    overflow: "hidden",
  },
})
type SkeletonProps = ShadowContainerProps & CommonProps
const InboxConversationBoxSkeletonComponent: React.FC<SkeletonProps> = ({
  cardView,
  size,
  transparentBackground,
}) => {
  const inboxContainerPadding = React.useMemo(
    () => getInboxContainerPadding(size),
    [size]
  )
  const avatarContainerSize = React.useMemo(
    () => getAvatarContainerSize(size),
    [size]
  )
  return (
    <ShadowContainer cardView={cardView}>
      <InboxContainer
        padding={inboxContainerPadding}
        pointerEvents="box-none"
        cardView={cardView}
        entering={ZoomIn.duration(100)}
        exiting={ZoomOut.duration(100)}
        transparentBackground={transparentBackground}
      >
        <TouchableWrapper>
          <AvatarBackground
            style={styles.avatarBackground}
            bgColor="default"
            size={avatarContainerSize}
          >
            <Skeleton style={styles.iconSkeleton} />
          </AvatarBackground>
          <Section>
            <Body>
              <Section>
                <Skeleton style={styles.nameSkeleton} />
              </Section>
              <Section>
                <Skeleton style={styles.messageSkeleton} />
              </Section>
            </Body>
          </Section>
        </TouchableWrapper>
      </InboxContainer>
    </ShadowContainer>
  )
}
export const InboxConversationBoxSkeleton = React.memo(
  InboxConversationBoxSkeletonComponent
)

const mapDispatchToProps: DispatchToProps = {
  archiveChats: ChatAction.archiveChats,
}

export const InboxConversationBox = connect(
  mapStateToProps,
  mapDispatchToProps
)(InboxConversationBoxComponent)
