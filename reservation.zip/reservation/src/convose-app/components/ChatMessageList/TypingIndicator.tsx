import React from "react"
import { DotIndicator } from "react-native-indicators"
import { SlideInDown, SlideOutDown } from "react-native-reanimated"

import { color } from "convose-styles"
import { Typing } from "convose-lib/chat"
import { unionBy } from "lodash"
import {
  MessageTypingContainer,
  TypingIndicatorContainer,
  TypingIndicatorUsersLoadingContainer,
} from "./Styled"
import { Avatar } from "../Avatar"

type Props = {
  typingUsers: ReadonlyArray<Typing>
  hideProfilePictures?: boolean
}

const TypingIndicatorComponent: React.FC<Props> = ({
  typingUsers,
  hideProfilePictures,
}) => {
  const isTyping = !!typingUsers.length && !hideProfilePictures

  if (!isTyping) {
    return null
  }

  const allTypings = hideProfilePictures ? [] : unionBy(typingUsers, "sender")
  return (
    <TypingIndicatorContainer
      entering={SlideInDown.duration(100)}
      exiting={SlideOutDown.duration(100)}
    >
      <TypingIndicatorUsersLoadingContainer>
        {allTypings.slice(0, 3).map((user) => (
          <Avatar key={user.sender} userAvatar={user?.avatar} height={30} />
        ))}
        <MessageTypingContainer hideProfilePictures={hideProfilePictures}>
          <DotIndicator size={6} count={3} color={color.darkergray} />
        </MessageTypingContainer>
      </TypingIndicatorUsersLoadingContainer>
    </TypingIndicatorContainer>
  )
}

export const TypingIndicator = React.memo(TypingIndicatorComponent)
