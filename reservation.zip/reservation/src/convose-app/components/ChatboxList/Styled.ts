import { View, StyleSheet, Dimensions } from "react-native"
import styled from "styled-components/native"

import { CenteredAnimatedText, CenteredText, Props, font } from "convose-styles"
import { isTablet } from "convose-lib/utils"

const { width: screenWidth } = Dimensions.get("screen")
const CARD_WIDTH_RAW = screenWidth * 0.9
export const CARD_WIDTH = isTablet() ? CARD_WIDTH_RAW / 2 : CARD_WIDTH_RAW

type ChatboxListProps = {
  bottomInset?: number
  topInset?: number
}
export const ChatboxListWrapper = styled(View)`
  background: ${(props: Props) => props.theme.main.background};
  width: 100%;
  height: 100%;
  padding-bottom: ${(props: ChatboxListProps) => props.bottomInset}px;
`

export const EmptyListAlert = styled(CenteredText)`
  font-family: ${font.bold};
  font-size: 16px;
  text-align: center;
  text-transform: uppercase;
  color: ${(props: Props) => props.theme.mainBlue};
  margin-top: 20px;
`

export const styles = StyleSheet.create({
  // Flex to fill, position absolute,
  // Fixed left/top, and the width set to the window width
  overlay: {
    position: "relative",
    bottom: 50,
    zIndex: 1,
  },
})

export const Separator = styled.View`
  width: 100%;
  height: 1px;
  background-color: ${(props: Props) =>
    props.theme.interests.autocompleteList.borderBottom};
  margin-left: 20px;
  margin-bottom: 10px;
`
export const SuggestionTypeTitle = styled(CenteredText)`
  left: 20px;
  font-family: ${font.bold};
  font-size: 22px;
  line-height: 33px;
  letter-spacing: 0.43px;
  text-align: left;
  color: ${(props: Props) => props.theme.main.text};
`

export const SuggestionContainer = styled.View`
  width: ${CARD_WIDTH}px;
  align-self: center;
  padding-right: ${(props: { isHorizontal: boolean }) =>
    props.isHorizontal ? 10 : 0}px;
`

export const TitleContainer = styled.View`
  background-color: ${(props: Props) => props.theme.main.background};
  padding-top: 30px;
  padding-bottom: 10px;
  width: 100%;
  justify-content: flex-start;
  align-items: flex-end;
  align-content: flex-end;
  flex-direction: row;
`
export const Title = styled(CenteredAnimatedText)`
  font-family: ${font.bold};
  font-size: 33px;
  line-height: 36px;
  letter-spacing: 0.43px;
  text-align: left;
  color: ${(props: Props) => props.theme.main.text};
  margin-left: 20px;
  margin-bottom: -5px;
  width: 90%;
`
