import React, { useCallback } from "react"

import { color } from "convose-styles"
import { useMainBlue } from "convose-lib/utils/useMainBlue"
import { MicSvg, SendSvg, TickSvg } from "../../../assets/svg"
import { IconButton } from "./UtilFunctions"
import { ICONS_SIZE, RightPanelContainer, SendContainer } from "./Styled"

type RightPanelType = {
  handleStartRecording: () => void
  handleOnSend: () => void
  handleOnEdit: () => void
  shouldShowSendButton: boolean
  strokeIcons?: boolean
  shouldShowEditButton: boolean
}
const hitSlop = {
  bottom: 20,
  left: 20,
  right: 20,
  top: 0,
}
const RightPanelComponent: React.FC<RightPanelType> = ({
  handleStartRecording,
  handleOnSend,
  handleOnEdit,
  shouldShowSendButton,
  strokeIcons,
  shouldShowEditButton,
}) => {
  const mainBlue = useMainBlue()

  const onPress = () => {
    if (shouldShowEditButton) {
      handleOnEdit()
    } else if (shouldShowSendButton) {
      handleOnSend()
    } else {
      handleStartRecording()
    }
  }
  const getIcon = useCallback(() => {
    if (shouldShowEditButton) {
      return (
        <TickSvg
          height={ICONS_SIZE + 10}
          color={mainBlue}
          strokeColor={strokeIcons ? color.black : undefined}
        />
      )
    }
    if (shouldShowSendButton) {
      return (
        <SendSvg
          height={ICONS_SIZE + 2}
          color={mainBlue}
          strokeColor={strokeIcons ? color.black : undefined}
        />
      )
    }
    return (
      <MicSvg
        height={ICONS_SIZE + 2}
        color={mainBlue}
        strokeColor={strokeIcons ? color.black : undefined}
      />
    )
  }, [mainBlue, shouldShowEditButton, shouldShowSendButton, strokeIcons])

  return (
    <RightPanelContainer>
      <SendContainer>
        <IconButton
          onPressIn={onPress}
          svg={getIcon()}
          hitSlop={hitSlop}
          withHitSlop
        />
      </SendContainer>
    </RightPanelContainer>
  )
}

export const RightPanel = React.memo(RightPanelComponent)
