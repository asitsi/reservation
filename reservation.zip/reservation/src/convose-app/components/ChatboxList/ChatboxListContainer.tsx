import React, { memo } from "react"
import {
  FlatList,
  ListRenderItemInfo,
  StyleSheet,
  ViewStyle,
} from "react-native"
import { useSafeAreaInsets } from "react-native-safe-area-context"

import { SuggestedProfile } from "convose-lib/users-list"
import { isTablet } from "convose-lib/utils"

import { ReturnToCall } from "../ReturnToCall"
import { ChatboxSkeleton } from "../Chatbox/ChatboxSkeleton"
import { Chatbox } from "../Chatbox/Chatbox"
import { Blank } from "../ChatMessageList/Styled"

import {
  CARD_WIDTH,
  ChatboxListWrapper,
  Separator,
  SuggestionContainer,
  SuggestionTypeTitle,
  Title,
  TitleContainer,
} from "./Styled"

const NUM_COLUMNS = isTablet() ? 2 : 1

const COLUMN_WRAPPER_STYLE: ViewStyle | undefined = isTablet()
  ? { justifyContent: "space-around", width: "100%" }
  : undefined
const styles = StyleSheet.create({
  centering: {
    alignItems: "center",
    justifyContent: "flex-start",
  },
  contentContainer: { flexGrow: 1 },
  chatBox: { alignSelf: "center" },
  containerContentContainerStyle: { paddingLeft: 20 },
})

type SuggestionTitleProps = {
  title: string
}
const SuggestionTitle: React.FC<SuggestionTitleProps> = ({ title }) => {
  return (
    <>
      <Separator />
      <SuggestionTypeTitle>{title}</SuggestionTypeTitle>
    </>
  )
}
export type SkeletonType = {
  uuid: string
  isSkeleton: boolean
}
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const isSkeletonType = (obj: any): obj is SkeletonType => {
  return "isSkeleton" in obj
}
const renderUser =
  (isHorizontal?: boolean) =>
  (
    info: ListRenderItemInfo<SuggestedProfile | SkeletonType>
  ): React.ReactElement => {
    const { item } = info
    if (isSkeletonType(item)) {
      return (
        <SuggestionContainer isHorizontal={isHorizontal}>
          <ChatboxSkeleton style={styles.chatBox} />
        </SuggestionContainer>
      )
    }
    return (
      <SuggestionContainer isHorizontal={isHorizontal}>
        <Chatbox style={styles.chatBox} key={item.uuid} user={item} />
      </SuggestionContainer>
    )
  }
type Props = {
  groups: SuggestedProfile[] | SkeletonType[]
  oneOnOnes: SuggestedProfile[] | SkeletonType[]
}

const ChatboxListContainerComponent: React.FC<Props> = ({
  groups,
  oneOnOnes,
}) => {
  const insets = useSafeAreaInsets()

  return (
    <ChatboxListWrapper bottomInset={insets.bottom}>
      <ReturnToCall />
      <FlatList
        scrollToOverflowEnabled
        contentContainerStyle={styles.contentContainer}
        columnWrapperStyle={COLUMN_WRAPPER_STYLE}
        numColumns={NUM_COLUMNS}
        data={oneOnOnes}
        renderItem={renderUser(false)}
        keyExtractor={(user) => user.uuid}
        ListHeaderComponent={
          <>
            <TitleContainer>
              <Title>People matching your interests:</Title>
            </TitleContainer>
            {!!groups.length && <SuggestionTitle title="Groups:" />}
            {!!groups.length && (
              <FlatList
                data={groups}
                renderItem={renderUser(true)}
                horizontal
                contentContainerStyle={styles.containerContentContainerStyle}
                showsHorizontalScrollIndicator={false}
                showsVerticalScrollIndicator={false}
                snapToOffsets={groups.map((x, i) => i * CARD_WIDTH)}
                decelerationRate="fast"
              />
            )}
            <SuggestionTitle title="1:1s:" />
          </>
        }
        ListEmptyComponent={<Blank />}
        ListFooterComponent={<Blank />}
        showsHorizontalScrollIndicator={false}
        showsVerticalScrollIndicator={false}
      />
    </ChatboxListWrapper>
  )
}

export const ChatboxListContainer = memo(ChatboxListContainerComponent)
