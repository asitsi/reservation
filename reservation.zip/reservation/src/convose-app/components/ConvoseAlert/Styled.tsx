import { Text, View, TouchableOpacity } from "react-native"
import styled from "styled-components/native"
import Ionicons from "react-native-vector-icons/Ionicons"

import { Props, color, font } from "convose-styles"

const StyledText = styled(Text)`
  font-family: ${font.semiBold};
  text-align: center;
  include-font-padding: false;
  text-align-vertical: center;
  color: ${(props: Props) => props.theme.main.text};
`
export const Title = styled(StyledText)`
  font-size: 24px;
  padding-bottom: 29px;
`
export const Description = styled(StyledText)`
  font-family: ${font.normal};
  font-size: 14px;
  padding-bottom: 29px;
`
export const Icon = styled(Ionicons)`
  color: ${(props: Props) => props.theme.main.text};
  margin-bottom: 29px;
`
export const CustomIconContainer = styled.View`
  margin-bottom: 29px;
`
type ButtonProps = Props & {
  isCancel: boolean
  isLast: boolean
  isWarning: boolean
}
export const ButtonLabel = styled(StyledText)`
  font-size: 18px;
  color: ${(props: ButtonProps) =>
    props.isCancel ? props.theme.mainBlue : "white"};
  align-self: center;
`
export const Button = styled(TouchableOpacity)`
  background-color: ${(props: ButtonProps) => {
    if (props.isCancel) {
      return "transparent"
    }
    if (props.isWarning) {
      return color.red
    }
    return props.theme.mainBlue
  }};
  height: 57px;
  border-radius: 40px;
  justify-content: center;
  align-items: center;
  text-align: center;
  flex-direction: row;
  margin-bottom: ${(props: ButtonProps) => (props.isLast ? "0" : "29")}px;
`
export const ButtonsContainer = styled(View)`
  width: 100%;
`
export const AlertContainer = styled.View`
  flex-direction: column;
  align-items: center;
  width: 100%;
  padding: 10px 15px 10px 15px;
  position: relative;
  ${(props: { minHeight?: number }) =>
    props.minHeight ? `min-height: ${props.minHeight}px` : ""};
  /* margin-bottom: 50px; */
`
