import React from "react"
import { useDispatch } from "react-redux"
import * as ScreenOrientation from "expo-screen-orientation"

import { AppAction, ScreenOrientationTypes } from "convose-lib/app"

const getScreenOrientationTypes = (
  orientation: ScreenOrientation.Orientation
): ScreenOrientationTypes => {
  switch (orientation) {
    case ScreenOrientation.Orientation.LANDSCAPE_LEFT:
      return "LANDSCAPE-RIGHT"
    case ScreenOrientation.Orientation.LANDSCAPE_RIGHT:
      return "LANDSCAPE-LEFT"
    default:
      return "PORTRAIT"
  }
}

const ScreenOrientationHandlerComponent: React.FC = () => {
  const dispatch = useDispatch()
  const setScreenOrientation = React.useCallback(
    (orientation: ScreenOrientationTypes) => {
      dispatch(AppAction.setScreenOrientation(orientation))
    },
    [dispatch]
  )
  React.useEffect(() => {
    ScreenOrientation.getOrientationAsync()
      .then((orientation) => {
        setScreenOrientation(getScreenOrientationTypes(orientation))
      })
      .catch()
    const subscription = ScreenOrientation.addOrientationChangeListener(
      (event) => {
        setScreenOrientation(
          getScreenOrientationTypes(event.orientationInfo.orientation)
        )
      }
    )
    return () => {
      subscription.remove()
      ScreenOrientation.removeOrientationChangeListeners()
    }
  }, [setScreenOrientation])
  return null
}

export const ScreenOrientationHandler = React.memo(
  ScreenOrientationHandlerComponent
)
