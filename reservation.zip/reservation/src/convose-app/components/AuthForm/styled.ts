import styled from "styled-components/native"
import { CenteredText, Props, font } from "convose-styles"
import Ionicons from "react-native-vector-icons/Ionicons"
import { PrimaryButton } from "../PrimaryButton"

export const FormWrapper = styled.View`
  width: 100%;
  justify-content: center;
  align-items: center;
`

export const ForgotPasswordText = styled(CenteredText)`
  font-family: ${font.bold};
  font-size: 11px;
  text-align: center;
  text-transform: uppercase;
  color: ${(props: Props) => props.theme.mainBlue};
  margin-top: 20px;
`

export const SubmitButton = styled(PrimaryButton)``

export const LoadingSpinnerContainer = styled.View`
  height: 40px;
  aspect-ratio: 1;
`
export const SubmitContainer = styled.View`
  margin-top: 20px;
  height: 60px;
  justify-content: center;
`
export const PasswordContainer = styled.View``
export const Icon = styled(Ionicons)`
  color: ${(props: Props) => props.theme.interests.input.placeholder};
  position: absolute;
  right: 10px;
  top: 40px;
`
export const AlreadyHaveAccount = styled.View`
  margin-top: 30px;
  justify-content: center;
  align-items: center;
  flex-direction: row;
`
export const AlreadyHaveAccountTitle = styled(CenteredText)`
  font-family: ${font.semiBold};
  font-size: 15px;
  line-height: 20px;
  color: ${(props: Props & { useBlue: boolean }) =>
    props.useBlue ? props.theme.mainBlue : props.theme.main.text};
`
export const LoginButton = styled.TouchableOpacity`
  padding: 0px;
  margin: 0px;
  align-self: center;
  justify-self: center;
`
