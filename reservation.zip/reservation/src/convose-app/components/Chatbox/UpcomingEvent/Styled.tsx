import styled from "styled-components/native"
import { CenteredText, Props, font } from "convose-styles"
import { CONTAINER_PADDING } from "../Styled"

export const OngoingEventUsersInCallContainer = styled.View`
  margin-left: ${-CONTAINER_PADDING}px;
`
export const TitleHostContainer = styled.View`
  flex-direction: row;
  align-items: flex-start;
`
export const UpcomingEventBottomContainer = styled.View`
  flex-direction: row;
  justify-content: flex-start;
  align-items: flex-end;
  margin-top: -5px;
  width: 100%;
`
export const UpcomingEventContainer = styled.View`
  margin-top: 5px;
  margin-bottom: 7px;
  margin-left: 10px;
  margin-right: 10px;
  background-color: ${(props: Props) => props.theme.eventBox.background};
  border-radius: 15px;
  border-color: ${(props: Props) => props.theme.eventBox.border};
  border-width: 0.5px;
  padding: 10px;
`
export const UpcomingEventDateHostContainer = styled.View`
  margin-right: 10px;
  min-width: 65%;
`
export const UpcomingEventTitle = styled(CenteredText)`
  font-family: ${font.extraBold};
  color: ${(props: Props) => props.theme.main.text};
  font-size: 13px;
  padding-bottom: 5px;
`
export const EventNameContainer = styled.View`
  margin-top: -2px;
`
