import React, { PropsWithChildren } from "react"
import {
  useAnimatedStyle,
  useSharedValue,
  withTiming,
} from "react-native-reanimated"

import {
  AVATAR_ACTIVE_INDICATOR_PLUS_SIZE,
  AVATAR_ACTIVE_INDICATOR_SIZE,
  AVATAR_CONTAINER_SIZE,
  ProfileActiveIndicator,
  ProfileContainer,
} from "./Styled"

type Props = {
  isActive: boolean
  isVideoCallMode: boolean
  isSharedScreen: boolean
}
const VIDEO_BORDER_RADIUS = 20
const INDICATOR_BORDER_RADIUS =
  VIDEO_BORDER_RADIUS + AVATAR_ACTIVE_INDICATOR_PLUS_SIZE / 2
const AVATAR_BORDER_RADIUS = AVATAR_CONTAINER_SIZE

const getBorderRadius = (isVideoCallMode: boolean) =>
  isVideoCallMode ? VIDEO_BORDER_RADIUS : AVATAR_BORDER_RADIUS
const getIndicatorRadius = (isVideoCallMode: boolean) =>
  isVideoCallMode ? INDICATOR_BORDER_RADIUS : AVATAR_ACTIVE_INDICATOR_SIZE

const ProfileWrapperComponent: React.FC<PropsWithChildren<Props>> = ({
  isActive,
  isVideoCallMode,
  isSharedScreen,
  children,
}) => {
  const borderRadiusRef = React.useRef(getBorderRadius(isVideoCallMode))
  const borderRadius = useSharedValue(borderRadiusRef.current)
  const indicatorRadius = useSharedValue(getIndicatorRadius(isVideoCallMode))

  const containerStyle = useAnimatedStyle(() => ({
    borderRadius: borderRadius.value,
  }))
  const indicatorStyle = useAnimatedStyle(() => ({
    borderRadius: indicatorRadius.value,
  }))

  React.useEffect(() => {
    const toValue = getBorderRadius(isVideoCallMode)
    if (toValue !== borderRadiusRef.current) {
      borderRadiusRef.current = toValue
      borderRadius.value = withTiming(toValue, { duration: 150 })
    }
    indicatorRadius.value = withTiming(getBorderRadius(isVideoCallMode), {
      duration: 150,
    })
  }, [borderRadius, indicatorRadius, isVideoCallMode])

  return (
    <ProfileActiveIndicator
      active={isActive}
      isSharedScreen={isSharedScreen}
      style={indicatorStyle}
    >
      <ProfileContainer style={containerStyle}>{children}</ProfileContainer>
    </ProfileActiveIndicator>
  )
}

export const ProfileWrapper = React.memo(ProfileWrapperComponent)
