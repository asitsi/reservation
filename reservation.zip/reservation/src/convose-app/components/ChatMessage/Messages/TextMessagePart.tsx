import React from "react"
import { GestureResponderEvent, Text, TextStyle } from "react-native"
import { emojiRegex } from "./utils"

const emojiStyle = { fontFamily: "System" }

type Style = TextStyle & { backgroundColor?: string }
type Props = {
  children: string
  style?: Style
  onPress?: ((event: GestureResponderEvent) => void) | undefined
}
const TextMessagePartComponent: React.FC<Props> = ({
  children,
  style,
  onPress,
}) => {
  const emojis = children.match(emojiRegex) || []
  const strings = children.split(emojiRegex)

  return (
    <Text style={style} onPress={onPress}>
      {strings.map((val, index) => (
        // eslint-disable-next-line react/no-array-index-key
        <Text key={index}>
          {val}
          {emojis[index] && (
            <Text style={emojiStyle}>{emojis[index] || ""}</Text>
          )}
        </Text>
      ))}
    </Text>
  )
}

export const TextMessagePart = React.memo(TextMessagePartComponent)
