import { Platform } from "react-native"

export const isAndroid = Platform.OS === "android"

const SPEAKER_MODES = [3, 4]
export const isSpeakerActive = (speakerMode: number) => {
  return SPEAKER_MODES.includes(speakerMode)
}
