import * as React from "react"
import { EmitterSubscription, Platform, UIManager } from "react-native"
import { connect } from "react-redux"
import _ from "lodash"
import { SafeAreaProvider } from "react-native-safe-area-context"
import * as Linking from "expo-linking"
import { ThemeProvider } from "styled-components"
import * as ScreenOrientation from "expo-screen-orientation"
import codePush from "react-native-code-push"

import { AppAction, initApis, selectIsDarkMode } from "convose-lib/app"
import { logEvent, registerAnalytics } from "convose-lib/services"
import { State } from "convose-lib/store"
import { selectMyUuid } from "convose-lib/user"
import {
  handleConvoseUniversalLinks,
  isValidConvoseUrl,
} from "convose-lib/utils"
import { deploymentKey } from "../../../../settings"
import {
  createConvoseAlertRef,
  createModalAlertRef,
} from "../../RootConvoseAlert"
import {
  componentColorsLight,
  componentColorsDark,
} from "../../../styles/colors"
import CallingNotification from "../../components/CallingNotification/CallingNotification"
import { MainViewWrapper, StyledRootStack } from "./Styled"
import { ConvoseAlert } from "../ConvoseAlert"
import { AppVersionControl } from "./AppVersionControl"
import { AppStateControl } from "./AppStateControl"
import { Ping } from "./Ping"
import { ScreenOrientationHandler } from "./ScreenOrientationHandler"
import { CallingDisplayText } from "./CallingDisplayText"
import { InAnotherCall } from "./InAnotherCall"
import { AppToast } from "./AppToast"
import { AppNotifications } from "./AppNotifications"
import { NetRecovery } from "./NetRecovery"
import { RegisterRN } from "./RegisterPN"
import { AuthDisplayText } from "./AuthDisplayText"
import { PushNotificationHandler } from "./PushNotificationHandler"
import { NavigationWatcher } from "./NavigationWatcher"
import { TaskManagerHandler } from "./TaskManager"
import { CallingEngine } from "./CallingEngine"
import { ModalAlert } from "../ModalAlert"
import { ThemeHandler } from "./ThemeHandler"
import { GroupCallSocketChecker } from "./GroupCallSocketChecker"
import { StatusBarAuto } from "../StatusBarAuto"
import { RefreshUser } from "./RefreshUser"

if (Platform.OS === "android") {
  if (UIManager.setLayoutAnimationEnabledExperimental) {
    UIManager.setLayoutAnimationEnabledExperimental(true)
  }
}

type MainViewProps = {
  readonly isDarkMode: boolean | null
  readonly myUuid: string
}

type MainViewDispatchProps = {
  readonly initApp: () => void
}

type MainViewPropsType = MainViewProps & MainViewDispatchProps

const handleUrl = (url: string) => {
  if (isValidConvoseUrl(url)) {
    handleConvoseUniversalLinks(url)
  }
}

const prepareResources = () => {
  initApis()
    .then()
    .catch(() => {
      logEvent("failedToInit")
    })
  if (!__DEV__) {
    codePush
      .sync({
        deploymentKey,
        installMode: codePush.InstallMode.ON_NEXT_RESTART,
      })
      .then()
      .catch(() => {
        logEvent("failedToGetCodePush")
      })
  }
}
class MainViewComponent extends React.Component<MainViewPropsType> {
  public linkingListener!: EmitterSubscription

  public async componentDidMount(): Promise<void> {
    ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.PORTRAIT_UP)
      .then()
      .catch()

    this.initApp()
    prepareResources()

    Linking.getInitialURL()
      .then((url) => {
        if (url) {
          Linking.canOpenURL(url)
            .then((supported) => {
              if (supported) {
                handleUrl(url)
              }
            })
            .catch()
        }
      })
      .catch()

    this.linkingListener = Linking.addEventListener("url", (event) => {
      Linking.canOpenURL(event.url).then((supported) => {
        if (supported) {
          handleUrl(event.url)
        }
      })
    })
  }

  shouldComponentUpdate(nextProps: Readonly<MainViewPropsType>): boolean {
    return !_.isEqual(this.props, nextProps)
  }

  public async componentDidUpdate(prevProps: MainViewPropsType): Promise<void> {
    const { myUuid } = this.props

    if (prevProps.myUuid !== myUuid && !!myUuid) {
      registerAnalytics(myUuid)
    }
  }

  componentWillUnmount() {
    this.linkingListener.remove()
  }

  public initApp = () => {
    const { initApp } = this.props
    initApp()
  }

  public render(): React.ReactNode {
    const { isDarkMode } = this.props

    return (
      <ThemeProvider
        theme={isDarkMode ? componentColorsDark : componentColorsLight}
      >
        <SafeAreaProvider>
          <MainViewWrapper>
            <RefreshUser />
            <StatusBarAuto hideSplash />
            <ThemeHandler />
            <ScreenOrientationHandler />
            <AppStateControl />
            <NetRecovery />
            <NavigationWatcher />
            <RegisterRN />
            <TaskManagerHandler />
            <PushNotificationHandler />
            <AppVersionControl />
            <Ping />
            <StyledRootStack />
            <AppToast />
            <AppNotifications />
            <CallingEngine />
            <GroupCallSocketChecker />
            <CallingNotification />
            <CallingDisplayText />
            <InAnotherCall />
            <ConvoseAlert ref={createConvoseAlertRef} />
            <ModalAlert ref={createModalAlertRef} />
            <AuthDisplayText />
          </MainViewWrapper>
        </SafeAreaProvider>
      </ThemeProvider>
    )
  }
}

const mapStateToProps = (state: State): MainViewProps => ({
  isDarkMode: selectIsDarkMode(state),
  myUuid: selectMyUuid(state),
})

const mapDispatchToProps: MainViewDispatchProps = {
  initApp: AppAction.initializeApp,
}
// MainViewComponent.whyDidYouRender = {
//   logOnDifferentValues: false,
//   customName: "MainViewComponent",
//   diffNameColor: "red",
// }
export const MainView = connect(
  mapStateToProps,
  mapDispatchToProps
)(MainViewComponent)
