import React, { Ref, memo } from "react"
import _, { noop } from "lodash"

import { UserInterest } from "convose-lib"
import { InterestList, InterestListRef } from "./InterestList"

type Props = {
  interestListRef: Ref<InterestListRef>
  interests: UserInterest[]
  onDelete: (interest: UserInterest) => void
  openRatingWheel: (interest: UserInterest) => void
  longPressInterest: (interest: UserInterest) => void
  onboarded: boolean
  sortInterestOnBoarded: () => void
}

const InterestListHandlerComponent: React.FC<Props> = ({
  interestListRef,
  interests,
  onDelete,
  openRatingWheel,
  longPressInterest,
  onboarded,
  sortInterestOnBoarded,
}) => {
  return (
    <InterestList
      ref={interestListRef}
      interests={_.uniqBy(Array.from(interests), "id")}
      deleteSuccess={noop}
      onDelete={onDelete}
      openRatingWheel={openRatingWheel}
      longPressInterest={longPressInterest}
      onboarded={onboarded}
      sortInterestOnBoarded={sortInterestOnBoarded}
    />
  )
}

export const InterestListHandler = memo(InterestListHandlerComponent)
