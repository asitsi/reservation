import React from "react"
import { FadeIn, FadeOut, ZoomIn, ZoomOut } from "react-native-reanimated"

import {
  Wrapper,
  BackgroundEmptyView,
  ModalContainer,
  ModalTitle,
  ModalDescription,
  BackgroundEmptyViewContainer,
  TitleDescriptionContainer,
  ButtonsContainer,
  ButtonText,
  StyledPressable,
} from "./Styled"

type ButtonType = {
  title: string
  onPress?: () => void
  type?: "default" | "warning"
  primaryChoice?: boolean
}
const Button: React.FC<ButtonType> = ({
  title,
  onPress,
  type = "default",
  primaryChoice,
}) => {
  return (
    <StyledPressable onPress={onPress}>
      <ButtonText
        adjustsFontSizeToFit
        numberOfLines={1}
        warning={type === "warning"}
        primaryChoice={primaryChoice}
      >
        {title}
      </ButtonText>
    </StyledPressable>
  )
}

type Props = unknown

type ModalType = {
  title?: string
  description?: string
  buttons: ButtonType[]
}

type State = {
  isShowing: boolean
} & ModalType

export class ModalAlert extends React.PureComponent<Props, State> {
  public state: State = {
    isShowing: false,
    title: "",
    description: "",
    buttons: [],
  }

  public onDismiss = () => {
    this.setState({
      isShowing: false,
    })
  }

  // eslint-disable-next-line react/no-unused-class-component-methods
  public show = (props: ModalType) => {
    const { buttons, description, title } = props
    this.setState({
      isShowing: true,
      buttons,
      description,
      title,
    })
  }

  render(): React.ReactNode {
    const { isShowing, buttons, description, title } = this.state
    if (!isShowing) {
      return null
    }
    return (
      <Wrapper>
        <BackgroundEmptyViewContainer onPress={this.onDismiss}>
          <BackgroundEmptyView
            entering={FadeIn.duration(150)}
            exiting={FadeOut.duration(50)}
          />
        </BackgroundEmptyViewContainer>
        <ModalContainer entering={ZoomIn} exiting={ZoomOut}>
          <TitleDescriptionContainer>
            {!!title && (
              <ModalTitle adjustsFontSizeToFit numberOfLines={1}>
                {title}
              </ModalTitle>
            )}
            {!!description && (
              <ModalDescription adjustsFontSizeToFit numberOfLines={4}>
                {description}
              </ModalDescription>
            )}
          </TitleDescriptionContainer>
          <ButtonsContainer>
            {buttons.map((button, index) => (
              <Button
                // eslint-disable-next-line react/no-array-index-key
                key={`${index}-${button.title}`}
                title={button.title}
                type={button.type}
                primaryChoice={button.primaryChoice}
                onPress={() => {
                  this.onDismiss()
                  button.onPress && button.onPress()
                }}
              />
            ))}
          </ButtonsContainer>
        </ModalContainer>
      </Wrapper>
    )
  }
}
