import { View } from "react-native"
import styled from "styled-components/native"

import { CenteredText, color, font, Props } from "convose-styles"
import Animated from "react-native-reanimated"

export const pnSwitchButtonStyle = { height: 20, width: 40 }
export const trackColorLight = {
  true: color.blue_transparent,
  false: color.gray,
}
export const trackColorDark = {
  true: color.blue_transparent,
  false: color.trackColorOffDark,
}

export const iconColor = {
  true: color.white,
  false: color.white,
}

// ${(props: { slideUp: boolean }) => (props.slideUp ? `` : `flex: 1;`)}
export const ChatMenuScreenWrapper = styled(View)`
  width: 100%;
`

export const ChatMenuHeaderWrapper = styled(View)``

export const ChatScreenWrapper = styled(View)`
  flex: 1;
  flex-direction: column;
  justify-content: flex-end;
  background-color: ${(props: Props) => props.color || props.theme.statusBar};
`
export const ChatboxHeader = styled(View)`
  flex-direction: column;
  justify-content: center;
  align-items: center;
`
export const ParticipantsPermissionsContainer = styled.View`
  padding: 10px;
  justify-content: center;
  align-items: center;
`
export const ParticipantsPermissionsHeaderContainer = styled.View`
  justify-content: center;
  align-items: center;
`
export const ParticipantsPermissionsHeader = styled(CenteredText)`
  color: ${(props: Props) => props.theme.main.text};
  font-family: ${font.semiBold};
  font-size: 24px;
  margin-bottom: 29px;
  margin-top: 29px;
`

export const Username = styled(CenteredText)`
  color: ${(props: Props & { themeColor?: string }) =>
    props.themeColor || props.theme.main.text};
  font-family: ${font.bold};
  font-size: 22px;
  line-height: 27px;
  max-width: 220px;
  text-align: center;
  text-transform: capitalize;
`
export const WaveButtonContainer = styled.View`
  margin-left: 10px;
  margin-bottom: 10px;
`
export const UsernameInputContainer = styled.View``
export const UsernameContainer = styled(Animated.View)`
  justify-content: center;
  align-items: center;
  flex-direction: row;
  margin-top: 10px;
  min-height: 48px;
`
export const AvatarContainer = styled(View)``

export const GroupInterestsTitle = styled(CenteredText)`
  font-family: Popins-bold;
  color: ${(props: Props) => props.theme.main.text};
  align-self: center;
  margin-top: 15px;
  font-size: 14px;
`
export const InterestsContainer = styled.View``
export const EditGroupInterestsContainer = styled(Animated.View)`
  width: 100%;
`

export const EditGroupInterestsScrollContainer = styled(Animated.ScrollView)`
  max-height: 300px;
  padding-top: 3px;
`
export const GroupInterests = styled(Animated.View)`
  flex-direction: row;
  justify-content: center;
  flex-wrap: wrap;
  margin-bottom: 10px;
`

export const EditGroupInterestsDescription = styled(CenteredText)`
  padding-bottom: 15px;
  font-family: Popins;
  color: ${(props: Props) => props.theme.main.text};
  align-self: center;
  font-size: 14px;
  text-align: center;
  flex: 1;
`
export const ButtonWrapper = styled.TouchableOpacity`
  border-radius: 50px;
  text-align: center;
  padding-vertical: 15px;
  padding-right: 15px;
  padding-left: 10px;
  background: ${(props: Props) => props.theme.mainBlue};
  justify-content: center;
  align-items: center;
  flex-direction: row;
  width: 170px;
  align-self: center;
  margin-top: 10px;
`
export const Label = styled(CenteredText)`
  font-family: Popins-medium;
  font-size: 15px;
  text-align: center;
  color: ${color.white};
  margin-left: 5px;
  include-font-padding: false;
  text-align-vertical: center;
`
export const GroupAvatarContainer = styled.View``
export const LoadingAvatarContainer = styled.View`
  height: ${(props: { size: number }) => props.size || 0}px;
  width: ${(props: { size: number }) => props.size || 0}px;
`
export const GroupAvatarEditButtonContainer = styled.View`
  position: absolute;
  bottom: ${(props: { hasAvatar: boolean }) => (props.hasAvatar ? 15 : 0)}px;
  right: ${(props: { hasAvatar: boolean }) => (props.hasAvatar ? 15 : 0)}px;
`
export const AddGroupBackgroundContainer = styled.TouchableOpacity`
  width: 85px;
  justify-content: center;
  align-items: center;
  position: absolute;
  top: 0px;
  right: 0px;
  z-index: 20;
  /* background-color: red; */
`
export const BlueLabel = styled(Label)`
  color: ${(props: Props) => props.theme.mainBlue};
  font-size: 13px;
  margin-left: 0px;
  font-family: Popins-bold;
`
export const EditButtonContainer = styled.View`
  margin-right: 5px;
`
export const UserThemeBanner = styled.View`
  background-color: ${(props: { bgColor: string }) =>
    props.bgColor || "transparent"};
  height: 90px;
  width: 100%;
  position: absolute;
  border-top-right-radius: 14px;
  border-top-left-radius: 14px;
`

export const LoadingGroupEventsWrapper = styled(Animated.View)``
export const LoadingGroupEventsContainer = styled(Animated.View)`
  width: 100%;
  align-items: center;
  flex-direction: row;
  justify-content: center;
`
const AnimatedCenteredText = Animated.createAnimatedComponent(CenteredText)
export const GroupEventsSavingChanges = styled(AnimatedCenteredText)`
  font-family: ${font.light};
  color: ${(props: Props) => props.theme.main.text};
  font-size: 20px;
  top: 0px;
  margin-left: 15px;
`
export const GroupEventsContainer = styled.View`
  min-height: 100px;
  align-items: center;
  justify-content: center;
  width: 100%;
  margin-bottom: 30px;
`

export const GroupEventsNoEvent = styled(AnimatedCenteredText)`
  font-family: ${font.light};
  color: ${(props: Props) => props.theme.main.text};
  font-size: 20px;
`
