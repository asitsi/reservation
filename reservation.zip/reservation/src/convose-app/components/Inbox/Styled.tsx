import styled from "styled-components/native"
import { StyleSheet } from "react-native"

import { CenteredText, Props, color, font } from "convose-styles"

export const style = StyleSheet.create({
  headerStyle: {
    zIndex: 1000,
  },
})

export const InboxWrapper = styled.View`
  flex: 1;
`

export const ConversationsWrapper = styled.View`
  flex: 1;
`

export const ScrollViewWrapper = styled.View``

export const EmptyStateContainer = styled.View`
  width: 100%;
  height: 100%;
  justify-content: center;
  align-items: center;
`
export const EmptyStateDescription = styled(CenteredText)`
  font-family: ${font.light};
  font-size: 18px;
  color: ${(props: Props) => props.theme.main.text};
  text-align: center;
`
export const EmptyStateIconContainer = styled.View`
  width: 100%;
  align-items: center;
  margin-bottom: 30px;
`

export const DeleteChatButton = styled.View`
  background-color: ${color.orange};
  justify-content: center;
  align-items: center;
  width: 81px;
  height: 81px;
  border-radius: 16px 0px 0px 16px;
`
