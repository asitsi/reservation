import React from "react"
import { ColorValue } from "react-native"
import { useTheme } from "styled-components"

import { resolveObjectPath } from "convose-lib/utils"

import { IndicatorLocations } from "./types"
import { OnlineIndicator } from "../OnlineIndicator"
import { RingContainer, getLocationSize } from "./Styled"

type PresenceIndicatorType = {
  readonly isOnline?: boolean
  readonly isGroupCallChat?: boolean
  readonly location?: IndicatorLocations
  readonly hideOnlineIndicator?: boolean
  readonly ringColor?: ColorValue
  readonly ringColorCode?: string
  readonly offlineIndicatorColor?: ColorValue
  readonly offlineIndicatorColorCode?: string
}

const PresenceIndicatorComponent: React.FunctionComponent<
  React.PropsWithChildren<PresenceIndicatorType>
> = ({
  children,
  isOnline,
  isGroupCallChat = false,
  location = "chatBox",
  hideOnlineIndicator = false,
  offlineIndicatorColor,
  offlineIndicatorColorCode,
  ringColor,
  ringColorCode,
}) => {
  const theme = useTheme()
  const ringSize = getLocationSize(location, true)
  const onlineIndicatorSize = getLocationSize(location)
  const offlineRingSize = getLocationSize(location, false, true)
  const getColor = React.useCallback(
    (color?: ColorValue, colorCode?: string) => {
      if (color) {
        return color
      }
      if (colorCode) {
        return resolveObjectPath(colorCode, theme)
      }
      return undefined
    },
    [theme]
  )

  const offlineColor = getColor(
    offlineIndicatorColor,
    offlineIndicatorColorCode
  )

  const outerRingColor = getColor(ringColor, ringColorCode)

  return (
    <>
      {children}
      {!isGroupCallChat && !hideOnlineIndicator && (
        <RingContainer
          size={ringSize}
          location={location}
          color={outerRingColor}
        >
          <OnlineIndicator
            isOnline={!!isOnline}
            offlineIndicatorColor={offlineColor}
            size={onlineIndicatorSize}
            offlineRingSize={offlineRingSize}
          />
        </RingContainer>
      )}
    </>
  )
}
export const PresenceIndicator = React.memo(PresenceIndicatorComponent)
