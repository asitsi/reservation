import { Easing, SlideInUp, SlideOutUp } from "react-native-reanimated"

export const HeaderEntering = SlideInUp.duration(50).easing(
  Easing.bezier(0, 1, 0.07, 1)
)
export const HeaderExiting = SlideOutUp.duration(100)
