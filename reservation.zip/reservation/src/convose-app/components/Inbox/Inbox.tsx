/* eslint-disable @typescript-eslint/no-explicit-any */
import * as React from "react"
import { NativeScrollEvent } from "react-native"
import { connect } from "react-redux"
import _ from "lodash"
import { withSafeAreaInsets } from "react-native-safe-area-context"

import { ChatSummary } from "convose-lib/chat"
import { State } from "convose-lib/store"
import {
  selectLoadingPartnerFeature,
  selectPartnerHasNextPage,
  selectPartnersFeature,
  UsersListAction,
} from "convose-lib/users-list"
import { PARTNER_LIMIT } from "convose-lib/utils/const"
import { NavigationProps } from "convose-app"
import { SafeAreaProps } from "convose-lib/generalTypes"
import { BlueMaterialIndicator } from "../MaterialIndicator"
import {
  ConversationsWrapper,
  EmptyStateContainer,
  EmptyStateDescription,
  EmptyStateIconContainer,
  InboxWrapper,
  style,
} from "./Styled"
import {
  InboxConversationBox,
  InboxConversationBoxSkeleton,
} from "../InboxConversationBox"
import { Header } from "../../components/Header"
import * as RootNavigation from "../../RootNavigation"
import { InboxRefreshControl } from "./InboxRefreshControll"
import { List, ListComponentRef } from "./List"
import { InboxFilters } from "./InboxFilters"
import { InboxFloatingNewGroupButton } from "./InboxFloatingNewGroupButton"
import EnvelopIcon from "../../../assets/Icons/components/EnvelopIcon"

const goHome = () => {
  RootNavigation.goBack()
}

const renderConversationBoxes =
  (loadingPartner: boolean) => (partner: { item: ChatSummary }) => {
    const { item } = partner
    if (/loading/.test(item.channel)) {
      if (loadingPartner) {
        return <InboxConversationBoxSkeleton />
      }
      return null
    }
    return (
      <InboxConversationBox
        key={item.channel}
        chatSummary={item}
        useDefaultBackgroundForGroups={false}
        forceDefaultTextColor
      />
    )
  }

type StateToProps = {
  readonly partners: ReadonlyArray<ChatSummary> | null
  readonly loadingPartner: boolean
  readonly hasNextPage: boolean
}

type DispatchToProps = {
  readonly getPartnersList: (from: number, limit: number) => void
  readonly setIsInInboxScreen: (isInInboxScreen: boolean) => void
}

type AllProps = StateToProps & DispatchToProps & NavigationProps & SafeAreaProps
type InboxState = {
  isPullToRefresh: boolean
}

const hasReachedEnd = (event: NativeScrollEvent, paddingToBottom: number) => {
  const { layoutMeasurement, contentOffset, contentSize } = event
  return (
    layoutMeasurement.height + contentOffset.y >=
    contentSize.height - paddingToBottom
  )
}
export class InboxComponent extends React.Component<AllProps, InboxState> {
  public focusUnsubscribe!: () => void

  public blurUnsubscribe!: () => void

  public listComponentRef = React.createRef<ListComponentRef>()

  public state: Readonly<InboxState> = {
    isPullToRefresh: false,
  }

  componentDidMount(): void {
    // control to stop refreshing while texting in a chat
    const { navigation, partners, getPartnersList, loadingPartner } = this.props
    if ((!partners || partners.length === 0) && !loadingPartner) {
      getPartnersList(0, PARTNER_LIMIT)
    }
    this.focusUnsubscribe = navigation.addListener("focus", this.onScreenFocus)
    this.blurUnsubscribe = navigation.addListener("blur", this.onScreenBlur)
  }

  public shouldComponentUpdate(prevProps: AllProps): boolean {
    return !_.isEqual(this.props, prevProps)
  }

  public componentDidUpdate(prevProps: AllProps): void {
    const { loadingPartner } = this.props
    const { isPullToRefresh } = this.state

    if (prevProps.loadingPartner && !loadingPartner) {
      if (isPullToRefresh) {
        this.setState({
          isPullToRefresh: false,
        })
      }
    }
  }

  componentWillUnmount(): void {
    this.focusUnsubscribe && this.focusUnsubscribe()
    this.blurUnsubscribe && this.blurUnsubscribe()
    this.onScreenBlur()
  }

  getContainerStyle = () => {
    const { insets } = this.props
    return { paddingBottom: 70 + insets.bottom, flexGrow: 1 }
  }

  public onScreenFocus = () => {
    const { setIsInInboxScreen } = this.props
    setIsInInboxScreen(true)
  }

  public onScreenBlur = () => {
    const { setIsInInboxScreen } = this.props
    setIsInInboxScreen(false)
  }

  private readonly handleOnEndReached = () => {
    const { partners, getPartnersList, loadingPartner, hasNextPage } =
      this.props
    if (!loadingPartner && hasNextPage) {
      getPartnersList(partners ? partners.length : 0, PARTNER_LIMIT)
    }
  }

  private checkHasReachedEnd = (event: NativeScrollEvent) => {
    const {
      insets: { bottom },
    } = this.props
    const paddingToBottom = 160 + bottom
    if (hasReachedEnd(event, paddingToBottom)) {
      this.handleOnEndReached()
    }
  }

  private readonly onRefresh = () => {
    const { getPartnersList } = this.props
    this.setState({
      isPullToRefresh: true,
    })
    getPartnersList(0, PARTNER_LIMIT)
  }

  private renderListEmptyComponent = (): React.ReactElement => {
    const { loadingPartner } = this.props
    if (loadingPartner) {
      return <BlueMaterialIndicator />
    }
    return (
      <EmptyStateContainer>
        <EmptyStateIconContainer>
          <EnvelopIcon height={150} />
        </EmptyStateIconContainer>
        <EmptyStateDescription>
          Looks like there’s nothing here!
        </EmptyStateDescription>
        <EmptyStateDescription>
          go back and start some conversations
        </EmptyStateDescription>
      </EmptyStateContainer>
    )
  }

  getPartners = () => {
    const { partners, loadingPartner } = this.props
    if (partners && partners.length) {
      return [
        ...partners,
        { channel: "loading1" } as ChatSummary,
        { channel: "loading2" } as ChatSummary,
        { channel: "loading3" } as ChatSummary,
        { channel: "loading4" } as ChatSummary,
      ]
    }
    if (loadingPartner) {
      return [
        { channel: "loading1" } as ChatSummary,
        { channel: "loading2" } as ChatSummary,
        { channel: "loading3" } as ChatSummary,
        { channel: "loading4" } as ChatSummary,
        { channel: "loading5" } as ChatSummary,
        { channel: "loading6" } as ChatSummary,
        { channel: "loading7" } as ChatSummary,
        { channel: "loading8" } as ChatSummary,
      ]
    }
    return []
  }

  public render(): React.ReactNode {
    const { loadingPartner } = this.props
    const { isPullToRefresh } = this.state

    const partnersWithLoading = this.getPartners()
    return (
      <InboxWrapper>
        <Header
          onBackPress={goHome}
          title="Inbox"
          textColor="SystemDefault"
          headerStyle={style.headerStyle}
          // filterButtonItems={filterButtonItems}
        />
        <ConversationsWrapper>
          <List
            ref={this.listComponentRef}
            data={partnersWithLoading}
            keyExtractor={(chat) => chat.channel}
            extraData={loadingPartner}
            renderItem={renderConversationBoxes(loadingPartner)}
            onScroll={this.checkHasReachedEnd}
            contentContainerStyle={this.getContainerStyle()}
            ListEmptyComponent={this.renderListEmptyComponent()}
            ListHeaderComponent={<InboxFilters />}
            refreshControl={
              <InboxRefreshControl
                onRefresh={this.onRefresh}
                refreshing={loadingPartner && isPullToRefresh}
              />
            }
          />
        </ConversationsWrapper>
        <InboxFloatingNewGroupButton
          translationY={this.listComponentRef.current?.translationY}
        />
      </InboxWrapper>
    )
  }
}

const mapStateToProps = (state: State): StateToProps => ({
  partners: selectPartnersFeature(state),
  loadingPartner: selectLoadingPartnerFeature(state),
  hasNextPage: selectPartnerHasNextPage(state),
})
const mapDispatchToProps: DispatchToProps = {
  getPartnersList: UsersListAction.getPartnersList,
  setIsInInboxScreen: UsersListAction.setIsInInboxScreen,
}
// InboxComponent.whyDidYouRender = {
//   logOnDifferentValues: false,
//   customName: "InboxComponent",
//   diffNameColor: "red",
// }
export const Inbox = connect(
  mapStateToProps,
  mapDispatchToProps
)(withSafeAreaInsets(InboxComponent))
