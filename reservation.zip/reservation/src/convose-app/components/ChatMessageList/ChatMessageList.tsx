import React from "react"
import {
  ViewToken,
  NativeScrollEvent,
  NativeSyntheticEvent,
  View,
  Platform,
} from "react-native"
import { FlatList } from "@stream-io/flat-list-mvcp"
import { connect } from "react-redux"
import { Dispatch } from "redux"
import { noop } from "rxjs"
import { withSafeAreaInsets } from "react-native-safe-area-context"

import {
  ChatChannel,
  ChatUser,
  Message,
  MessageToPublish,
  selectRetrievingHistory,
  selectPagesLeft,
  selectActualPage,
  ChatAction,
  selectUnreadMentions,
  BlockSendContent,
  selectForceChatUpdate,
  MessageType,
} from "convose-lib/chat"
import { UserInterest, InterestLocation } from "convose-lib/interests"
import { Avatar, selectUserActive, selectUserInterests } from "convose-lib/user"
import { DEFAULT_HIT_SLOP, MESSAGE_LIMIT } from "convose-lib/utils"
import { appHeaderHeight, color, statusBarHeight } from "convose-styles"
import { State } from "convose-lib"
import { SafeAreaProps } from "convose-lib/generalTypes"

import { isEqual, uniqBy } from "lodash"
import {
  selectScreenOrientation,
  ScreenOrientationTypes,
} from "convose-lib/app"
import { selectIsGroupAdmin } from "convose-lib/users-list"
import { Routes } from "convose-lib/router"
import SimpleEditIcon from "../../../assets/Icons/components/SimpleEditIcon"
import { checkForNewMassages } from "./utils"
import {
  CommonInterests,
  CommonInterestsList,
  RetrievingHistoryText,
  Blank,
  ButtonWrapper,
  Label,
  MessageListFooter,
  EditGroupInterestsContainer,
  EditGroupInterestsTitle,
  EditGroupInterestsTitleWrapper,
  EditGroupInterestsIconContainer,
  GroupInterestTitle,
  EditGroupQuickButtons,
  StyledSimpleEditIcon,
  StyledAddGroupIcon,
  StyledGroupParticipantsIcon,
  GroupAvatarNameContainer,
  GroupName,
  GroupCreator,
} from "./Styled"
import { ChatInfo } from "../../components/ChatInfo"
import { IconButton } from "../../components/IconButton"
import { InterestButton } from "../../components/InterestButton"
import ChatMessageWrapper from "./ChatMessageWrapper"
import { ChatListTypingIndicator } from "./ChatListTypingIndicator"
import { PrimaryButton } from "../PrimaryButton"
import { QuickEditButton } from "./QuickEditButton"
import { GroupAvatar } from "../Avatar"
import { createGroupAction } from "../ChatMenu/MenuItems"
import * as RootNavigation from "../../RootNavigation"
import { MessageList } from "./MessageList"

const skipEditGroup = true
const isAndroid = Platform.OS === "android"

type ListMessage = Message | MessageToPublish
type Messages = ReadonlyArray<ListMessage>
type ChatMessageListProps = {
  readonly chatChannel: ChatChannel
  readonly chatUser: ChatUser | null
  readonly getHistory: (
    chatChannel: ChatChannel,
    page: number,
    size: number
  ) => void
  readonly isGroup: boolean
  readonly markAsRead: (chatChannel: ChatChannel) => void
  readonly messages: Messages
  readonly isFullScreenVideoCall: boolean
  readonly me: ChatUser
  readonly setFullScreenImage: (uri: { uri: string } | undefined) => void
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  readonly setMessageListRef: (element: any) => void
  readonly isChatHide: boolean
  readonly isHeaderHide: boolean
  readonly onUpdateReaction: (
    emoji: string,
    messageUuid: string,
    reacted: boolean
  ) => void
  readonly dismissSelectedMessage: (noToggleHeader?: boolean) => void
  readonly callingPanelRef?: View
  readonly isInCallingChat: boolean
  readonly groupAvatar?: Avatar
  readonly groupName?: string
  readonly participants?: ChatUser[]
  readonly showProfile: () => void
  readonly groupInterests?: UserInterest[]
  readonly groupCreator?: ChatUser
  readonly endCall: ({ displayText }: { displayText: boolean }) => void
  readonly setChatTranslateYOffset: (value: number) => void
  readonly hideSwipeCallOnboarding: () => void
} & BlockSendContent

type StateToProps = {
  readonly retrievingHistory: boolean
  readonly actualPage: number
  readonly pagesLeft: number
  readonly interests: ReadonlyArray<UserInterest>
  readonly unreadMentions: ReadonlyArray<string>
  readonly userActive: boolean
  readonly screenOrientation: ScreenOrientationTypes
  readonly isGroupAdmin: boolean
  readonly forceChatUpdate: boolean
}

type DispatchToProps = {
  readonly markMentionAsRead: (
    chatChannel: ChatChannel,
    mention: string
  ) => void
  readonly markAllMentionsAsRead: (chatChannel: ChatChannel) => void
}

type ChatMessageListState = {
  hasNewMessage: boolean
  firstPageMentionReady: boolean
  audioQueue: string[]
  currentAudioUUID: string
  selectedMessageUuidToScrollTo?: string
  messageUuidToScaleAnimation?: string
  callingPanelHeight: number
}
const newMsgRenderThreshold = 30

const mentionButtonPosition = 0.5
const indexesInFirstHalfOfScreen = [1, 2, 3, 4, 5, 6]

const createAudioQueueFromSameUser = (
  messages: Messages,
  sender?: string
): string[] => {
  const audioQueue = []
  let index = 0
  const reversedMessages = Array.from(messages).reverse()
  while (index < reversedMessages.length) {
    const message = reversedMessages[index]
    if (
      message.message_type === MessageType.Audio &&
      message.sender === sender
    ) {
      audioQueue.push(message.uuid)
    } else {
      break
    }
    index += 1
  }
  return audioQueue
}

enum specialUuids {
  typing = "typing",
  footer = "footer",
}
type AllProps = ChatMessageListProps &
  StateToProps &
  DispatchToProps &
  SafeAreaProps

class ChatMessageListComponent extends React.Component<
  AllProps,
  ChatMessageListState
> {
  public scrollViewRef!: FlatList

  public viewableItems: Messages = []

  public currentScrollOffset = 0

  public readonly state: ChatMessageListState = {
    hasNewMessage: false,
    firstPageMentionReady: false,
    audioQueue: [],
    currentAudioUUID: "",
    messageUuidToScaleAnimation: undefined,
    selectedMessageUuidToScrollTo: undefined,
    callingPanelHeight: 0,
  }

  private scrollYPosition = 0

  private shouldStartToDetectMention = true

  private canMarkMentions = false

  public constructor(props: AllProps) {
    super(props)
    props.setMessageListRef(this)
  }

  // eslint-disable-next-line complexity
  public shouldComponentUpdate(
    prevProps: AllProps,
    prevState: ChatMessageListState
  ): boolean {
    const {
      messages,
      isFullScreenVideoCall,
      unreadMentions,
      userActive,
      me,
      isChatHide,
      insets,
      screenOrientation,
      isHeaderHide,
      isBlocked,
      isGroupAdmin,
      forceChatUpdate,
      isInCallingChat,
    } = this.props
    const {
      hasNewMessage,
      firstPageMentionReady,
      audioQueue,
      currentAudioUUID,
      messageUuidToScaleAnimation,
      selectedMessageUuidToScrollTo,
      callingPanelHeight,
    } = this.state

    const { detectedNewMessage, lastMessageIsNotMine } = checkForNewMassages(
      prevProps.messages,
      messages,
      me.uuid
    )
    this.setShouldStartToDetectMention(userActive, prevProps.userActive)
    if (
      detectedNewMessage &&
      lastMessageIsNotMine &&
      this.scrollYPosition > newMsgRenderThreshold
    ) {
      this.setState({ hasNewMessage: detectedNewMessage })
    }

    return (
      forceChatUpdate !== prevProps.forceChatUpdate ||
      detectedNewMessage ||
      prevProps.messages.length !== messages.length ||
      hasNewMessage !== prevState.hasNewMessage ||
      isFullScreenVideoCall !== prevProps.isFullScreenVideoCall ||
      prevProps.unreadMentions.length !== unreadMentions.length ||
      prevState.firstPageMentionReady !== firstPageMentionReady ||
      prevState.audioQueue !== audioQueue ||
      prevState.currentAudioUUID !== currentAudioUUID ||
      prevState.messageUuidToScaleAnimation !== messageUuidToScaleAnimation ||
      prevState.selectedMessageUuidToScrollTo !==
        selectedMessageUuidToScrollTo ||
      prevProps.isChatHide !== isChatHide ||
      !isEqual(prevProps.insets, insets) ||
      prevProps.screenOrientation !== screenOrientation ||
      prevProps.isHeaderHide !== isHeaderHide ||
      prevProps.isBlocked !== isBlocked ||
      prevProps.isGroupAdmin !== isGroupAdmin ||
      prevProps.isInCallingChat !== isInCallingChat ||
      prevState.callingPanelHeight !== callingPanelHeight
    )
  }

  componentDidUpdate(
    prevProps: Readonly<AllProps>
    // prevState: Readonly<ChatMessageListState>
  ): void {
    const { messages, isInCallingChat } = this.props
    if (
      prevProps.messages.length !== messages.length &&
      this.shouldStartToDetectMention
    ) {
      this.scrollAndMarkFirstPage()
    }
    if (isInCallingChat !== prevProps.isInCallingChat && !isInCallingChat) {
      this.setState({
        callingPanelHeight: 0,
      })
    }
  }

  private setShouldStartToDetectMention(
    userActive: boolean,
    nextUserActive: boolean
  ) {
    if (userActive && !nextUserActive) {
      this.canMarkMentions = false
      this.shouldStartToDetectMention = false
      this.setState({ firstPageMentionReady: false })
    }

    if (!userActive && nextUserActive) {
      this.shouldStartToDetectMention = true
    }
  }

  private readonly renderBlank = () => {
    const { callingPanelHeight } = this.state
    const { insets } = this.props
    // eslint-disable-next-line no-nested-ternary
    const blankMarginTop = callingPanelHeight
      ? isAndroid
        ? (callingPanelHeight * 2) / 3
        : callingPanelHeight / 2 + insets.top
      : 0

    return <Blank marginTop={blankMarginTop} topInsets={insets?.top} />
  }

  private readonly renderCommonInterests = () => {
    const { chatUser, pagesLeft, retrievingHistory, isGroup, groupInterests } =
      this.props
    const interests = chatUser?.interests
    // eslint-disable-next-line react/destructuring-assignment
    const myInterests = this.props.interests

    const rawInterests = isGroup
      ? uniqBy(groupInterests, "name")
      : (interests || []).filter((interest: UserInterest) =>
          myInterests.find(({ name }) => name === interest.name)
        )
    const commonInterests = rawInterests
      ? rawInterests.map((interest: UserInterest) => (
          <InterestButton
            key={interest.name}
            interest={interest}
            disabled
            interestLocation={InterestLocation.Chatbox}
          />
        ))
      : []

    return pagesLeft === 0 && !retrievingHistory && commonInterests.length ? (
      <CommonInterests>
        {isGroup ? (
          <GroupInterestTitle>Group interests:</GroupInterestTitle>
        ) : (
          <ChatInfo text="Common interests:" />
        )}
        <CommonInterestsList>{commonInterests}</CommonInterestsList>
      </CommonInterests>
    ) : null
  }

  private onUnreadButtonPress = (isNewMessageButton: boolean) => () => {
    if (isNewMessageButton) {
      this.scrollToEnd()
    } else {
      this.scrollToMention()
    }
  }

  private onMarkAllMentionsAsReadPress = () => {
    const { markAllMentionsAsRead, chatChannel } = this.props
    markAllMentionsAsRead(chatChannel)
  }

  private readonly renderMentionButton = (): React.ReactNode => {
    const labelText = "unread @mentions"
    const iconName = "chevron-up"
    const top = appHeaderHeight + statusBarHeight + 10
    return (
      <ButtonWrapper
        onPress={this.onUnreadButtonPress(false)}
        hitSlop={DEFAULT_HIT_SLOP}
        top={top}
      >
        <IconButton name={iconName} size={22} iconColor={color.white} />
        <Label>{labelText}</Label>
        <IconButton
          name="close-sharp"
          size={22}
          iconColor={color.white}
          onPress={this.onMarkAllMentionsAsReadPress}
        />
      </ButtonWrapper>
    )
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private setScrollViewRefRef = (element: any) => {
    this.scrollViewRef = element
  }

  private readonly handleOnEndReached = () => {
    const {
      actualPage,
      chatChannel,
      getHistory,
      pagesLeft,
      retrievingHistory,
      callingPanelRef,
      isInCallingChat,
    } = this.props
    // TODO: Check this login about retrieving history again!!
    if (!retrievingHistory && pagesLeft > 0) {
      if (isInCallingChat) {
        callingPanelRef?.measure((x, y, w, panelHeight) => {
          this.setState({
            callingPanelHeight: panelHeight,
          })
        })
      }
      getHistory(chatChannel, actualPage, MESSAGE_LIMIT)
    }
  }

  private readonly scrollToLatest = () => {
    requestAnimationFrame(() => {
      setTimeout(() => {
        this.scrollViewRef && this.scrollViewRef.scrollToIndex({ index: 0 })
        this.scrollYPosition = 0
        this.setState({ hasNewMessage: false })
      }, 1)
    })
  }

  // is being used by ref
  private readonly scrollToEnd = (skipMarkAsRead?: boolean) => {
    const { chatChannel, markAsRead, messages } = this.props
    const messagesLength = messages.length

    if (messagesLength > 0) {
      if (!skipMarkAsRead) {
        markAsRead(chatChannel)
      }
      this.scrollToLatest()
    }
  }

  private readonly scrollAndMarkFirstPage = () => {
    setTimeout(() => {
      this.canMarkMentions = true
      this.shouldStartToDetectMention = false
    }, 4000)
    setTimeout(() => {
      this.scrollViewRef &&
        this.scrollViewRef.scrollToOffset({
          offset: this.scrollYPosition + 0.5,
        })
    }, 4100)
  }

  private scrollToPosition = (index: number) => {
    if (this.scrollViewRef) {
      this.scrollViewRef.scrollToIndex({
        index,
        viewPosition: mentionButtonPosition,
      })
    }
  }

  private readonly scrollToMention = () => {
    const { unreadMentions, messages, chatChannel, markMentionAsRead } =
      this.props
    const messagesList = messages
    const mentionIndex =
      unreadMentions.length > 0
        ? messagesList.findIndex(
            (message) => message.uuid === unreadMentions[0]
          )
        : -1
    if (mentionIndex >= 0) {
      markMentionAsRead(chatChannel, unreadMentions[0])
      this.scrollToPosition(mentionIndex)
    }
  }

  private requestToShowRepliedMessage = (): void => {
    const { selectedMessageUuidToScrollTo } = this.state
    if (selectedMessageUuidToScrollTo) {
      this.setState({
        selectedMessageUuidToScrollTo: undefined,
        messageUuidToScaleAnimation: selectedMessageUuidToScrollTo,
      })
    }
  }

  private scrollToReply = (uuid: string) => {
    const { messages } = this.props
    const messagesList = messages
    const index = messagesList.findIndex((message) => message.uuid === uuid)

    if (index >= 0) {
      const itemIndexOnView = this.viewableItems.findIndex(
        (message) => message.uuid === uuid
      )
      if (indexesInFirstHalfOfScreen.includes(itemIndexOnView)) {
        this.setState({
          messageUuidToScaleAnimation: uuid,
        })
      } else {
        this.setState({
          selectedMessageUuidToScrollTo: uuid,
        })
      }
      this.scrollToPosition(index)
    }
  }

  private readonly handleScroll = (
    event: NativeSyntheticEvent<NativeScrollEvent>
  ) => {
    this.requestToShowRepliedMessage()
    const { hasNewMessage } = this.state
    const { y } = event.nativeEvent.contentOffset
    this.scrollYPosition = y
    if (y < newMsgRenderThreshold && hasNewMessage) {
      this.setState({ hasNewMessage: false })
    }
  }

  // eslint-disable-next-line complexity
  private readonly handleViewableItemsChange = ({
    viewableItems,
  }: {
    viewableItems: ViewToken[]
  }) => {
    this.viewableItems = viewableItems.map((viewableItem) => viewableItem.item)
    const {
      messages,
      unreadMentions,
      chatChannel,
      markMentionAsRead,
      userActive,
    } = this.props
    const { firstPageMentionReady } = this.state
    if (
      userActive &&
      this.canMarkMentions &&
      viewableItems &&
      viewableItems.length > 0 &&
      unreadMentions.length > 0
    ) {
      const topViewableItemIndex =
        viewableItems[Math.round(viewableItems.length / 2)]?.index
      if (!topViewableItemIndex) return
      const messagesList = messages
      const toBeMarkedMentions =
        unreadMentions.length > 0
          ? unreadMentions.filter((mention: string) => {
              const mentionIndex = messagesList.findIndex(
                (message) => message.uuid === mention
              )
              return mentionIndex >= 0 && mentionIndex <= topViewableItemIndex
            })
          : []
      toBeMarkedMentions.forEach((mention: string) =>
        markMentionAsRead(chatChannel, mention)
      )
      !firstPageMentionReady &&
        setTimeout(() => this.setState({ firstPageMentionReady: true }), 500)
    }
  }

  private readonly editGroupInterests = (): React.ReactElement | null => {
    const { isGroup, isGroupAdmin } = this.props
    if (skipEditGroup) {
      return null
    }
    if (isGroup && isGroupAdmin) {
      return (
        <EditGroupInterestsContainer>
          <PrimaryButton
            label=""
            onPress={noop}
            padding={1}
            // eslint-disable-next-line react-perf/jsx-no-new-object-as-prop
            style={{ minWidth: 1 }}
          >
            <EditGroupInterestsTitleWrapper>
              <EditGroupInterestsIconContainer>
                <SimpleEditIcon color={color.white} height={16} />
              </EditGroupInterestsIconContainer>
              <EditGroupInterestsTitle>Interests</EditGroupInterestsTitle>
            </EditGroupInterestsTitleWrapper>
          </PrimaryButton>
        </EditGroupInterestsContainer>
      )
    }
    return null
  }

  private inviteToGroup = () => {
    const { isBlocked, isGroup, showBlockAlert } = this.props
    if (isBlocked) {
      showBlockAlert && showBlockAlert("Invite")
      return
    }
    createGroupAction(isGroup)
  }

  private openGroupMembers = () => {
    const { chatChannel, me, isBlocked } = this.props
    const { uuid } = me
    RootNavigation.navigate(Routes.UserList, {
      chatChannel,
      firstTwoParticipants: [],
      myUuid: uuid,
      disableOnUserPress: isBlocked,
    })
  }

  private readonly renderEditGroup = (): React.ReactElement | null => {
    const { isGroup, showProfile, isGroupAdmin } = this.props
    if (isGroup) {
      return (
        <EditGroupQuickButtons>
          <QuickEditButton title="Invite" onPress={this.inviteToGroup}>
            <StyledAddGroupIcon height={17} />
          </QuickEditButton>
          {isGroupAdmin && (
            <QuickEditButton title="Name" onPress={showProfile}>
              <StyledSimpleEditIcon height={17} />
            </QuickEditButton>
          )}
          <QuickEditButton title="Members" onPress={this.openGroupMembers}>
            <StyledGroupParticipantsIcon height={17} />
          </QuickEditButton>
        </EditGroupQuickButtons>
      )
    }
    return null
  }

  private renderGroupNameAvatar = (): React.ReactElement | null => {
    const { isGroup, groupCreator, participants, groupAvatar, groupName } =
      this.props

    if (isGroup) {
      return (
        <GroupAvatarNameContainer>
          <GroupAvatar
            participants={
              // eslint-disable-next-line react-perf/jsx-no-new-array-as-prop
              participants && participants.length ? participants : []
            }
            size={120}
            avatar={groupAvatar}
            showRing
            ringSize={6}
            bgColor="background"
          />
          <GroupName>{groupName}</GroupName>
          {groupCreator && (
            <GroupCreator>
              {groupCreator.username} created this group
            </GroupCreator>
          )}
        </GroupAvatarNameContainer>
      )
    }
    return null
  }

  private readonly renderListFooter = (): React.ReactElement => {
    const { messages, pagesLeft, dismissSelectedMessage } = this.props
    const messagesLength = messages.length
    const renderRetrievingHistory = (
      <RetrievingHistoryText>Retrieving History ...</RetrievingHistoryText>
    )
    const renderNoHistory = messagesLength > 0 && null

    return (
      <MessageListFooter
        // insetTop={insets?.top || 0}
        onPress={dismissSelectedMessage}
      >
        {this.renderBlank()}
        {this.renderGroupNameAvatar()}
        {this.renderEditGroup()}
        {this.renderCommonInterests()}
        {this.editGroupInterests()}
        {pagesLeft > 0 ? renderRetrievingHistory : renderNoHistory}
      </MessageListFooter>
    )
  }

  public readonly getMessagesAfterCurrentPlayingAudio = (
    uuid: string
  ): Messages => {
    const { messages } = this.props
    const currentPlayingAudioIndex = messages.findIndex(
      (message) => message.uuid === uuid
    )
    return messages.slice(0, currentPlayingAudioIndex)
  }

  public readonly getMessageFromUuid = (uuid: string) => {
    const { messages } = this.props
    return messages.find((message) => message.uuid === uuid)
  }

  public readonly requestPlay = (uuid: string): void => {
    const messagesAfterCurrentPlayingAudio =
      this.getMessagesAfterCurrentPlayingAudio(uuid)
    const currentMessage = this.getMessageFromUuid(uuid)
    const audioQueue = createAudioQueueFromSameUser(
      messagesAfterCurrentPlayingAudio,
      currentMessage?.sender
    )
    this.setState({ audioQueue, currentAudioUUID: uuid })
  }

  public readonly prepareNextAudioToPlay = (): void => {
    const { audioQueue } = this.state
    const [nextAudioUUID, ...newAudioQueue] = audioQueue
    if (!nextAudioUUID) {
      this.setState({
        currentAudioUUID: "",
        audioQueue: [],
      })
      return
    }
    this.setState({
      currentAudioUUID: nextAudioUUID,
      audioQueue: newAudioQueue,
    })
  }

  public readonly requestStop = (pause: boolean): void => {
    if (pause) {
      return
    }
    this.prepareNextAudioToPlay()
  }

  private clearMessageUuidToScaleAnimation = () => {
    this.setState({
      messageUuidToScaleAnimation: undefined,
    })
  }

  private setContentOffsetY = (contentOffsetY: number) => {
    this.currentScrollOffset = contentOffsetY
  }

  private fixTypingIndicatorSpace = () => {
    if (this.currentScrollOffset <= 31) {
      this.scrollViewRef &&
        this.scrollViewRef.scrollToOffset({ offset: 1, animated: true })
    }
  }

  private getMessages = () => {
    const { messages } = this.props
    return messages.length
      ? [
          { uuid: specialUuids.typing } as ListMessage,
          ...messages,
          { uuid: specialUuids.footer } as ListMessage,
        ]
      : []
  }

  private readonly renderMessage = ({
    item,
    index,
  }: {
    readonly item: ListMessage
    readonly index: number
  }): React.ReactElement => {
    const { uuid } = item

    const {
      isGroup,
      me,
      isFullScreenVideoCall,
      setFullScreenImage,
      isBlocked,
      showBlockAlert,
      isGroupAdmin,
      chatChannel,
      onUpdateReaction,
      dismissSelectedMessage,
    } = this.props
    if (uuid === specialUuids.typing) {
      return (
        <ChatListTypingIndicator
          chatChannel={chatChannel}
          scrollToBottom={this.fixTypingIndicatorSpace}
        />
      )
    }
    if (uuid === specialUuids.footer) {
      return this.renderListFooter()
    }
    const messages = this.getMessages()
    const { currentAudioUUID, messageUuidToScaleAnimation } = this.state
    const shouldPlay = currentAudioUUID === uuid

    return (
      <ChatMessageWrapper
        message={item}
        nextMessage={messages[index + 1]}
        prevMessage={messages[index - 1]}
        isFullScreenVideoCall={isFullScreenVideoCall}
        isGroup={isGroup}
        me={me}
        setFullScreenImage={setFullScreenImage}
        requestPlay={this.requestPlay}
        shouldPlay={shouldPlay}
        requestStop={this.requestStop}
        scrollToReply={this.scrollToReply}
        messageUuidToScaleAnimation={
          messageUuidToScaleAnimation === uuid
            ? messageUuidToScaleAnimation
            : undefined
        }
        clearMessageUuidToScaleAnimation={this.clearMessageUuidToScaleAnimation}
        isBlocked={isBlocked}
        showBlockAlert={showBlockAlert}
        isGroupAdmin={isGroupAdmin}
        chatChannel={chatChannel}
        onUpdateReaction={onUpdateReaction}
        dismissSelectedMessage={dismissSelectedMessage}
      />
    )
  }

  // public handleListScroll = (): void => {
  //   const { dismissSelectedMessage } = this.props

  //   Keyboard.dismiss()
  //   dismissSelectedMessage(true)
  // }

  public hideChat = (): boolean => {
    const { screenOrientation, isChatHide, isHeaderHide } = this.props
    const isLandscape =
      screenOrientation === "LANDSCAPE-RIGHT" ||
      screenOrientation === "LANDSCAPE-LEFT"
    if (!isLandscape) {
      return isChatHide
    }
    return !(!isChatHide || !isHeaderHide)
  }

  // eslint-disable-next-line complexity
  public render(): React.ReactNode {
    const {
      unreadMentions,
      isFullScreenVideoCall,
      screenOrientation,
      isInCallingChat,
      endCall,
      setChatTranslateYOffset,
      hideSwipeCallOnboarding,
    } = this.props
    const { hasNewMessage, firstPageMentionReady } = this.state
    const hideChat = this.hideChat()
    const listData = this.getMessages()

    return (
      <MessageList
        endCall={endCall}
        firstPageMentionReady={firstPageMentionReady}
        handleOnEndReached={this.handleOnEndReached}
        handleScroll={this.handleScroll}
        hasNewMessage={hasNewMessage}
        hideChat={hideChat}
        isFullScreenVideoCall={isFullScreenVideoCall}
        isInCallingChat={isInCallingChat}
        listData={listData}
        setContentOffsetY={this.setContentOffsetY}
        renderBlank={this.renderBlank}
        renderCommonInterests={this.renderCommonInterests}
        renderMentionButton={this.renderMentionButton}
        renderMessage={this.renderMessage}
        screenOrientation={screenOrientation}
        scrollToLatest={this.scrollToLatest}
        setScrollViewRefRef={this.setScrollViewRefRef}
        unreadMentions={unreadMentions}
        handleViewableItemsChange={this.handleViewableItemsChange}
        setChatTranslateYOffset={setChatTranslateYOffset}
        hideSwipeCallOnboarding={hideSwipeCallOnboarding}
      />
    )
  }
}

const mapStateToProps = (
  state: State,
  ownProps: ChatMessageListProps
): StateToProps => ({
  retrievingHistory: selectRetrievingHistory(state),
  actualPage: selectActualPage(ownProps.chatChannel)(state) || 0,
  pagesLeft: selectPagesLeft(ownProps.chatChannel)(state) || 0,
  interests: selectUserInterests(state),
  unreadMentions: selectUnreadMentions(ownProps.chatChannel)(state) || [],
  userActive: selectUserActive(state),
  screenOrientation: selectScreenOrientation(state),
  isGroupAdmin: selectIsGroupAdmin(ownProps.chatChannel)(state),
  forceChatUpdate: selectForceChatUpdate(state),
})

const mapDispatchToProps = (
  dispatch: Dispatch<ChatAction>
): DispatchToProps => ({
  markMentionAsRead: (channel: ChatChannel, mention: string) =>
    dispatch(ChatAction.markMentionAsRead(channel, mention)),
  markAllMentionsAsRead: (channel: ChatChannel) =>
    dispatch(ChatAction.markAllMentionsAsRead(channel)),
})
const MemoChatMessageListComponent = React.memo(ChatMessageListComponent)
// MemoChatMessageListComponent.whyDidYouRender = {
//   logOnDifferentValues: true,
//   customName: "ChatMessageListComponent",
//   diffNameColor: "red",
// }
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withSafeAreaInsets(MemoChatMessageListComponent))
