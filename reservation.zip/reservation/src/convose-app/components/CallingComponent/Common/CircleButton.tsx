import React from "react"
import { ViewStyle, Insets } from "react-native"

import { CircleButtonBorder, StyledCircleButton } from "./Styled"

type Props = {
  size?: number
  backgroundColorCode?: string
  onPress?: () => void
  style?: ViewStyle
  defaultBackgroundOnOffMode?: boolean
  noBorder?: boolean
  borderOnActive?: boolean
  isLandscape?: boolean
  margin?: number
  active?: boolean
  backgroundColor?: string
  borderSize?: number
  hitSlop?: Insets
  disabled?: boolean
}
const CircleButtonComponent: React.FC<React.PropsWithChildren<Props>> = ({
  backgroundColorCode,
  borderOnActive,
  children,
  defaultBackgroundOnOffMode,
  isLandscape,
  noBorder,
  onPress,
  size,
  style,
  margin,
  active,
  backgroundColor,
  borderSize = 1,
  hitSlop,
  disabled,
}) => {
  return (
    <StyledCircleButton
      backgroundColorCode={backgroundColorCode}
      defaultBackgroundOnOffMode={defaultBackgroundOnOffMode}
      onPress={onPress}
      size={size}
      style={style}
      margin={margin}
      active={active}
      backgroundColor={backgroundColor}
      hitSlop={hitSlop}
      disabled={disabled}
    >
      <CircleButtonBorder
        active={active}
        size={size}
        noBorder={noBorder}
        borderOnActive={borderOnActive}
        isLandscape={isLandscape}
        borderSize={borderSize}
      />
      {children}
    </StyledCircleButton>
  )
}

export const CircleButton = React.memo(CircleButtonComponent)
