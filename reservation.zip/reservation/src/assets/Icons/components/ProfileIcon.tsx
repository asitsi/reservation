import React from "react"
import { Svg, Circle, Ellipse } from "react-native-svg"
import { SvgProps } from "../../svg/types"
import { getRatio, getWidth } from "../../svg/utils"

const defaultHeight = 21
const defaultWidth = 24
const ratio = getRatio(defaultHeight, defaultWidth)

const ProfileIconComponent: React.FunctionComponent<SvgProps> = ({
  color,
  height,
}) => {
  const svgHeight = height || defaultHeight
  const svgWidth = height ? getWidth(ratio, height) : defaultWidth
  return (
    <Svg width={svgWidth} height={svgHeight} viewBox="0 0 21 24" fill="none">
      <Ellipse
        cx="10.0892"
        cy="18.0049"
        rx="10.0892"
        ry="5.64995"
        fill={color || "#19AAEB"}
      />
      <Circle cx="10.0901" cy="5.4016" r="5.4016" fill={color || "#19AAEB"} />
    </Svg>
  )
}
export const ProfileIcon = React.memo(ProfileIconComponent)
export default ProfileIcon
