import React, { useCallback, useMemo, useRef } from "react"
import { LayoutChangeEvent, TouchableOpacity, ViewStyle } from "react-native"
import Ionicons from "react-native-vector-icons/Ionicons"
import {
  interpolate,
  useAnimatedStyle,
  useSharedValue,
  withTiming,
} from "react-native-reanimated"

import { color } from "convose-styles"
import { InterestLocation, UserInterest } from "convose-lib"
import {
  Container,
  EditButtonContainer,
  ExpandButton,
  GradientContainer,
  InterestsContainer,
  ScrollContainer,
} from "./Styled"
import { InterestButton } from "../InterestButton"
import { GradientEffect } from "../Navbar/GradientEffect"
import { BlueEditButton } from "../BlueEditButton"

const interestStyle = {
  marginLeft: 0,
  marginTop: 0,
  marginRight: 10,
  marginBottom: 10,
}

type Props = {
  interests: UserInterest[]
  hasEditButton?: boolean
  onEditPress?: () => void
}
const InterestsListWithGradientComponent: React.FC<Props> = ({
  interests,
  hasEditButton,
  onEditPress,
}) => {
  const hasGradient = interests.length > 10

  const handleOnEditPress = () => {
    onEditPress && onEditPress()
  }

  return (
    <Container>
      <ScrollContainer showsVerticalScrollIndicator={false}>
        <InterestsContainer hasGradient={hasGradient}>
          {interests.map((interest) => (
            <InterestButton
              disabled
              interest={interest}
              key={interest.name}
              interestLocation={InterestLocation.Chatbox}
              wrapperStyle={interestStyle}
            />
          ))}
          {hasEditButton && (
            <EditButtonContainer>
              <BlueEditButton onPress={handleOnEditPress} size={30} />
            </EditButtonContainer>
          )}
        </InterestsContainer>
      </ScrollContainer>
      {hasGradient && (
        <GradientContainer pointerEvents="none">
          <GradientEffect bottomInset={0} />
        </GradientContainer>
      )}
    </Container>
  )
}
const INITIAL_INTERESTS_COUNT = 11

const calculationViewStyle: ViewStyle = {
  position: "absolute",
  opacity: 0,
  zIndex: -10,
}

const InterestsListComponent: React.FC<Props> = ({
  interests,
  hasEditButton,
  onEditPress,
}) => {
  const isExpandInterestsHeightSet = useRef(false)
  const isExpanded = useSharedValue(0)
  const expandInterestsHeight = useSharedValue(0)

  const showingInterests = useMemo(() => {
    const trimmedInterests = interests.slice(0, INITIAL_INTERESTS_COUNT)
    return interests.length > INITIAL_INTERESTS_COUNT
      ? [...trimmedInterests, "show-more"]
      : trimmedInterests
  }, [interests])

  const expandButtonStyle = useAnimatedStyle(() => {
    return {
      transform: [
        {
          rotate: `${interpolate(isExpanded.value, [0, 1], [0, 180])}deg`,
        },
      ],
    }
  })
  const expandInterestsStyle = useAnimatedStyle(() => ({
    maxHeight: interpolate(
      isExpanded.value,
      [0, 1],
      [0, expandInterestsHeight.value]
    ),
  }))

  const handleOnEditPress = useCallback(() => {
    onEditPress && onEditPress()
  }, [onEditPress])

  const toggleExpandInterests = () => {
    isExpanded.value = withTiming(isExpanded.value ? 0 : 1)
  }

  return (
    <Container>
      <InterestsContainer>
        {showingInterests.map((interest) => {
          if (typeof interest === "string") {
            return (
              <TouchableOpacity key="expand" onPress={toggleExpandInterests}>
                <ExpandButton style={expandButtonStyle}>
                  <Ionicons
                    name="chevron-down-outline"
                    color={color.white}
                    size={25}
                  />
                </ExpandButton>
              </TouchableOpacity>
            )
          }
          return (
            <InterestButton
              disabled
              interest={interest}
              key={interest.name}
              interestLocation={InterestLocation.Chatbox}
              wrapperStyle={interestStyle}
            />
          )
        })}
        {hasEditButton && (
          <EditButtonContainer>
            <BlueEditButton onPress={handleOnEditPress} size={30} />
          </EditButtonContainer>
        )}
      </InterestsContainer>
      {interests.length > INITIAL_INTERESTS_COUNT && (
        <>
          <InterestsContainer style={expandInterestsStyle}>
            {interests.slice(INITIAL_INTERESTS_COUNT).map((interest) => (
              <InterestButton
                disabled
                interest={interest}
                key={interest.name}
                interestLocation={InterestLocation.Chatbox}
                wrapperStyle={interestStyle}
              />
            ))}
          </InterestsContainer>
          <InterestsContainer
            style={calculationViewStyle}
            onLayout={(layoutEvent: LayoutChangeEvent) => {
              const { height } = layoutEvent.nativeEvent.layout
              if (!isExpandInterestsHeightSet.current) {
                isExpandInterestsHeightSet.current = true
                expandInterestsHeight.value = height
              }
            }}
          >
            {interests.slice(INITIAL_INTERESTS_COUNT).map((interest) => (
              <InterestButton
                disabled
                interest={interest}
                key={interest.name}
                interestLocation={InterestLocation.Chatbox}
                wrapperStyle={interestStyle}
              />
            ))}
          </InterestsContainer>
        </>
      )}
    </Container>
  )
}

export const InterestsListWithGradient = React.memo(
  InterestsListWithGradientComponent
)

export const InterestsList = React.memo(InterestsListComponent)
