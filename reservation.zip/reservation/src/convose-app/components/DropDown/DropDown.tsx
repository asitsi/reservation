/* eslint-disable @typescript-eslint/no-explicit-any */
import React from "react"
import { ViewStyle, TouchableOpacity } from "react-native"
import {
  withTiming,
  EntryAnimationsValues,
  ExitAnimationsValues,
} from "react-native-reanimated"

import {
  BlueIonicons,
  DropDownContainer,
  DropDownItemContainer,
  DropDownText,
  DropDownTitleContainer,
  ItemsContainer,
} from "./Styled"

export type DropDownItemType = {
  id: any
  name: string
  isSelected?: boolean
  onPress: (id: any) => void
}

type Props = {
  items: Array<DropDownItemType>
  nonSelectedTitle?: string
  style?: ViewStyle
}

type ItemProps = DropDownItemType & {
  onClose: () => void
}
const Item: React.FC<ItemProps> = ({
  id,
  name,
  onPress,
  isSelected,
  onClose,
}) => {
  const handleOnPress = () => {
    onClose()
    onPress(id)
  }
  return (
    <TouchableOpacity onPress={handleOnPress}>
      <DropDownItemContainer selected={isSelected}>
        <DropDownText selected={isSelected}>{name}</DropDownText>
      </DropDownItemContainer>
    </TouchableOpacity>
  )
}

const entering = (targetValues: EntryAnimationsValues) => {
  "worklet"

  const animations = {
    borderRadius: withTiming(10, { duration: 50 }),
    height: withTiming(targetValues.targetHeight, { duration: 150 }),
  }
  const initialValues = {
    borderRadius: 0,
    height: 0,
  }
  return {
    initialValues,
    animations,
  }
}
const exiting = (targetValues: ExitAnimationsValues) => {
  "worklet"

  const animations = {
    borderRadius: withTiming(10, { duration: 50 }),
    height: withTiming(0, { duration: 150 }),
  }
  const initialValues = {
    borderRadius: 10,
    height: targetValues.currentHeight,
  }
  return {
    initialValues,
    animations,
  }
}
const DropDownComponent: React.FC<Props> = ({
  items,
  nonSelectedTitle,
  style,
}) => {
  const [isOpen, setOpen] = React.useState(false)
  const selectedItem = items.find((item) => item.isSelected)
  const chosenItemName = selectedItem?.name || nonSelectedTitle || "Choose"

  const closeDropDown = () => {
    setOpen(false)
  }

  const onChangeItemPress = () => {
    setOpen(!isOpen)
  }

  return (
    <DropDownContainer style={style}>
      <TouchableOpacity onPress={onChangeItemPress}>
        <DropDownTitleContainer>
          <DropDownText title>{chosenItemName}</DropDownText>
          <BlueIonicons name="chevron-down" size={15} />
        </DropDownTitleContainer>
      </TouchableOpacity>
      {isOpen && (
        <ItemsContainer entering={entering} exiting={exiting}>
          {items.map((item) => (
            <Item
              key={item.id}
              id={item.id}
              name={item.name}
              onPress={item.onPress}
              isSelected={item.isSelected}
              onClose={closeDropDown}
            />
          ))}
        </ItemsContainer>
      )}
    </DropDownContainer>
  )
}

export const DropDown = React.memo(DropDownComponent)
