import React, { forwardRef } from "react"
import { Svg, Path } from "react-native-svg"
import { SvgProps } from "./types"
import { getRatio, getWidth } from "./utils"

const defaultHeight = 18
const defaultWidth = 24
const ratio = getRatio(defaultHeight, defaultWidth)

const CheckMark = forwardRef<Svg | undefined, SvgProps>(
  ({ height, color }, ref) => {
    const svgHeight = height || defaultHeight
    const svgWidth = height ? getWidth(ratio, height) : defaultWidth
    return (
      <Svg
        ref={ref}
        width={svgWidth}
        height={svgHeight}
        viewBox="0 0 24 18"
        fill="none"
      >
        <Path
          fillRule="evenodd"
          clipRule="evenodd"
          d="M4.5 7.5C3.67157 6.67157 2.32843 6.67157 1.5 7.5C0.671573 8.32843 0.671573 9.67157 1.5 10.5L7.61539 16.6154C8.38009 17.3801 9.61991 17.3801 10.3846 16.6154L22.5 4.5C23.3284 3.67157 23.3284 2.32843 22.5 1.5C21.6716 0.671573 20.3284 0.671573 19.5 1.5L9.26087 11.7391C9.1168 11.8832 8.8832 11.8832 8.73913 11.7391L4.5 7.5Z"
          fill={color || "black"}
        />
      </Svg>
    )
  }
)

export const CheckMarkSvg = React.memo(CheckMark)
