import React from "react"
import { Svg, Path } from "react-native-svg"
import { SvgProps } from "../../svg/types"

const PlayIcon: React.FC<SvgProps> = ({ color, height = 32 }) => {
  return (
    <Svg width={height} height={height} viewBox="0 0 32 32" id="play">
      <Path
        d="M29.91 14.89a4.78 4.78 0 0 0-2.56-3.1L8.7 2.47a4.63 4.63 0 0 0-5.52 1A4.73 4.73 0 0 0 2 6.73v18.48a5.53 5.53 0 0 0 1.51 3.6 4.62 4.62 0 0 0 5.19.72l18.78-9.39a4.63 4.63 0 0 0 2.43-5.25ZM28 16.25a3.08 3.08 0 0 1-1.58 2.17L7.81 27.74a2.64 2.64 0 0 1-3.15-.6A2.72 2.72 0 0 1 4 25.28V6.72a2.76 2.76 0 0 1 .63-1.83 2.69 2.69 0 0 1 2-.91 2.62 2.62 0 0 1 1.18.28l18.77 9.39a2.6 2.6 0 0 1 1.42 2.6Z"
        data-name="Layer 51"
        fill={color || "#525863"}
        stroke={color || "#525863"}
        strokeWidth={0.5}
      />
    </Svg>
  )
}

export default PlayIcon
