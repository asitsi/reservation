import React from "react"
import Animated, {
  ZoomIn,
  ZoomOut,
  interpolateColor,
  useAnimatedStyle,
} from "react-native-reanimated"
import { useTheme } from "styled-components"

import { CheckMarkSvg } from "../../../assets/svg/CheckMark"
import { CheckMarkContainer } from "./Styled"

const AnimatedSvg = Animated.createAnimatedComponent(CheckMarkSvg)

type Props = {
  selected?: boolean
}
const CheckMarkComponent: React.FC<Props> = ({ selected = false }) => {
  const theme = useTheme()
  const style = useAnimatedStyle(
    () => ({
      borderColor: interpolateColor(
        Number(selected),
        [0, 1],
        [theme.main.text, theme.mainBlue]
      ),
      backgroundColor: interpolateColor(
        Number(selected),
        [0, 1],
        [theme.main.background, theme.mainBlue]
      ),
    }),
    [selected, theme]
  )

  return (
    <CheckMarkContainer style={style}>
      {selected && (
        <AnimatedSvg
          entering={ZoomIn.duration(100)}
          exiting={ZoomOut.duration(100)}
          color="white"
          height={13}
        />
      )}
    </CheckMarkContainer>
  )
}

export const CheckMark = React.memo(CheckMarkComponent)
