/* eslint-disable import/no-extraneous-dependencies */
import React from "react"
import Autolink from "react-native-autolink"
import { Pressable, View, StyleSheet } from "react-native"
import { Match } from "autolinker/dist/es2015"

import { color } from "convose-styles"
import {
  handleConvoseUniversalLinks,
  isValidConvoseUrl,
  LONG_PRESS_DURATION,
} from "convose-lib/utils"
import { useMainBlue } from "convose-lib/utils/useMainBlue"
import { openUrl } from "convose-lib/utils/openUrl"

import {
  isMentionPartType,
  parseValue,
  Part,
} from "../../../../../self-maintained-packages/react-native-controlled-mentions/src"
import { MessageText } from "../Styled"
import { TextMessagePart } from "./TextMessagePart"

const mentionStyle = StyleSheet.create({
  meMentioned: {
    backgroundColor: color.mentionYellow,
  },
  otherMentioned: {
    backgroundColor: color.mentionBlue,
  },
  replyMention: {
    color: color.mentionBlue,
  },
  autoLinkStyle: {
    flexWrap: "wrap",
    alignItems: "flex-start",
    flexDirection: "row",
  },
})
type Props = {
  myMessage: boolean
  message: string
  deleted?: boolean
  onPress?: () => void
  onLongPress?: () => void
  disablePress?: boolean
  myUid: string
  showProfile?: (id?: string) => void
  isReply?: boolean
}

const TextMessageComponent: React.FC<Props> = ({
  myMessage,
  message,
  deleted,
  onLongPress,
  onPress,
  disablePress,
  myUid,
  showProfile,
  isReply,
}) => {
  const mainBlue = useMainBlue()
  const linkStyle = {
    color: myMessage ? color.white : mainBlue,
    textDecorationLine: "underline",
  }
  const handleOnPress = (match: Match) => () => {
    if (disablePress) {
      return
    }
    onPress && onPress()
    const url = match.getAnchorHref()
    if (isValidConvoseUrl(url)) {
      handleConvoseUniversalLinks(url, true)
      return
    }
    openUrl(match.getAnchorHref())
  }
  const handleOnLongPress = () => {
    onLongPress && onLongPress()
  }
  const handleShowProfile = (id?: string) => () => {
    showProfile && showProfile(id)
  }
  const getTextPartStyle = (isMine: boolean) => {
    if (isReply) {
      return mentionStyle.replyMention
    }
    return isMine ? mentionStyle.meMentioned : mentionStyle.otherMentioned
  }

  const messageTextProps = React.useMemo(
    () => ({
      myMessage,
      deleted,
      isReply,
      ellipsizeMode: "tail",
      numberOfLines: isReply ? 3 : undefined,
    }),
    [myMessage, deleted, isReply]
  )

  const renderTextPart = (part: Part, index: number): React.ReactNode => {
    if (!part.partType) {
      return (
        <Autolink
          key={`${index}-al`}
          text={part.text}
          email
          component={View}
          style={mentionStyle.autoLinkStyle}
          linkDefault
          stripPrefix={false}
          renderText={(txt) => {
            // eslint-disable-next-line react/jsx-props-no-spreading
            return <MessageText {...messageTextProps}>{txt}</MessageText>
          }}
          renderLink={(text, match) => (
            <Pressable
              key={`${index}-${text}-al-p`}
              onPress={handleOnPress(match)}
              onLongPress={handleOnLongPress}
              delayLongPress={LONG_PRESS_DURATION}
              // eslint-disable-next-line react/no-children-prop
              children={({ pressed }) => (
                <MessageText
                  // eslint-disable-next-line react-perf/jsx-no-new-array-as-prop
                  style={[
                    {
                      backgroundColor: pressed ? color.gray : color.transparent,
                    },
                    linkStyle,
                  ]}
                  // eslint-disable-next-line react/jsx-props-no-spreading
                  {...messageTextProps}
                >
                  {text}
                </MessageText>
              )}
            />
          )}
        />
      )
    }

    if (isMentionPartType(part.partType)) {
      return (
        <MessageText
          key={`${index}-${part.data?.trigger}`}
          // eslint-disable-next-line react/jsx-props-no-spreading
          {...messageTextProps}
        >
          <TextMessagePart
            key={`${index}-${part.data?.trigger}`}
            style={getTextPartStyle(part.data?.id === myUid)}
            onPress={handleShowProfile(part.data?.id)}
          >
            {part.text}
          </TextMessagePart>
        </MessageText>
      )
    }

    return (
      // eslint-disable-next-line react/jsx-props-no-spreading
      <MessageText key={`${index}-${part.data?.trigger}`} {...messageTextProps}>
        <TextMessagePart>{part.text}</TextMessagePart>
      </MessageText>
    )
  }
  const { parts } = parseValue(message, [
    {
      trigger: "@",
    },
  ])
  return (
    <View style={mentionStyle.autoLinkStyle}>{parts.map(renderTextPart)}</View>
  )
}
export const TextMessage = React.memo(TextMessageComponent)
