/* eslint-disable react-perf/jsx-no-new-object-as-prop, @typescript-eslint/no-var-requires */
import React, { useCallback } from "react"
import { Avatar as UserAvatar } from "convose-lib/user"
import FastImage from "react-native-fast-image"
import { ImageStyle, TouchableOpacity, ViewStyle } from "react-native"

import { ChatUser } from "convose-lib/chat"
import {
  GroupAvatarContainer,
  AvatarRing,
  GroupAvatarWrapper,
  StyledAvatar,
  StyledImage,
} from "./Styled"

const defaultAvatarImage = require("../../../assets/Icons/avatar.png")
const defaultAvatarImageGroup = require("../../../assets/Icons/group.png")

export type AvatarProps = {
  readonly height?: number
  readonly userAvatar?: UserAvatar
  readonly noRadius?: boolean
  readonly style?: ViewStyle
  readonly imageStyle?: ImageStyle
  readonly showRing?: boolean
  readonly isGroup?: boolean
  readonly bgColor?: string
  readonly ringColor?: string
  readonly ringSize?: number
}

export const Avatar: React.FC<AvatarProps> = ({
  height = 60,
  userAvatar,
  noRadius,
  style,
  imageStyle,
  showRing,
  isGroup,
  bgColor,
  ringColor,
  ringSize = 3,
}) => {
  const avatar = (() => {
    if (userAvatar && userAvatar.url) {
      return { uri: userAvatar.url, priority: FastImage.priority.low }
    }
    if (isGroup) {
      return defaultAvatarImageGroup
    }
    return defaultAvatarImage
  })()

  return (
    <AvatarRing
      noRadius={noRadius}
      height={showRing ? height + ringSize * 2 : height}
      showRing={showRing}
      style={style}
      bgColor={bgColor}
      isGroup={isGroup}
      ringColor={ringColor}
      ringSize={ringSize}
    >
      <StyledAvatar noRadius={noRadius} height={height}>
        <StyledImage
          height={height}
          noRadius={noRadius}
          source={avatar}
          style={imageStyle}
        />
      </StyledAvatar>
    </AvatarRing>
  )
}

type GroupAvatarType = {
  participants?: Array<ChatUser>
  size?: number
  iconFunction?: (forRejoinCall: boolean | undefined) => void
  showRing?: boolean
  bgColor?: string
  isDarkMode?: boolean
  avatar?: UserAvatar | null
  ringSize?: number
  singleAvatarStyle?: ViewStyle
}
export const GroupAvatar: React.FC<GroupAvatarType> = ({
  bgColor,
  iconFunction,
  isDarkMode,
  participants,
  showRing,
  size = 30,
  avatar,
  ringSize,
  singleAvatarStyle,
}) => {
  const onAvatarPress = useCallback(() => {
    iconFunction && iconFunction(false)
  }, [iconFunction])

  if (avatar && avatar.url) {
    return (
      <TouchableOpacity
        style={singleAvatarStyle}
        onPress={onAvatarPress}
        disabled={!iconFunction}
      >
        <Avatar
          height={size}
          showRing={showRing}
          isGroup
          bgColor={bgColor}
          userAvatar={avatar}
          ringSize={ringSize}
        />
      </TouchableOpacity>
    )
  }

  if (participants && participants.length > 1) {
    const realSize = showRing ? size + (ringSize ? ringSize * 2 : 6) : size
    const groupItemSize = size * 0.75
    const firstParticipant = participants[participants.length - 1]
    const secondParticipant = participants[participants.length - 2]
    const getUserBg = (user: ChatUser) => {
      if (isDarkMode === undefined) {
        return bgColor
      }
      if (isDarkMode) {
        return user.dark_background_color
      }
      return user.background_theme_color
    }

    return (
      <GroupAvatarContainer
        size={realSize}
        onPress={onAvatarPress}
        disabled={!iconFunction}
      >
        <Avatar
          height={groupItemSize}
          userAvatar={firstParticipant?.avatar}
          showRing={showRing}
          bgColor={getUserBg(firstParticipant)}
          isGroup
          ringSize={ringSize}
        />
        <GroupAvatarWrapper size={realSize}>
          <Avatar
            height={groupItemSize}
            userAvatar={secondParticipant?.avatar}
            showRing={showRing}
            bgColor={getUserBg(secondParticipant)}
            isGroup
            ringSize={ringSize}
          />
        </GroupAvatarWrapper>
      </GroupAvatarContainer>
    )
  }
  return <Avatar height={size} showRing={showRing} isGroup bgColor={bgColor} />
}
