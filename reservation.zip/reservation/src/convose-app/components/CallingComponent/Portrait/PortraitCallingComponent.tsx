/* eslint-disable react-perf/jsx-no-new-array-as-prop, react-hooks/exhaustive-deps */
import React from "react"
import { View } from "react-native"
import { useSelector } from "react-redux"
import { withSafeAreaInsets } from "react-native-safe-area-context"
import {
  GestureEvent,
  HandlerStateChangeEvent,
  PanGestureHandler,
  PanGestureHandlerEventPayload,
  ScrollView,
} from "react-native-gesture-handler"

import { softShadows } from "convose-styles"
import { selectIsPickingImage, selectIsTakingImage } from "convose-lib/chat"
import { iSharedScreenPeer } from "convose-lib/services/agora"
import {
  runOnJS,
  useAnimatedStyle,
  useSharedValue,
  withTiming,
} from "react-native-reanimated"
import { Pill } from "../../SlideUpWrapper/Pill"
import { CallingButton } from "../Common/CallingButtons"
import { CallingUsers } from "../Common/CallingUsers"
import { PortraitContainer } from "../Common/Styled"
import { CallingComponentProps } from "../dto"
import { isSpeakerActive } from "../Common/utils"

const defaultInsets = {
  top: 0,
  right: 0,
  bottom: 0,
  left: 0,
}
const SHOW_VALUE = 0
const HIDE_VALUE = -280
const MID_VALUE = -120
const TRANSLATE_LIMIT = 40
const VELOCITY_LIMIT = 200
const ANIMATION_DURATION = 150
const PortraitCallingComponentRaw: React.FC<CallingComponentProps> = ({
  insets = defaultInsets,
  show,
  isFullScreenVideoCall = false,
  audioSetting,
  endCall,
  toggleAudio,
  toggleSpeaker,
  toggleVideo,
  unsetUnmuteAlert,
  unmuteAlert,
  groupInfo,
  me,
  peers,
  channel,
  isCaller,
  isGroup,
  muteRemoteUser,
  participants,
  setVideoCallFullScreenUid,
  videoCallFullScreenUid,
  isGroupAdmin,
  isHandRaiseEnabled,
  toggleHandRaise,
  myRaisedHandStatus,
  setContainerRef,
}) => {
  const userListScrollRef = React.useRef<ScrollView>()
  const isPickingImage = useSelector(selectIsPickingImage)
  const isTakingImage = useSelector(selectIsTakingImage)
  const containerOffset = useSharedValue(HIDE_VALUE)
  const positionYOffset = useSharedValue(HIDE_VALUE)
  const [isShowingCallingButtons, setShowingCallingButtons] =
    React.useState(false)
  const [isVisible, setVisible] = React.useState(false)
  const [isPanGestureEnabled, setPanGestureEnabled] = React.useState(true)

  const containerStyle = useAnimatedStyle(() => ({
    transform: [{ translateY: containerOffset.value }],
  }))

  const showOnlyCallingButtons = () => {
    containerOffset.value = withTiming(
      MID_VALUE,
      { duration: ANIMATION_DURATION },
      () => {
        runOnJS(setShowingCallingButtons)(true)
        positionYOffset.value = MID_VALUE
      }
    )
  }
  function slideDown() {
    setVisible(true)
    containerOffset.value = withTiming(
      SHOW_VALUE,
      { duration: ANIMATION_DURATION },
      () => {
        runOnJS(setShowingCallingButtons)(false)
        positionYOffset.value = SHOW_VALUE
      }
    )
  }
  function slideUp() {
    if (!isVisible) {
      return
    }
    containerOffset.value = withTiming(
      HIDE_VALUE,
      {
        duration: ANIMATION_DURATION,
      },
      () => {
        runOnJS(setVisible)(false)
      }
    )
  }
  React.useEffect(() => {
    if (show) {
      slideDown()
    } else {
      slideUp()
    }
  }, [show])
  React.useEffect(() => {
    if (show) {
      if (!isTakingImage || !isPickingImage) {
        slideDown()
      }
    }
  }, [isTakingImage, isPickingImage])

  const insetTop = insets.top
  const onGestureEvent = (
    event: GestureEvent<PanGestureHandlerEventPayload>
  ) => {
    const { translationY } = event.nativeEvent
    if (
      translationY < 0 &&
      !isShowingCallingButtons &&
      -positionYOffset.value <= -MID_VALUE
    ) {
      positionYOffset.value = translationY
      containerOffset.value = positionYOffset.value
    }
    if (
      isShowingCallingButtons &&
      translationY > 0 &&
      positionYOffset.value <= SHOW_VALUE
    ) {
      positionYOffset.value = translationY + MID_VALUE
      containerOffset.value = positionYOffset.value
    }
  }
  const onEnd = (event: HandlerStateChangeEvent<Record<string, unknown>>) => {
    const translationY = Number(event.nativeEvent.translationY)
    const velocityY = Number(event.nativeEvent.velocityY)

    if (
      (-translationY > TRANSLATE_LIMIT || -velocityY > VELOCITY_LIMIT) &&
      !isShowingCallingButtons
    ) {
      showOnlyCallingButtons()
      return
    }
    if (translationY > TRANSLATE_LIMIT && isShowingCallingButtons) {
      slideDown()
      return
    }
    if (!isShowingCallingButtons) {
      containerOffset.value = SHOW_VALUE
    } else {
      containerOffset.value = MID_VALUE
    }
  }
  const isTransparentContainer: boolean = React.useMemo(() => {
    if (!isVisible || !isFullScreenVideoCall) {
      return false
    }
    if (videoCallFullScreenUid === null) {
      return false
    }
    return !iSharedScreenPeer(videoCallFullScreenUid)
  }, [isFullScreenVideoCall, isVisible, videoCallFullScreenUid])

  if (!isVisible) {
    return null
  }
  const isCalling = isCaller && peers.size === 0
  const setUserScrollRef = (ref: ScrollView) => {
    userListScrollRef.current = ref
  }
  const scrollToStart = () => {
    userListScrollRef.current?.scrollTo({
      animated: true,
      x: 0,
    })
  }
  const handleToggleAudio = () => {
    scrollToStart()
    toggleAudio()
  }
  const handleToggleSpeaker = () => {
    toggleSpeaker()
  }
  const handleToggleVideo = () => {
    scrollToStart()
    toggleVideo()
  }
  const disablePanGesture = () => {
    setPanGestureEnabled(false)
  }
  const enablePanGesture = () => {
    setPanGestureEnabled(true)
  }
  const onEndCall = () => {
    requestAnimationFrame(() => {
      endCall({ displayText: true })
    })
  }
  const setRef = (ref: View) => {
    setContainerRef && setContainerRef(ref)
  }
  return (
    <PanGestureHandler
      onGestureEvent={onGestureEvent}
      onEnded={onEnd}
      enabled={isPanGestureEnabled}
    >
      <PortraitContainer
        ref={setRef}
        insetTop={insetTop || 10}
        style={[!isTransparentContainer && softShadows, containerStyle]}
        transparent={isTransparentContainer}
      >
        <CallingUsers
          isCalling={isCalling}
          isHide={isShowingCallingButtons}
          groupInfo={groupInfo}
          me={me}
          peers={peers}
          channel={channel}
          isGroup={isGroup}
          muteRemoteUser={muteRemoteUser}
          audioSetting={audioSetting}
          videoCallFullScreenUid={videoCallFullScreenUid}
          setUserScrollRef={setUserScrollRef}
          onUserScrollBeginDrag={disablePanGesture}
          onUserScrollEndDrag={enablePanGesture}
          participants={participants}
          setVideoCallFullScreenUid={setVideoCallFullScreenUid}
          isGroupAdmin={isGroupAdmin}
          isHandRaiseEnabled={isHandRaiseEnabled}
        />
        <CallingButton
          isAudioEnabled={audioSetting.isAudioEnabled}
          isSpeakerActive={isSpeakerActive(audioSetting.speakerMode)}
          isVideoEnabled={audioSetting.isVideoEnabled}
          endCall={onEndCall}
          toggleAudio={handleToggleAudio}
          toggleSpeaker={handleToggleSpeaker}
          toggleVideo={handleToggleVideo}
          unmuteAlert={unmuteAlert}
          unsetUnmuteAlert={unsetUnmuteAlert}
          isGroup={isGroup}
          isGroupAdmin={isGroupAdmin}
          isHandRaiseEnabled={isHandRaiseEnabled}
          toggleHandRaise={toggleHandRaise}
          myRaisedHandStatus={myRaisedHandStatus}
        />
        <Pill bottom={10} />
      </PortraitContainer>
    </PanGestureHandler>
  )
}

export const PortraitCallingComponent = React.memo(
  withSafeAreaInsets(PortraitCallingComponentRaw)
)
