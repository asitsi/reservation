import React, { useCallback } from "react"
import { Keyboard, useWindowDimensions } from "react-native"
import { useAnimatedStyle, withTiming } from "react-native-reanimated"

import { useKeyboard } from "convose-lib/utils/useKeyboard"
import {
  Container,
  FormContainer,
  HeaderContainer,
  StyledTouchableWithoutFeedback,
} from "./Styled"
import { Header } from "../Header"
import { goBack } from "../../RootNavigation"

const HEADER_SAFE_HEIGHT = 65

const AuthContainerComponent: React.FC<React.PropsWithChildren> = ({
  children,
}) => {
  const window = useWindowDimensions()
  const [keyboardHeight, keyboardAnimationDuration] = useKeyboard()

  const formStyle = useAnimatedStyle(
    () => ({
      height: withTiming(window.height - keyboardHeight + HEADER_SAFE_HEIGHT, {
        duration: keyboardAnimationDuration || keyboardHeight,
      }),
    }),
    [window.height, keyboardHeight, keyboardAnimationDuration]
  )

  const dismissKeyboard = useCallback(() => {
    Keyboard.dismiss()
  }, [])
  const onBack = () => {
    goBack()
  }
  return (
    <StyledTouchableWithoutFeedback onPress={dismissKeyboard}>
      <Container style={formStyle}>
        <HeaderContainer>
          <Header onBackPress={onBack} title="" />
        </HeaderContainer>
        <FormContainer>{children}</FormContainer>
      </Container>
    </StyledTouchableWithoutFeedback>
  )
}

export const AuthContainer = React.memo(AuthContainerComponent)
