import { Props } from "convose-styles"
import styled from "styled-components/native"

export const ShadowWrapper = styled.View`
  background-color: ${(props: Props) => props.theme.main.chatBoxOnCallShadow};
  margin-vertical: ${(props: Props) =>
    9 - props.theme.main.chatBoxShadowSize}px;
  border-radius: ${(props: Props & { borderRadius: number }) =>
    props.borderRadius + props.theme.main.chatBoxShadowSize}px;
  padding-bottom: ${(props: Props) => props.theme.main.chatBoxShadowSize}px;
  width: ${(props: { widthPercentage: number }) => props.widthPercentage}%;
  align-self: center;
`
