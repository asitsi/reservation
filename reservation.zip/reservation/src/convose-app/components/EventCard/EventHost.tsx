import React from "react"

import { UserMinimum } from "convose-lib/user"

import { Avatar } from "../Avatar"
import { HostContainer, HostTitle, HostUsername } from "./Styled"

type HostProps = {
  creator: UserMinimum
  title?: string
  boldTitle?: boolean
  addColonAtTheEndOfName?: boolean
}
const hostAvatarStyle = {
  marginLeft: 5,
  marginRight: 3,
}
const EventHostComponent: React.FC<HostProps> = ({
  creator,
  title = "Host:",
  boldTitle = false,
  addColonAtTheEndOfName = false,
}) => {
  return (
    <HostContainer>
      <HostTitle boldTitle={boldTitle}>{title}</HostTitle>
      <Avatar
        userAvatar={creator?.avatar}
        height={18}
        style={hostAvatarStyle}
      />
      <HostUsername themeColor={creator?.theme_color}>
        {`${creator?.username}${addColonAtTheEndOfName ? ":" : ""}`}
      </HostUsername>
    </HostContainer>
  )
}

export const EventHost = React.memo(EventHostComponent)
