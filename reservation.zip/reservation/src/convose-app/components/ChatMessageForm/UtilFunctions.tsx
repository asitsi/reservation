import React, { useCallback } from "react"
import { Insets, PressableStateCallbackType } from "react-native"
import { IconButtonPressable, IconWrapper } from "./Styled"

const defaultHitSlop = {
  bottom: 20,
  left: 20,
  right: 20,
  top: 5,
}
type Props = {
  svg: React.ReactNode
  onPress?: () => void
  onPressIn?: () => void
  withHitSlop?: boolean
  hitSlop?: Insets
}

export const IconButton: React.FC<Props> = ({
  onPress,
  onPressIn,
  svg,
  hitSlop,
  withHitSlop,
}) => {
  const handleOnPress = useCallback(() => {
    !!onPress && onPress()
  }, [onPress])
  const handleOnPressIn = useCallback(() => {
    !!onPressIn && onPressIn()
  }, [onPressIn])
  return (
    <IconButtonPressable
      onPress={handleOnPress}
      onPressIn={handleOnPressIn}
      hitSlop={withHitSlop ? hitSlop || defaultHitSlop : undefined}
    >
      {({ pressed }: PressableStateCallbackType) => (
        <IconWrapper pressed={pressed}>{svg}</IconWrapper>
      )}
    </IconButtonPressable>
  )
}
