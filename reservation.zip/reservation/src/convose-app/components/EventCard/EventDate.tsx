import React from "react"

import { convertDateToInformalText } from "convose-lib/utils/date"
import { DateDescription } from "./Styled"

type Props = {
  date: Date
  time: Date
}

const EventDateComponent: React.FC<Props> = ({ date, time }) => {
  const formattedDate = convertDateToInformalText({ date, time })

  return <DateDescription>{formattedDate}</DateDescription>
}

export const EventDate = React.memo(EventDateComponent)
