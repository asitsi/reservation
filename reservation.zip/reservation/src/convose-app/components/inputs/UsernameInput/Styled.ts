import { View } from "react-native"
import styled from "styled-components"
import Animated from "react-native-reanimated"
import { TextInput } from "react-native-gesture-handler"

import { CenteredText, font, Props } from "convose-styles"
import { SvgButton } from "../../IconButton"

export const Container = styled(Animated.View)``
export const InputWrapper = styled(Animated.View)`
  border-radius: 30px;
  background-color: ${(props: Props) => props.theme.textInput.background};
  flex-direction: row;
  justify-content: ${(props: { justifyContent: string }) =>
    props.justifyContent || "center"};
  align-items: center;
  overflow: hidden;
  padding: 5px 15px;
  min-width: 150px;
  max-width: 100%;
`

export const StyledInput = styled(TextInput)`
  font-family: ${font.semiBold};
  font-size: 28px;
  line-height: 38px;
  padding: 0px;
  margin: 0px;
  margin-top: 1px;
  align-self: center;
  color: ${(props: Props) =>
    props.color ? props.color : props.theme.mainBlue};
  include-font-padding: false;
  text-align-vertical: center;
  align-items: center;
  align-content: center;
  border-width: 0px;
  height: 40px;
`

export const EditButtonContainer = styled(Animated.View)`
  justify-content: center;
  align-items: flex-end;
`
export const EditButton = styled(SvgButton)``
export const BoxSize = styled(View)`
  position: absolute;
  width: 12px;
  height: 15px;
  background-color: red;
`
export const BoxSizeTop = styled(BoxSize)`
  top: 0px;
  left: 15px;
`
export const BoxSizeBottom = styled(BoxSize)`
  bottom: 0px;
  left: 15px;
`
const AnimatedCenteredText = Animated.createAnimatedComponent(CenteredText)
export const Description = styled(AnimatedCenteredText)`
  position: absolute;
  bottom: 0px;
  align-self: center;
  font-size: 15px;
  color: ${(props: Props) => props.theme.mainBlue};
  font-family: ${font.normal};
`
