import React, {
  FunctionComponent,
  useCallback,
  useEffect,
  useState,
} from "react"
import { Share } from "react-native"
import { connect } from "react-redux"
import { uniqBy } from "lodash"
import { setAdjustNothing, setAdjustResize } from "rn-android-keyboard-adjust"

import {
  BlockSendContent,
  ChatAction,
  ChatSummary,
  ChatUser,
  checkIsGroup,
  selectIsChangingGroupAvatar,
  selectShowPushNotifications,
  UserStatus,
} from "convose-lib/chat"
import {
  EventInputType,
  EventType,
  selectChatSummary,
  selectParticipantsArray,
  selectUserFeature,
  UsersListAction,
} from "convose-lib/users-list"
import { State } from "convose-lib/store"
import { color } from "convose-styles"
import { Routes } from "convose-lib/router"
import {
  Avatar as AvatarType,
  LoginType,
  selectIsGuest,
  selectMyUuid,
} from "convose-lib/user"
import { chooseAvatar, chooseImage } from "convose-lib/utils"
import { UserInterest } from "convose-lib"

import { convoseAlertRef } from "../../RootConvoseAlert"
import * as RootNavigation from "../../RootNavigation"
import { Avatar, GroupAvatar } from "../Avatar"
import { MenuButtons } from "../MenuButtons"
import { PresenceIndicator } from "../PresenceIndicator"

import {
  ChatMenuHeaderWrapper,
  ChatMenuScreenWrapper,
  ChatboxHeader,
  AvatarContainer,
  GroupInterestsTitle,
  GroupAvatarContainer,
  GroupAvatarEditButtonContainer,
  AddGroupBackgroundContainer,
  BlueLabel,
  EditButtonContainer,
  LoadingAvatarContainer,
} from "./Styled"
import {
  InterestsList,
  UserInterestsContainer,
} from "../InterestsListWithGradient"
import { EditGroupInterests } from "./EditGroupInterests"
import { BlueEditButton, BlueEditIcon } from "../BlueEditButton"
import { BlueMaterialIndicator } from "../MaterialIndicator"
import {
  createGroupAction,
  menuItemsGroup,
  menuItemsOneToOne,
  menuItemsUserProfile,
} from "./MenuItems"
import { EventIcon } from "./EventIcon"
import { GroupEvents } from "./GroupEvents"
import { AddEditGroupEventForm } from "../AddEditGroupEventForm"
import { AuthButtonList } from "../AuthButtonList"
import { ChatMenuUsername } from "./ChatMenuUsername"

type AddBackgroundImageType = {
  onChangeGroupBackground: () => void
}
const AddBackgroundImage: React.FC<AddBackgroundImageType> = ({
  onChangeGroupBackground,
}) => (
  <AddGroupBackgroundContainer onPress={onChangeGroupBackground}>
    <BlueLabel>
      <EditButtonContainer>
        <BlueEditIcon size={13} />
      </EditButtonContainer>
      Add
    </BlueLabel>
    <BlueLabel>background</BlueLabel>
  </AddGroupBackgroundContainer>
)

const AVATAR_SIZE = 160

type ChatMenuProps = {
  channel: string
  chatUser: ChatUser | null
  openPermissions?: () => void
  setSelectedGroupEvent?: (event: EventType) => void
  isUserProfile?: boolean
} & Partial<BlockSendContent>

type StateToPropsType = {
  readonly chatSummary: ChatSummary | null
  readonly participants: ChatUser[]
  readonly chatUser: ChatUser | null
  readonly showPushNotifications: boolean
  readonly myUuid: string
  readonly isGuest: boolean
  readonly isChangingGroupAvatar: boolean
}

type DispatchToPropsType = {
  readonly blockUser: (user: ChatUser) => void
  readonly leaveGroup: (ChatChannel: string) => void
  readonly toggleLocalPNSettings: () => void
  readonly updateGroupName: (groupname: string, chatChannel: string) => void
  readonly changeGroupAvatar: (file: FormData, chatChannel: string) => void
  readonly changeGroupBackgroundImage: (
    file: string,
    chatChannel: string
  ) => void
  readonly editGroupInterests: (
    channel: string,
    interests: UserInterest[]
  ) => void
  readonly addEventToGroup: (event: EventInputType, chatChannel: string) => void
}
const isAddBackgroundEnabled = false
const isEditGroupInterestsEnabled = false
const isEditGroupAvatarEnabled = true
type Props = StateToPropsType & DispatchToPropsType & ChatMenuProps
const ChatMenuComponent: FunctionComponent<Props> = ({
  chatSummary,
  chatUser,
  participants,
  blockUser,
  leaveGroup,
  showPushNotifications,
  toggleLocalPNSettings,
  updateGroupName,
  channel,
  myUuid,
  openPermissions,
  isBlocked,
  showBlockAlert,
  isGuest,
  changeGroupAvatar,
  isChangingGroupAvatar,
  changeGroupBackgroundImage,
  editGroupInterests,
  setSelectedGroupEvent,
  addEventToGroup,
  isUserProfile,
}) => {
  const isGroup = checkIsGroup(chatSummary, channel)
  const goBack = () => {
    RootNavigation.goBack()
  }
  const derivedChatUser =
    chatUser || chatSummary?.participants[0] || participants[0]
  const themeColor = isGroup ? color.black : derivedChatUser?.theme_color

  const [username, setUsername] = useState(
    isGroup && chatSummary ? chatSummary.group_name : derivedChatUser?.username
  )

  const {
    permissions: { owner },
  } = { permissions: { owner: false }, ...chatSummary }

  useEffect(() => {
    setAdjustNothing()
    return () => {
      setAdjustResize()
    }
  }, [])
  const changeUsername = useCallback(() => {
    updateGroupName(username || "Group", channel)
  }, [channel, updateGroupName, username])

  // const cancel = (): void => goBack()
  const confirmToBlockUser = () => {
    convoseAlertRef?.show({
      ioniconName: "warning",
      title: `Block ${username}`,
      description: `You won't receive messages from ${username} that may have been sent during the block.`,
      buttons: [
        {
          onPress: () => {
            derivedChatUser && blockUser(derivedChatUser)
            goBack()
          },
          title: "Block",
        },
        { title: "Cancel", type: "cancel" },
      ],
    })
  }

  const confirmToLeaveGroup = () => {
    convoseAlertRef?.show({
      ioniconName: "exit",
      title: `Leave group?`,
      description: `You won't receive messages from the group after you leave.`,
      buttons: [
        {
          onPress: () => {
            leaveGroup(channel)
          },
          title: "Leave",
        },
        { title: "Cancel", type: "cancel" },
      ],
    })
  }

  const inviteToGroup = () => {
    if (isBlocked) {
      showBlockAlert && showBlockAlert("Invite")
      return
    }
    createGroupAction(isGroup)
  }
  const hideConvoseAlert = (callback?: () => void) => {
    convoseAlertRef?.setState({
      isVisible: false,
    })
    callback && callback()
  }
  const onLoginPress = () => {
    convoseAlertRef?.show({
      title: "To create a group, you need to sign in first!",
      ioniconName: "log-in",
      description: (
        <AuthButtonList
          loginOrSignUp={LoginType.SignUp}
          onAuthCompleted={hideConvoseAlert}
          onHideComponent={hideConvoseAlert}
        />
      ),
      buttons: null,
    })
  }
  const createGroup = () => {
    if (isGuest) {
      onLoginPress()
      return
    }
    if (isBlocked) {
      showBlockAlert && showBlockAlert("Invite")
      return
    }
    createGroupAction(isGroup, [derivedChatUser.uuid])
  }

  const renderChatAvatar = useCallback(
    (
      avatar: AvatarType,
      status?: UserStatus,
      hideOnlineIndicator?: boolean
    ): React.ReactNode => (
      <AvatarContainer>
        <PresenceIndicator
          isOnline={status === UserStatus.Online}
          location="chatMenu"
          hideOnlineIndicator={hideOnlineIndicator}
          offlineIndicatorColorCode="main.background"
        >
          <Avatar
            userAvatar={avatar}
            height={AVATAR_SIZE}
            showRing
            bgColor="background"
            ringSize={8}
          />
        </PresenceIndicator>
      </AvatarContainer>
    ),
    []
  )

  const firstTwoParticipants = chatSummary
    ? Object.values(chatSummary.participants)
    : []
  const openGroupParticipants = () => {
    RootNavigation.navigate(Routes.UserList, {
      chatChannel: channel,
      firstTwoParticipants,
      myUuid,
      disableOnUserPress: isBlocked,
    })
  }

  const participantsPermissions = () => {
    openPermissions && openPermissions()
  }
  const onCreateNewEventPress = () => {
    if (isBlocked) {
      setTimeout(() => {
        showBlockAlert && showBlockAlert("Content")
      }, 200)
      return
    }
    const onDismiss = () => {
      setTimeout(() => {
        // eslint-disable-next-line @typescript-eslint/no-use-before-define
        onGroupEventsPress()
      }, 200)
    }
    const onAddEvent = (event: EventInputType) => {
      addEventToGroup(event, channel)
      convoseAlertRef?.setState({ isVisible: false })
      onDismiss()
    }
    setTimeout(() => {
      convoseAlertRef?.show({
        title: "Create new event",
        description: <AddEditGroupEventForm type="add" onPress={onAddEvent} />,
        icon: <EventIcon useDefaultColor height={50} />,
        onDismiss,
        buttons: null,
      })
    }, 200)
  }
  const onGroupEventsPress = () => {
    if (setSelectedGroupEvent) {
      convoseAlertRef?.show({
        buttons: [
          {
            title: "Create new event",
            onPress: onCreateNewEventPress,
          },
        ],
        icon: <EventIcon useDefaultColor height={50} />,
        title: "Upcoming events",
        description: (
          <GroupEvents
            setSelectedGroupEvent={setSelectedGroupEvent}
            chatChannel={channel}
          />
        ),
      })
    }
  }
  const startConversation = (): void => {
    requestAnimationFrame(() => {
      RootNavigation.goBack()
      RootNavigation.navigate(Routes.Chat, {
        channel,
        chatUser,
        forRejoinCall: false,
      })
    })
  }
  const onShareGroup = () => {
    const url = `https://convose.com/?id=${channel}`
    Share.share({
      title: "Share group!",
      message: `I’m part of this awesome Convose group come join us here: ${url}`,
    })
      .then()
      .catch()
  }
  const getMenuOptions = () => {
    if (derivedChatUser.uuid === myUuid) {
      return []
    }
    if (isUserProfile) {
      return menuItemsUserProfile(startConversation)
    }
    if (isGroup) {
      return menuItemsGroup({
        confirmToLeaveGroup,
        inviteToGroup,
        onGroupEventsPress,
        onShareGroup,
        openGroupParticipants,
        showPushNotifications,
        toggleLocalPNSettings,
        participantPermissions: owner ? participantsPermissions : undefined,
      })
    }
    return menuItemsOneToOne({
      createGroup,
      toggleLocalPNSettings,
      confirmToBlockUser,
      showPushNotifications,
    })
  }

  const onEditGroupAvatar = useCallback(async () => {
    try {
      const file = await chooseAvatar()
      if (!file) {
        return
      }
      const data = new FormData()
      data.append("file", file)
      changeGroupAvatar(data, channel)
    } catch (error) {
      // console.log(JSON.stringify(error, null, 2))
    }
  }, [changeGroupAvatar, channel])

  const renderAvatar = () => {
    if (isChangingGroupAvatar && owner) {
      return (
        <LoadingAvatarContainer size={AVATAR_SIZE}>
          <BlueMaterialIndicator size={AVATAR_SIZE / 3} />
        </LoadingAvatarContainer>
      )
    }
    if (isGroup) {
      return (
        <GroupAvatarContainer>
          <GroupAvatar
            participants={firstTwoParticipants}
            size={AVATAR_SIZE}
            avatar={chatSummary?.avatar}
            showRing
            ringSize={7}
            bgColor="background"
          />
          {owner && isEditGroupAvatarEnabled && (
            <GroupAvatarEditButtonContainer
              hasAvatar={!!chatSummary?.avatar?.url}
            >
              <BlueEditButton
                onPress={onEditGroupAvatar}
                size={32}
                borderColorCode="main.background"
              />
            </GroupAvatarEditButtonContainer>
          )}
        </GroupAvatarContainer>
      )
    }
    return renderChatAvatar(derivedChatUser?.avatar, derivedChatUser?.status)
  }

  const menuItems = getMenuOptions()

  const onAddInterestsPress = useCallback(() => {
    RootNavigation.navigate(Routes.GroupInterests, {
      channel,
    })
  }, [channel])

  const onEditInterestsPress = useCallback(() => {
    const interests = chatSummary?.interests || []
    convoseAlertRef?.show({
      title: "My group’s interests",
      description: (
        <EditGroupInterests
          channel={channel}
          interests={interests}
          editGroupInterests={editGroupInterests}
        />
      ),

      buttons: [
        {
          title: "Interests",
          onPress: onAddInterestsPress,
        },
      ],
    })
  }, [onAddInterestsPress, chatSummary?.interests, editGroupInterests, channel])

  const onChangeGroupBackground = useCallback(async () => {
    try {
      const image = await chooseImage()
      if (image) {
        const { data } = image
        changeGroupBackgroundImage(data, channel)
      }
    } catch (error) {
      // console.log(JSON.stringify(error, null, 2))
    }
  }, [changeGroupBackgroundImage, channel])

  const renderUserInterests = () => {
    const interests = isGroup
      ? // eslint-disable-next-line react-perf/jsx-no-new-array-as-prop
        [...(chatSummary?.interests || [])]
      : // eslint-disable-next-line react-perf/jsx-no-new-array-as-prop
        [...(chatUser?.interests || [])]
    return (
      <UserInterestsContainer>
        {isGroup && <GroupInterestsTitle>Group Interests:</GroupInterestsTitle>}
        <InterestsList
          interests={uniqBy(interests, "name")}
          hasEditButton={isGroup && owner && isEditGroupInterestsEnabled}
          onEditPress={onEditInterestsPress}
        />
      </UserInterestsContainer>
    )
  }

  return (
    <ChatMenuScreenWrapper>
      {isGroup && owner && isAddBackgroundEnabled && (
        <AddBackgroundImage onChangeGroupBackground={onChangeGroupBackground} />
      )}
      <ChatMenuHeaderWrapper>
        <ChatboxHeader>
          {renderAvatar()}
          <ChatMenuUsername
            changeUsername={changeUsername}
            isGroup={isGroup}
            owner={owner}
            setUsername={setUsername}
            themeColor={themeColor}
            username={username}
            chatChannel={channel}
          />
        </ChatboxHeader>
        {renderUserInterests()}
      </ChatMenuHeaderWrapper>
      <MenuButtons items={menuItems} />
    </ChatMenuScreenWrapper>
  )
}

const mapStateToProps = (
  state: State,
  ownProps: ChatMenuProps
): StateToPropsType => ({
  myUuid: selectMyUuid(state),
  showPushNotifications: selectShowPushNotifications(state),
  chatSummary: selectChatSummary(ownProps.channel)(state),
  participants: selectParticipantsArray(ownProps.channel)(state),
  chatUser: ownProps.chatUser?.avatar
    ? ownProps.chatUser
    : selectUserFeature(ownProps.chatUser?.uuid || "")(state) || null,
  isGuest: selectIsGuest(state),
  isChangingGroupAvatar: selectIsChangingGroupAvatar(state),
})
const mapDispatchToProps: DispatchToPropsType = {
  blockUser: UsersListAction.blockUser,
  leaveGroup: ChatAction.leaveGroup,
  toggleLocalPNSettings: ChatAction.toggleLocalPNSettings,
  updateGroupName: ChatAction.updateGroupName,
  changeGroupAvatar: ChatAction.changeGroupAvatar,
  changeGroupBackgroundImage: ChatAction.changeGroupBackgroundImage,
  editGroupInterests: UsersListAction.editGroupInterests,
  addEventToGroup: UsersListAction.addEventToGroup,
}

export const ChatMenu = connect(
  mapStateToProps,
  mapDispatchToProps
)(ChatMenuComponent)
