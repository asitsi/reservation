import React from "react"
import { Image } from "react-native"
import ImageZoom from "react-native-image-pan-zoom"
import {
  Easing,
  SlideInDown,
  SlideOutDown,
  ZoomIn,
  ZoomOut,
} from "react-native-reanimated"

import { height, width } from "convose-styles"
import { withSafeAreaInsets } from "react-native-safe-area-context"
import { SafeAreaProps } from "convose-lib/generalTypes"
import {
  Action,
  ActionLabel,
  ButtonAction,
  ButtonActionContainer,
  FullscreenImageWrapper,
  styles,
} from "./Styled"
import { Header } from "../Header"

type Props = {
  onClose: () => void
  image: { uri: string }
  onSavePress?: () => void
} & SafeAreaProps

const FullscreenImageComponent: React.FC<Props> = ({
  onClose,
  image,
  insets,
  onSavePress,
}) => {
  const [isShowingActions, setShowingActions] = React.useState(true)
  const timeout = React.useRef<ReturnType<typeof setTimeout>>()

  React.useEffect(() => {
    if (isShowingActions) {
      timeout.current = setTimeout(() => {
        if (isShowingActions) {
          setShowingActions(false)
        }
      }, 3000)
    }
    return () => {
      if (timeout.current) {
        clearTimeout(timeout.current)
      }
    }
  }, [isShowingActions])

  return (
    <FullscreenImageWrapper
      entering={ZoomIn.duration(150)}
      exiting={ZoomOut.duration(150)}
      inPreview={!isShowingActions}
    >
      <ImageZoom
        cropWidth={width}
        cropHeight={height}
        imageWidth={width}
        imageHeight={height}
        onClick={() => setShowingActions(!isShowingActions)}
        enableSwipeDown
        onSwipeDown={onClose}
      >
        <Image style={styles.imageStyle} source={image} resizeMode="contain" />
      </ImageZoom>
      {isShowingActions && (
        <Header onBackPress={onClose} title="Image" sticky hideReturnToCall />
      )}
      {isShowingActions && !!onSavePress && (
        <ButtonActionContainer
          entering={SlideInDown.duration(50).easing(
            Easing.bezier(0, 1, 0.07, 1)
          )}
          exiting={SlideOutDown.duration(100)}
        >
          <ButtonAction insetBottom={insets?.bottom || 0}>
            <Action onPress={onSavePress}>
              <ActionLabel>Save</ActionLabel>
            </Action>
          </ButtonAction>
        </ButtonActionContainer>
      )}
    </FullscreenImageWrapper>
  )
}

export const FullscreenImage = React.memo(
  withSafeAreaInsets(FullscreenImageComponent)
)
