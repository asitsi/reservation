import React, { useCallback, useMemo } from "react"
import { LayoutChangeEvent, LayoutRectangle } from "react-native"
import Animated, {
  LinearTransition,
  ZoomIn,
  ZoomOut,
  useAnimatedStyle,
} from "react-native-reanimated"

import { InterestLocation, UserInterest } from "convose-lib"
import { MY_INTEREST_SIZE } from "convose-styles"

import { InterestButton } from "../InterestButton"

const layout = LinearTransition.damping(18).springify()

export const INTEREST_ICON_SIZE = 30
export const wrapperStyle = {
  marginTop: 0,
}
export const iconWrapperStyle = {
  marginLeft: 3,
}

type InterestItemType = {
  interest: UserInterest
  onDelete: (interest: UserInterest) => void
  onPress: (interest: UserInterest) => void
  onLongPress: (interest: UserInterest, position: LayoutRectangle) => void
  movingInterest: UserInterest | null
  index: number
}
const InterestItemComponent: React.FC<InterestItemType> = ({
  interest,
  onDelete,
  onLongPress,
  onPress,
  movingInterest,
  index,
}) => {
  const position = React.useRef<LayoutRectangle>({
    height: 0,
    width: 0,
    x: 0,
    y: 0,
  })

  const isMoving = useMemo(() => {
    return movingInterest?.id === interest.id
  }, [movingInterest, interest])

  const style = useAnimatedStyle(
    () => ({
      opacity: isMoving ? 0 : 1,
    }),
    [isMoving]
  )
  const handleLongPress = useCallback(
    (userInterest: UserInterest) => {
      if (index === 0) {
        return
      }
      onLongPress(userInterest, position.current)
    },
    [onLongPress, index]
  )

  return (
    <Animated.View
      onLayout={(layoutEvent: LayoutChangeEvent) => {
        position.current = layoutEvent.nativeEvent.layout
      }}
      style={style}
      entering={ZoomIn}
      exiting={ZoomOut}
      layout={layout}
    >
      <InterestButton
        size={MY_INTEREST_SIZE}
        interestLocation={InterestLocation.MyInterests}
        interest={interest}
        key={interest.name}
        onDelete={onDelete}
        onPress={onPress}
        onLongPress={handleLongPress}
        addBorder
        transparentBackground
        iconSize={INTEREST_ICON_SIZE}
        wrapperStyle={wrapperStyle}
        iconWrapperStyle={iconWrapperStyle}
        backgroundColorCode="interests.inputAndCurrentInterests.background"
      />
    </Animated.View>
  )
}
export const InterestItem = React.memo(InterestItemComponent)
