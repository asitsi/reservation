import React from "react"
import { Svg, Path, Ellipse, Circle } from "react-native-svg"
import { SvgProps } from "../../svg/types"
import { getRatio, getWidth } from "../../svg/utils"

const defaultHeight = 20
const defaultWidth = 25
const ratio = getRatio(defaultHeight, defaultWidth)

const AddGroupIcon: React.FC<SvgProps> = ({ color, height = 24 }) => {
  const svgHeight = height || defaultHeight
  const svgWidth = height ? getWidth(ratio, height) : defaultWidth
  return (
    <Svg width={svgWidth} height={svgHeight} viewBox="0 0 25 20" fill="none">
      <Path
        d="M23.4329 5.54717H20.7383V2.85257C20.7383 2.34266 20.3245 1.92891 19.8146 1.92891C19.3046 1.92891 18.891 2.34278 18.891 2.85264V5.54724H16.1963C15.6864 5.54724 15.2727 5.96099 15.2727 6.4709C15.2727 6.98082 15.6864 7.39457 16.1963 7.39457H18.891V10.0892C18.891 10.5991 19.3047 11.0128 19.8147 11.0128C20.3246 11.0128 20.7383 10.5991 20.7383 10.0892V7.39457H23.4329C23.9428 7.39457 24.3566 6.98082 24.3566 6.4709C24.3566 5.96102 23.9428 5.54717 23.4329 5.54717Z"
        fill={color || "#3F9AF7"}
        stroke={color || "#3F9AF7"}
        strokeWidth="0.4"
      />
      <Ellipse
        cx="8.38314"
        cy="14.9604"
        rx="8.38314"
        ry="4.69456"
        fill={color || "#3F9AF7"}
      />
      <Circle cx="8.38396" cy="4.4882" r="4.4882" fill={color || "#3F9AF7"} />
    </Svg>
  )
}

export default AddGroupIcon
