import React from "react"

import { useSkeleton } from "../../Skeleton"
import { StyledImageContainer, StyledImage } from "../Styled"

type Props = {
  uri: { uri: string }
  ratio: number | null
  resizeMode: string
}

export const ImageMessage: React.FunctionComponent<Props> = ({
  ratio,
  resizeMode,
  uri,
}) => {
  const [animatedStyles, startLoading, stopLoading] = useSkeleton()

  return (
    <StyledImageContainer ratio={ratio} style={animatedStyles}>
      <StyledImage
        source={uri}
        ratio={ratio}
        resizeMode={resizeMode}
        onLoadStart={startLoading}
        onLoad={stopLoading}
      />
    </StyledImageContainer>
  )
}
