import React from "react"
import { ColorValue, ViewStyle } from "react-native"

import { useMainBlue } from "convose-lib/utils/useMainBlue"
import { SvgButton } from "../IconButton"
import EditIcon from "../../../assets/Icons/components/EditIcon"
import { ButtonBorder } from "./Styled"

type Props = {
  size?: number
  onPress: () => void
  withBoarder?: boolean
  borderColor?: ColorValue
  borderColorCode?: string
}
const BlueEditButtonComponent: React.FC<Props> = ({
  onPress,
  withBoarder,
  size = 17,
  borderColor,
  borderColorCode,
}) => {
  const mainBlue = useMainBlue()
  const buttonStyle: ViewStyle = React.useMemo(() => {
    return {
      backgroundColor: mainBlue,
      width: size - 4,
      height: size - 4,
    }
  }, [mainBlue, size])
  return (
    <ButtonBorder
      size={size}
      withBoarder={withBoarder}
      borderColor={borderColor}
      borderColorCode={borderColorCode}
      onPress={onPress}
    >
      <SvgButton
        iconComponent={
          <EditIcon color="white" height={size - 17} opacity={1} />
        }
        size={size - 2}
        style={buttonStyle}
      />
    </ButtonBorder>
  )
}

type BlueIconProps = {
  size?: number
}
const BlueEditIconComponent: React.FC<BlueIconProps> = ({ size = 17 }) => {
  const mainBlue = useMainBlue()
  return <EditIcon color={mainBlue} height={size} opacity={1} />
}

export const BlueEditIcon = React.memo(BlueEditIconComponent)

export const BlueEditButton = React.memo(BlueEditButtonComponent)
