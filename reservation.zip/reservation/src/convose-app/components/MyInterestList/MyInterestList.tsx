import React from "react"
import { NativeEventSubscription, AppState } from "react-native"
import { connect } from "react-redux"
import _, { debounce } from "lodash"

import { UserInterest } from "convose-lib/interests"
import { Routes } from "convose-lib/router"
import { State } from "convose-lib/store"
import {
  selectOnboarded,
  selectUserLocalInterests,
  UserAction,
} from "convose-lib/user"
import { softShadows } from "convose-styles"
import Animated, { LinearTransition, ZoomIn } from "react-native-reanimated"

import { convoseAlertRef } from "../../RootConvoseAlert"
import * as RootNavigation from "../../RootNavigation"
import {
  AddInterestButton,
  InterestContainer,
  InterestsLabel,
  InterestsWrapper,
  NoInterestText,
} from "./styled"
import { NoInterests } from "./NoInterests"
import { InterestListRef } from "./InterestList"
import { InterestListHandler } from "./InterestListHandler"
// import { SortableInterestList } from "./SortableList"

const addInterestText = `Add hobbies, skills, languages and locations here to find interesting people to talk with.`

type StateToProps = {
  readonly interests: ReadonlyArray<UserInterest>
  readonly onboarded: boolean
}

type DispatchToProps = {
  readonly deleteUserInterest: (interestIds: number[]) => void
  readonly removeUserLocalInterests: (interest: UserInterest) => void
  readonly setUserLocalInterests: (interests: UserInterest[]) => void
  readonly updateUserInterests: (interests: UserInterest[]) => void
  readonly sortInterestOnBoarded: () => void
}

type Props = {
  scrollToTop: (callback?: () => void, duration?: number) => void
  slideDown: (callback?: () => void) => void
}

type MyInterestListProps = StateToProps & DispatchToProps & Props

const openRatingWheel = (interest: UserInterest) => {
  requestAnimationFrame(() => {
    RootNavigation.navigate(Routes.Rating, { interest })
  })
}
const layout = LinearTransition.damping(18).duration(50).springify()

// const openSorting = () => {
//   requestAnimationFrame(() => {
//     RootNavigation.navigate(Routes.SortMyInterests, {})
//   })
// }
class MyInterestListComponent extends React.PureComponent<MyInterestListProps> {
  public deletedInterestsRef: number[] = []

  public hasChangedPositionRef = false

  public subscribe!: NativeEventSubscription

  public myInterestsListRef = React.createRef<InterestListRef>()

  debouncedDeleteHandler = debounce(
    () => this.deleteInterestsAndCleanUp(),
    2000
  )

  debouncedSaveInterests = debounce(() => this.saveInterests(), 2000)

  componentDidMount(): void {
    this.subscribe = AppState.addEventListener("change", (state) => {
      if (state.match(/inactive|background/)) {
        this.deleteInterestsAndCleanUp()
        this.saveInterests()
      }
    })
  }

  componentDidUpdate(prevProps: Readonly<MyInterestListProps>): void {
    const { interests } = this.props
    if (interests.length !== prevProps.interests.length) {
      if (this.deletedInterestsRef.length) {
        this.debouncedDeleteHandler()
      }
    }
    if (interests !== prevProps.interests && this.hasChangedPositionRef) {
      this.debouncedSaveInterests()
    }
  }

  componentWillUnmount(): void {
    this.deleteInterestsAndCleanUp()
    this.saveInterests()
    this.subscribe && this.subscribe.remove()
  }

  deleteInterestsAndCleanUp = () => {
    const { deleteUserInterest } = this.props
    if (this.deletedInterestsRef.length) {
      deleteUserInterest(this.deletedInterestsRef)
      this.deletedInterestsRef = []
    }
  }

  onDelete = (interest: UserInterest): void => {
    const { removeUserLocalInterests } = this.props
    convoseAlertRef?.setState({
      canDismiss: false,
    })
    removeUserLocalInterests(interest)
    convoseAlertRef?.setState({
      canDismiss: true,
    })
    this.deletedInterestsRef.push(interest.id)
  }

  onSetLocalInterests = (interests: UserInterest[]): void => {
    const { setUserLocalInterests } = this.props
    setUserLocalInterests(interests)
  }

  saveInterests = () => {
    if (!this.hasChangedPositionRef) {
      return
    }
    const { interests, updateUserInterests } = this.props
    updateUserInterests([...interests])
    this.hasChangedPositionRef = false
  }

  moveInterestToFirstPosition = (interest: UserInterest) => {
    const { scrollToTop, interests } = this.props
    const newInterests = interests.filter(
      (userInterest) => userInterest.id !== interest.id
    )
    setTimeout(() => {
      this.onSetLocalInterests([interest, ...newInterests])
    }, 300)
    scrollToTop(() => {
      this.hasChangedPositionRef = true
      setTimeout(() => {
        this.myInterestsListRef.current?.sortingFinished()
      }, 200)
    }, 800)
  }

  onAddInterestPress = () => {
    const { slideDown } = this.props
    slideDown(() =>
      setTimeout(() => {
        RootNavigation.navigate(Routes.Interests)
      }, 100)
    )
  }

  renderAddInterestsButton = (): React.ReactNode => {
    const { interests } = this.props
    return (
      <AddInterestButton
        length={interests.length}
        style={softShadows}
        onPress={this.onAddInterestPress}
      />
    )
  }

  renderInterestList = (): React.ReactNode => {
    const { interests, onboarded, sortInterestOnBoarded } = this.props
    return (
      <InterestContainer layout={layout}>
        {interests && interests.length ? (
          <InterestListHandler
            interestListRef={this.myInterestsListRef}
            interests={_.uniqBy(Array.from(interests), "id")}
            onDelete={this.onDelete}
            openRatingWheel={openRatingWheel}
            // longPressInterest={openSorting}
            longPressInterest={this.moveInterestToFirstPosition}
            onboarded={onboarded}
            sortInterestOnBoarded={sortInterestOnBoarded}
          />
        ) : (
          <Animated.View entering={ZoomIn}>
            <NoInterests />
            <NoInterestText>{addInterestText}</NoInterestText>
          </Animated.View>
        )}
        {this.renderAddInterestsButton()}
      </InterestContainer>
    )
  }

  render(): React.ReactNode {
    return (
      <InterestsWrapper>
        <InterestsLabel>My interests:</InterestsLabel>
        {this.renderInterestList()}
      </InterestsWrapper>
    )
  }
}

const mapStateToProps = (state: State): StateToProps => ({
  interests: selectUserLocalInterests(state) || [],
  onboarded: selectOnboarded(state),
})

const mapDispatchToProps: DispatchToProps = {
  deleteUserInterest: UserAction.deleteUserInterest,
  removeUserLocalInterests: UserAction.removeUserLocalInterests,
  setUserLocalInterests: UserAction.setUserLocalInterests,
  updateUserInterests: UserAction.updateUserInterests,
  sortInterestOnBoarded: UserAction.sortInterestOnBoarded,
}
// MyInterestListComponent.whyDidYouRender = {
//   logOnDifferentValues: false,
//   customName: "MyInterestListComponent",
//   diffNameColor: "red",
// }
export const MyInterestList = React.memo(
  connect(mapStateToProps, mapDispatchToProps)(MyInterestListComponent)
)
