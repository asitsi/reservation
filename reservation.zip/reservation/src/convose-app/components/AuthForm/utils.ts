export const isEmailValid = (email: string): boolean => {
  return !!String(email)
    .toLowerCase()
    .match(
      /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
    )
}
export const isPasswordValid = (password: string): boolean => {
  return password.length >= 8
}

export const INVALID_EMAIL = "Please enter a valid Email"
export const INVALID_PASSWORD = "Password is too short(minimum 8 characters)"
