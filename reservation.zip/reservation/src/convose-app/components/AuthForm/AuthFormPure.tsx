/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { FunctionComponent, useRef } from "react"
import { TextInput } from "react-native-gesture-handler"

import { Routes } from "convose-lib/router"

import { PrimaryButton } from "../../components/PrimaryButton"
import { UserTextInput } from "../../components/UserTextInput"
import * as RootNavigation from "../../RootNavigation"
import { BlueMaterialIndicator } from "../MaterialIndicator"
import {
  AlreadyHaveAccount,
  AlreadyHaveAccountTitle,
  ForgotPasswordText,
  FormWrapper,
  Icon,
  LoadingSpinnerContainer,
  LoginButton,
  PasswordContainer,
  SubmitButton,
  SubmitContainer,
} from "./styled"
import { AuthFormPureProps } from "./types"

const AuthFormPure: FunctionComponent<AuthFormPureProps> = ({
  email,
  password,
  onEmailChange,
  onPasswordChange,
  type,
  isLoading,
  onSubmit,
  onForgotPassword,
  emailError,
  passwordError,
}) => {
  const passwordRef = useRef<TextInput>()
  const [isPasswordSecure, setPasswordSecure] = React.useState(true)

  const togglePassSecure = () => {
    setPasswordSecure(!isPasswordSecure)
  }
  const renderForgotPasswordButton = () => {
    const forgotPasswordComponent = (
      <ForgotPasswordText>forgot password</ForgotPasswordText>
    )

    return (
      <PrimaryButton
        type="text"
        label="forgot password"
        onPress={onForgotPassword}
      >
        {forgotPasswordComponent}
      </PrimaryButton>
    )
  }
  const onHaveAccountPress = () => {
    RootNavigation.replace(Routes.Login)
  }
  const renderAlreadyHaveAccount = () => {
    return (
      <AlreadyHaveAccount>
        <AlreadyHaveAccountTitle>
          Already have an account?{" "}
        </AlreadyHaveAccountTitle>
        <LoginButton onPress={onHaveAccountPress}>
          <AlreadyHaveAccountTitle useBlue>Login</AlreadyHaveAccountTitle>
        </LoginButton>
      </AlreadyHaveAccount>
    )
  }
  const focusPassword = () => {
    passwordRef.current?.focus()
  }

  const setRef = (ref: any) => {
    passwordRef.current = ref
  }

  return (
    <FormWrapper>
      <UserTextInput
        autoCapitalize="none"
        placeholder="e-mail"
        onTextChange={onEmailChange}
        value={email}
        autoComplete="email"
        enablesReturnKeyAutomatically
        keyboardType="email-address"
        returnKeyLabel="next"
        returnKeyType="next"
        selectTextOnFocus
        onSubmitEditing={focusPassword}
        errorMessage={emailError}
      />
      <PasswordContainer>
        <UserTextInput
          autoCapitalize="none"
          placeholder="password"
          secure={isPasswordSecure}
          onTextChange={onPasswordChange}
          value={password}
          autoComplete="password"
          blurOnSubmit
          enablesReturnKeyAutomatically
          returnKeyLabel="done"
          returnKeyType="done"
          selectTextOnFocus
          keyboardType="default"
          onSubmitEditing={onSubmit}
          getRef={setRef}
          multiline={false}
          errorMessage={passwordError}
        />
        <Icon
          name={isPasswordSecure ? "eye-off-outline" : "eye-outline"}
          size={22}
          onPress={togglePassSecure}
        />
      </PasswordContainer>
      {type === Routes.Login && renderForgotPasswordButton()}
      <SubmitContainer>
        {isLoading ? (
          <LoadingSpinnerContainer>
            <BlueMaterialIndicator />
          </LoadingSpinnerContainer>
        ) : (
          <SubmitButton label={type} onPress={onSubmit} />
        )}
      </SubmitContainer>
      {type === Routes.SignUp && renderAlreadyHaveAccount()}
    </FormWrapper>
  )
}

export default AuthFormPure
