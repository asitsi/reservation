import React from "react"
import { connect } from "react-redux"

import { CALLER_FOR_JOIN } from "convose-lib/utils"
import { State } from "convose-lib"
import {
  JoinCall,
  selectCallerUuid,
  selectCallingChatId,
  selectIsCaller,
  selectIsCalling,
  selectIsGroup,
  selectJoinCall,
  selectSkipCallNotification,
} from "convose-lib/calling"

import { publishMessage } from "convose-lib/users-list/dao"
import ReceivingCallNotification from "./ReceivingCallNotification"

type StateToProps = {
  readonly chatId: string
  readonly isCaller: boolean
  readonly callerUuid: string
  readonly isCalling: boolean
  readonly isGroup: boolean
  readonly joinCall: JoinCall
  readonly skipCallNotification: boolean
}

type CallingState = {
  readonly durationTime: string
}

type CallingNotificationType = StateToProps

class CallingNotification extends React.PureComponent<
  CallingNotificationType,
  CallingState
> {
  public someoneIsCalling = () => {
    const { isCalling, isCaller, joinCall, callerUuid, skipCallNotification } =
      this.props

    return (
      isCalling &&
      !isCaller &&
      !joinCall.isJoined &&
      callerUuid &&
      callerUuid !== CALLER_FOR_JOIN &&
      !skipCallNotification
    )
  }

  public render() {
    const { chatId, isGroup } = this.props
    const showCallNotification = this.someoneIsCalling()

    return showCallNotification ? (
      <ReceivingCallNotification
        isGroup={isGroup}
        chatId={chatId}
        publishMessage={publishMessage}
        delayOnTouchResponseInMs={300 + 200} // 200 is notification animation duration to show
        transparentBackground
      />
    ) : null
  }
}

const mapStateToProps = (state: State): StateToProps => ({
  chatId: selectCallingChatId(state),
  callerUuid: selectCallerUuid(state),
  isCaller: selectIsCaller(state),
  isCalling: selectIsCalling(state),
  isGroup: selectIsGroup(state),
  joinCall: selectJoinCall(state),
  skipCallNotification: selectSkipCallNotification(state),
})

export default connect(mapStateToProps, null)(CallingNotification)
