import React from "react"
import { AppState, AppStateStatus, NativeEventSubscription } from "react-native"
import { connect } from "react-redux"

import { HeartBeatData, UserHeartBeatStatus } from "convose-lib/app/dto"
import {
  beat,
  startBeatSystem,
  stopBeatSystem,
} from "convose-lib/users-list/dao"
import { selectToken } from "convose-lib/user"
import { JoinCall, selectIsCaller, selectJoinCall } from "convose-lib/calling"
import {
  ChatChannel,
  selectOpenChatChannel,
  selectOpenChatUserId,
} from "convose-lib/chat"
import { State } from "convose-lib"
import { isEqual } from "lodash"
import { UsersListAction } from "convose-lib/users-list"

type MapState = {
  token: string
  isCaller: boolean
  joinCall: JoinCall
  openChatUserId: number | null
  openChat: string | null
}

type MapDispatch = {
  setUserOnlineStatus: (
    chatChannel: ChatChannel,
    id: number,
    isOnline: boolean
  ) => void
}

type Props = MapState & MapDispatch

class PingComponent extends React.PureComponent<Props> {
  public userStatusRef: UserHeartBeatStatus = {}

  public subscribe!: NativeEventSubscription

  public isPinging = false

  public timeout!: ReturnType<typeof setTimeout> | null

  componentDidMount(): void {
    this.subscribe = AppState.addEventListener(
      "change",
      this.handleAppStateChange
    )
    this.startPingBackend()
  }

  componentDidUpdate(prevProps: Readonly<Props>): void {
    const { token } = this.props
    if (token !== prevProps.token) {
      this.stopPingBackend()
      this.startPingBackend()
    }
  }

  componentWillUnmount(): void {
    this.subscribe && this.subscribe.remove()
    if (this.timeout) {
      clearTimeout(this.timeout)
      this.timeout = null
    }
  }

  handleAppStateChange = (state: AppStateStatus) => {
    if (state.match(/inactive|background/)) {
      this.onInactiveOrBackground()
    }
    if (state === "active") {
      this.startPingBackend()
    }
  }

  updateOnlineStatus = (status: UserHeartBeatStatus) => {
    const { setUserOnlineStatus, openChat, openChatUserId } = this.props
    if (!openChat || !openChatUserId || status[openChatUserId] === undefined) {
      return
    }
    setUserOnlineStatus(openChat, openChatUserId, status[openChatUserId])
  }

  heartBeat = (data: HeartBeatData | "stopped") => {
    if (data === "stopped") {
      this.isPinging = false
      this.startPingBackend()
      return
    }
    const { openChatUserId } = this.props
    if (data.action === "ping") {
      beat(openChatUserId)
    }
    if (!isEqual(data.user_status, this.userStatusRef)) {
      this.userStatusRef = data.user_status
      this.updateOnlineStatus(data.user_status)
    }
  }

  startPingBackend = () => {
    const { token } = this.props
    if (token && !this.isPinging) {
      const started = startBeatSystem(this.heartBeat)
      if (started) {
        this.isPinging = true
      } else {
        this.timeout = setTimeout(() => {
          this.startPingBackend()
          this.timeout = null
        }, 5000)
      }
    }
  }

  stopPingBackend = () => {
    this.isPinging = false
    stopBeatSystem()
  }

  onInactiveOrBackground = () => {
    const { joinCall, isCaller } = this.props
    if (joinCall.isJoined || isCaller) {
      return
    }
    this.stopPingBackend()
  }

  render(): React.ReactNode {
    return null
  }
}
const mapState = (state: State): MapState => {
  return {
    token: selectToken(state),
    isCaller: selectIsCaller(state),
    joinCall: selectJoinCall(state),
    openChatUserId: selectOpenChatUserId(state),
    openChat: selectOpenChatChannel(state),
  }
}
const mapDispatch: MapDispatch = {
  setUserOnlineStatus: UsersListAction.setUserOnlineStatus,
}

const ConnectedComponent = connect(mapState, mapDispatch)(PingComponent)
export const Ping = React.memo(ConnectedComponent)
