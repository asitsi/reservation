import React, { memo, useCallback, useState } from "react"
import { LinearTransition } from "react-native-reanimated"
import { useTheme } from "styled-components"
import { GROUP_NAME_MAX_LENGTH } from "convose-styles"
import {
  Username,
  UsernameContainer,
  UsernameInputContainer,
  WaveButtonContainer,
} from "./Styled"
import { UsernameInput } from "../inputs"
import { WaveButton, useWaveButton } from "../WaveButton"

const layout = LinearTransition.duration(50)
const userInputStyle = { minWidth: 50 }
const usernameStyle = {
  fontSize: 25,
}
type Props = {
  isGroup: boolean
  owner: boolean | undefined
  username: string | null | undefined
  setUsername: (name: string) => void
  changeUsername: () => void
  themeColor: string
  chatChannel: string
}

const ChatMenuUsernameComponent: React.FC<Props> = ({
  changeUsername,
  isGroup,
  owner,
  setUsername,
  themeColor,
  username,
  chatChannel,
}) => {
  const theme = useTheme()
  const { onPress, canWave } = useWaveButton(chatChannel)
  const [isShowingWave, setShowingWave] = useState(!isGroup)

  const renderUsername = useCallback(() => {
    if (isGroup && !!owner) {
      return (
        <UsernameInputContainer>
          <UsernameInput
            value={username || ""}
            onChangeText={setUsername}
            onBlur={changeUsername}
            onSubmitEditing={changeUsername}
            // eslint-disable-next-line react/destructuring-assignment
            color={theme.main.text}
            onBlurMessage="Name saved!"
            maxLength={GROUP_NAME_MAX_LENGTH}
            numberOfLines={1}
            multiline={false}
            allowFontScaling
            maxFontSizeMultiplier={1}
            containerStyle={userInputStyle}
          />
        </UsernameInputContainer>
      )
    }
    return (
      <Username
        themeColor={!isGroup ? themeColor : undefined}
        style={usernameStyle}
        numberOfLines={2}
        maxFontSizeMultiplier={1}
        adjustsFontSizeToFit
      >
        {username}
      </Username>
    )
  }, [
    changeUsername,
    isGroup,
    owner,
    setUsername,
    theme.main.text,
    themeColor,
    username,
  ])
  const hideWaveButton = useCallback(() => {
    setShowingWave(false)
  }, [])
  return (
    <UsernameContainer layout={layout}>
      {renderUsername()}
      {isShowingWave && (
        <WaveButtonContainer>
          <WaveButton
            size={38}
            onDisappeared={hideWaveButton}
            disable={!canWave}
            fireOnPressOnDisabled
            onPress={onPress}
          />
        </WaveButtonContainer>
      )}
    </UsernameContainer>
  )
}

export const ChatMenuUsername = memo(ChatMenuUsernameComponent)
