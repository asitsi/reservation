import React from "react"
import { Svg, Path } from "react-native-svg"
import { SvgProps } from "../../svg/types"
import { getRatio, getWidth } from "../../svg/utils"

const defaultHeight = 21
const defaultWidth = 26
const ratio = getRatio(defaultHeight, defaultWidth)

const GroupParticipantsIconComponent: React.FunctionComponent<SvgProps> = ({
  color,
  height,
}) => {
  const svgHeight = height || defaultHeight
  const svgWidth = height ? getWidth(ratio, height) : defaultWidth
  return (
    <Svg width={svgWidth} height={svgHeight} viewBox="0 0 26 21" fill="none">
      <Path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M8.4399 9.13392C10.9353 9.13392 12.9583 7.08923 12.9583 4.56697C12.9583 2.0447 10.9353 0 8.4399 0C5.94451 0 3.92158 2.0447 3.92158 4.56697C3.92158 7.08923 5.94451 9.13392 8.4399 9.13392ZM8.43941 20C9.37338 20 10.2719 19.9141 11.1117 19.7555C10.49 19.0644 10.1352 18.2659 10.1352 17.4153C10.1352 15.3857 12.1552 13.6529 15 12.968C14.469 12.5755 14.0246 12.0706 13.701 11.4879C12.2581 10.8358 10.4292 10.4461 8.43941 10.4461C3.77846 10.4461 0 12.5848 0 15.223C0 17.8612 3.77846 20 8.43941 20Z"
        fill={color || "white"}
      />
      <Path
        d="M19 21C22.866 21 26 19.433 26 17.5C26 15.567 22.866 14 19 14C15.134 14 12 15.567 12 17.5C12 19.433 15.134 21 19 21Z"
        fill={color || "white"}
      />
      <Path
        d="M18.5 13C20.433 13 22 11.433 22 9.5C22 7.567 20.433 6 18.5 6C16.567 6 15 7.567 15 9.5C15 11.433 16.567 13 18.5 13Z"
        fill={color || "white"}
      />
    </Svg>
  )
}
export const GroupParticipantsIcon = React.memo(GroupParticipantsIconComponent)
export default GroupParticipantsIcon
