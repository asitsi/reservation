import React from "react"
import { useSelector } from "react-redux"
import { FadeIn, FadeOut } from "react-native-reanimated"

import { selectAuthMessage } from "convose-lib"
import { DisplayTextModal, ModalContent } from "./Styled"

const style = {
  zIndex: Number.MAX_SAFE_INTEGER,
  elevation: Number.MAX_SAFE_INTEGER,
}
const AuthDisplayTextComponent: React.FC = () => {
  const authDisplayText = useSelector(selectAuthMessage)

  return authDisplayText ? (
    <DisplayTextModal entering={FadeIn} exiting={FadeOut} style={style}>
      <ModalContent>{authDisplayText}</ModalContent>
    </DisplayTextModal>
  ) : null
}

export const AuthDisplayText = React.memo(AuthDisplayTextComponent)
