import React from "react"
import { isEqual, uniqBy } from "lodash"

import { SuggestedProfile } from "convose-lib/users-list/dto"
import {
  ChatboxListContainer,
  SkeletonType,
  isSkeletonType,
} from "./ChatboxListContainer"

type Props = {
  readonly users: ReadonlyArray<SuggestedProfile> | null
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const isSuggestedProfile = (obj: any): obj is SuggestedProfile => {
  return "avatar" in obj
}
type AllProps = Props
class ChatboxListComponent extends React.Component<AllProps> {
  shouldComponentUpdate(nextProps: AllProps): boolean {
    const { users } = this.props
    return !isEqual(users, nextProps.users)
  }

  public getUsers = (): SuggestedProfile[] | SkeletonType[] => {
    const { users } = this.props
    if (!users || !users.length) {
      return Array(4)
        .fill(1)
        .map((_, index) => {
          return {
            uuid: `${index}`,
            isSkeleton: true,
          }
        })
    }
    return uniqBy(users, "uuid").filter((user) => {
      if ("call_users" in user && !!user.call_users) {
        return true
      }
      if (user?.permissions?.blocked) {
        return false
      }
      return true
    })
  }

  public render(): React.ReactNode {
    const uniqueUsers = this.getUsers()
    const isLoading = !!uniqueUsers.filter(isSkeletonType).length
    const groups = isLoading
      ? uniqueUsers
      : uniqueUsers.filter(isSuggestedProfile).filter((user) => user.group_name)
    const oneOnOnes = isLoading
      ? uniqueUsers
      : uniqueUsers
          .filter(isSuggestedProfile)
          .filter((user) => !user.group_name)

    return <ChatboxListContainer groups={groups} oneOnOnes={oneOnOnes} />
  }
}

// ChatboxListComponent.whyDidYouRender = {
//   logOnDifferentValues: false,
//   customName: "ChatboxListComponent",
//   diffNameColor: "red",
// }
export const ChatboxList = React.memo(ChatboxListComponent)
