/* eslint-disable complexity, react-hooks/exhaustive-deps */
import React, { forwardRef, useImperativeHandle } from "react"
import { AppState, AppStateStatus, NativeEventSubscription } from "react-native"
import { connect } from "react-redux"

import { State, selectOnboarding } from "convose-lib"
import {
  ChatAction,
  selectIsPickingImage,
  selectIsTakingImage,
  selectOpenChatChannel,
} from "convose-lib/chat"
import { selectToken, UserAction } from "convose-lib/user"
import {
  getMessageCount,
  MESSAGE_COUNT_LIMIT,
  selectUnreadLoadingPartnerFeature,
  setMessageCount,
  UsersListAction,
} from "convose-lib/users-list"
import { CallingAction, selectIsCalling } from "convose-lib/calling"
import { AppAction, selectIsRequestingPermission } from "convose-lib/app"
import { useNavbarStatusWithPrevious } from "convose-lib/utils"
import { saveToDb, getNumberFromDb } from "../../../storage"

type StatusHandlerRefType = {
  setPreviousNavbarStatusColor: () => void
}
const StatusHandler = forwardRef<StatusHandlerRefType>((props, ref) => {
  const { setPreviousNavbarStatusColor } = useNavbarStatusWithPrevious()
  useImperativeHandle(ref, () => ({
    setPreviousNavbarStatusColor,
  }))
  return null
})

type StateToProps = {
  isPickingImageState: boolean
  isTakingImageState: boolean
  onboarding: boolean
  authToken: string
  openChat: string | null
  loadingUnreadPartners: boolean
  isCalling: boolean
  isRequestingPermission: boolean
}
type DispatchToProps = {
  stopGettingUsersList: () => void
  startSendingPushNotifications: () => void
  unsubscribeChat: (chatChannel: string) => void
  getUsersList: () => void
  getUnreadPartnersList: () => void
  startNotifying: () => void
  stopSendingPushNotifications: () => void
  subscribeChat: (chatChannel: string) => void
  setShouldFetchAfterNetRecover: () => void
  setIsPickingImage: (isPickingImage: boolean) => void
  setIsTakingImage: (isTakingImage: boolean) => void
  // getInboxUpdate: () => void
  markAsRead: (chatChannel: string) => void
  setGroupCallChannelStatusOnConnecting: () => void
  setRequestingPermission: (isRequesting: boolean) => void
}
const FB_MESSAGE_COUNT_KEY = "FB_MESSAGE_COUNT_KEY"
type Props = StateToProps & DispatchToProps
class AppStateControlComponent extends React.PureComponent<Props> {
  public appStateSubscription!: NativeEventSubscription

  public statusHandlerRef = React.createRef<StatusHandlerRefType>()

  // prevents connecting to socket on the app start
  public isFirstRun = true

  componentDidMount(): void {
    // const { getInboxUpdate } = this.props
    // getInboxUpdate()
    this.appStateSubscription = AppState.addEventListener(
      "change",
      this.handleAppStateChange
    )
  }

  componentWillUnmount(): void {
    this.appStateSubscription && this.appStateSubscription.remove()
  }

  handleAppStateChange = (appState: AppStateStatus) => {
    const {
      isPickingImageState,
      isTakingImageState,
      isCalling,
      stopGettingUsersList,
      onboarding,
      authToken,
      startSendingPushNotifications,
      openChat,
      unsubscribeChat,
      getUsersList,
      loadingUnreadPartners,
      getUnreadPartnersList,
      setIsPickingImage,
      setIsTakingImage,
      setShouldFetchAfterNetRecover,
      startNotifying,
      stopSendingPushNotifications,
      subscribeChat,
      markAsRead,
      setGroupCallChannelStatusOnConnecting,
      isRequestingPermission,
      setRequestingPermission,
    } = this.props

    if (
      appState.match(/inactive|background/) &&
      !isPickingImageState &&
      !isTakingImageState
    ) {
      const messageCount = getMessageCount()
      messageCount <= MESSAGE_COUNT_LIMIT &&
        saveToDb(FB_MESSAGE_COUNT_KEY, messageCount)
      if (isRequestingPermission) {
        return
      }
      if (!isCalling) {
        stopGettingUsersList()
      }
      !onboarding && authToken && startSendingPushNotifications()
      openChat && !isCalling && unsubscribeChat(openChat)
      openChat && markAsRead(openChat)
    }

    if (appState === "active") {
      setMessageCount(getNumberFromDb(FB_MESSAGE_COUNT_KEY) || 0)
      if (!isPickingImageState && !isTakingImageState) {
        if (isRequestingPermission) {
          setRequestingPermission(false)
          return
        }
        authToken &&
          !loadingUnreadPartners &&
          !onboarding &&
          !isCalling &&
          getUnreadPartnersList()
        openChat && !isCalling && subscribeChat(openChat)

        if (!onboarding) {
          if (this.isFirstRun) {
            this.isFirstRun = false
          } else {
            getUsersList()
            !isCalling && startNotifying()
          }
        }
        setGroupCallChannelStatusOnConnecting()
        authToken && stopSendingPushNotifications()
        openChat && setShouldFetchAfterNetRecover()
        this.statusHandlerRef.current?.setPreviousNavbarStatusColor()
      } else {
        isPickingImageState ? setIsPickingImage(false) : setIsTakingImage(false)
      }
    }
  }

  render(): React.ReactNode {
    return <StatusHandler ref={this.statusHandlerRef} />
  }
}
const mapStateToProps = (state: State): StateToProps => {
  return {
    isPickingImageState: selectIsPickingImage(state),
    isTakingImageState: selectIsTakingImage(state),
    onboarding: selectOnboarding(state),
    authToken: selectToken(state),
    openChat: selectOpenChatChannel(state),
    loadingUnreadPartners: selectUnreadLoadingPartnerFeature(state),
    isCalling: selectIsCalling(state),
    isRequestingPermission: selectIsRequestingPermission(state),
  }
}
const mapDispatchToProps: DispatchToProps = {
  stopGettingUsersList: UsersListAction.stopGettingUsersList,
  startSendingPushNotifications: UserAction.setUserInactive,
  unsubscribeChat: ChatAction.unsubscribeChat,
  getUsersList: UsersListAction.getUsersList,
  getUnreadPartnersList: UsersListAction.getUnreadPartnersList,
  startNotifying: ChatAction.startNotifying,
  stopSendingPushNotifications: UserAction.setUserActive,
  subscribeChat: ChatAction.subscribeChat,
  setShouldFetchAfterNetRecover: ChatAction.setShouldFetchAfterNetRecover,
  setIsPickingImage: ChatAction.setIsPickingImage,
  setIsTakingImage: ChatAction.setIsTakingImage,
  // getInboxUpdate: UsersListAction.getInboxUpdate,
  markAsRead: UsersListAction.markAsRead,
  setGroupCallChannelStatusOnConnecting:
    CallingAction.setGroupCallChannelStatusOnConnecting,
  setRequestingPermission: AppAction.setRequestingPermission,
}
export const AppStateControl = React.memo(
  connect(mapStateToProps, mapDispatchToProps)(AppStateControlComponent)
)
