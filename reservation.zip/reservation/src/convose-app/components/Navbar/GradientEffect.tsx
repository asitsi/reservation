/* eslint-disable react-perf/jsx-no-new-array-as-prop, react-perf/jsx-no-new-object-as-prop, @typescript-eslint/no-explicit-any */
import React from "react"
import { LinearGradient } from "expo-linear-gradient"
import { useTheme } from "styled-components"

import { interestsBarHeight } from "convose-styles"
import { GradientEffectBase, GradientsContainer } from "./Styled"

type Props = {
  bottomInset: number
  pointerEvents?: "auto" | "none" | "box-none"
}

const barHeight = interestsBarHeight + 25
const GradientEffectComponent: React.FC<Props> = ({
  bottomInset,
  pointerEvents,
}) => {
  const theme = useTheme()
  return (
    <>
      <GradientsContainer
        bottomInset={bottomInset}
        pointerEvents={pointerEvents}
      >
        <LinearGradient
          colors={[theme.statusBarTransparent, theme.statusBar]}
          locations={[0, 1]}
          style={{
            position: "absolute",
            left: 0,
            right: 0,
            bottom: barHeight - 10,
            height: barHeight + 10,
            zIndex: 2,
          }}
        />
        <LinearGradient
          colors={[theme.statusBarTransparent, theme.statusBar]}
          locations={[0, 0.1]}
          style={{
            position: "absolute",
            left: 0,
            right: 0,
            bottom: 0,
            height: barHeight,
          }}
        />
      </GradientsContainer>
      <GradientEffectBase height={bottomInset} />
    </>
  )
}

export const GradientEffect = React.memo(GradientEffectComponent)
