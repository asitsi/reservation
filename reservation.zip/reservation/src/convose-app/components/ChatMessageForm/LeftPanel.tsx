import React, { useCallback, useEffect } from "react"
import Animated, {
  FadeInRight,
  FadeOutRight,
  LinearTransition,
  useAnimatedStyle,
  useSharedValue,
  withTiming,
} from "react-native-reanimated"

import { color } from "convose-styles"
import { useMainBlue } from "convose-lib/utils/useMainBlue"
import {
  ArrowRightSvg,
  CameraSvg,
  GallerySvg,
  CommandSvg,
} from "../../../assets/svg"
import {
  ICONS_SIZE,
  LeftPanelContainer,
  LeftPanelFullPanelContainer,
} from "./Styled"
import { IconButton } from "./UtilFunctions"

const layout = LinearTransition.damping(25).springify(250)

type LeftPanelType = {
  isInCallingChat: boolean
  onTakePicturePress: () => void
  onChoosePicturePress: () => void
  onCommandPress: () => void
  toggleFullPanel: () => void
  shouldShowFullPanel: boolean
  strokeIcons?: boolean
}
const CLOSED_WIDTH = ICONS_SIZE + 25
const FULL_PANEL_WIDTH_IN_CALL = CLOSED_WIDTH * 2
const FULL_PANEL_WIDTH = CLOSED_WIDTH * 3
const ANIMATION_DURATION = 100
const LeftPanelComponent: React.FC<LeftPanelType> = ({
  isInCallingChat,
  onChoosePicturePress,
  onTakePicturePress,
  onCommandPress,
  toggleFullPanel,
  shouldShowFullPanel,
  strokeIcons,
}) => {
  const mainBlue = useMainBlue()

  const getPanelSize = useCallback(() => {
    if (shouldShowFullPanel && !isInCallingChat) {
      return FULL_PANEL_WIDTH
    }
    if (
      (!shouldShowFullPanel && isInCallingChat) ||
      (shouldShowFullPanel && isInCallingChat)
    ) {
      return FULL_PANEL_WIDTH_IN_CALL
    }
    return CLOSED_WIDTH
  }, [isInCallingChat, shouldShowFullPanel])
  const widthOffset = useSharedValue(getPanelSize())
  const style = useAnimatedStyle(() => ({
    width: widthOffset.value,
  }))
  useEffect(() => {
    widthOffset.value = withTiming(getPanelSize(), {
      duration: ANIMATION_DURATION,
    })
  }, [getPanelSize, widthOffset])
  const renderFullPanel = () => {
    return (
      <LeftPanelFullPanelContainer>
        {!isInCallingChat && (
          <IconButton
            onPress={onTakePicturePress}
            svg={
              <CameraSvg
                height={ICONS_SIZE}
                color={mainBlue}
                strokeColor={strokeIcons ? color.black : undefined}
              />
            }
          />
        )}
        <IconButton
          onPress={onChoosePicturePress}
          svg={
            <GallerySvg
              height={ICONS_SIZE}
              color={mainBlue}
              strokeColor={strokeIcons ? color.black : undefined}
            />
          }
        />
        <IconButton
          onPress={onCommandPress}
          svg={
            <CommandSvg
              height={ICONS_SIZE + 2}
              color={mainBlue}
              strokeColor={strokeIcons ? color.black : undefined}
            />
          }
        />
      </LeftPanelFullPanelContainer>
    )
  }

  const renderExpander = () => {
    return (
      <Animated.View
        exiting={FadeOutRight.duration(ANIMATION_DURATION)}
        entering={FadeInRight.duration(ANIMATION_DURATION)}
      >
        <IconButton
          onPress={toggleFullPanel}
          svg={<ArrowRightSvg height={ICONS_SIZE} color={color.mainBlue} />}
        />
      </Animated.View>
    )
  }
  return (
    <LeftPanelContainer style={style} layout={layout}>
      {!shouldShowFullPanel && !isInCallingChat
        ? renderExpander()
        : renderFullPanel()}
    </LeftPanelContainer>
  )
}

export const LeftPanel = React.memo(LeftPanelComponent)
