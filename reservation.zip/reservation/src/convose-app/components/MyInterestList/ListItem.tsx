import React, { useState } from "react"
import { Gesture, GestureDetector } from "react-native-gesture-handler"
import Animated, {
  SharedValue,
  runOnJS,
  useAnimatedReaction,
  useAnimatedStyle,
  useSharedValue,
  withSpring,
  withTiming,
} from "react-native-reanimated"

type PositionsType = {
  [id: string]: number
}
type ListItemProps = {
  enableSorting: () => void
  isSorting: boolean
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  index: any
  positions: SharedValue<PositionsType>
  itemCount: number
  itemHeight: number
  onSortEnded?: () => void
  onSortStart?: () => void
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
function objectMove(object: any, from: number, to: number) {
  "worklet"

  const newObject = { ...object }

  // eslint-disable-next-line no-restricted-syntax, guard-for-in
  for (const id in object) {
    if (object[id] === from) {
      newObject[id] = to
    }

    if (object[id] === to) {
      newObject[id] = from
    }
  }

  return newObject
}

function clamp(value: number, lowerBound: number, upperBound: number) {
  "worklet"

  return Math.max(lowerBound, Math.min(value, upperBound))
}

export const ListItem: React.FC<React.PropsWithChildren<ListItemProps>> = ({
  children,
  enableSorting,
  isSorting,
  index,
  positions,
  itemCount,
  itemHeight,
  onSortEnded,
  onSortStart,
}) => {
  const top = useSharedValue(positions.value[index] * itemHeight)
  const [isMoving, setIsMoving] = useState(false)
  const startTouchPoint = useSharedValue(0)

  useAnimatedReaction(
    () => positions.value[index],
    (currentPosition, previousPosition) => {
      if (currentPosition !== previousPosition) {
        if (!isMoving) {
          top.value = withSpring(currentPosition * itemHeight)
        }
      }
    },
    [isMoving]
  )

  const containerSortingStyle = useAnimatedStyle(
    () => ({
      height: itemHeight,
      position: isSorting ? "absolute" : "relative",
      top: top.value,
      zIndex: isMoving ? 1 : 0,
      shadowOpacity: withSpring(isMoving ? 0.2 : 0),
      elevation: withSpring(isMoving ? 2 : 0),
      shadowRadius: 10,
    }),
    [isMoving, isSorting]
  )

  const longPress = Gesture.LongPress()
    .onStart(() => {
      runOnJS(enableSorting)()
    })
    .onTouchesDown((_, state) => {
      if (isSorting) {
        state.fail()
      }
    })
  const pan = Gesture.Pan()
    .onTouchesDown((_, state) => {
      if (!isSorting) {
        state.fail()
      } else {
        onSortStart && runOnJS(onSortStart)()
        runOnJS(setIsMoving)(true)
        startTouchPoint.value = top.value + itemHeight
      }
    })
    .onUpdate(({ translationY }) => {
      const positionY = translationY + startTouchPoint.value
      top.value = withTiming(positionY - itemHeight, {
        duration: 16,
      })

      const newPosition = clamp(
        Math.floor(positionY / itemHeight),
        0,
        itemCount - 1
      )
      if (newPosition !== positions.value[index]) {
        // eslint-disable-next-line no-param-reassign
        positions.value = objectMove(
          positions.value,
          positions.value[index],
          newPosition
        )
      }
    })
    .onEnd(() => {
      !!onSortEnded && runOnJS(onSortEnded)()
    })
    .onTouchesUp(() => {
      top.value = positions.value[index] * itemHeight
      runOnJS(setIsMoving)(false)
    })
  const gesture = Gesture.Simultaneous(longPress, pan)
  return (
    <GestureDetector gesture={gesture}>
      <Animated.View style={containerSortingStyle}>{children}</Animated.View>
    </GestureDetector>
  )
}
