/* eslint-disable @typescript-eslint/no-shadow */
import React from "react"
import { Keyboard } from "react-native"
import { connect } from "react-redux"
import { debounceTime, filter } from "rxjs/operators"
import { BehaviorSubject } from "rxjs"
import { withSafeAreaInsets } from "react-native-safe-area-context"
import { uniqBy } from "lodash"

import {
  ChatChannel,
  ChatSummary,
  ChatUser,
  createChatChannelId,
} from "convose-lib/chat"
import { State } from "convose-lib/store"
import {
  selectParticipantsArray,
  selectLoadingParticipantsFeature,
  selectParticipantsHasNextPage,
  selectIsGroupAdmin,
  selectChatSummary,
} from "convose-lib/users-list"
import { color } from "convose-styles"
import { Routes } from "convose-lib/router"
import { DEFAULT_DEBOUNCE_TIME, PARTICIPANT_LIMIT } from "convose-lib/utils"
import { selectToken } from "convose-lib/user"
import { selectIsDarkMode } from "convose-lib/app"
import { SafeAreaProps } from "convose-lib/generalTypes"

import { AddPersonItem } from "../AddPersonItem"
import { Header } from "../../components/Header"
import * as RootNavigation from "../../RootNavigation"
import {
  UsersListAction,
  searchParticipants,
} from "../../../convose-lib/users-list"

import {
  ConversationsWrapper,
  InboxWrapper,
  LoadingContainer,
  StyledFlatList,
  StyledSearchUserInput,
} from "./Styled"
import { BlueMaterialIndicator } from "../MaterialIndicator"
import { GroupAvatar } from "../Avatar"

type LocalState = {
  searchResults: ChatUser[]
  keyword: string
}

type Props = {
  readonly goBackCallback?: () => void
  readonly chatChannel: string
  readonly myUuid?: string
  readonly firstTwoParticipants: ChatUser[]
  readonly openChatOnPress?: boolean
  readonly disableOnUserPress?: boolean
}

type StateToProps = {
  readonly participants: ChatUser[]
  readonly hasNextPage: boolean
  readonly loadingParticipants: boolean
  readonly token: string
  readonly isDarkMode: boolean | null
  readonly isGroupAdmin: boolean
  readonly chatSummary: ChatSummary | null
}

type DispatchToProps = {
  readonly getParticipants: (
    chatChannel: ChatChannel,
    from: number,
    limit: number
  ) => void
}

const keyExtract = (item: ChatUser): string => {
  return item.uuid
}

type AllProps = Props & StateToProps & DispatchToProps & SafeAreaProps

class UserListComponent extends React.PureComponent<AllProps, LocalState> {
  state: LocalState = {
    searchResults: [],
    keyword: "",
  }

  private readonly phrase$: BehaviorSubject<string> = new BehaviorSubject("")

  constructor(props: AllProps) {
    super(props)
    const { chatChannel, getParticipants } = this.props
    getParticipants(chatChannel, 0, PARTICIPANT_LIMIT)
  }

  public componentDidMount(): void {
    const { participants } = this.props
    // eslint-disable-next-line react/no-did-update-set-state
    this.setState({ searchResults: participants })
    this.phrase$
      .pipe(
        debounceTime(DEFAULT_DEBOUNCE_TIME),
        filter((v) => !!v)
      )
      .subscribe(this.onSearch)
  }

  public componentDidUpdate(prevProps: AllProps, prevState: LocalState): void {
    const { participants, chatChannel } = this.props
    const { keyword } = this.state
    if (
      participants.length > prevProps.participants.length ||
      prevProps.chatChannel !== chatChannel ||
      (prevState.keyword && !keyword)
    ) {
      // eslint-disable-next-line react/no-did-update-set-state
      this.setState({ searchResults: participants })
    }
  }

  public componentWillUnmount(): void {
    this.phrase$.unsubscribe()
  }

  private onSearch = async (text: string) => {
    const { chatChannel, token } = this.props
    const searchResults =
      (await searchParticipants(token, chatChannel, text).toPromise()) || []
    text && this.setState({ searchResults })
  }

  private handleTouch =
    (chatUser: ChatUser) =>
    (userId: string): void => {
      const {
        myUuid,
        openChatOnPress,
        isGroupAdmin,
        chatChannel,
        disableOnUserPress,
      } = this.props
      if (disableOnUserPress) {
        return
      }
      Keyboard.dismiss()
      if (openChatOnPress) {
        if (myUuid === userId) {
          return
        }
        const channel = createChatChannelId(myUuid || "", userId)
        RootNavigation.navigate(Routes.Chat, {
          channel,
          chatUser,
          forRejoinCall: false,
        })
      } else {
        RootNavigation.navigate(Routes.UserProfile, {
          chatUserId: userId,
          chatUser,
          myUuid,
          canBlock: isGroupAdmin,
          chatChannel,
        })
      }
    }

  private renderFooter = () => {
    const { loadingParticipants, insets } = this.props
    return (
      <LoadingContainer insetBottom={insets.bottom || 10}>
        {loadingParticipants ? <BlueMaterialIndicator /> : null}
      </LoadingContainer>
    )
  }

  private renderChatUser = ({
    item,
  }: {
    readonly item: ChatUser
    readonly index: number
  }) => {
    if (item.uuid === "footer") {
      return this.renderFooter()
    }
    return (
      <AddPersonItem
        key={item.uuid}
        user={item}
        handleTouch={this.handleTouch(item)}
        selected={false}
        listStyle
      />
    )
  }

  // Todo: fetch backend endpoint to search
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  private handleChangeText = (text: string) => {
    this.setState({ keyword: text })
    this.phrase$.next(text)
  }

  private readonly handleOnEndReached = () => {
    const {
      getParticipants,
      loadingParticipants,
      chatChannel,
      hasNextPage,
      participants,
    } = this.props
    const { keyword } = this.state

    if (!loadingParticipants && !keyword && hasNextPage) {
      getParticipants(
        chatChannel,
        // this.dataPage * PARTICIPANT_LIMIT,
        (participants || []).length,
        PARTICIPANT_LIMIT
      )
      // this.dataPage += 1
    }
  }

  private onBackPress = () => {
    const { goBackCallback } = this.props
    goBackCallback && goBackCallback()
  }

  public render(): React.ReactNode {
    const { firstTwoParticipants, isDarkMode, insets, chatSummary } = this.props
    const { searchResults } = this.state
    const horizontalInset = Math.max(insets.left, insets.right) || 0
    const uniqueSearchResults = uniqBy(
      [...searchResults, { uuid: "footer" }],
      "uuid"
    )

    return (
      <InboxWrapper horizontalInset={horizontalInset}>
        <Header
          avatar={
            <GroupAvatar
              participants={firstTwoParticipants}
              avatar={chatSummary?.avatar}
            />
          }
          onBackPress={this.onBackPress}
          title="Group members:"
          hasMenu={false}
        />
        <ConversationsWrapper>
          <StyledSearchUserInput
            placeholder="Search"
            placeholderTextColor={color.interests.autocompleteList.color}
            textAlign="center"
            multiline={false}
            onChangeText={this.handleChangeText}
            keyboardAppearance={isDarkMode ? "dark" : "light"}
          />
          <StyledFlatList
            data={uniqueSearchResults}
            renderItem={this.renderChatUser}
            keyExtractor={keyExtract}
            ListEmptyComponent={<BlueMaterialIndicator />}
            onEndReached={this.handleOnEndReached}
            onEndReachedThreshold={0.5}
            keyboardShouldPersistTaps="handled"
          />
        </ConversationsWrapper>
      </InboxWrapper>
    )
  }
}

const mapStateToProps = (state: State, ownProps: Props): StateToProps => ({
  participants: selectParticipantsArray(ownProps.chatChannel)(state),
  loadingParticipants: selectLoadingParticipantsFeature(state),
  hasNextPage: selectParticipantsHasNextPage(state),
  token: selectToken(state) || "",
  isDarkMode: selectIsDarkMode(state),
  isGroupAdmin: selectIsGroupAdmin(ownProps.chatChannel)(state),
  chatSummary: selectChatSummary(ownProps.chatChannel)(state),
})

const mapDispatchToProps: DispatchToProps = {
  getParticipants: UsersListAction.getParticipants,
}

export const UserList = connect(
  mapStateToProps,
  mapDispatchToProps
)(withSafeAreaInsets(UserListComponent))
