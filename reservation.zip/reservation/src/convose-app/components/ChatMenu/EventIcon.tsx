import React from "react"
import { useSelector } from "react-redux"

import { useMainBlue } from "convose-lib/utils/useMainBlue"
import { color } from "convose-styles"
import { selectIsDarkMode } from "convose-lib/app"
import { EventGear } from "../../../assets/Icons/components/Event"

type Props = {
  height?: number
  useDefaultColor?: boolean
}
const EventIconComponent: React.FC<Props> = ({ height, useDefaultColor }) => {
  const mainBlue = useMainBlue()
  const isDark = useSelector(selectIsDarkMode)
  const defaultColor = isDark ? color.white : color.black
  return (
    <EventGear
      height={height}
      color={useDefaultColor ? defaultColor : mainBlue}
    />
  )
}

export const EventIcon = React.memo(EventIconComponent)
