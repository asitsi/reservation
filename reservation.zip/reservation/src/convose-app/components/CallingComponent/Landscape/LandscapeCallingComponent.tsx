import React from "react"
import { ScrollView, StatusBar } from "react-native"
import { withSafeAreaInsets } from "react-native-safe-area-context"

import { isSpeakerActive } from "../Common/utils"
import { CallingComponentProps } from "../dto"
import { LandscapeCallingButtons } from "./CallingButtons"
import { LandscapeCallingUsers } from "./CallingUsers"

type Props = CallingComponentProps & {
  isLandscapeRight: boolean
}
const LandscapeCallingRaw: React.FC<Props> = ({
  me,
  isGroup,
  audioSetting,
  peers,
  channel,
  endCall,
  unmuteAlert,
  unsetUnmuteAlert,
  toggleAudio,
  toggleSpeaker,
  toggleVideo,
  insets,
  isLandscapeRight,
  groupInfo,
  muteRemoteUser,
  videoCallFullScreenUid,
  participants,
  isHeaderHide,
  isChatHide,
  isGroupAdmin,
  isHandRaiseEnabled,
  toggleHandRaise,
  myRaisedHandStatus,
}) => {
  React.useEffect(() => {
    StatusBar.setHidden(true)
    return () => {
      StatusBar.setHidden(false)
    }
  }, [])

  const userListScrollRef = React.useRef<ScrollView>()

  const setUserScrollRef = (ref: ScrollView) => {
    userListScrollRef.current = ref
  }

  const scrollToStart = () => {
    userListScrollRef.current?.scrollTo({
      animated: true,
      y: 0,
    })
  }
  const handleToggleAudio = () => {
    scrollToStart()
    toggleAudio()
  }
  const handleToggleSpeaker = () => {
    toggleSpeaker()
  }
  const handleToggleVideo = () => {
    scrollToStart()
    toggleVideo()
  }

  return (
    <>
      <LandscapeCallingUsers
        insetRight={isLandscapeRight ? insets.right : 10}
        isCalling={false}
        isHide={false}
        groupInfo={groupInfo}
        me={me}
        peers={peers}
        channel={channel}
        isGroup={isGroup}
        muteRemoteUser={muteRemoteUser}
        audioSetting={audioSetting}
        videoCallFullScreenUid={videoCallFullScreenUid}
        setUserScrollRef={setUserScrollRef}
        participants={participants}
        isLandscape
        isHeaderHide={isHeaderHide}
        isGroupAdmin={isGroupAdmin}
        isHandRaiseEnabled={isHandRaiseEnabled}
      />
      <LandscapeCallingButtons
        insetBottom={insets.bottom}
        insetLeft={insets.left}
        isLandscapeLeft={!isLandscapeRight}
        isAudioEnabled={audioSetting.isAudioEnabled}
        isSpeakerActive={isSpeakerActive(audioSetting.speakerMode)}
        isVideoEnabled={audioSetting.isVideoEnabled}
        endCall={() => endCall({ displayText: true })}
        toggleAudio={handleToggleAudio}
        toggleSpeaker={handleToggleSpeaker}
        toggleVideo={handleToggleVideo}
        unmuteAlert={unmuteAlert}
        unsetUnmuteAlert={unsetUnmuteAlert}
        isGroup={isGroup}
        isLandscape
        isHeaderHide={isHeaderHide}
        isGroupAdmin={isGroupAdmin}
        isHandRaiseEnabled={isHandRaiseEnabled}
        toggleHandRaise={toggleHandRaise}
        myRaisedHandStatus={myRaisedHandStatus}
        isChatHide={isChatHide}
      />
    </>
  )
}

export const LandscapeCallingComponent = React.memo(
  withSafeAreaInsets(LandscapeCallingRaw)
)
