import React, { useEffect } from "react"
import { ViewStyle } from "react-native"
import { ZoomIn, ZoomOut } from "react-native-reanimated"
import { useTheme } from "styled-components"

import { AVATAR_SIZE } from "convose-styles"

import {
  ChatboxAvatar,
  ChatboxBody,
  ChatboxHeader,
  ChatboxInterests,
  ChatboxWrapper,
  EmptyAvatar,
  EmptyInterest,
  EmptyInterestLine,
  HeaderColorBox,
} from "./Styled"
import { useSkeleton } from "../Skeleton"

type Props = {
  readonly style?: ViewStyle
}
const ChatboxSkeletonComponent: React.FC<Props> = ({ style }) => {
  const theme = useTheme()
  const [animatedStyles, startLoading, stopLoading] = useSkeleton(
    theme.main.chatBoxSkeletonLight,
    theme.main.chatBoxSkeletonBold
  )
  useEffect(() => {
    startLoading()
    return () => {
      stopLoading()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])
  return (
    <ChatboxWrapper
      style={style}
      widthPercentage={100}
      entering={ZoomIn.duration(100)}
      exiting={ZoomOut.duration(100)}
      isUpcomingEvent={false}
      isGroupCallWithUpcomingEvent={false}
    >
      <HeaderColorBox style={animatedStyles} />
      <ChatboxHeader>
        <ChatboxAvatar>
          <EmptyAvatar size={AVATAR_SIZE} style={animatedStyles} />
        </ChatboxAvatar>
      </ChatboxHeader>
      <ChatboxBody>
        <ChatboxInterests hasJoinCall={false} isUpcomingEvent={false}>
          <EmptyInterestLine>
            <EmptyInterest style={animatedStyles} />
            <EmptyInterest isBig style={animatedStyles} />
          </EmptyInterestLine>
          <EmptyInterestLine>
            <EmptyInterest isBig style={animatedStyles} />
            <EmptyInterest style={animatedStyles} />
          </EmptyInterestLine>
          <EmptyInterestLine>
            <EmptyInterest style={animatedStyles} />
            <EmptyInterest isBig style={animatedStyles} />
          </EmptyInterestLine>
        </ChatboxInterests>
      </ChatboxBody>
    </ChatboxWrapper>
  )
}

export const ChatboxSkeleton = React.memo(ChatboxSkeletonComponent)
