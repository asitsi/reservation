import { CenteredText, Props, font } from "convose-styles"
import styled from "styled-components/native"
import EntypoIcon from "react-native-vector-icons/Entypo"
import Animated from "react-native-reanimated"

export const Container = styled(Animated.View)`
  width: 100%;
  background-color: ${(props: Props) => props.theme.message.otherMessageBubble};
  flex-direction: column;
  align-items: flex-start;
  padding: 15px;
  border-radius: 11px;
  margin-bottom: 10px;
`
export const TitleMenuContainer = styled.View`
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  margin-top: -5px;
  margin-bottom: -5px;
`
export const TitleContainer = styled.View`
  width: 90%;
  justify-content: flex-start;
  align-items: flex-start;
`
export const Title = styled(CenteredText)`
  font-family: ${font.bold};
  font-size: 18px;
  color: ${(props: Props) => props.theme.main.text};
`
export const MainBlueEntypoIcon = styled(EntypoIcon)`
  color: ${(props: Props) => props.theme.mainBlue};
  margin-bottom: 5px;
`
export const DateDescription = styled(CenteredText)`
  font-family: ${font.bold};
  font-size: 13px;
  color: ${(props: Props) => props.theme.main.text};
  padding-bottom: 3px;
`

export const HostAttendanceContainer = styled.View`
  flex-direction: row;
  width: 100%;
  justify-content: flex-start;
`
export const HostAttendeesContainer = styled.View`
  min-width: 70%;
`

export const HostTitle = styled(CenteredText)`
  font-family: ${(props: { boldTitle: boolean }) =>
    props.boldTitle ? font.semiBold : font.normal};
  font-size: ${(props: { boldTitle: boolean }) =>
    props.boldTitle ? "15px" : "13px"};
  color: ${(props: Props) => props.theme.main.text};
  ${(props: { boldTitle: boolean }) =>
    props.boldTitle ? "line-height: 18.5px;" : ""};
`
export const HostContainer = styled.View`
  flex-direction: row;
`
export const HostUsername = styled(CenteredText)`
  font-family: ${font.bold};
  font-size: 13px;
  color: ${(props: Props & { themeColor?: string }) =>
    props.themeColor || props.theme.main.text};
  text-transform: capitalize;
`
export const AttendeesContainer = styled.View`
  flex-direction: ${(props: { showAttendeesFirst: boolean }) =>
    props.showAttendeesFirst ? "row-reverse" : "row"};
  ${(props: { showAttendeesFirst: boolean }) =>
    props.showAttendeesFirst ? "justify-content: flex-end;" : ""};
`
export const AttendeesAvatarsContainer = styled.View`
  ${(props: { showAttendeesFirst: boolean }) =>
    !props.showAttendeesFirst ? "margin-left: 5px;" : ""};
  ${(props: { showAttendeesFirst: boolean }) =>
    props.showAttendeesFirst ? "margin-right: -8px;" : ""};
`
export const Touchable = styled.TouchableOpacity``
export const AttendButtonContainer = styled(Animated.View)`
  flex-direction: row;
  justify-content: center;
  align-items: center;
  border: 1px;
  border-color: ${(
    props: Props & { noBorder: boolean; useMainTextColor: boolean }
  ) => {
    if (props.noBorder) {
      return "transparent"
    }
    if (props.useMainTextColor) {
      return props.theme.main.text
    }
    return props.theme.mainBlue
  }};
  border-radius: 20px;
  padding: 0px 7px;
  overflow: hidden;
  height: 35px;
`

export const AttendButtonTitle = styled(CenteredText)`
  color: ${(props: Props & { useMainTextColor: boolean }) =>
    props.useMainTextColor ? props.theme.main.text : props.theme.mainBlue};
  font-family: ${font.medium};
  font-size: 14px;
  margin: 0px 3px;
  text-align: center;
`
export const AttendingButtonLoadingContainer = styled.View`
  width: 20px;
  aspect-ratio: 1;
`
