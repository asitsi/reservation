import React from "react"
import { BackHandler, NativeEventSubscription } from "react-native"

type Props = {
  canDismiss: boolean
  onDismiss: () => void
}
class HandleBackPressComponent extends React.Component<Props> {
  private backHandler!: NativeEventSubscription

  componentDidMount(): void {
    this.backHandler = BackHandler.addEventListener(
      "hardwareBackPress",
      this.backAction
    )
  }

  componentWillUnmount(): void {
    this.backHandler?.remove()
  }

  private backAction = (): boolean => {
    const { canDismiss, onDismiss } = this.props
    if (canDismiss) {
      onDismiss()
    }
    return true
  }

  render(): React.ReactNode {
    return null
  }
}

export const HandleBackPress = HandleBackPressComponent
