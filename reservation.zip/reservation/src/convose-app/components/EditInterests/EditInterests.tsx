/* eslint-disable react/style-prop-object, react-hooks/exhaustive-deps */
import React, { useEffect, useMemo, useState } from "react"
import { Keyboard } from "react-native"
import { useSafeAreaInsets } from "react-native-safe-area-context"
import { debounce, isEqual, uniqBy } from "lodash"
import { UIActivityIndicator } from "react-native-indicators"
import { useTheme } from "styled-components"

import { Interest, InterestType, UserInterest } from "convose-lib/interests"
import { Routes } from "convose-lib/router"

import { softShadows } from "convose-styles"
import { navigate } from "../../RootNavigation"
import { InterestsBar } from "../InterestsBar"
import { AutosuggestOptionList } from "../AutosuggestOptionList"
import { InterestComponentWrapper, LoadingSpinnerContainer } from "./Styled"
import { InterestHeader } from "./InterestHeader"

type ActivityIndicatorProps = {
  size?: number
}
const ActivityIndicator: React.FC<ActivityIndicatorProps> = ({ size = 30 }) => {
  const theme = useTheme()
  return <UIActivityIndicator color={theme.main.text} size={size} count={10} />
}

const headerTextStyle = { fontSize: 17 }
const headerStyle = {
  zIndex: 100000,
  elevation: 100000,
}

type Props = {
  readonly searchResults: ReadonlyArray<Interest> | null
  readonly clearInterestsResults: () => void
  readonly searchInterest: (text: string) => void
  readonly addNewInterest: (interest: UserInterest) => void
  readonly hasMore: boolean
  readonly searchText: string
  readonly clearNewInterest: () => void
  readonly removeInterest: (interest: UserInterest) => void
  readonly localInterests: UserInterest[]
  readonly addUserLocalInterests: (interest: UserInterest) => void
  readonly removeUserLocalInterests: (interest: UserInterest) => void
  readonly updateUserInterests: (interests: UserInterest[]) => void
  readonly isLoadingSearchResults: boolean
  readonly goBack: () => void
  readonly title?: string
  readonly newInterestInfoDescription?: string
  readonly channel?: string
  readonly setInterests?: (interests: UserInterest[]) => void
}

const EditInterestsComponent: React.FC<Props> = ({
  searchResults,
  clearInterestsResults,
  searchInterest,
  addNewInterest,
  hasMore,
  searchText,
  clearNewInterest,
  removeInterest,
  localInterests,
  addUserLocalInterests,
  removeUserLocalInterests,
  updateUserInterests,
  isLoadingSearchResults,
  goBack,
  title,
  newInterestInfoDescription,
  channel,
  setInterests,
}) => {
  const insets = useSafeAreaInsets()
  const [interestValue, setInterestValue] = useState("")
  const localInterestsRef = React.useRef<UserInterest[]>([])
  const savedInterestsRef = React.useRef<UserInterest[]>([])
  const isFirstRun = React.useRef(true)

  function updateInterest(interests: UserInterest[]) {
    updateUserInterests(interests)
    savedInterestsRef.current = interests
  }
  // if user didn't change anything, after 1 second we will save changes!
  const debouncedUpdateInterest = React.useCallback(
    debounce(updateInterest, 1000),
    []
  )

  useEffect(() => {
    localInterestsRef.current = localInterests
    // to avoid send repeated data to server on the first run!
    if (isFirstRun.current) {
      savedInterestsRef.current = localInterests
      isFirstRun.current = false
    } else {
      debouncedUpdateInterest(localInterests)
    }
  }, [localInterests.length])
  useEffect(() => {
    return () => {
      if (!isEqual(localInterestsRef.current, savedInterestsRef.current)) {
        // we make sure to save data if user closes the window too quickly
        // but we make sure to save data only if they are not saved!
        updateInterest(localInterestsRef.current)
      }
      clearNewInterest()
    }
  }, [])

  const onDeleteInterest = (interest: UserInterest | Interest): void => {
    removeUserLocalInterests(interest as UserInterest)
    removeInterest(interest as UserInterest)
  }

  const onGoBack = () => {
    clearInterestsResults()
    goBack()
  }

  const returnToMostPopularInterests = (): void => {
    if (interestValue) {
      setInterestValue("")
      searchInterest("")
    }
  }
  const interestToUserInterest = ({ ...interest }: Interest): UserInterest => ({
    ...interest,
    level: 0,
  })

  const addInterest = (userInterest: UserInterest) => {
    addNewInterest(userInterest)
    addUserLocalInterests(userInterest)
  }
  const openRatingPage = (interest: UserInterest, isEdit?: boolean): void => {
    Keyboard.dismiss()
    navigate(Routes.Rating, {
      interest,
      isFromInterestScreen: true,
      isEdit,
    })
  }
  const handleOnInterestAddPress = (interest: Interest): void => {
    returnToMostPopularInterests()
    const userInterest = interestToUserInterest(interest)
    if (interest.type === InterestType.Language && !channel) {
      openRatingPage(userInterest, false)
      return
    }
    addInterest(userInterest)
  }
  const onEditRatingPress = (interest: UserInterest) => {
    if (!channel) {
      openRatingPage(interest, true)
    }
  }
  const loadMoreInterest = (): void => {
    if (hasMore && !isLoadingSearchResults) {
      searchInterest(searchText)
    }
  }
  const resultsToList = uniqBy(searchResults, "name")
  const renderNewInterest = useMemo(() => {
    return (
      !(!resultsToList || resultsToList.length) &&
      !!searchText &&
      interestValue === searchText // immediately show loading
    )
  }, [resultsToList, searchText, interestValue])

  const showSpinner = useMemo(
    () =>
      isLoadingSearchResults && interestValue !== searchText && !!interestValue,
    [isLoadingSearchResults, interestValue, searchText]
  )
  const isLoadingInterests = useMemo(() => {
    return isLoadingSearchResults && interestValue === "" // immediately show loading
  }, [isLoadingSearchResults, interestValue])

  const insetBottom = insets.bottom || 0

  return (
    <InterestComponentWrapper>
      <InterestHeader
        onBackPress={onGoBack}
        title={title || "Add interests"}
        textColor="SystemDefault"
        headerTextStyle={headerTextStyle}
        headerStyle={headerStyle}
      />
      <AutosuggestOptionList
        results={resultsToList}
        onSelect={handleOnInterestAddPress}
        hasMoreInterests={hasMore}
        onLoadMoreInterest={loadMoreInterest}
        searchText={searchText}
        hasSelectedInterest={!!localInterests.length}
        onRemove={onDeleteInterest}
        renderNewInterest={renderNewInterest}
        isLoadingSearchResults={isLoadingInterests}
        newInterestInfoDescription={newInterestInfoDescription}
        currentInterests={localInterests}
      />
      <InterestsBar
        onSearch={searchInterest}
        onAddInterest={handleOnInterestAddPress}
        searchResults={searchResults}
        currentInterests={localInterests}
        onDeleteInterest={onDeleteInterest}
        openRatingWheel={onEditRatingPress}
        interestValue={interestValue}
        setInterestValue={setInterestValue}
        renderNewInterest={renderNewInterest}
        insetBottom={insetBottom}
        setInterests={setInterests}
        isLoadingInterests={isLoadingInterests}
      />
      {showSpinner && (
        <LoadingSpinnerContainer style={softShadows} insetTop={insets.top}>
          <ActivityIndicator size={23} />
        </LoadingSpinnerContainer>
      )}
    </InterestComponentWrapper>
  )
}

export const EditInterests = React.memo(EditInterestsComponent)
