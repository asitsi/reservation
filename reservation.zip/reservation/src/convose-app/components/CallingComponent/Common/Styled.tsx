import { StyleSheet, TouchableOpacity } from "react-native"
import styled from "styled-components/native"
import { ScrollView } from "react-native-gesture-handler"
import FontAwesome5 from "react-native-vector-icons/FontAwesome5"
import MaterialIcons from "react-native-vector-icons/MaterialIcons"
import FastImage from "react-native-fast-image"
import Animated from "react-native-reanimated"

import { CenteredText, color, font, Props } from "convose-styles"
import { resolveObjectPath } from "convose-lib/utils"

export const AVATAR_CONTAINER_SIZE = 80
export const AVATAR_ACTIVE_INDICATOR_PLUS_SIZE = 6
export const AVATAR_ACTIVE_INDICATOR_SIZE =
  AVATAR_CONTAINER_SIZE + AVATAR_ACTIVE_INDICATOR_PLUS_SIZE + 5
const AVATAR_ACTIVE_INDICATOR_BORDER_SIZE = 4
export const AVATAR_SIZE = AVATAR_CONTAINER_SIZE

export const styles = StyleSheet.create({
  minActiveIcon: {
    marginLeft: 1,
  },
  minActiveIconOtherUsers: {
    marginLeft: 1,
  },
  video: { width: "100%", height: "100%" },
  muteButtonStyle: {
    position: "absolute",
    bottom: 10,
    right: 0,
  },
  videoButtonStyle: {
    position: "absolute",
    bottom: 10,
    left: 0,
  },
  handButtonStyle: {
    position: "absolute",
    top: 0,
    right: 0,
  },
  profileVideo: {
    width: AVATAR_CONTAINER_SIZE + 10,
    height: AVATAR_CONTAINER_SIZE + 10,
    borderRadius: 20,
  },
})
type ContainerProps = Props & {
  insetTop: number
  transparent: boolean
}
export const PortraitContainer = styled(Animated.View)`
  background-color: ${(props: ContainerProps) =>
    props.transparent
      ? `${props.theme.callingComponent.background}E5`
      : props.theme.callingComponent.background};
  padding-top: ${(props: ContainerProps) => props.insetTop + 20}px;
  margin-top: -10px;
  padding-bottom: 20px;
  position: absolute;
  width: 100%;
  z-index: 100;
  top: 0px;
  border-bottom-left-radius: 20px;
  border-bottom-right-radius: 20px;
  justify-content: center;
  ${(props: ContainerProps) => props.transparent && `overflow: hidden;`}
  align-items: center;
`
// export const LandscapeContainer = styled.View`
//   width: 100%;
//   height: 100%;
//   position: absolute;
// `
type InsetProps = {
  insetBottom: number
  insetTop: number
  insetLeft: number
  insetRight: number
}
type LandscapeCallingButtonsContainerProps = InsetProps & {
  isLandscapeLeft: boolean
  isLandscapeRight: boolean
}

export const LandscapeCallingButtonsContainer = styled(Animated.View)`
  position: absolute;
  bottom: ${(props: LandscapeCallingButtonsContainerProps) =>
    props.insetBottom + 5}px;
  align-self: center;
  ${(props: LandscapeCallingButtonsContainerProps) =>
    props.isLandscapeLeft ? `margin-left:${props.insetLeft}px` : ``};
`
export const LandscapeCallingUsersContainer = styled(Animated.View)`
  position: absolute;
  right: ${(props: InsetProps) => props.insetRight}px;
  top: 0px;
`
export const StyledCircleButton = styled(TouchableOpacity)`
  border-radius: 50px;
  aspect-ratio: 1;
  height: ${(props: Props) => (props.size ? `${props.size}px` : "40px")};
  width: ${(props: Props) => (props.size ? `${props.size}px` : "40px")};
  justify-content: center;
  align-items: center;
  margin: ${(props: Props) => (props.margin ? `${props.margin}px` : "4px")};
  background: ${(
    props: Props & {
      backgroundColorCode: string
      defaultBackgroundOnOffMode: boolean
      active: boolean
    }
  ) => {
    if (!props.active && props.defaultBackgroundOnOffMode) {
      return props.theme.callingComponent.background
    }
    if (props.backgroundColorCode) {
      return resolveObjectPath(props.backgroundColorCode, props.theme)
    }
    return props.backgroundColor || "rgba(0, 0 ,0 ,0.2)"
  }};
`
export const CircleButtonBorder = styled.View`
  border-radius: 50px;
  aspect-ratio: 1;
  height: ${(props: Props) =>
    props.size ? `${props.size + 0.4}px` : "40.4px"};
  width: ${(props: Props) => (props.size ? `${props.size + 0.4}px` : "40.4px")};
  position: absolute;
  border-width: ${(props: { borderSize: number }) => props.borderSize || 1}px;
  border-color: ${(
    props: Props & {
      active: boolean
      noBorder: boolean
      isLandscape: boolean
      borderOnActive: boolean
    }
  ) => {
    if (props.active && props.borderOnActive) {
      return props.theme.callingComponent.background
    }
    if (props.active || props.noBorder || props.isLandscape) {
      return "transparent"
    }
    return props.theme.calling.notActive
  }};
`
export const CallingButtonsContainer = styled.View`
  width: 100%;
  flex-direction: row;
  justify-content: center;
`
export const CallingButtonHolder = styled.View`
  margin-left: 2px;
  margin-right: 2px;
`

export const StyledMaterialIcons = styled(MaterialIcons)`
  color: ${(props: Props & { active: boolean }) =>
    props.active ? color.white : props.theme.calling.notActive};
`
export const StyledFontAwesome5 = styled(FontAwesome5)`
  color: ${(props: Props & { active: boolean }) =>
    props.active ? color.white : props.theme.calling.notActive};
`
export const StyledCallingUsersContainer = styled(ScrollView)`
  height: ${(props: { isLandscape: boolean; height: number }) =>
    props.isLandscape ? props.height - 20 : 110}px;
  ${(props: { isLandscape: boolean }) =>
    !props.isLandscape ? `width: 100%;` : ``}
`

export const UsersScrollContainer = styled.View`
  flex-direction: ${(props: { isLandscape: boolean }) =>
    props.isLandscape ? "column" : "row"};
  ${(props: { isLandscape: boolean }) => {
    return props.isLandscape ? `padding-bottom: 30px;` : ``
  }}
`

export const ProfileContainer = styled(Animated.View)`
  width: ${AVATAR_CONTAINER_SIZE}px;
  height: ${AVATAR_CONTAINER_SIZE}px;
  overflow: hidden;
  justify-content: center;
  align-items: center;
`
export const ProfileActiveIndicator = styled(Animated.View)`
  width: ${(props: { isSharedScreen: boolean }) =>
    AVATAR_ACTIVE_INDICATOR_SIZE - (props.isSharedScreen ? 2 : 1)}px;
  height: ${(props: { isSharedScreen: boolean }) =>
    AVATAR_ACTIVE_INDICATOR_SIZE - (props.isSharedScreen ? 2 : 1)}px;
  border-width: ${(props: { isSharedScreen: boolean }) =>
    AVATAR_ACTIVE_INDICATOR_BORDER_SIZE - (props.isSharedScreen ? 2 : 1)}px;
  border-color: ${(
    props: Props & { active: boolean; isSharedScreen: boolean }
  ) => {
    if (props.active) {
      return color.darkGreen
    }
    if (props.isSharedScreen) {
      return props.theme.callingComponent.sharedScreenThumbnailBorder
    }
    return "transparent"
  }};
  justify-content: center;
  align-items: center;
  ${(props: { isSharedScreen: boolean }) =>
    props.isSharedScreen ? "margin-bottom: 2px;" : undefined}
`

export const StyledImage = styled(FastImage)`
  width: ${AVATAR_SIZE}px;
  height: ${AVATAR_SIZE}px;
`
export const UsernameContainer = styled.View`
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
`
export const ProfileUsernameTouchable = styled.TouchableOpacity`
  justify-content: space-between;
  align-items: center;
`
export const SharedScreenIconContainer = styled.View`
  padding-right: 3px;
`

export const Username = styled(CenteredText)`
  font-family: ${font.semiBold};
  color: ${(props: Props & { color: string }) =>
    props.color ? props.color : props.theme.main.text};
  max-width: 75px;
`
export const ProfileUsernameContainer = styled.View`
  width: 90px;
  height: 95px;
  justify-content: space-between;
  align-items: center;
  ${(props: { isLandscape: boolean }) =>
    props.isLandscape ? `` : `margin-left: 5px;`}
`
export const IsCallingContainer = styled.View`
  flex-direction: row;
  justify-content: center;
  align-items: center;
  margin-bottom: 25px;
  margin-left: 10px;
  width: 230px;
`
export const CallingEffectContainer = styled.View`
  width: 50px;
  height: 50px;
  margin-left: 30px;
`
export const IsCallingText = styled(CenteredText)`
  line-height: 20px;
  font-size: 16px;
  flex: 1;
  color: ${(props: Props) => props.theme.main.text};
  font-family: ${font.normal};
`
type UnmuteAlertContainerProps = {
  isLandscape: boolean
}
export const UnmuteAlertContainer = styled.View`
  background-color: ${(props: Props) => props.theme.mainBlue};
  width: 150px;
  height: 40px;
  position: absolute;
  border-radius: 15px;
  bottom: ${(props: UnmuteAlertContainerProps) =>
    props.isLandscape ? `55px` : `-60px`};
  left: -20px;
  justify-content: space-between;
  align-items: center;
  flex-direction: row;
  padding-left: 10px;
  padding-right: 10px;
`

const POINTER_HEIGHT = 16
const POINTER_WIDTH = (POINTER_HEIGHT * 9) / 10
export const UnmuteAlertPointerTop = styled.View`
  width: 0px;
  height: 0px;
  background-color: transparent;
  border-style: solid;
  border-top-width: 0px;
  border-bottom-width: ${POINTER_HEIGHT}px;
  border-right-width: ${POINTER_WIDTH}px;
  border-left-width: ${POINTER_WIDTH}px;
  border-top-color: transparent;
  border-right-color: transparent;
  border-bottom-color: ${(props: Props) => props.theme.mainBlue};
  border-left-color: transparent;
  position: absolute;
  top: -${POINTER_HEIGHT - 1}px;
  left: 25px;
`
export const UnmuteAlertPointerBottom = styled.View`
  width: 0px;
  height: 0px;
  background-color: transparent;
  border-style: solid;
  border-top-width: ${POINTER_HEIGHT}px;
  border-bottom-width: 0px;
  border-right-width: ${POINTER_WIDTH}px;
  border-left-width: ${POINTER_WIDTH}px;
  border-top-color: ${(props: Props) => props.theme.mainBlue};
  border-right-color: transparent;
  border-bottom-color: transparent;
  border-left-color: transparent;
  position: absolute;
  bottom: -${POINTER_HEIGHT - 1}px;
  left: 25px;
`
export const UnmuteAlertText = styled(CenteredText)`
  color: ${color.white};
  font-family: ${font.normal};
  font-size: 14px;
  padding-left: 5px;
`
type VideContainerProps = {
  isShareScreen: boolean
  keyboardHeight: number
  isLandscape: boolean
  shareScreenHeight: number
  width: number
  height: number
  translateYOnSharedScreen: number
  horizontalPaddingInLandscape: number
}

export const StyledVideoCallContainer = styled.View`
  position: absolute;
  width: ${(props: VideContainerProps) =>
    props.isLandscape ? props.width : props.width}px;
  height: ${(props: VideContainerProps) =>
    props.isShareScreen && !props.isLandscape
      ? props.shareScreenHeight
      : props.height}px;
  background-color: ${color.darkLevel1};
  align-self: center;

  ${(props: VideContainerProps) =>
    props.isLandscape
      ? `padding-horizontal: ${props.horizontalPaddingInLandscape}px`
      : ``}
  ${(props: VideContainerProps) =>
    props.isShareScreen &&
    !props.isLandscape &&
    `transform: translateY(-${
      props.translateYOnSharedScreen - props.keyboardHeight < 0
        ? 0
        : props.translateYOnSharedScreen - props.keyboardHeight
    }px);`}
`
export const UserIsNotConnectedToAgora = styled.View`
  height: 30%;
  width: 100%;
  background-color: ${color.red}E8;
  position: absolute;
  bottom: 0px;
`
export const OutgoingCallWrapper = styled.View`
  position: absolute;
  elevation: 10;
  width: 0px;
  height: 0px;
  top: 50%;
  left: 12%;
  align-items: center;
  justify-content: center;
  background: ${color.transparent};
`
export const RippleCircle = styled(Animated.View)`
  position: absolute;
  width: 50px;
  height: 50px;
  background: ${color.green};
  border-radius: 100px;
`
