/* eslint-disable react/jsx-props-no-spreading */
import React, { useImperativeHandle } from "react"
import { FlatListProps, NativeScrollEvent } from "react-native"
import Animated, {
  SharedValue,
  runOnJS,
  useAnimatedScrollHandler,
  useAnimatedStyle,
  useSharedValue,
  withTiming,
} from "react-native-reanimated"

import { ChatSummary } from "convose-lib/chat"
// import { FilterButtonItemType } from "../FilterButtonSet"

type Props = Omit<FlatListProps<ChatSummary>, "onScroll"> & {
  onScroll?: (event: NativeScrollEvent) => void
}
export type ListComponentRef = {
  translationY: SharedValue<number>
}
const ListComponent = React.forwardRef<ListComponentRef, Props>(
  (props, ref) => {
    const { ListHeaderComponent, onScroll } = props
    const translationY = useSharedValue(1)

    const style = useAnimatedStyle(() => {
      const scaleY = (() => {
        if (translationY.value < 1) {
          return 1
        }
        if (translationY.value > 15) {
          const translatedValue = 1 - (translationY.value - 10) / 30
          if (translatedValue < 0) {
            return 0
          }
          return translatedValue
        }
        return translationY.value
      })()

      return {
        opacity: withTiming(scaleY, { duration: 50 }),
      }
    })

    const scrollHandler = useAnimatedScrollHandler((event) => {
      onScroll && runOnJS(onScroll)(event)
      translationY.value = event.contentOffset.y
    })

    const renderListHeader = (): React.ReactNode => {
      return ListHeaderComponent as React.ReactNode
    }

    useImperativeHandle(ref, () => ({
      translationY,
    }))

    return (
      <Animated.FlatList
        {...props}
        onScroll={scrollHandler}
        ListHeaderComponent={
          <Animated.View style={style}>{renderListHeader()}</Animated.View>
        }
      />
    )
  }
)
export const List = React.memo(ListComponent)
