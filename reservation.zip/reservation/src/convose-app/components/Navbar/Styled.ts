import { View, StyleSheet } from "react-native"
import styled from "styled-components/native"

import {
  CenteredText,
  color,
  font,
  interestsBarHeight,
  Props,
} from "convose-styles"
import Ionicons from "react-native-vector-icons/Ionicons"
import Animated from "react-native-reanimated"

import { css } from "styled-components"
import { SearchInterests } from "../SearchInterests"
import { SvgButton } from "../IconButton/IconButton"
import { AnimatedIonicons } from "./AnimatedIonicons"

export const StyledAnimatedIonicons = styled(AnimatedIonicons)``
const navbarHeight = interestsBarHeight
export const PLUS_INTERESTS_TRANSFORM = 65

type NavbarViewProps = {
  bottomInset?: number
}
function calculateHeight(props: NavbarViewProps) {
  const addHeight = props.bottomInset || 0
  return navbarHeight + addHeight + 30
}
function calculatePadding(props: NavbarViewProps) {
  return props.bottomInset || 0
}
export const NavbarView = styled(View)`
  background: rgba(0, 0, 0, 0);
  position: absolute;
  bottom: 0px;
  width: 100%;
  height: ${calculateHeight}px;
  padding-horizontal: 15px;
  justify-content: center;
  align-items: flex-end;
  flex-direction: row;
  elevation: 4;
  z-index: 3;
  padding-bottom: ${calculatePadding}px;
`

export const SearchInterestsButton = styled(SearchInterests)`
  transform: ${(props: { bottomInset: number }) =>
    `translateY(-${props.bottomInset + PLUS_INTERESTS_TRANSFORM}px)`};
  elevation: 5;
  z-index: 3;
  position: absolute;
`
const AnimatedCenterText = Animated.createAnimatedComponent(CenteredText)
export const NavActionTitleNoColor = styled(AnimatedCenterText)`
  font-family: ${font.bold};
  font-size: 12px;
  text-align: center;
`
export const NavActionTitle = styled(NavActionTitleNoColor)`
  color: ${(props: Props) => props.theme.mainBlue};
`
export const NavActionContainer = styled(View)`
  align-items: center;
  justify-content: center;
`
const pressEffect = css`
  background-color: ${(props: Props & { pressed: boolean }) =>
    props.pressed ? props.theme.buttonOnPress : "transparent"};
`
export const NavActionButton = styled.View`
  width: 80px;
  height: 50px;
  border-radius: 50px;
  justify-content: center;
  align-items: center;
  ${pressEffect}
`
export const Styles = StyleSheet.create({
  searchInterestShadow: {
    shadowOffset: { width: 0, height: 4 },
    shadowColor: color.black,
    shadowOpacity: 0.22,
    shadowRadius: 2.22,
  },
})

export const WhiteBackgroundBar = styled(View)`
  position: absolute;
  width: 100%;
  height: ${(props: NavbarViewProps) => calculateHeight(props) - 30}px;
  background-color: ${(props: Props) => props.theme.statusBar};
  bottom: 0px;
  z-index: 0;
`

export const ProfileSvg = styled(SvgButton)`
  bottom: 15px;
`
export const GradientEffectBase = styled.View`
  background-color: ${(props: Props) => props.theme.statusBar};
  position: absolute;
  width: 100%;
  left: 0px;
  bottom: 0px;
`
export const GradientsContainer = styled.View`
  width: 100%;
  position: absolute;
  left: 0px;
  right: 0px;
  bottom: ${(props: NavbarViewProps) => props.bottomInset || 0}px;
`
export const ExplainerIcon = styled(Ionicons)`
  color: ${(props: Props) => props.theme.explainerText};
`
export const ExplainerIconsWrapper = styled(View)`
  flex-direction: row;
  justify-content: space-around;
  align-items: center;
  margin-top: -10px;
  margin-bottom: -15px;
  padding-horizontal: 10px;
`
export const ExplainerIconContainer = styled(View)``
export const ExplainerIconsInsideWrapper = styled(View)`
  flex-direction: column;
  justify-content: space-around;
`
export const QuickCallContainer = styled.View`
  position: absolute;
  transform: ${(props: { bottomInset: number }) =>
    `translateX(137px) translateY(-${75 + props.bottomInset}px)`};
`

export const QuickCallNavContainer = styled.View`
  ${pressEffect}
  justify-content: center;
  align-items: center;
  padding: 5.5px 20px;
  border-radius: 50px;
  min-width: 100px;
`
