import styled from "styled-components/native"
import { ColorValue } from "react-native"

import { Props, color } from "convose-styles"
import { resolveObjectPath } from "convose-lib/utils"

export const ButtonBorder = styled.TouchableOpacity`
  background-color: ${(
    props: Props & {
      withBoarder: boolean
      borderColor?: ColorValue
      borderColorCode?: string
    }
  ) => {
    if (props.borderColorCode) {
      return resolveObjectPath(props.borderColorCode, props.theme)
    }
    if (props.borderColor) {
      return props.borderColor
    }
    if (props.withBoarder) {
      return color.white
    }
    return props.theme.mainBlue
  }};
  width: ${(props: { size: number }) => props.size}px;
  height: ${(props: { size: number }) => props.size}px;
  border-radius: ${(props: { size: number }) => props.size}px;
  justify-content: center;
  align-items: center;
`
