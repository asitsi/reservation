import React, { memo } from "react"
import { State, clearAgoraChannel } from "convose-lib"
import { UserAction, selectIsGuest, selectToken } from "convose-lib/user"
import { ChatAction } from "convose-lib/chat"
import { UsersListAction } from "convose-lib/users-list"
import { CallingAction, selectIsGroup } from "convose-lib/calling"
import { connect } from "react-redux"
import { AppAction } from "convose-lib/app"

type StateToProps = {
  readonly authToken: string
  readonly isGuest: boolean
  readonly isGroupCall: boolean
}
type DispatchProps = {
  readonly stopSendingPushNotifications: () => void
  readonly resetHistory: () => void
  readonly resetPartnersList: () => void
  readonly clearPushNotification: () => void
  readonly setCallingToDefault: () => void
  readonly resetWaveCount: () => void
}
type Props = StateToProps & DispatchProps
class RefreshUserComponent extends React.PureComponent<Props> {
  public async componentDidUpdate(prevProps: Props): Promise<void> {
    const { authToken, isGuest, isGroupCall } = this.props
    if (prevProps.authToken && prevProps.authToken !== authToken) {
      this.refreshUser(prevProps.isGuest && !isGuest && isGroupCall)
    }
  }

  public refreshUser = async (skipRefreshCalls: boolean): Promise<void> => {
    const {
      resetHistory,
      resetPartnersList,
      stopSendingPushNotifications,
      clearPushNotification,
      resetWaveCount,
    } = this.props
    resetWaveCount()
    resetHistory()
    resetPartnersList()
    this.handleCall(skipRefreshCalls)
    clearPushNotification()
    stopSendingPushNotifications()
  }

  public handleCall = (skipRefreshCalls: boolean) => {
    const { setCallingToDefault } = this.props
    if (!skipRefreshCalls) {
      setCallingToDefault()
      clearAgoraChannel().then().catch()
    }
  }

  render(): React.ReactNode {
    return null
  }
}

const mapStateToProps = (state: State): StateToProps => ({
  authToken: selectToken(state),
  isGuest: selectIsGuest(state),
  isGroupCall: selectIsGroup(state),
})
const mapDispatchToProps: DispatchProps = {
  stopSendingPushNotifications: UserAction.setUserActive,
  resetHistory: ChatAction.resetHistory,
  resetPartnersList: UsersListAction.resetPartnersList,
  clearPushNotification: UserAction.clearPushNotification,
  setCallingToDefault: CallingAction.setCallingToDefault,
  resetWaveCount: AppAction.restWaveCount,
}

export const RefreshUser = memo(
  connect(mapStateToProps, mapDispatchToProps)(RefreshUserComponent)
)
