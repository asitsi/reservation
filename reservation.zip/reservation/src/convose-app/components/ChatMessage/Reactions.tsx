import React from "react"

import { MessageReaction } from "convose-lib/chat"
import { ZoomIn, ZoomOut } from "react-native-reanimated"
import {
  ReactText,
  ReactionContainer,
  ReactionsContainer,
  StyledReactionEmoji,
} from "./Styled"

type ReactionType = {
  reaction: MessageReaction
  messageUuid: string
  onUpdateReaction: (
    emoji: string,
    messageUuid: string,
    reacted: boolean
  ) => void
}
const Reaction: React.FC<ReactionType> = ({
  reaction,
  messageUuid,
  onUpdateReaction,
}) => {
  const onUpdateReactionPress = () => {
    onUpdateReaction(reaction.emoji, messageUuid, reaction.reacted)
  }

  return (
    <ReactionContainer
      entering={ZoomIn.duration(150)}
      exiting={ZoomOut.duration(150)}
      key={reaction.emoji}
      myReaction={reaction.reacted}
      onPress={onUpdateReactionPress}
    >
      <>
        <StyledReactionEmoji
          entering={ZoomIn.springify(250).mass(40).stiffness(200)}
        >
          {reaction.emoji}
        </StyledReactionEmoji>
        <ReactText count myReaction={reaction.reacted}>
          {reaction.count}
        </ReactText>
      </>
    </ReactionContainer>
  )
}

type Props = {
  myMessage: boolean
  reactions: MessageReaction[]
  deleted: boolean | undefined
  messageUuid: string
  onUpdateReaction: (
    emoji: string,
    messageUuid: string,
    reacted: boolean
  ) => void
  hasReply: boolean
}
const MessageReactionsComponent: React.FC<Props> = ({
  deleted,
  messageUuid,
  myMessage,
  reactions,
  onUpdateReaction,
  hasReply,
}) => {
  if (deleted || !Array.isArray(reactions) || !reactions.length) {
    return null
  }
  return (
    <ReactionsContainer myMessage={myMessage} hasReply={hasReply}>
      {reactions.map((reaction) => (
        <Reaction
          key={reaction.emoji}
          messageUuid={messageUuid}
          onUpdateReaction={onUpdateReaction}
          reaction={reaction}
        />
      ))}
    </ReactionsContainer>
  )
}

export const MessageReactions = React.memo(MessageReactionsComponent)
