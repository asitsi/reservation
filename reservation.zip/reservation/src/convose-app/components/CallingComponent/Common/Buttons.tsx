import React from "react"
import { View, ViewStyle } from "react-native"
import Ionicons from "react-native-vector-icons/Ionicons"
import { MaterialIndicator } from "react-native-indicators"

import { color } from "convose-styles"
import {
  UnmuteAlertContainer,
  UnmuteAlertPointerBottom,
  UnmuteAlertPointerTop,
  UnmuteAlertText,
} from "./Styled"
import { CircleButton } from "./CircleButton"
import { MicIcon } from "../Icons/Mic"
import { VideoIcon } from "../Icons/Video"
import { SharedScreenIcon } from "../Icons/SharedScreen"
import { HandIcon } from "../Icons/Hand"
import { SpeakingIcon } from "../Icons/Speaking"

export const DEFAULT_ICON_SIZE = 25

export const getButtonBackgroundColor = (
  itemToCheck?: boolean,
  isLandscape?: boolean
): string => {
  if (itemToCheck) {
    return "calling.active"
  }
  if (isLandscape) {
    return "calling.notActiveLandscape"
  }
  return "calling.userBoxBackground"
}
type UnmuteAlertProps = {
  onClose: () => void
  isLandscape?: boolean
}
const UnmuteAlert: React.FC<UnmuteAlertProps> = ({ onClose, isLandscape }) => {
  return (
    <UnmuteAlertContainer isLandscape={isLandscape}>
      {isLandscape ? <UnmuteAlertPointerBottom /> : <UnmuteAlertPointerTop />}
      <UnmuteAlertText>Unmute here</UnmuteAlertText>
      <Ionicons name="close" size={24} color="white" onPress={onClose} />
    </UnmuteAlertContainer>
  )
}

type VideoAndShareScreenButtonProps = {
  onPress?: () => void
  isVideoEnabled: boolean
  size?: number
  viewStyle?: ViewStyle
  iconSize?: number
  isLandscape?: boolean
}
type VideoButtonType = VideoAndShareScreenButtonProps & {
  borderOnCameraOn?: boolean
  borderSize?: number
}

export const VideoButton: React.FC<VideoButtonType> = ({
  isVideoEnabled,
  onPress,
  size,
  viewStyle,
  iconSize = DEFAULT_ICON_SIZE,
  isLandscape,
  borderOnCameraOn,
  borderSize,
}) => {
  return (
    <CircleButton
      backgroundColorCode={getButtonBackgroundColor(
        isVideoEnabled,
        isLandscape
      )}
      onPress={onPress}
      active={isVideoEnabled}
      size={size}
      style={viewStyle}
      isLandscape={isLandscape}
      borderOnActive={borderOnCameraOn}
      borderSize={borderSize}
    >
      <VideoIcon
        size={iconSize}
        isEnable={isVideoEnabled}
        isLandscape={isLandscape}
      />
    </CircleButton>
  )
}
type HandButtonType = {
  onPress?: () => void
  isHandRaised: boolean
  isLoading: boolean
  size?: number
  viewStyle?: ViewStyle
  iconSize?: number
  isLandscape?: boolean
  borderOnHandRaised?: boolean
  borderSize?: number
  defaultBackgroundOnOffMode?: boolean
  noBorder?: boolean
}
export const HandRaiseButton: React.FC<HandButtonType> = ({
  isHandRaised,
  isLoading,
  onPress,
  size,
  viewStyle,
  iconSize = DEFAULT_ICON_SIZE,
  isLandscape,
  borderOnHandRaised,
  borderSize,
  defaultBackgroundOnOffMode,
  noBorder,
}) => {
  return (
    <CircleButton
      backgroundColorCode={getButtonBackgroundColor(isHandRaised, isLandscape)}
      onPress={onPress}
      active={isHandRaised}
      size={size}
      style={viewStyle}
      isLandscape={isLandscape}
      borderOnActive={borderOnHandRaised}
      borderSize={borderSize}
      defaultBackgroundOnOffMode={defaultBackgroundOnOffMode}
      noBorder={noBorder}
    >
      {isLoading ? (
        <MaterialIndicator size={iconSize} color={color.white} />
      ) : (
        <HandIcon
          size={iconSize - 1}
          isEnable={isHandRaised}
          isLandscape={isLandscape}
        />
      )}
    </CircleButton>
  )
}

type HandRaiseSpeakingButtonType = {
  onPress?: () => void
  isSpeaking: boolean
  size?: number
  viewStyle?: ViewStyle
  iconSize?: number
  isLandscape?: boolean
  borderOnHandRaised?: boolean
  borderSize?: number
  defaultBackgroundOnOffMode?: boolean
  noBorder?: boolean
}
export const HandRaiseSpeakingButton: React.FC<HandRaiseSpeakingButtonType> = ({
  isSpeaking,
  onPress,
  size,
  viewStyle,
  iconSize = DEFAULT_ICON_SIZE,
  isLandscape,
  borderOnHandRaised,
  borderSize,
  defaultBackgroundOnOffMode,
  noBorder,
}) => {
  return (
    <CircleButton
      backgroundColorCode={getButtonBackgroundColor(isSpeaking, isLandscape)}
      onPress={onPress}
      active={isSpeaking}
      size={size}
      style={viewStyle}
      isLandscape={isLandscape}
      borderOnActive={borderOnHandRaised}
      borderSize={borderSize}
      defaultBackgroundOnOffMode={defaultBackgroundOnOffMode}
      noBorder={noBorder}
    >
      <SpeakingIcon
        size={iconSize - 1}
        isEnable={isSpeaking}
        isLandscape={isLandscape}
      />
    </CircleButton>
  )
}
export const ShareScreenButton: React.FC<VideoAndShareScreenButtonProps> = ({
  isVideoEnabled,
  onPress,
  size,
  viewStyle,
  iconSize = DEFAULT_ICON_SIZE,
  isLandscape,
}) => {
  return (
    <CircleButton
      backgroundColorCode={getButtonBackgroundColor(
        isVideoEnabled,
        isLandscape
      )}
      onPress={onPress}
      active={isVideoEnabled}
      size={size}
      style={viewStyle}
      isLandscape={isLandscape}
    >
      <SharedScreenIcon size={iconSize} isEnable={isVideoEnabled} />
    </CircleButton>
  )
}
type MuteButtonProps = {
  onPress?: () => void
  isAudioEnabled: boolean
  size?: number
  viewStyle?: ViewStyle
  iconSize?: number
  defaultBackgroundOnMute?: boolean
  showAlert?: boolean
  onCloseMuteAlert?: () => void
  isLoading?: boolean
  noBorderOnMuted?: boolean
  isLandscape?: boolean
  borderOnUnmute?: boolean
  borderSize?: number
  hasHitSlop?: boolean
  disabled?: boolean
}
const MuteButtonHitSlop = { bottom: 10, left: 10, right: 10, top: 10 }
export const MuteButton: React.FC<MuteButtonProps> = ({
  isAudioEnabled,
  onPress,
  size,
  viewStyle,
  iconSize = DEFAULT_ICON_SIZE,
  defaultBackgroundOnMute = false,
  showAlert = false,
  // eslint-disable-next-line @typescript-eslint/no-empty-function
  onCloseMuteAlert = () => {},
  isLoading,
  noBorderOnMuted,
  isLandscape,
  borderOnUnmute,
  borderSize,
  hasHitSlop,
  disabled,
}) => {
  const onPressMute = () => {
    requestAnimationFrame(() => {
      if (!onPress || isLoading) {
        return
      }
      onPress()
    })
  }
  return (
    <View pointerEvents={disabled ? "none" : "auto"} style={viewStyle}>
      <CircleButton
        backgroundColorCode={getButtonBackgroundColor(
          isAudioEnabled,
          isLandscape
        )}
        onPress={onPressMute}
        active={isAudioEnabled}
        size={size}
        defaultBackgroundOnOffMode={defaultBackgroundOnMute}
        noBorder={noBorderOnMuted && !isAudioEnabled}
        borderOnActive={borderOnUnmute}
        isLandscape={isLandscape}
        borderSize={borderSize}
        hitSlop={hasHitSlop ? MuteButtonHitSlop : undefined}
        disabled={disabled}
      >
        {isLoading ? (
          <MaterialIndicator size={iconSize} color={color.white} />
        ) : (
          <MicIcon
            size={iconSize}
            isEnable={isAudioEnabled}
            isLandscape={isLandscape}
          />
        )}
        {showAlert && (
          <UnmuteAlert onClose={onCloseMuteAlert} isLandscape={isLandscape} />
        )}
      </CircleButton>
    </View>
  )
}
