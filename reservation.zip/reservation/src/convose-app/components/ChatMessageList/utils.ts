import {
  createChatIdleText,
  createChatInfoText,
  Message,
  MessageToPublish,
  MessageType,
} from "convose-lib/chat"
import { filterMessages } from "convose-lib/utils/messages"
import { isEqual } from "lodash"

export function checkForNewMassages(
  prevMessages: ReadonlyArray<Message | MessageToPublish>,
  nextMessages: ReadonlyArray<Message | MessageToPublish>,
  myUuid: string
): { detectedNewMessage: boolean; lastMessageIsNotMine: boolean } {
  const filteredMessages = filterMessages(nextMessages)
  const filteredPrevMessages = filterMessages(prevMessages)

  const detectedNewMessage = !isEqual(
    filteredMessages[0],
    filteredPrevMessages[0]
  )

  const lastMessageIsNotMine = filteredMessages[0]?.sender !== myUuid

  return { detectedNewMessage, lastMessageIsNotMine }
}

export function checkIsSameSenderWithUpMsg(
  message: Message | MessageToPublish,
  nextMessage?: Message | MessageToPublish
): boolean {
  return (
    message.sender === nextMessage?.sender &&
    nextMessage?.message_type !== MessageType.System &&
    nextMessage?.message_type !== MessageType.Call &&
    !createChatInfoText(message, nextMessage) &&
    !createChatIdleText(message, nextMessage)
  )
}

export function checkIsSameSenderWithDownMsg(
  message: Message | MessageToPublish,
  prevMessage?: Message | MessageToPublish
): boolean {
  return (
    message.sender === prevMessage?.sender &&
    prevMessage?.message_type !== MessageType.System &&
    prevMessage?.message_type !== MessageType.Call &&
    !createChatInfoText(prevMessage, message) &&
    !createChatIdleText(prevMessage, message)
  )
}

export function checkIsNotSameSenderWithDownMsg(
  message: Message | MessageToPublish,
  prevMessage?: Message | MessageToPublish
): boolean {
  return (
    message.sender !== prevMessage?.sender ||
    prevMessage?.message_type === MessageType.System ||
    prevMessage?.message_type === MessageType.Call ||
    typeof createChatInfoText(prevMessage, message) === "string" ||
    typeof createChatIdleText(prevMessage, message) === "string"
  )
}
