import React from "react"
import { useTheme } from "styled-components"
import { MaterialIndicator } from "react-native-indicators"

type Props = {
  size?: number
  useMainTextColor?: boolean
}
const BlueMaterialIndicatorComponent: React.FC<Props> = ({
  size,
  useMainTextColor,
}) => {
  const theme = useTheme()
  const color = useMainTextColor ? theme.main.text : theme.mainBlue
  return <MaterialIndicator color={color} size={size} />
}

export const BlueMaterialIndicator = React.memo(BlueMaterialIndicatorComponent)
