/* eslint-disable react/style-prop-object, react-perf/jsx-no-new-object-as-prop, react/destructuring-assignment, complexity */
import React from "react"
import Ionicons from "react-native-vector-icons/Ionicons"
import { TextStyle, ViewStyle } from "react-native"

import { DEFAULT_HIT_SLOP } from "convose-lib/utils"
import { color } from "convose-styles"

import {
  AppHeader,
  AppHeaderContent,
  HeaderText,
  Subtext,
  TextWrapper,
  CallText,
  AppHeaderContentWrapper,
  AvatarContainer,
  RightActionsContainer,
  BlueButtonWrapper,
  HeaderTextContainer,
  CloseButtonText,
  CloseButton,
  CallLoadingContainer,
} from "./Styled"
import { PressableIconButton } from "../../components/IconButton"
import { ReturnToCall } from "../ReturnToCall/ReturnToCall"
import JoinCallBar from "../ReturnToCall/JoinCallBar"
import { DropDown, DropDownItemType } from "../DropDown"
import { FilterButtonSet, FilterButtonItemType } from "../FilterButtonSet"
import { OnlineIndicator } from "../OnlineIndicator"
import { HeaderEntering, HeaderExiting } from "./EnteringExiting"
import { BlueLoading } from "../ConvoseLoading"
// import { AndroidStatusBarFix } from "../MainView/Styled"

export type HeaderProps = {
  readonly avatar?: React.ReactNode
  readonly backgroundColor?: string
  readonly textColor?: string
  readonly onBackPress?: () => void
  readonly onTitlePress?: () => void
  readonly subheader?: string
  readonly title: string
  readonly onMenuPress?: () => void
  readonly height?: number
  readonly paddingTop?: number
  readonly sticky?: boolean
  readonly hasMenu?: boolean
  readonly startCall?: () => void
  readonly rejoinCall?: () => void
  readonly canRejoinCall?: boolean
  readonly isInCallingChat?: boolean
  readonly chatChannel?: string
  readonly headerTextStyle?: TextStyle
  readonly headerStyle?: ViewStyle
  readonly hideReturnToCall?: boolean
  readonly dropDownItems?: Array<DropDownItemType>
  readonly filterButtonItems?: Array<FilterButtonItemType>
  readonly iconColor?: string
  readonly isOnline?: boolean
  readonly onRefresh?: () => void
  readonly onClose?: () => void
  readonly isConnectedToChatChannel?: boolean
  readonly isCallingLoading?: boolean
}

const ICONS_SIZE = 30
const style = { right: 2 }

const BackButton = (
  onPress?: () => void,
  iconColor?: string
): React.ReactNode => (
  <PressableIconButton
    name="chevron-left"
    iconType="Entypo"
    size={ICONS_SIZE}
    onPress={onPress}
    containerStyle={{
      paddingLeft: 15,
      paddingRight: 5,
    }}
    iconColor={iconColor}
    withHitSlop
  />
)
const JoinCallingButton = (
  startCall: () => void,
  rejoinCall: () => void,
  isJoinCall: boolean,
  iconColor?: string,
  loading?: boolean
): React.ReactNode => {
  if (loading) {
    return (
      <CallLoadingContainer>
        <BlueLoading size={22} />
      </CallLoadingContainer>
    )
  }
  const callFunction = isJoinCall ? rejoinCall : startCall
  return (
    <PressableIconButton
      name="call"
      size={22}
      onPress={callFunction}
      iconColor={iconColor}
    />
  )
}
const RefreshButton = (
  onRefresh: () => void,
  iconColor?: string
): React.ReactNode => {
  return (
    <PressableIconButton
      name="reload"
      size={22}
      onPress={onRefresh}
      iconColor={iconColor}
    />
  )
}

const MenuButton = (
  onPress?: () => void,
  iconColor?: string
): React.ReactNode => (
  <PressableIconButton
    name="dots-three-vertical"
    iconType="Entypo"
    size={22}
    onPress={onPress}
    iconColor={iconColor}
    containerStyle={{
      paddingLeft: 0,
      paddingRight: 15,
    }}
  />
)
const HeaderComponent: React.FC<HeaderProps> = ({
  avatar,
  onBackPress,
  onTitlePress,
  subheader = "",
  textColor,
  title,
  onMenuPress,
  backgroundColor,
  height,
  paddingTop,
  sticky,
  hasMenu,
  startCall,
  rejoinCall,
  canRejoinCall,
  isInCallingChat,
  chatChannel,
  headerTextStyle,
  headerStyle,
  hideReturnToCall,
  dropDownItems,
  filterButtonItems,
  iconColor,
  isOnline,
  onRefresh,
  onClose,
  isConnectedToChatChannel,
  isCallingLoading,
}) => {
  return (
    <AppHeader
      color={backgroundColor}
      height={height}
      sticky={sticky || false}
      style={headerStyle}
      entering={HeaderEntering}
      exiting={HeaderExiting}
    >
      <ReturnToCall hideReturnToCall={hideReturnToCall || isInCallingChat} />
      {/* <AndroidStatusBarFix /> */}
      <AppHeaderContentWrapper paddingTop={paddingTop}>
        {Boolean(onBackPress) && BackButton(onBackPress, iconColor)}
        {Boolean(onClose) && (
          <CloseButton onPress={onClose}>
            <CloseButtonText>Close</CloseButtonText>
          </CloseButton>
        )}
        <AppHeaderContent withAvatar={Boolean(avatar)}>
          {Boolean(avatar) && <AvatarContainer>{avatar}</AvatarContainer>}
          <TextWrapper
            withAvatar={Boolean(avatar)}
            hitSlop={DEFAULT_HIT_SLOP}
            onPress={onTitlePress}
            disabled={!onTitlePress}
            maxFontSizeMultiplier={1}
          >
            <HeaderTextContainer>
              <HeaderText
                color={textColor}
                withAvatar={Boolean(avatar)}
                maxFontSizeMultiplier={1}
                style={headerTextStyle}
                adjustsFontSizeToFit
                numberOfLines={2}
              >
                {title}
              </HeaderText>
              {typeof isOnline === "boolean" && (
                <OnlineIndicator
                  isOnline={isOnline}
                  offlineIndicatorColor={backgroundColor}
                  size={10}
                  style={{
                    marginLeft: 5,
                  }}
                />
              )}
            </HeaderTextContainer>
            {subheader !== "" && (
              <Subtext
                numberOfLines={1}
                maxFontSizeMultiplier={1}
                color={textColor}
              >
                {subheader}
              </Subtext>
            )}
          </TextWrapper>
        </AppHeaderContent>
        <RightActionsContainer>
          {Boolean(avatar) && hasMenu && !!startCall && !!rejoinCall && (
            <>
              {JoinCallingButton(
                startCall,
                rejoinCall,
                !!isInCallingChat,
                iconColor,
                isCallingLoading
              )}
              {MenuButton(onMenuPress, iconColor)}
            </>
          )}
          {dropDownItems && (
            <DropDown
              style={{
                marginRight: 20,
              }}
              items={dropDownItems}
            />
          )}
          {Boolean(onRefresh) &&
            onRefresh &&
            RefreshButton(onRefresh, iconColor)}
        </RightActionsContainer>
      </AppHeaderContentWrapper>
      {filterButtonItems && <FilterButtonSet items={filterButtonItems} />}
      {canRejoinCall &&
        !!rejoinCall &&
        !isInCallingChat &&
        isConnectedToChatChannel && (
          <JoinCallBar rejoinCall={rejoinCall} chatChannel={chatChannel} />
        )}
    </AppHeader>
  )
}

export const RejoinCallingButton = (
  rejoinCall: () => void,
  pressColor?: string
): React.ReactNode => (
  <BlueButtonWrapper
    onPress={rejoinCall}
    underlayColor={pressColor || color.buttonOnPress}
    width={70}
    height={30}
  >
    <>
      <Ionicons name="call" size={16} color="white" style={style} />
      <CallText>Join</CallText>
    </>
  </BlueButtonWrapper>
)
// HeaderComponent.whyDidYouRender = {
//   logOnDifferentValues: false,
//   customName: "HeaderComponent",
//   diffNameColor: "red",
// }
export const Header = HeaderComponent
