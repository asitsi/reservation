import React, { PureComponent } from "react"
import { connect } from "react-redux"

import { selectAuthFeature } from "convose-lib/auth"
import { State } from "convose-lib/store"
import { Routes } from "convose-lib/router"
import AuthFormPure from "./AuthFormPure"
import { AuthFormProps, AuthFormState, StateToProps } from "./types"
import * as RootNavigation from "../../RootNavigation"
import {
  INVALID_EMAIL,
  INVALID_PASSWORD,
  isEmailValid,
  isPasswordValid,
} from "./utils"

const handleForgotPassword = (): void => {
  requestAnimationFrame(() => {
    // TODO: forgot password function
    RootNavigation.navigate(Routes.ForgetPassword, null)
  })
}

export class AuthFormComponent extends PureComponent<
  AuthFormProps,
  AuthFormState
> {
  private hasPasswordError = false

  private hasEmailError = false

  public readonly state: AuthFormState = {
    email: "",
    password: "",
    emailError: "",
    passwordError: "",
  }

  public readonly handleFormSubmit = (): void => {
    requestAnimationFrame(() => {
      const { onSubmit } = this.props
      const { email, password } = this.state
      const errors = {
        emailError: "",
        passwordError: "",
      }
      if (!isEmailValid(email)) {
        this.hasEmailError = true
        errors.emailError = INVALID_EMAIL
      } else {
        this.hasEmailError = false
        errors.emailError = ""
      }
      if (!isPasswordValid(password)) {
        this.hasPasswordError = true
        errors.passwordError = INVALID_PASSWORD
      } else {
        this.hasPasswordError = false
        errors.passwordError = ""
      }
      this.setState({
        ...errors,
      })
      if (!this.hasEmailError && !this.hasPasswordError) {
        onSubmit(email.trim(), password)
      }
    })
  }

  public readonly onEmailChange = (email: string): void => {
    this.setState({ email: email.toLocaleLowerCase() })
  }

  public readonly onPasswordChange = (password: string): void => {
    this.setState({ password })
  }

  public render(): React.ReactNode {
    const { email, password, emailError, passwordError } = this.state
    const {
      type,
      auth: { loading },
    } = this.props

    return (
      <AuthFormPure
        type={type}
        email={email}
        password={password}
        isLoading={loading}
        onSubmit={this.handleFormSubmit}
        onEmailChange={this.onEmailChange}
        onPasswordChange={this.onPasswordChange}
        onForgotPassword={handleForgotPassword}
        emailError={emailError}
        passwordError={passwordError}
      />
    )
  }
}

const mapStateToProps = (state: State): StateToProps => ({
  auth: selectAuthFeature(state),
})

export const AuthForm = connect(mapStateToProps)(AuthFormComponent)
