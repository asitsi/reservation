import { View, TouchableOpacity, Text } from "react-native"
import styled from "styled-components"
import { font, Props } from "convose-styles"
import Ionicons from "react-native-vector-icons/Ionicons"
import Animated from "react-native-reanimated"

type ComponentWrapperType = {
  isVisible: boolean
  bottomInset: number
}
// const componentWrapperHeight = interestsBarHeight + 65
export const ComponentWrapper = styled(Animated.View)`
  background: rgba(0, 0, 0, 0);
  background-color: ${(props: Props) => props.theme.messageActions.wrapper};
  width: 100%;
  flex-direction: row;
  elevation: 4;
  z-index: 4;
  position: absolute;
  bottom: 0px;
`
export const MessageActionsWrapper = styled(View)`
  background-color: ${(props: Props) => props.theme.messageActions.background};
  border-top-left-radius: 15px;
  border-top-right-radius: 15px;
  flex-direction: column;
  width: 100%;
  padding-bottom: ${(props: ComponentWrapperType) => props.bottomInset + 20}px;
  overflow: hidden;
  padding-top: 15px;
`
export const EmojisContainer = styled.View`
  flex-direction: row;
  justify-content: space-between;
  width: 100%;
  flex: 1;
  padding-right: 18px;
  padding-left: 18px;
  margin-bottom: 15px;
`
export const ActionsContainer = styled.View`
  flex-direction: row;
  justify-content: space-between;
  width: 100%;
  flex: 1;
  margin-top: 5px;
`
export const ActionButton = styled(TouchableOpacity)`
  flex: 0.3;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  /* background-color: red; */
`
type IconProps = Props & { size: number }
export const ActionIcon = styled(Ionicons)`
  color: ${(props: Props & { disable: boolean }) =>
    props.disable ? props.theme.message.deletedText : props.theme.mainBlue};
  width: ${(props: IconProps) => props.size}px;
  height: ${(props: IconProps) => props.size}px;
`
export const ActionTitle = styled(Text)`
  color: ${(props: Props & { disable: boolean }) =>
    props.disable ? props.theme.message.deletedText : props.theme.main.text};
  padding-top: 5px;
  font-family: ${font.normal};
  font-size: ${(props: { emoji: boolean }) => (props.emoji ? 30 : 12)}px;
  text-align: center;
  include-font-padding: false;
  text-align-vertical: center;
`
