import React, { FC, memo, useEffect, useRef, useState } from "react"
import {
  ViewToken,
  ViewStyle,
  NativeScrollEvent,
  NativeSyntheticEvent,
} from "react-native"
// import { FlatList } from "@stream-io/flat-list-mvcp"
import { noop } from "rxjs"
import Animated, {
  runOnJS,
  useAnimatedProps,
  useAnimatedScrollHandler,
  useSharedValue,
} from "react-native-reanimated"

import { Message, MessageToPublish } from "convose-lib/chat"
import { MESSAGE_LIMIT } from "convose-lib/utils"
import { chatInputBarHeight, height } from "convose-styles"
import { ScreenOrientationTypes } from "convose-lib/app"
import { Gesture, GestureType, FlatList } from "react-native-gesture-handler"
import {
  RetrievingHistoryText,
  MessageListEmpty,
  MessageListEmptyContainer,
} from "./Styled"
import { HideMessage } from "../HideMessage"
import { OpenChatNotificationHandler } from "./OpenChatNotificationHandler"
import { FadingView } from "../FadingView"
import { MainChatWrapper } from "./MainChatWrapper"
import { BackToBottom } from "./BackToBottom"
import { SwipeToNextCall } from "./SwipeToNextCall"

const AnimatedFlatList = Animated.createAnimatedComponent(FlatList)

const hideMessageStyle: ViewStyle = { height: "100%" }
const flatListStyle: ViewStyle = {
  marginBottom: chatInputBarHeight,
  height: height - chatInputBarHeight,
}

const contentPosition = {
  autoscrollToTopThreshold: 10,
  minIndexForVisible: 1,
}
const viewabilityConfig = {
  minimumViewTime: 300,
  viewAreaCoveragePercentThreshold: 100,
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const keyExtract = (item: any): string => {
  return item.uuid
}

type ListMessage = Message | MessageToPublish

type Props = {
  screenOrientation: ScreenOrientationTypes
  hideChat: boolean
  isFullScreenVideoCall: boolean
  listData: ListMessage[]
  isInCallingChat: boolean
  endCall: ({ displayText }: { displayText: boolean }) => void
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  setScrollViewRefRef: (element: any) => void
  renderBlank: () => JSX.Element
  renderCommonInterests: () => JSX.Element | null
  unreadMentions: readonly string[]
  firstPageMentionReady: boolean
  renderMentionButton: () => React.ReactNode
  scrollToLatest: () => void
  hasNewMessage: boolean
  handleOnEndReached: () => void
  renderMessage: ({
    item,
    index,
  }:
    | {
        readonly item: ListMessage
        readonly index: number
      }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    | any) => React.ReactElement<any, string | React.JSXElementConstructor<any>>
  handleScroll: (event: NativeSyntheticEvent<NativeScrollEvent>) => void
  handleViewableItemsChange?: (info: {
    viewableItems: ViewToken[]
    changed: ViewToken[]
  }) => void
  setContentOffsetY: (contentOffsetY: number) => void
  setChatTranslateYOffset: (value: number) => void
  hideSwipeCallOnboarding: () => void
}
const MessageListComponent: FC<Props> = ({
  endCall,
  firstPageMentionReady,
  hideChat,
  isFullScreenVideoCall,
  isInCallingChat,
  listData,
  renderBlank,
  renderCommonInterests,
  renderMentionButton,
  screenOrientation,
  setScrollViewRefRef,
  unreadMentions,
  scrollToLatest,
  hasNewMessage,
  handleOnEndReached,
  renderMessage,
  handleScroll,
  handleViewableItemsChange,
  setContentOffsetY,
  setChatTranslateYOffset,
  hideSwipeCallOnboarding,
}) => {
  const [loadingChat, setLoadingChat] = useState(true)
  useEffect(() => {
    const timeout = setTimeout(() => {
      setLoadingChat(false)
    }, 200)
    return () => clearTimeout(timeout)
  }, [])
  const panGestureRef = useRef<GestureType>(Gesture.Pan())
  const contentOffsetY = useSharedValue(0)
  const bounces = useSharedValue(true)
  const stopScroll = useSharedValue(false)

  const scrollHandler = useAnimatedScrollHandler((event) => {
    runOnJS(setContentOffsetY)(event.contentOffset.y)
    contentOffsetY.value = event.contentOffset.y
  })
  const animatedProps = useAnimatedProps(() => ({
    bounces: bounces.value,
    scrollEnabled: !stopScroll.value,
  }))

  const setStopScroll = (stop: boolean) => {
    "worklet"

    stopScroll.value = stop
  }
  const setBounces = (enabled: boolean) => {
    "worklet"

    bounces.value = enabled
  }
  if (loadingChat) {
    return null
  }

  return (
    <MainChatWrapper screenOrientation={screenOrientation}>
      <HideMessage style={hideMessageStyle} hide={hideChat}>
        <FadingView fade={isFullScreenVideoCall} fadingPosition="fadeTop">
          <OpenChatNotificationHandler isChatHide={hideChat} />
          {listData.length ? (
            <SwipeToNextCall
              setBounces={setBounces}
              panGestureRef={panGestureRef}
              contentOffsetY={contentOffsetY}
              isInCallingChat={isInCallingChat}
              endCall={endCall}
              setChatTranslateYOffset={setChatTranslateYOffset}
              hideSwipeCallOnboarding={hideSwipeCallOnboarding}
              setStopScroll={setStopScroll}
            >
              <AnimatedFlatList
                initialScrollIndex={0}
                key={screenOrientation}
                scrollEnabled={!hideChat}
                style={flatListStyle}
                data={listData}
                ref={setScrollViewRefRef}
                keyExtractor={keyExtract}
                viewabilityConfig={viewabilityConfig}
                onScrollToIndexFailed={noop}
                onEndReached={handleOnEndReached}
                onEndReachedThreshold={0.01}
                renderItem={renderMessage}
                initialNumToRender={MESSAGE_LIMIT}
                maxToRenderPerBatch={MESSAGE_LIMIT}
                showsVerticalScrollIndicator={false}
                showsHorizontalScrollIndicator={false}
                onScrollEndDrag={handleScroll}
                onMomentumScrollEnd={handleScroll}
                onViewableItemsChanged={handleViewableItemsChange}
                maintainVisibleContentPosition={contentPosition}
                scrollEventThrottle={100}
                keyboardShouldPersistTaps="handled"
                onScroll={scrollHandler}
                inverted
                // eslint-disable-next-line react-perf/jsx-no-new-array-as-prop
                simultaneousHandlers={[panGestureRef]}
                animatedProps={animatedProps}
              />
            </SwipeToNextCall>
          ) : (
            <MessageListEmptyContainer style={flatListStyle}>
              <MessageListEmpty>
                {renderBlank()}
                {renderCommonInterests()}
                <RetrievingHistoryText>{`Let's chat!`}</RetrievingHistoryText>
              </MessageListEmpty>
            </MessageListEmptyContainer>
          )}
          {unreadMentions.length > 0 &&
            firstPageMentionReady &&
            renderMentionButton()}
          <BackToBottom
            onPress={scrollToLatest}
            hasUnread={hasNewMessage}
            contentOffsetY={contentOffsetY}
          />
        </FadingView>
      </HideMessage>
    </MainChatWrapper>
  )
}

export const MessageList = memo(MessageListComponent)
