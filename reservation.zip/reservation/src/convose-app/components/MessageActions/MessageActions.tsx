import React from "react"
import { Platform } from "react-native"
import _ from "lodash"
import { useSafeAreaInsets } from "react-native-safe-area-context"
import { SlideInDown, SlideOutDown } from "react-native-reanimated"

import { hardShadow, softShadows } from "convose-styles"
import { MessageActionType } from "convose-lib/chat"

import {
  ComponentWrapper,
  MessageActionsWrapper,
  ActionButton,
  ActionIcon,
  ActionTitle,
  EmojisContainer,
  ActionsContainer,
} from "./Styled"
import { NavbarHandler } from "./NavbarHandler"

const Button: React.FunctionComponent<MessageActionType> = ({
  ioniconName,
  onPress,
  title,
  disable,
}) => {
  return (
    <ActionButton onPress={disable ? undefined : onPress} disabled={disable}>
      <ActionIcon name={ioniconName} size={21} disable={disable} />
      <ActionTitle disable={disable}>{title}</ActionTitle>
    </ActionButton>
  )
}
const isAndroid = Platform.OS === "android"

const emojis = ["❤️", "😂", "😢", "😡", "👍", "🤩", "😯"]
export type MessageActionsType = {
  actions: MessageActionType[]
  isVisible: boolean
  onAddReaction?: (emoji: string) => void
}
const MessageActionsComponent: React.FC<MessageActionsType> = ({
  actions,
  isVisible,
  onAddReaction,
}) => {
  const insets = useSafeAreaInsets()
  const bottomInset = insets?.bottom || 0
  if (!isVisible) {
    return null
  }
  return (
    <>
      {isAndroid && <NavbarHandler isVisible={isVisible} />}
      <ComponentWrapper
        entering={SlideInDown.duration(150)}
        exiting={SlideOutDown.duration(150)}
        style={softShadows}
      >
        <MessageActionsWrapper style={hardShadow} bottomInset={bottomInset}>
          {!!onAddReaction && (
            <EmojisContainer>
              {emojis.map((emoji) => (
                <ActionButton key={emoji} onPress={() => onAddReaction(emoji)}>
                  <ActionTitle emoji>{emoji}</ActionTitle>
                </ActionButton>
              ))}
            </EmojisContainer>
          )}
          <ActionsContainer>
            {actions.map((action) => (
              <Button
                key={action.title}
                title={action.title}
                ioniconName={action.ioniconName}
                onPress={action.onPress}
                disable={action.disable}
              />
            ))}
          </ActionsContainer>
        </MessageActionsWrapper>
      </ComponentWrapper>
    </>
  )
}
export const MessageActions = React.memo(
  MessageActionsComponent,
  (prevProps, nextProps) => _.isEqual(prevProps, nextProps)
)
// MessageActions.whyDidYouRender = {
//   logOnDifferentValues: false,
//   customName: "MessageActions",
//   diffNameColor: "red",
// }
