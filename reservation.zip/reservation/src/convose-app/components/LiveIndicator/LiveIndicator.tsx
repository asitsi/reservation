import React from "react"
import { BarIndicator } from "react-native-indicators"
import { useTheme } from "styled-components"

type Props = {
  color?: string
  size?: number
}
const LiveIndicatorComponent: React.FC<Props> = ({ color, size = 20 }) => {
  const theme = useTheme()
  return (
    <BarIndicator
      color={color || theme.main.text}
      count={3}
      size={size}
      animationDuration={500}
    />
  )
}

export const LiveIndicator = React.memo(LiveIndicatorComponent)
