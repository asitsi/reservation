import React from "react"
import { Svg, Path } from "react-native-svg"
import { SvgProps } from "../../svg/types"
import { getRatio, getWidth } from "../../svg/utils"

const defaultHeight = 24
const defaultWidth = 25
const ratio = getRatio(defaultHeight, defaultWidth)

const InboxIconComponent: React.FunctionComponent<SvgProps> = ({
  color,
  height,
}) => {
  const svgHeight = height || defaultHeight
  const svgWidth = height ? getWidth(ratio, height) : defaultWidth
  return (
    <Svg width={svgWidth} height={svgHeight} viewBox="0 0 25 24" fill="none">
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M24.2888 11.8218C24.2888 18.3506 18.9961 23.6431 12.4672 23.6431C12.0351 23.6431 11.6084 23.6201 11.1883 23.5747C11.0705 23.6089 10.9427 23.6274 10.8057 23.627L1.28681 23.603C0.334385 23.6006 -0.286312 22.6016 0.13361 21.7466L2.16166 17.6177C1.19632 15.9053 0.645573 13.9277 0.645573 11.8218C0.645573 5.29248 5.9383 0 12.4672 0C18.9961 0 24.2888 5.29248 24.2888 11.8218ZM6.87125 6.33301C6.51545 6.33301 6.22702 6.62158 6.22702 6.97705V7.66309C6.22702 8.01855 6.51545 8.30713 6.87125 8.30713H18.0642C18.42 8.30713 18.7084 8.01855 18.7084 7.66309V6.97705C18.7084 6.62158 18.42 6.33301 18.0642 6.33301H6.87125ZM6.22635 11.3374C6.22635 10.9814 6.51477 10.6929 6.87055 10.6929H18.0635C18.4193 10.6929 18.7077 10.9814 18.7077 11.3374V12.0229C18.7077 12.3789 18.4193 12.667 18.0635 12.667H6.87055C6.51477 12.667 6.22635 12.3789 6.22635 12.0229V11.3374ZM6.87055 15.2876C6.51477 15.2876 6.22635 15.5762 6.22635 15.9321V16.6177C6.22635 16.9736 6.51477 17.2622 6.87055 17.2622H12.5997C12.9555 17.2622 13.2439 16.9736 13.2439 16.6177V15.9321C13.2439 15.5762 12.9555 15.2876 12.5997 15.2876H6.87055Z"
        fill={color || "#19AAEB"}
      />
    </Svg>
  )
}
export const InboxIcon = React.memo(InboxIconComponent)
export default InboxIcon
