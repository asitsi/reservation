import React, { useEffect } from "react"
import { ViewStyle } from "react-native"
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withTiming,
} from "react-native-reanimated"

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const getItemPositions = (list: Array<any>, key: string) => {
  return list.reduce(
    (prevVal, currentVal, index) => ({
      ...prevVal,
      [currentVal[key]]: index,
    }),
    {}
  )
}
const containerStyle: ViewStyle = {
  flexDirection: "row",
  flexWrap: "wrap",
}
// const scrollViewStyle: ViewStyle = { width: "100%" }

type ListType = {
  isSorting: boolean
  itemsCount: number
  itemHeight: number
  wrapperStyle?: ViewStyle
}
export const List: React.FC<React.PropsWithChildren<ListType>> = ({
  children,
  isSorting,
  itemsCount,
  itemHeight,
  wrapperStyle,
}) => {
  const minHeightOffset = useSharedValue(
    isSorting ? itemsCount * itemHeight : 0
  )

  useEffect(() => {
    if (isSorting) {
      minHeightOffset.value = withTiming(itemsCount * itemHeight, {
        duration: 100,
      })
    } else {
      minHeightOffset.value = withTiming(0, {
        duration: 200,
      })
    }
  }, [isSorting, itemHeight, itemsCount, minHeightOffset])

  const style = useAnimatedStyle(() => ({
    minHeight: minHeightOffset.value,
  }))

  return (
    // eslint-disable-next-line react-perf/jsx-no-new-array-as-prop
    <Animated.View style={[style, wrapperStyle, containerStyle]}>
      {children}
    </Animated.View>
  )
}
