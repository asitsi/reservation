import React, {
  useEffect,
  useImperativeHandle,
  useMemo,
  useRef,
  useState,
} from "react"
import {
  NativeSyntheticEvent,
  TextInput,
  TextInputProps,
  TextInputFocusEventData,
  Keyboard,
  ViewStyle,
} from "react-native"
import { useSelector } from "react-redux"

import { selectIsDarkMode } from "convose-lib/app"
import { FadeOut, useAnimatedStyle, withTiming } from "react-native-reanimated"
import {
  Container,
  Description,
  EditButton,
  EditButtonContainer,
  InputWrapper,
  StyledInput,
} from "./Styled"

import EditIcon from "../../../../assets/Icons/components/EditIcon"

type UsernameInputProps = TextInputProps & {
  readonly color: string
  readonly onBlurMessage?: string
  readonly noEditButton?: boolean
  readonly containerStyle?: ViewStyle
}
export type UserInputRefType = {
  focus: () => void
}
enum mapTextAlienToJustifyContent {
  center = "center",
  left = "flex-start",
  right = "flex-end",
}
const EDIT_ICON_SIZE = 17
const editButtonStyle = { width: EDIT_ICON_SIZE, height: EDIT_ICON_SIZE }
export const UsernameInput = React.forwardRef<
  UserInputRefType,
  UsernameInputProps
>(
  (
    { color, onBlurMessage, noEditButton, containerStyle, ...inputProps },
    ref
  ) => {
    const [isFocused, setIsFocused] = useState(false)
    const [description, setDescription] = useState("")
    const inputRef = useRef<TextInput>()
    const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null)
    const isDarkMode = useSelector(selectIsDarkMode)
    const hasEditButton = useMemo(
      () => !isFocused && !noEditButton,
      [isFocused, noEditButton]
    )
    const editButtonContainerStyle = useAnimatedStyle(
      () => ({
        transform: [
          { scale: withTiming(hasEditButton ? 1 : 0, { duration: 150 }) },
        ],
        width: withTiming(hasEditButton ? 25 : 0, { duration: 150 }),
      }),
      [hasEditButton]
    )
    const containerAnimatedStyle = useAnimatedStyle(
      () => ({
        paddingBottom: withTiming(description ? 20 : 0, { duration: 150 }),
      }),
      [description]
    )

    useEffect(() => {
      if (description) {
        timeoutRef.current = setTimeout(() => {
          setDescription("")
          timeoutRef.current = null
        }, 2000)
      }
      return () => {
        timeoutRef.current && clearTimeout(timeoutRef.current)
      }
    }, [description])

    const focusInput = () => {
      inputRef.current && inputRef.current.focus()
    }
    const onFocus = () => {
      setIsFocused(true)
    }
    const onBlur = (e: NativeSyntheticEvent<TextInputFocusEventData>) => {
      const callback = inputProps.onBlur
      setIsFocused(false)
      Keyboard.dismiss()
      callback && callback(e)
      onBlurMessage && setDescription(onBlurMessage)
    }

    useImperativeHandle(ref, () => ({
      focus: focusInput,
    }))

    return (
      <Container
        // eslint-disable-next-line react-perf/jsx-no-new-array-as-prop
        style={[containerStyle, containerAnimatedStyle]}
      >
        <InputWrapper
          justifyContent={
            mapTextAlienToJustifyContent[inputProps.textAlign || "center"]
          }
        >
          <StyledInput
            ref={inputRef}
            maxLength={12}
            blurOnSubmit
            selectTextOnFocus
            spellCheck={false}
            autoCorrect={false}
            textAlign="center"
            color={color}
            onFocus={onFocus}
            // eslint-disable-next-line react/jsx-props-no-spreading
            {...inputProps}
            onBlur={onBlur}
            keyboardAppearance={isDarkMode ? "dark" : "light"}
            scrollEnabled={false}
          />

          <EditButtonContainer style={editButtonContainerStyle}>
            <EditButton
              onPress={focusInput}
              iconComponent={<EditIcon height={EDIT_ICON_SIZE} />}
              style={editButtonStyle}
            />
          </EditButtonContainer>
        </InputWrapper>
        {!!description && (
          <Description exiting={FadeOut}>{description}</Description>
        )}
      </Container>
    )
  }
)
