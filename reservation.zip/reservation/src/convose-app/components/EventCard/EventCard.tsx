import React from "react"
import { useSelector } from "react-redux"
import { ZoomIn, ZoomOut } from "react-native-reanimated"

import { EventType } from "convose-lib/users-list/dto"
import { selectMyUuid } from "convose-lib/user"

import {
  Touchable,
  // AttendButtonContainer,
  // AttendButtonTitle,
  Container,
  HostAttendanceContainer,
  HostAttendeesContainer,
  MainBlueEntypoIcon,
  TitleMenuContainer,
} from "./Styled"

import { EventName } from "./EventName"
import { EventDate } from "./EventDate"
import { EventHost } from "./EventHost"
import { EventAttendees } from "./EventAttendees"
import { EventAttendButton } from "./EventAttendButton"

type EventCardComponentProps = {
  event: EventType
  onAttendPress: () => void
  onOptionsPress: () => void
  hideOptions?: boolean
  hideAttendingButton?: boolean
  myUuid: string
}

const EventCardComponent: React.FC<EventCardComponentProps> = ({
  event,
  onAttendPress,
  onOptionsPress,
  hideAttendingButton,
  hideOptions,
  myUuid,
}) => {
  const { time, date } = event

  return (
    <Container entering={ZoomIn} exiting={ZoomOut}>
      <TitleMenuContainer>
        <EventName name={event.name} />
        {!hideOptions && (
          <Touchable onPress={onOptionsPress}>
            <MainBlueEntypoIcon name="dots-three-vertical" size={20} />
          </Touchable>
        )}
      </TitleMenuContainer>
      <EventDate date={date} time={time} />
      <HostAttendanceContainer>
        <HostAttendeesContainer>
          <EventHost creator={event.creator} />
          <EventAttendees
            attendees={event.attendees}
            attendeesCount={event.attendees_count}
          />
        </HostAttendeesContainer>
        {!hideAttendingButton && event?.creator?.uuid !== myUuid && (
          <EventAttendButton
            isAttending={event.status === "attending"}
            onPress={onAttendPress}
          />
        )}
        {/* {event?.creator?.uuid === myUuid && (
          <AttendButtonContainer noBorder>
            <AttendButtonTitle>Host</AttendButtonTitle>
          </AttendButtonContainer>
        )} */}
      </HostAttendanceContainer>
    </Container>
  )
}

type Props = {
  event: EventType
  setSelectedGroupEvent?: (event: EventType) => void
  hideOptions?: boolean
  hideAttendingButton?: boolean
  onAttendPress?: (event: EventType) => void
}
export const EventCard: React.FC<Props> = ({
  event,
  setSelectedGroupEvent,
  hideAttendingButton,
  hideOptions,
  onAttendPress,
}) => {
  const myUuid = useSelector(selectMyUuid)
  const handleOnAttendPress = React.useCallback(() => {
    onAttendPress && onAttendPress(event)
  }, [event, onAttendPress])

  const onOptionPress = React.useCallback(() => {
    setSelectedGroupEvent && setSelectedGroupEvent(event)
  }, [event, setSelectedGroupEvent])

  return (
    <EventCardComponent
      event={event}
      onAttendPress={handleOnAttendPress}
      onOptionsPress={onOptionPress}
      hideAttendingButton={hideAttendingButton}
      hideOptions={hideOptions}
      myUuid={myUuid}
    />
  )
}
