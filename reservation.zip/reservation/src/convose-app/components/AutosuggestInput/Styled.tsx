import { TextInput, TouchableOpacity } from "react-native"
import styled from "styled-components/native"
import Animated from "react-native-reanimated"

import { CenteredText, color, font, Props } from "convose-styles"

const borderRadius = 40

export const AutosuggestWrapper = styled.View`
  flex: 1;
  border-radius: ${borderRadius}px;
  overflow: hidden;
  background: ${(props: Props) =>
    props.theme.interests.input.wrapperBackground};
  height: 50px;
`

export const StyledAutosuggestInput = styled(TextInput).attrs(
  (props: Props) => ({
    placeholderTextColor: props.theme.interests.input.placeholder,
  })
)`
  height: 100%;
  width: 100%;
  padding: 5px 20px;
  padding-right: 55px;
  font-size: 18px;
  color: ${(props: Props) => props.theme.textInput.color};
  font-family: ${font.light};
  include-font-padding: false;
  text-align-vertical: center;
`

// old
export const StyledTextInput = styled(TextInput)`
  border-radius: ${borderRadius}px;
  color: ${(props: Props) => props.theme.interests.input.buttonBackground};
  padding: 5px 20px;
  flex: 1;
  font-size: 18px;
  include-font-padding: false;
  text-align-vertical: center;
`

export const CaretView = styled.View`
  width: 1.5;
  height: 20px;
  background-color: ${color.white};
  border-radius: 2px;
`
const AnimatedTouchableOpacity =
  Animated.createAnimatedComponent(TouchableOpacity)
export const AddButton = styled(AnimatedTouchableOpacity)`
  position: absolute;
  background-color: ${(props: Props) => props.theme.mainBlue};
  padding: 8px;
  border-radius: 30px;
  right: 6px;
  top: 6px;
  bottom: 6px;
`
export const NewInterestConfirmationContainer = styled.View``
export const NewInterestConfirmationDescription = styled(CenteredText)`
  font-family: ${font.normal};
  font-size: 14px;
  padding-bottom: 29px;
  text-align: center;
  color: ${(props: Props) => props.theme.main.text};
`
