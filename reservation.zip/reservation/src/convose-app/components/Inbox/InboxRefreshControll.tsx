import React from "react"
import { RefreshControl, RefreshControlProps } from "react-native"
import { useTheme } from "styled-components"

type Props = {
  refreshing: boolean
  onRefresh: () => void
} & RefreshControlProps

const InboxRefreshControlComponent: React.FC<Props> = ({
  refreshing,
  onRefresh,
  ...props
}) => {
  const theme = useTheme()
  return (
    <RefreshControl
      refreshing={refreshing}
      onRefresh={onRefresh}
      tintColor={theme.main.text}
      // eslint-disable-next-line react-perf/jsx-no-new-array-as-prop
      colors={[theme.main.text]}
      progressBackgroundColor={theme.main.background}
      // eslint-disable-next-line react/jsx-props-no-spreading
      {...props}
    />
  )
}

export const InboxRefreshControl = React.memo(InboxRefreshControlComponent)
