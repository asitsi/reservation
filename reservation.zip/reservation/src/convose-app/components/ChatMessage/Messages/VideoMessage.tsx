import React, { useCallback, useMemo } from "react"
import { Image, ImageStyle } from "react-native"

import { Message } from "convose-lib/chat"

import { Routes } from "convose-lib/router"
import { LONG_PRESS_DURATION } from "convose-lib/utils"
import { useSkeleton } from "../../Skeleton"
import {
  PlayIconBackground,
  PlayIconContainer,
  VideoMessageContainer,
  VideoMessageInnerWrapper,
} from "./style"

import PlayIcon from "../../../../assets/Icons/components/PlayIcon"
import { navigate } from "../../../RootNavigation"

const imageStyle: ImageStyle = { width: "100%", height: "100%" }

type Props = {
  readonly message: Message
  readonly selectMessage: (message: Message) => void
}
const VideoMessageComponent: React.FC<Props> = ({ message, selectMessage }) => {
  const [animatedStyles, startLoading, stopLoading] = useSkeleton()

  const poster = useMemo(() => {
    if (!message.poster) {
      return null
    }
    if (typeof message.poster === "string") {
      const obj = JSON.parse(message.poster)
      return obj.url
    }
    return message.poster.url
  }, [message.poster])

  const onPlayPress = () => {
    requestAnimationFrame(() => {
      navigate(Routes.VideoPlayer, {
        url: message.data,
        duration: message.length || 0,
        poster,
      })
    })
  }
  const handleLongPress = useCallback(() => {
    selectMessage(message)
  }, [message, selectMessage])

  return (
    <VideoMessageContainer
      style={animatedStyles}
      onPress={onPlayPress}
      onLongPress={handleLongPress}
      delayLongPress={LONG_PRESS_DURATION}
    >
      <VideoMessageInnerWrapper>
        <Image
          // eslint-disable-next-line react-perf/jsx-no-new-object-as-prop
          source={{
            uri: poster,
          }}
          style={imageStyle}
          resizeMode="cover"
          onLoadStart={startLoading}
          onLoad={stopLoading}
        />
        <PlayIconBackground />
        <PlayIconContainer>
          <PlayIcon height={40} color="white" />
        </PlayIconContainer>
      </VideoMessageInnerWrapper>
    </VideoMessageContainer>
  )
}

export const VideoMessage = React.memo(VideoMessageComponent)
