import React from "react"
import { useSelector, useDispatch } from "react-redux"

import { selectOnboarding } from "convose-lib"
import { ChatAction, selectNotifications, Notification } from "convose-lib/chat"
import { Notifications } from "../Notifications"

const AppNotificationsComponent: React.FC = () => {
  const onboarding = useSelector(selectOnboarding)
  const notifications = useSelector(selectNotifications)
  const dispatch = useDispatch()
  const closeNotification = React.useCallback(
    (notification: Notification) => {
      dispatch(ChatAction.removeNotification(notification))
    },
    [dispatch]
  )
  if (onboarding) {
    return null
  }
  return (
    <Notifications
      closeNotification={closeNotification}
      notifications={notifications}
    />
  )
}

export const AppNotifications = React.memo(AppNotificationsComponent)
