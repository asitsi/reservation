import React, { useEffect, useState } from "react"
import { LayoutRectangle } from "react-native"
import Animated, {
  FadeOut,
  LinearTransition,
  interpolate,
  runOnJS,
  scrollTo,
  useAnimatedReaction,
  useAnimatedRef,
  useAnimatedScrollHandler,
  useAnimatedStyle,
  useSharedValue,
  withTiming,
} from "react-native-reanimated"
import _ from "lodash"

import { InterestLocation, UserInterest } from "convose-lib"
import { MY_INTEREST_SIZE, downShadow } from "convose-styles"

import { InterestButton } from "../InterestButton"
import { CurrentInterestsWrapper } from "./Styled"
import {
  INTEREST_ICON_SIZE,
  InterestItem,
  iconWrapperStyle,
  wrapperStyle,
} from "./InterestItem"

const layout = LinearTransition.damping(18).springify(50)

type ContainerProps = {
  interestsLength: number
}
const Container: React.FC<React.PropsWithChildren<ContainerProps>> = ({
  children,
  interestsLength,
}) => {
  const interestBarHeightOffset = useSharedValue(interestsLength ? 50 : 0)
  const interestsWrapperStyle = useAnimatedStyle(() => ({
    height: interestBarHeightOffset.value,
    marginBottom: interpolate(interestBarHeightOffset.value, [0, 50], [0, 5]),
  }))
  useEffect(() => {
    interestBarHeightOffset.value = withTiming(interestsLength ? 50 : 0, {
      duration: 150,
    })
  }, [interestsLength, interestBarHeightOffset])
  return (
    <CurrentInterestsWrapper layout={layout} style={interestsWrapperStyle}>
      {children}
    </CurrentInterestsWrapper>
  )
}

const animationDuration = 700

type Props = {
  interests: UserInterest[]
  onInterestPress: (interest: UserInterest) => void
  onDeleteInterestPress: (interest: UserInterest) => void
  setInterests?: (interests: UserInterest[]) => void
}

const InterestsListComponent: React.FC<Props> = ({
  interests,
  onDeleteInterestPress,
  onInterestPress,
  setInterests,
}) => {
  const scrollViewPosition = useSharedValue(0)
  const scrollViewRef = useAnimatedRef<Animated.ScrollView>()
  const [movingInterest, setMovingInterest] = useState<UserInterest | null>(
    null
  )
  const hasMovingInterest = useSharedValue(false)
  const moving = useSharedValue<LayoutRectangle>({
    height: 0,
    width: 0,
    x: 0,
    y: 0,
  })

  const scrollHandler = useAnimatedScrollHandler((event) => {
    if (!hasMovingInterest.value) {
      scrollViewPosition.value = event.contentOffset.x
    }
  })
  useAnimatedReaction(
    () => scrollViewPosition.value,
    (currentValue) => {
      scrollTo(scrollViewRef, currentValue, 0, false)
    }
  )
  const onLongPress = (interest: UserInterest, position: LayoutRectangle) => {
    if (!setInterests) {
      return
    }
    const interestsWithoutMovingOne = interests.filter(
      (intr) => intr.id !== interest.id
    )
    setMovingInterest(interest)
    hasMovingInterest.value = true
    moving.value = position
    setInterests([interest, ...interestsWithoutMovingOne])
    moving.value = withTiming(
      {
        ...moving.value,
        x: 12,
        y: 0,
      },
      { duration: animationDuration },
      () => {
        runOnJS(setMovingInterest)(null)
        hasMovingInterest.value = false
      }
    )
    scrollViewPosition.value = withTiming(0, { duration: animationDuration })
  }
  const uniqInterests = React.useMemo(
    () => _.uniqBy(interests || [], "name"),
    [interests]
  )

  const style = useAnimatedStyle(() => ({
    position: "absolute",
    left: moving.value.x,
    top: moving.value.y,
    zIndex: 1,
    ...downShadow,
  }))

  return (
    <Animated.ScrollView
      ref={scrollViewRef}
      horizontal
      onScroll={scrollHandler}
      showsHorizontalScrollIndicator={false}
      keyboardShouldPersistTaps="handled"
      layout={layout}
    >
      <Container interestsLength={uniqInterests.length}>
        {uniqInterests.map((interest, index) => (
          <InterestItem
            key={interest.id}
            index={index}
            interest={interest}
            movingInterest={movingInterest}
            onDelete={onDeleteInterestPress}
            onLongPress={onLongPress}
            onPress={onInterestPress}
          />
        ))}
        {movingInterest && (
          <Animated.View style={style} exiting={FadeOut.duration(250)}>
            <InterestButton
              interest={movingInterest}
              size={MY_INTEREST_SIZE}
              interestLocation={InterestLocation.MyInterests}
              addBorder
              transparentBackground
              iconSize={INTEREST_ICON_SIZE}
              wrapperStyle={wrapperStyle}
              iconWrapperStyle={iconWrapperStyle}
              backgroundColorCode="interests.inputAndCurrentInterests.background"
            />
          </Animated.View>
        )}
      </Container>
    </Animated.ScrollView>
  )
}

export const InterestsList = React.memo(InterestsListComponent)
