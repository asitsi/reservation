import React, { FC, memo, useMemo } from "react"
import { LinearTransition } from "react-native-reanimated"

import { BlockAlertValue, Message } from "convose-lib/chat"
import { WaveButton, useWaveButton } from "../WaveButton"
import {
  WaveButtonContainer,
  WaveMessageBox,
  WaveMessageContainer,
} from "./Styled"
import { EmojiOnlyText } from "../ChatMessage/Styled"
import { SenderUsernameAvatar } from "../ChatMessage/SenderUsernameAvatar"

const layout = LinearTransition.duration(50)

type WaveMessageType = {
  message: Message
  chatChannel: string
  isFullScreenVideoCall: boolean
  isBlocked: boolean
  showBlockAlert: (type: BlockAlertValue) => void
  isGroupAdmin: boolean
  myUuid: string
  sameSender: boolean
}
const WaveMessageComponent: FC<WaveMessageType> = ({
  message,
  chatChannel,
  isFullScreenVideoCall,
  isBlocked,
  showBlockAlert,
  isGroupAdmin,
  myUuid,
  sameSender,
}) => {
  const { onPress } = useWaveButton(chatChannel, {
    reply_to_id: message.uuid,
    reply_to_message: message.data,
    reply_to_message_type: message.message_type,
    reply_to_user_id: message.sender,
    reply_to_username: message.senderUsername,
  })
  const canRenderWaveButton = useMemo(() => {
    if (message.myMessage || message.responded || message.reply_to_user_id) {
      return false
    }
    return true
  }, [message.myMessage, message.reply_to_user_id, message.responded])

  return (
    <WaveMessageContainer myMessage={message.myMessage}>
      <SenderUsernameAvatar
        avatar={message.avatar}
        chatChannel={chatChannel}
        deleted={message.deleted}
        isBlocked={isBlocked}
        isFullScreenVideoCall={isFullScreenVideoCall}
        isGroupAdmin={isGroupAdmin}
        myMessage={message.myMessage}
        myUuid={myUuid}
        replyId={message.reply_to_id}
        sameSender={sameSender}
        sender={message.sender}
        senderUsername={message.senderUsername}
        showBlockAlert={showBlockAlert}
        themeColor={message.theme_color}
      />
      <WaveMessageBox layout={layout} myMessage={message.myMessage}>
        <EmojiOnlyText>{message.data}</EmojiOnlyText>
        {canRenderWaveButton && (
          <WaveButtonContainer>
            <WaveButton
              onDisappeared={onPress}
              isWaveBack
              text="Wave back"
              noWaveTextFeedback
            />
          </WaveButtonContainer>
        )}
      </WaveMessageBox>
    </WaveMessageContainer>
  )
}

export const WaveMessage = memo(WaveMessageComponent)
