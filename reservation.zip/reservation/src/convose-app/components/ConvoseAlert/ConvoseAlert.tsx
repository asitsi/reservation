import React, { ReactElement, ReactNode } from "react"
import { LayoutChangeEvent, Platform } from "react-native"

import {
  Description,
  Title,
  Icon,
  ButtonsContainer,
  AlertContainer,
  CustomIconContainer,
} from "./Styled"
import { ButtonType, AlertButton } from "./AlertButton"
import { SlideUpWrapper } from "../SlideUpWrapper"

const isAndroid = Platform.OS === "android"

type ShowProps = {
  icon?: ReactElement | null
  ioniconName?: string
  title?: string | ReactElement
  description?: string | ReactElement
  buttons?: ButtonType[] | null
  canDismiss?: boolean
  onDismiss?: () => void
  keyboardShouldPersistTaps?: "always" | "never" | "handled"
}
type State = ShowProps & {
  isVisible: boolean
  minHeight?: number
}
type Props = ShowProps & {
  isVisible?: boolean
}
const slideUpWrapperStyle = {
  zIndex: Number.MAX_SAFE_INTEGER - 1,
  elevation: Number.MAX_SAFE_INTEGER - 1,
}
const tryRenderComponent = (
  // eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types, @typescript-eslint/no-explicit-any
  Container: any,
  field?: string | ReactElement
): ReactNode | null => {
  if (!field) {
    return null
  }
  if (typeof field === "string") {
    return <Container>{field}</Container>
  }
  return field
}
export class ConvoseAlert extends React.PureComponent<Props, State> {
  constructor(props: Props) {
    super(props)
    const state = this.initState()
    this.state = state
  }

  componentDidUpdate(prevProps: Props, prevState: State): void {
    const { isVisible } = this.props
    if (!prevProps.isVisible && isVisible) {
      this.setVisible()
    }
    const { isVisible: stateIsVisible } = this.state
    if (prevState.isVisible && !stateIsVisible) {
      this.setState({
        minHeight: undefined,
      })
    }
  }

  private initState = (): State => {
    const {
      isVisible = false,
      ioniconName = "",
      title = "",
      description = "",
      buttons = [],
      icon = null,
      canDismiss = true,
      onDismiss,
      keyboardShouldPersistTaps,
    } = this.props
    return {
      isVisible,
      ioniconName,
      title,
      description,
      buttons,
      icon,
      canDismiss,
      onDismiss,
      minHeight: undefined,
      keyboardShouldPersistTaps,
    }
  }

  private setInvisible = (): void => {
    const { onDismiss } = this.state

    !!onDismiss && onDismiss()
    this.setState({
      isVisible: false,
    })
  }

  private setVisible = (): void => {
    this.setState({
      isVisible: true,
    })
  }

  private renderButtons = (): ReactNode => {
    const { buttons } = this.state
    if (buttons?.length) {
      const buttonLength = buttons.length
      return (
        <ButtonsContainer>
          {buttons.map((button: ButtonType, index) => {
            return (
              <AlertButton
                // eslint-disable-next-line react/no-array-index-key
                key={`${button.title}-${index}`}
                title={button.title}
                onPress={() => {
                  if (!button.keepAlertOpenAfterPress) {
                    this.setInvisible()
                  }
                  if (typeof button.onPress === "function") {
                    button.onPress()
                  }
                }}
                type={button.type}
                isLast={index + 1 === buttonLength}
              />
            )
          })}
        </ButtonsContainer>
      )
    }
    if (buttons === null) {
      return null
    }
    return (
      <ButtonsContainer>
        <AlertButton title="OK" onPress={this.setInvisible} isLast />
      </ButtonsContainer>
    )
  }

  // eslint-disable-next-line react/no-unused-class-component-methods
  public show = (props: ShowProps): void => {
    const {
      buttons,
      description,
      ioniconName,
      title,
      canDismiss = true,
      onDismiss,
      icon,
      keyboardShouldPersistTaps,
    } = props
    this.setState({
      buttons,
      description,
      ioniconName,
      title,
      isVisible: true,
      canDismiss,
      onDismiss,
      icon,
      keyboardShouldPersistTaps,
    })
  }

  // eslint-disable-next-line react/no-unused-class-component-methods
  public updateDescription = ({
    description,
  }: {
    description: string | ReactElement
  }) => {
    this.setState({
      description,
    })
  }

  public renderTitle = (): ReactNode | null => {
    const { title } = this.state
    return tryRenderComponent(Title, title)
  }

  public renderDescription = (): ReactNode | null => {
    const { description } = this.state
    return tryRenderComponent(Description, description)
  }

  public renderIcon = (): ReactNode | null => {
    const { icon, ioniconName } = this.state
    if (ioniconName) {
      return <Icon name={ioniconName} size={45} />
    }
    if (icon) {
      return <CustomIconContainer>{icon}</CustomIconContainer>
    }
    return null
  }

  render(): ReactNode {
    const { isVisible, canDismiss, minHeight, keyboardShouldPersistTaps } =
      this.state
    if (!isVisible) {
      return null
    }
    return (
      <SlideUpWrapper
        canDismiss={canDismiss}
        onDismiss={this.setInvisible}
        wrapperStyle={slideUpWrapperStyle}
        keyboardShouldPersistTaps={keyboardShouldPersistTaps}
      >
        <AlertContainer
          onLayout={(event: LayoutChangeEvent) => {
            if (isAndroid) {
              this.setState({ minHeight: event.nativeEvent.layout.height })
            }
          }}
          minHeight={minHeight}
        >
          {this.renderIcon()}
          {this.renderTitle()}
          {this.renderDescription()}
          {this.renderButtons()}
        </AlertContainer>
      </SlideUpWrapper>
    )
  }
}
// ConvoseAlert.whyDidYouRender = {
//   logOnDifferentValues: false,
//   customName: "ConvoseAlert",
//   diffNameColor: "red",
// }
/*
How to use it as alert!
create a ref this type

private convoseAlertRef!: ConvoseAlert | null

place the component in the render

<ConvoseAlert
          ref={(ref) => {
            this.convoseAlertRef = ref
          }}
 />

 and anywhere you want to call it: 
 this.convoseAlertRef?.show({
        title: "title",
        description: "description",
        ioniconName: "trash",
        buttons: [
          {
            title: "Remove",
            onPress: () => {
              this.deleteMessage(selectedMessage)
              this.dismissSelectedMessage()
            },
          },
          {
            title: "Cancel",
            type: "cancel",
            onPress: this.dismissSelectedMessage,
          },
        ],
      })

*/
