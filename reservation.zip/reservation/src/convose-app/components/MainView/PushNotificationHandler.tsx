/* eslint-disable import/no-extraneous-dependencies */
import React from "react"
import { Platform } from "react-native"
import * as Notifications from "expo-notifications"
import { Subscription } from "expo-modules-core"
import { connect } from "react-redux"

import { Routes } from "convose-lib/router"
import { State } from "convose-lib"
import { selectToken } from "convose-lib/user"
import * as RootNavigation from "../../RootNavigation"

const dismissAllNotifications = (): void => {
  Notifications.dismissAllNotificationsAsync()
}

const handleNotification = (
  notification: Notifications.NotificationRequest
) => {
  dismissAllNotifications()
  const pnChannel = notification.content.data.chat
  RootNavigation?.navigate &&
    RootNavigation?.navigate(Routes.Chat, {
      channel: pnChannel,
      chatUser: null,
    })
}

type StateToProps = {
  readonly authToken?: string
}
type Props = StateToProps
class PushNotificationHandlerComponent extends React.Component<Props> {
  public notificationSubscription!: Subscription

  public async componentDidMount(): Promise<void> {
    this.notificationSubscription =
      Notifications.addNotificationResponseReceivedListener((response) => {
        handleNotification(response.notification.request)
      })

    if (Platform.OS === "android") {
      const lastNotificationResponse =
        await Notifications.getLastNotificationResponseAsync()
      if (
        lastNotificationResponse &&
        lastNotificationResponse.notification.request.content &&
        lastNotificationResponse.actionIdentifier ===
          Notifications.DEFAULT_ACTION_IDENTIFIER
      ) {
        handleNotification(lastNotificationResponse.notification.request)
      }
    }
  }

  public componentDidUpdate(prevProps: Props): void {
    const { authToken } = this.props
    if (prevProps.authToken !== authToken) {
      dismissAllNotifications()
    }
  }

  public componentWillUnmount(): void {
    this.notificationSubscription && this.notificationSubscription.remove()
  }

  render(): React.ReactNode {
    return null
  }
}
const mapStateToProps = (state: State): StateToProps => {
  return {
    authToken: selectToken(state),
  }
}

export const PushNotificationHandler = React.memo(
  connect(mapStateToProps, null)(PushNotificationHandlerComponent)
)
