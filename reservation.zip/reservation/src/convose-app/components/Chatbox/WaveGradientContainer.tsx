import React, { PropsWithChildren, memo } from "react"
import Svg, { Defs, RadialGradient, Stop, Circle } from "react-native-svg"
import { useTheme } from "styled-components"

import { ThemeType } from "convose-styles"
import { GradientWrapper, WaveGradientWrapper } from "./Styled"

type Props = {
  size: number
}

const WaveGradientContainerComponent: React.FC<PropsWithChildren<Props>> = ({
  size = 70,
  children,
}) => {
  const theme: ThemeType = useTheme()
  const fadingColor = theme.main.chatBoxBackground

  return (
    <WaveGradientWrapper>
      <GradientWrapper>
        <Svg width={size} height={size} viewBox="0 0 200 200" fill="none">
          <Circle cx="100" cy="100" r="100" fill="url(#paint0_radial_13_3)" />
          <Defs>
            <RadialGradient
              id="paint0_radial_13_3"
              cx="0"
              cy="0"
              r="1"
              gradientUnits="userSpaceOnUse"
              gradientTransform="translate(100 100) rotate(90) scale(100)"
            >
              <Stop stopColor={fadingColor} />
              <Stop offset="0.55" stopColor={fadingColor} stopOpacity="0.9" />
              <Stop offset="0.85" stopColor={fadingColor} stopOpacity="0.5" />
              <Stop offset="1" stopColor={fadingColor} stopOpacity="0" />
            </RadialGradient>
          </Defs>
        </Svg>
      </GradientWrapper>
      {children}
    </WaveGradientWrapper>
  )
}

export const WaveGradientContainer = memo(WaveGradientContainerComponent)
