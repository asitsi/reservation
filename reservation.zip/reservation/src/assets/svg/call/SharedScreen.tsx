import React from "react"
import { Svg, Path } from "react-native-svg"
import { SvgProps } from "../types"
import { getRatio, getWidth } from "../utils"

const defaultHeight = 14
const defaultWidth = 13
const ratio = getRatio(defaultHeight, defaultWidth)

const SharedScreenSvgComponent: React.FunctionComponent<SvgProps> = ({
  color,
  height,
}) => {
  const svgHeight = height || defaultHeight
  const svgWidth = height ? getWidth(ratio, height) : defaultWidth
  return (
    <Svg width={svgWidth} height={svgHeight} viewBox="0 0 14 13" fill="none">
      <Path
        d="M11.6667 1H2.33333C1.59695 1 1 1.59695 1 2.33333V7.66667C1 8.40305 1.59695 9 2.33333 9H11.6667C12.403 9 13 8.40305 13 7.66667V2.33333C13 1.59695 12.403 1 11.6667 1Z"
        stroke={color || "white"}
        strokeWidth="1.5"
      />
      <Path d="M7 9V12" stroke={color || "white"} strokeWidth="1.2" />
      <Path
        d="M5 12L9 12"
        stroke={color || "white"}
        strokeWidth="1.2"
        strokeLinecap="round"
      />
    </Svg>
  )
}

export const SharedScreenSvg = React.memo(SharedScreenSvgComponent)
