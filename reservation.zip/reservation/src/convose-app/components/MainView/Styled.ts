import { Platform } from "react-native"
import styled from "styled-components/native"
import Animated from "react-native-reanimated"

import {
  CenteredText,
  Props,
  color,
  font,
  statusBarHeight,
} from "convose-styles"
import { RootStack } from "../../router"

const isAndroid = Platform.OS === "android"

export const StyledRootStack = styled(RootStack)`
  flex: 1;
`

export const MainViewWrapper = styled.View`
  background: ${(props: Props) => props.theme.main.background};
  flex: 1;
  height: 100%;
  width: 100%;
`

export const DisplayTextModal = styled(Animated.View)`
  position: absolute;
  height: 100%;
  width: 100%;
  align-items: center;
  justify-content: center;
  background: ${color.black_transparent_light};
  elevation: 1000;
`
export const ModalContent = styled(CenteredText)`
  color: ${color.white};
  font-family: ${font.semiBold};
  font-size: 22px;
`
export const AndroidStatusBarFix = styled.View`
  background-color: transparent;
  ${isAndroid && `height: ${statusBarHeight}; `}
  width: 100%;
`
export const SocialLoginContainer = styled.View`
  padding: 10px 15px 10px 15px;
`
