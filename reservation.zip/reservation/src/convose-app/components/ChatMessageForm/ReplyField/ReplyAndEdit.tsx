/* eslint-disable react-perf/jsx-no-new-object-as-prop */
import React, { useEffect } from "react"
import Ionicons from "react-native-vector-icons/Ionicons"

import { Message, MessageType } from "convose-lib/chat"
import { useMainBlue } from "convose-lib/utils/useMainBlue"
import {
  runOnJS,
  useAnimatedStyle,
  useSharedValue,
  withTiming,
} from "react-native-reanimated"
import { parseValue } from "../../../../../self-maintained-packages/react-native-controlled-mentions/src"

import {
  ActionField,
  ActionsContainer,
  CloseWrapper,
  DescriptionText,
  DescriptionWrapper,
  Field,
  MessageText,
  ReplyUser,
  Wrapper,
  Image,
  CloseButton,
} from "./Styled"

function capitalize(str: string): string {
  return str.charAt(0).toUpperCase() + str.slice(1)
}

type Props = {
  readonly message?: Message
  readonly onClose: () => void
  readonly isEdit?: boolean
}
const SHOW_HEIGHT = 53
const HIDE_HEIGHT = 0
const ANIMATION_DURATION = 150
const ReplyAndEditComponent: React.FC<Props> = ({
  message,
  onClose,
  isEdit,
}) => {
  const mainBlue = useMainBlue()
  const height = useSharedValue(message ? SHOW_HEIGHT : HIDE_HEIGHT)

  const style = useAnimatedStyle(
    () => ({
      height: height.value,
    }),
    [message]
  )
  useEffect(() => {
    if (message) {
      height.value = withTiming(SHOW_HEIGHT, { duration: ANIMATION_DURATION })
    } else {
      height.value = withTiming(HIDE_HEIGHT, { duration: ANIMATION_DURATION })
    }
  }, [message, height])

  if (!message) {
    return null
  }
  const handleOnClose = () => {
    height.value = withTiming(
      HIDE_HEIGHT,
      { duration: ANIMATION_DURATION },
      () => {
        runOnJS(onClose)()
      }
    )
  }
  const { senderUsername, data, myMessage, message_type: messageType } = message
  const parsData = (messageToReplyData: string) => {
    const { parts } = parseValue(messageToReplyData, [
      {
        trigger: "@",
      },
    ])
    return parts.map((part) => part.text).join("")
  }
  return (
    <Wrapper style={style}>
      <Field>
        <DescriptionWrapper>
          {isEdit ? (
            <DescriptionText>Edit message</DescriptionText>
          ) : (
            <>
              <DescriptionText>Replying to </DescriptionText>
              <ReplyUser>{myMessage ? "Yourself" : senderUsername}</ReplyUser>
            </>
          )}
        </DescriptionWrapper>
        <MessageText numberOfLines={1}>
          {" "}
          {messageType === "text" ? parsData(data) : capitalize(messageType)}
        </MessageText>
      </Field>
      <ActionField>
        <ActionsContainer>
          {messageType === MessageType.Image && !!data && (
            <Image source={{ uri: data }} />
          )}
          <CloseButton onPress={handleOnClose}>
            <CloseWrapper>
              <Ionicons name="close" size={19} color={mainBlue} />
            </CloseWrapper>
          </CloseButton>
        </ActionsContainer>
      </ActionField>
    </Wrapper>
  )
}

export const ReplyAndEditField = React.memo(ReplyAndEditComponent)
