import React from "react"
import {
  SharedValue,
  useAnimatedStyle,
  withTiming,
} from "react-native-reanimated"
import { useSafeAreaInsets } from "react-native-safe-area-context"
import { useSelector } from "react-redux"

import { LoginType, selectIsGuest } from "convose-lib/user"
import { Routes } from "convose-lib/router"
import { downShadow } from "convose-styles"
import { AuthButtonList } from "../../AuthButtonList"
import { GroupCallSvg } from "../../../../assets/Icons/components/GroupCall"
import { convoseAlertRef } from "../../../RootConvoseAlert"
import * as RootNavigation from "../../../RootNavigation"

import { Container, Title } from "./Style"

const duration = 180

type Props = {
  translationY?: SharedValue<number>
}

const InboxFloatingNewGroupButtonComponent: React.FC<Props> = ({
  translationY,
}) => {
  const insets = useSafeAreaInsets()
  const isGuest = useSelector(selectIsGuest)

  const titleStyle = useAnimatedStyle(() => ({
    maxWidth: withTiming((translationY?.value || 0) > 1 ? 0 : 300, {
      duration,
    }),
    marginLeft: withTiming((translationY?.value || 0) > 1 ? 0 : 15, {
      duration,
    }),
    transform: [
      {
        scale: withTiming((translationY?.value || 0) > 1 ? 0 : 1, {
          duration:
            (translationY?.value || 0) > 1 ? duration - 20 : 1.5 * duration,
        }),
      },
    ],
  }))
  const hideConvoseAlert = (callback?: () => void) => {
    convoseAlertRef?.setState({
      isVisible: false,
    })
    callback && callback()
  }
  const onLoginPress = () => {
    convoseAlertRef?.show({
      title: "To create a group, you need to sign in first!",
      ioniconName: "log-in",
      description: (
        <AuthButtonList
          loginOrSignUp={LoginType.SignUp}
          onAuthCompleted={hideConvoseAlert}
          onHideComponent={hideConvoseAlert}
        />
      ),
      buttons: null,
    })
  }

  const onPress = () => {
    if (isGuest) {
      onLoginPress()
      return
    }

    RootNavigation.navigate(Routes.CreateGroup, {
      members: [],
      isGroup: false,
      isFromInbox: true,
    })
  }

  return (
    <Container style={downShadow} insetBottom={insets.bottom} onPress={onPress}>
      <GroupCallSvg height={22} />
      <Title style={titleStyle}>Create group</Title>
    </Container>
  )
}

export const InboxFloatingNewGroupButton = React.memo(
  InboxFloatingNewGroupButtonComponent
)
