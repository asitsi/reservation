import React, { useCallback } from "react"
import { useSelector } from "react-redux"
import {
  SharedValue,
  useAnimatedStyle,
  withTiming,
} from "react-native-reanimated"

import { softShadows } from "convose-styles"
import { selectIsDarkMode } from "convose-lib/app"

import {
  BackToBottomContainer,
  BackToBottomTouchable,
  StyledIonicons,
  UnreadBadge,
} from "./Styled"

const duration = 100
const SHOW_OFFSET = 80
// eslint-disable-next-line react/no-unused-prop-types
type PressablePress = { pressed: boolean }

type Props = {
  onPress: () => void
  hasUnread?: boolean
  contentOffsetY: SharedValue<number>
}

const BackToBottomComponent: React.FC<Props> = ({
  onPress,
  hasUnread,
  contentOffsetY,
}) => {
  const isDark = useSelector(selectIsDarkMode)
  const handleOnPress = useCallback(() => {
    requestAnimationFrame(() => {
      onPress && onPress()
    })
  }, [onPress])
  const style = useAnimatedStyle(() => {
    return {
      transform: [
        {
          scale: withTiming(contentOffsetY.value > SHOW_OFFSET ? 1 : 0, {
            duration,
          }),
        },
        {
          translateY: withTiming(contentOffsetY.value > SHOW_OFFSET ? -75 : 0, {
            duration,
          }),
        },
      ],
    }
  })
  return (
    <BackToBottomTouchable style={style} hitSlop={15} onPress={handleOnPress}>
      {({ pressed }: PressablePress) => (
        <BackToBottomContainer
          pressed={pressed}
          style={!isDark ? softShadows : undefined}
        >
          {!!hasUnread && <UnreadBadge />}
          <StyledIonicons name="arrow-down" size={20} />
        </BackToBottomContainer>
      )}
    </BackToBottomTouchable>
  )
}

export const BackToBottom = React.memo(BackToBottomComponent)
