import React from "react"

import {
  getInterestNameWithDetails,
  InterestType,
  RatingLevel,
  UserInterest,
} from "convose-lib/interests"
import {
  IconContainer,
  IconNameContainer,
  InterestDetailContainer,
  InterestNameContainer,
  NameContainer,
  RatingLevelWrapper,
  StyledButton,
  TopTextViewWrapper,
  TopTextWrapper,
} from "./Styled"
import { LinearKnowledgeLevelDisplay } from "../LinearKnowledgeLevelDisplay"
import { InterestIcon } from "../InterestIcon"

type RatingWheelProps = {
  readonly interest: UserInterest
  readonly onChange: (level: RatingLevel | null) => void
}

type RatingWheelState = {
  readonly level: RatingLevel
}

export class KnowledgeLevelWidget extends React.Component<
  RatingWheelProps,
  RatingWheelState
> {
  public readonly state: RatingWheelState = {
    // eslint-disable-next-line react/destructuring-assignment
    level: this.props.interest.level || RatingLevel.Beginner,
  }

  private readonly changeLevel = (level: RatingLevel) => {
    this.setState({ level })
  }

  private readonly handleOnChange = () => {
    const { onChange } = this.props
    const { level } = this.state
    onChange(level)
  }

  private readonly removeInterest = () => {
    const { onChange } = this.props
    onChange(null)
  }

  public render(): React.ReactNode {
    const { interest } = this.props
    const { level } = this.state
    const { details, name } = getInterestNameWithDetails(interest.name)
    return (
      <RatingLevelWrapper>
        <TopTextViewWrapper>
          <NameContainer>
            <IconNameContainer>
              <IconContainer>
                <InterestIcon
                  imageUrl={interest?.avatar}
                  name={interest.name}
                  color={interest.color}
                  size={35}
                />
              </IconContainer>
              <InterestNameContainer>
                <TopTextWrapper
                  adjustsFontSizeToFit
                  numberOfLines={1}
                  maxFontSizeMultiplier={1}
                  size={28}
                >
                  {name}
                </TopTextWrapper>
              </InterestNameContainer>
            </IconNameContainer>
            {!!details && (
              <InterestDetailContainer>
                <TopTextWrapper
                  adjustsFontSizeToFit
                  numberOfLines={1}
                  maxFontSizeMultiplier={1}
                  size={16}
                >
                  [{details}]
                </TopTextWrapper>
              </InterestDetailContainer>
            )}
          </NameContainer>
          <TopTextWrapper size={18} numberOfLines={1} ellipsizeMode="tail">
            My knowledge level:
          </TopTextWrapper>
        </TopTextViewWrapper>
        <LinearKnowledgeLevelDisplay
          level={level}
          changeLevel={this.changeLevel}
        />
        <StyledButton onPress={this.handleOnChange} label="Done" />
        {interest.type === InterestType.General && (
          <StyledButton
            onPress={this.removeInterest}
            label="Remove rating"
            type="text"
            isTextMainBlue
          />
        )}
      </RatingLevelWrapper>
    )
  }
}
