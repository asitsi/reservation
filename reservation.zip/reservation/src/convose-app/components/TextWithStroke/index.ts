export * from "./TextWithStroke"
