import React from "react"
import { isEqual } from "lodash"
import { useSafeAreaInsets } from "react-native-safe-area-context"
import { useSelector } from "react-redux"

import { selectScreenOrientation } from "convose-lib/app"
import { ChatMenuUserInterests } from "./Styled"

const LANDSCAPES = ["LANDSCAPE-LEFT", "LANDSCAPE-RIGHT"]
const UserInterestsContainerComponent: React.FC<React.PropsWithChildren> = ({
  children,
}) => {
  const { left, right } = useSafeAreaInsets()
  const screenOrientation = useSelector(selectScreenOrientation)

  const insetHorizontal = LANDSCAPES.includes(screenOrientation)
    ? Math.max(left, right)
    : 0
  return (
    <ChatMenuUserInterests insetHorizontal={insetHorizontal}>
      {children}
    </ChatMenuUserInterests>
  )
}

export const UserInterestsContainer = React.memo(
  UserInterestsContainerComponent,
  (prevProps, nextProps) => isEqual(prevProps, nextProps)
)
