import React, { useEffect, useState } from "react"
import { StyleSheet } from "react-native"
import FontAwesome from "react-native-vector-icons/FontAwesome"
import { FadeIn, FadeOut } from "react-native-reanimated"

import { AutoSuggestInterest } from "convose-lib/interests"
import { roundNumberTo } from "convose-lib/utils"

import {
  InterestTextWrapper,
  StyledOptionText,
  StyledOptionView,
  StyledExistingIndicatorText,
  AddedMarkerWrapper,
  StyledFontAwesomeAddedMarker,
  InterestWrapper,
} from "./Styled"
import { InterestIcon } from "../InterestIcon"
import { Skeleton } from "../Skeleton"

const styles = StyleSheet.create({
  iconSkeleton: {
    width: 30,
    height: 30,
    borderRadius: 15,
  },
  nameSkeleton: {
    width: 110,
    height: 15,
    borderRadius: 15,
  },
})
const renderExistingMarker = (
  exists: boolean | undefined,
  removed: boolean
): React.ReactElement | null => {
  if (exists) {
    return (
      <AddedMarkerWrapper entering={FadeIn} exiting={FadeOut}>
        <StyledFontAwesomeAddedMarker name="check" size={13} />
        <StyledExistingIndicatorText>Added</StyledExistingIndicatorText>
      </AddedMarkerWrapper>
    )
  }
  if (removed) {
    return (
      <AddedMarkerWrapper entering={FadeIn} exiting={FadeOut}>
        <StyledFontAwesomeAddedMarker name="close" size={13} removed />
        <StyledExistingIndicatorText removed>
          Removed
        </StyledExistingIndicatorText>
      </AddedMarkerWrapper>
    )
  }
  return null
}

const renderLoadingItem = (): React.ReactElement => {
  return (
    <StyledOptionView>
      <InterestWrapper>
        <Skeleton style={styles.iconSkeleton} />
        <InterestTextWrapper>
          <Skeleton style={styles.nameSkeleton} />
        </InterestTextWrapper>
      </InterestWrapper>
    </StyledOptionView>
  )
}
type InterestMatchesType = {
  interestMatchCount: number | string
}
const InterestMatches: React.FC<InterestMatchesType> = ({
  interestMatchCount,
}) => (
  <StyledOptionText>
    {` ( ${interestMatchCount} `}
    <FontAwesome name="user" />
    {` )`}
  </StyledOptionText>
)

type InterestNameType = {
  name: string
}
const InterestName: React.FC<InterestNameType> = ({ name }) => (
  <InterestTextWrapper>
    <StyledOptionText ellipsizeMode="tail" numberOfLines={1}>
      {name}
    </StyledOptionText>
  </InterestTextWrapper>
)
interface IOptionProps {
  readonly interest: AutoSuggestInterest
  readonly onSelect: (interest: AutoSuggestInterest) => void
  readonly onRemove: (interest: AutoSuggestInterest) => void
  readonly isLoading: boolean
}

const AutosuggestOptionComponent: React.FC<IOptionProps> = ({
  interest,
  isLoading,
  onRemove,
  onSelect,
}) => {
  const timeout = React.useRef<ReturnType<typeof setTimeout> | null>(null)
  const isFirstRun = React.useRef(true)
  const [removed, setRemoved] = useState(false)

  useEffect(() => {
    timeout.current && clearTimeout(timeout.current)
  }, [])

  useEffect(() => {
    const removeRemovedMarked = () => {
      if (removed) {
        timeout.current = setTimeout(() => {
          setRemoved(false)
          timeout.current = null
        }, 1000)
      }
    }
    removeRemovedMarked()
  }, [removed])

  useEffect(() => {
    if (isFirstRun.current) {
      isFirstRun.current = false
    } else if (!interest.existing && !removed) {
      setRemoved(true)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [interest.existing])

  const selectInterest = (): void => {
    if (interest.existing) {
      onRemove(interest)
      setRemoved(true)
      return
    }
    onSelect(interest)
  }

  if (isLoading) {
    return renderLoadingItem()
  }

  const interestMatchCountDividedTo1000 = interest.match / 1000
  const interestMatchCount =
    interestMatchCountDividedTo1000 > 1
      ? `${roundNumberTo(interestMatchCountDividedTo1000)}k`
      : interest.match
  return (
    <StyledOptionView onPress={selectInterest}>
      <InterestWrapper hasAdded={interest.existing} removed={removed}>
        <InterestIcon
          imageUrl={interest?.avatar}
          name={interest.name}
          color={interest.color}
          size={30}
        />
        <InterestName name={interest.name} />
        <InterestMatches interestMatchCount={interestMatchCount} />
        {renderExistingMarker(interest.existing, removed)}
      </InterestWrapper>
    </StyledOptionView>
  )
}
export const AutosuggestOption = React.memo(AutosuggestOptionComponent)
