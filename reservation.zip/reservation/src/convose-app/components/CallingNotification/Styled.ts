import { Pressable, TouchableOpacity, View } from "react-native"
import styled from "styled-components"

import {
  CenteredText,
  color,
  font,
  ongoingCallHeight,
  Props,
} from "convose-styles"
import { isAndroid } from "../../../../settings"

export const ReceivingCallUIContainer = styled(View)`
  background: transparent;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  align-self: center;
  padding: 10px;
  opacity: ${(props: { pressEffect: boolean }) =>
    props.pressEffect ? 0.4 : 1};
`

export const ButtonWrapper = styled(TouchableOpacity)`
  width: 100%;
  height: ${ongoingCallHeight}px;
  background: ${(props: Props) => props.color || color.darkGreen};
  justify-content: center;
  align-items: center;
  flex-direction: row;
`

export const TextWrapper = styled(View)`
  overflow: visible;
  justify-content: center;
  align-items: center;
  flex-direction: row;
`

export const Label = styled(CenteredText)`
  font-family: ${font.medium};
  font-size: 15px;
  text-align: center;
  color: ${(props: Props) => props.color || color.white};
  include-font-padding: false;
`
export const GroupAcceptCallButton = styled(TouchableOpacity)`
  padding: 5px 10px;
  background-color: ${(props: Props) => props.theme.mainBlue};
  border-radius: 11px;
  overflow: hidden;
`
export const GroupAcceptCallButtonContainer = styled.View`
  height: ${(props: { height: number }) => props.height}px;
  flex-direction: row;
  justify-content: flex-start;
  align-items: center;
  /* padding-horizontal: 10px; */
`
export const GroupAcceptCallButtonText = styled(CenteredText)`
  color: ${color.white};
  font-family: ${font.semiBold};
  font-size: 14px;
  margin-left: 5px;
  margin-right: 5px;
`
export const GroupAvatarContainer = styled.View`
  flex-direction: row;
  justify-content: flex-start;
  align-items: center;
  height: 100%;
  width: ${(props: { width: number }) => props.width || 0}px;
`
export const TouchableWrapperNoFeedback = styled(Pressable)`
  flex-direction: row;
  justify-content: center;
  align-items: center;
  background-color: ${(props: Props & { transparentBackground: boolean }) => {
    if (props.transparentBackground) {
      return isAndroid
        ? props.theme.notificationChildren.androidTransparent
        : props.theme.notificationChildren.transparent
    }
    return props.theme.main.background
  }};
`
export const AvatarBackground = styled.View`
  background-color: ${(props: Props & { bgColor: string }) =>
    props.bgColor === undefined
      ? // ? props.theme.main.chatBoxBackground
        "transparent"
      : props.bgColor};
  width: ${(props: { size: number }) => props.size}px;
  height: ${(props: { size: number }) => props.size}px;
  justify-content: center;
  align-items: center;
  border-radius: 16px;
`
