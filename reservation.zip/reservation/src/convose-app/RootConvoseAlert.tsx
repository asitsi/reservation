import { ConvoseAlert } from "./components"
import { ModalAlert } from "./components/ModalAlert"

// eslint-disable-next-line import/no-mutable-exports
export let convoseAlertRef: ConvoseAlert | null = null

// eslint-disable-next-line import/no-mutable-exports
export let modalAlertRef: ModalAlert | null = null

export const createConvoseAlertRef = (ref: ConvoseAlert): void => {
  convoseAlertRef = ref
}

export const createModalAlertRef = (ref: ModalAlert): void => {
  modalAlertRef = ref
}
