import styled from "styled-components/native"

import { CenteredText, Props, font } from "convose-styles"
import { PrimaryButton } from "../PrimaryButton"

export const RatingLevelWrapper = styled.View`
  align-self: center;
  align-items: center;
  background-color: ${(props: Props) => props.theme.main.background};
  border-radius: 10px;
  height: auto;
  width: 100%;
`

export const TopTextViewWrapper = styled.View`
  margin-top: 14px;
  padding: 0px 10px;
  align-items: center;
`

export const TopTextWrapper = styled(CenteredText)`
  color: ${(props: Props) => props.theme.main.text};
  font-size: ${(props: Props) => (props.size ? props.size : 16)}px;
  font-family: ${font.semiBold};
  text-align: center;
`
export const StyledButton = styled(PrimaryButton)`
  align-self: center;
  margin-bottom: 30px;
  width: 200px;
`
export const IconNameContainer = styled.View`
  flex-direction: row;
  justify-content: center;
  align-items: center;
  /* align-self: center; */
`
export const NameContainer = styled.View`
  flex-direction: column;
  margin-bottom: 40px;
  justify-content: center;
  align-items: center;
  width: 100%;
`
export const IconContainer = styled.View`
  margin-right: 7px;
  /* flex: 1; */
`
export const InterestNameContainer = styled.View`
  /* flex: 1; */
  max-width: 90%;
`

export const InterestDetailContainer = styled.View`
  margin-top: 7px;
`
