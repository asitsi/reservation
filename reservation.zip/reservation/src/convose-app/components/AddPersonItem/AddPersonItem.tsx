import React from "react"
import { useSelector } from "react-redux"

import { ChatUser, UserStatus } from "convose-lib/chat"

import { selectIsDarkMode } from "convose-lib/app"
import { Avatar } from "../../components/Avatar"
import { PresenceIndicator } from "../../components/PresenceIndicator"
import {
  AvatarContainer,
  Body,
  ListItem,
  Section,
  TouchableWrapper,
  Username,
  ItemContainer,
  Separator,
  UsernameBG,
} from "./Styled"
import { CheckMark } from "./CheckMark"

type PropsType = {
  readonly user: ChatUser
  readonly handleTouch: (userId: string) => void
  readonly selected: boolean
  readonly listStyle?: boolean
}

const AddPersonItemComponent: React.FC<PropsType> = ({
  handleTouch,
  selected,
  user,
  listStyle,
}) => {
  const isDark = useSelector(selectIsDarkMode)
  if (!user) return null

  const renderSelection = () => {
    if (listStyle) {
      return null
    }
    return <CheckMark selected={selected} />
  }
  const getColor = () => {
    return isDark ? user.dark_background_color : user.background_theme_color
  }

  return (
    <ItemContainer>
      <ListItem pointerEvents="box-none">
        <TouchableWrapper onPress={() => handleTouch(user.uuid)}>
          <AvatarContainer>
            <PresenceIndicator
              isOnline={user.status === UserStatus.Online}
              offlineIndicatorColorCode="main.background"
              ringColorCode="main.background"
              location="chat"
            >
              <Avatar height={45} userAvatar={user?.avatar} />
            </PresenceIndicator>
          </AvatarContainer>
          <Body>
            <Section>
              <UsernameBG color={getColor()}>
                <Username>{user.username}</Username>
              </UsernameBG>
              {renderSelection()}
            </Section>
          </Body>
        </TouchableWrapper>
      </ListItem>
      <Separator />
    </ItemContainer>
  )
}

export const AddPersonItem = AddPersonItemComponent
