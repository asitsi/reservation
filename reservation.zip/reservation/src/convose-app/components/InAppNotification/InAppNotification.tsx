import React, { FC, PropsWithChildren, useEffect, useRef } from "react"
import {
  SlideInUp,
  SlideOutUp,
  useAnimatedStyle,
  useSharedValue,
  withSpring,
} from "react-native-reanimated"
import { useSafeAreaInsets } from "react-native-safe-area-context"
import {
  GestureEvent,
  PanGestureHandler,
  PanGestureHandlerEventPayload,
} from "react-native-gesture-handler"
// import { useSelector } from "react-redux"

import { defaultShadows } from "convose-styles"
// import { selectIsDarkMode } from "convose-lib/app"
import {
  InAppNotificationContainer,
  InAppNotificationView,
  ChildrenContainer,
  InAppNotificationViewContainer,
} from "./Styles"

type ContainerProps = {
  useBlur?: boolean
}
const BlurContainer: FC<PropsWithChildren<ContainerProps>> = ({
  useBlur,
  children,
}) => {
  // const isDarkMode = useSelector(selectIsDarkMode)
  if (useBlur) {
    return (
      <InAppNotificationViewContainer>
        <InAppNotificationView
          // blurType={isDarkMode ? "light" : "dark"}
          blurType="light"
          blurAmount={32}
          overlayColor="transparent"
          blurRadius={25}
        >
          {children}
        </InAppNotificationView>
      </InAppNotificationViewContainer>
    )
  }
  // eslint-disable-next-line react/jsx-no-useless-fragment
  return <>{children}</>
}

type InAppNotificationProps = {
  readonly onCloseNotification?: () => void
  readonly lockSwipe?: boolean
  readonly persistNotification?: boolean
  readonly hideDurationInMs?: number
  readonly noShadow?: boolean
  readonly useBlur?: boolean
  readonly flatShadow?: boolean
}

const duration = 200
// const HIDE_VALUE = -200
const SHOW_VALUE = 0
const InAppNotificationComponent: FC<
  PropsWithChildren<InAppNotificationProps>
> = ({
  children,
  hideDurationInMs,
  lockSwipe,
  onCloseNotification,
  persistNotification,
  noShadow,
  useBlur,
  flatShadow,
}) => {
  const insets = useSafeAreaInsets()

  const isDismissed = useRef(false)

  const offset = useSharedValue(SHOW_VALUE)

  const animatedStyles = useAnimatedStyle(() => {
    return {
      transform: [{ translateY: offset.value }],
    }
  })

  useEffect(() => {
    if (!persistNotification && hideDurationInMs) {
      const timer = setTimeout(() => {
        onCloseNotification && onCloseNotification()
      }, hideDurationInMs)
      return () => {
        clearTimeout(timer)
      }
    }
    return () => null
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const show = () => {
    offset.value = withSpring(SHOW_VALUE)
  }

  const onGestureEvent = (
    event: GestureEvent<PanGestureHandlerEventPayload>
  ) => {
    if (lockSwipe) {
      return
    }
    if (isDismissed.current) {
      return
    }
    if (event.nativeEvent.translationY > 20) {
      return
    }
    if (-event.nativeEvent.translationY > 10) {
      onCloseNotification && onCloseNotification()
      return
    }
    offset.value = withSpring(event.nativeEvent.translationY, {
      velocity: event.nativeEvent.velocityY,
    })
  }

  const onEnd = () => {
    if (!isDismissed.current) {
      show()
    } else {
      isDismissed.current = false
    }
  }

  const insetTop = insets?.top || 5
  const shadow = !noShadow && !flatShadow ? defaultShadows : {}
  return (
    <PanGestureHandler onGestureEvent={onGestureEvent} onEnded={onEnd}>
      <InAppNotificationContainer
        entering={SlideInUp.duration(duration)}
        exiting={SlideOutUp.duration(duration)}
        // eslint-disable-next-line react-perf/jsx-no-new-array-as-prop
        style={[
          {
            marginTop: insetTop,
            ...shadow,
          },
          animatedStyles,
        ]}
        flatShadow={flatShadow}
      >
        <BlurContainer useBlur={useBlur}>
          <ChildrenContainer>{children}</ChildrenContainer>
        </BlurContainer>
      </InAppNotificationContainer>
    </PanGestureHandler>
  )
}

export const InAppNotification = React.memo(InAppNotificationComponent)
