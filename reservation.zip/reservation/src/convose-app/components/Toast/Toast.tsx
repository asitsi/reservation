import React from "react"
import { SlideInUp, SlideOutUp, FadeIn, FadeOut } from "react-native-reanimated"
import { useSafeAreaInsets } from "react-native-safe-area-context"
import { useSelector } from "react-redux"

import { ToastProps } from "convose-lib/toast"
import { selectScreenOrientation } from "convose-lib/app/selector"
import { Message, StyledToast, ToastWrapper } from "./Styled"

export const Toast: React.FunctionComponent<ToastProps> = ({
  message,
  type,
  position = "top",
}) => {
  const { top } = useSafeAreaInsets()
  const screenOrientation = useSelector(selectScreenOrientation)
  if (typeof message !== "string") {
    return null
  }
  const entering = position === "middle" ? FadeIn : SlideInUp
  const exiting = position === "middle" ? FadeOut : SlideOutUp
  return (
    <ToastWrapper
      entering={entering}
      exiting={exiting}
      position={
        screenOrientation === "LANDSCAPE-LEFT" ||
        screenOrientation === "LANDSCAPE-RIGHT"
          ? "top"
          : position
      }
      insetTop={top || 10}
    >
      <StyledToast type={type}>
        <Message>{message}</Message>
      </StyledToast>
    </ToastWrapper>
  )
}
