import styled from "styled-components"
import { CenteredText, Props } from "convose-styles"

type NoImageIconProps = {
  size: number
  color?: string
}
export const NoImageIcon = styled.View`
  width: ${(props: NoImageIconProps) => props.size}px;
  height: ${(props: NoImageIconProps) => props.size}px;
  border-radius: ${(props: NoImageIconProps) => props.size / 2}px;
  background-color: ${(props: Props & NoImageIconProps) =>
    props.color || props.theme.mainBlue};
  justify-content: center;
  align-items: center;
`
export const NoImageIconText = styled(CenteredText)`
  color: white;
`
export const ImageIcon = styled.Image`
  width: ${(props: NoImageIconProps) => props.size}px;
  height: ${(props: NoImageIconProps) => props.size}px;
  border-radius: ${(props: NoImageIconProps) => props.size / 2}px;
  background-color: ${(props: Props & { isLoading: boolean }) =>
    props.isLoading ? props.theme.message.loadingMessage : "transparent"};
`
