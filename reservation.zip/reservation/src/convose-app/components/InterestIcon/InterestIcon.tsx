import React from "react"
import { ImageIcon, NoImageIcon, NoImageIconText } from "./Styles"

type Props = {
  name: string
  imageUrl: string | null
  size?: number
  color?: string
}
type LoadingImageProps = {
  size: number
  uri: string
}
const LoadingImage: React.FC<LoadingImageProps> = ({ size, uri }) => {
  const [isLoading, setLoading] = React.useState(true)
  const onLoadEnd = () => {
    setLoading(false)
  }
  return (
    <ImageIcon
      size={size}
      resizeMode="cover"
      // eslint-disable-next-line react-perf/jsx-no-new-object-as-prop
      source={{ uri }}
      isLoading={isLoading}
      onLoadEnd={onLoadEnd}
    />
  )
}

const InterestIconComponent: React.FC<Props> = ({
  imageUrl,
  name,
  size = 24,
  color,
}) => {
  if (imageUrl) {
    return <LoadingImage size={size} uri={imageUrl} />
  }
  const firstLetter = name[0] || ""
  return (
    <NoImageIcon size={size} color={color}>
      <NoImageIconText>{firstLetter.toUpperCase()}</NoImageIconText>
    </NoImageIcon>
  )
}

export const InterestIcon = React.memo(InterestIconComponent)
