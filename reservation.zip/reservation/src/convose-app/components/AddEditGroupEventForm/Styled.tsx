import { CenteredText, Props, color, font } from "convose-styles"
import { TextInput } from "react-native"
import Animated from "react-native-reanimated"
import styled, { css } from "styled-components/native"

export const FormContainer = styled(Animated.View)`
  width: 100%;
`
export const InputsContainer = styled.View`
  width: 100%;
  padding-bottom: 30px;
`
const fieldStyle = css`
  background-color: ${(props: Props) =>
    props.theme.interests.input.wrapperBackground};
  margin-bottom: 5px;
  border-radius: 11px;
  padding: 15px;
  border-width: 1px;
  border-color: transparent;
  ${(props: { isLast: boolean }) =>
    props.isLast
      ? `border-bottom-right-radius: 22px;
  border-bottom-left-radius: 22px;`
      : ""};
  ${(props: { isFirst: boolean }) =>
    props.isFirst
      ? `border-top-left-radius: 22px;
  border-top-right-radius: 22px;`
      : ""};
`
const fontStyle = css`
  font-family: ${font.normal};
  font-size: 15px;
  color: ${(props: Props) => props.theme.main.text};
`

const AnimatedTextInput = Animated.createAnimatedComponent(TextInput)
export const StyledInput = styled(AnimatedTextInput).attrs((props: Props) => ({
  placeholderTextColor: props.theme.textInput.placeholder,
}))`
  ${fieldStyle}
  ${fontStyle}
`
export const PressableField = styled.Pressable`
  ${fieldStyle}
  flex-direction: row;
  justify-content: space-between;
`
export const FieldTitle = styled(CenteredText)`
  ${fontStyle}
`
const animatedCenterText = Animated.createAnimatedComponent(CenteredText)
export const ErrorText = styled(animatedCenterText)`
  font-family: ${font.light};
  color: ${color.red};
  font-size: 12px;
  margin-bottom: 5px;
  margin-top: -5px;
  margin-left: 5px;
`
