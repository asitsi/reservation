import React from "react"
import { useSelector } from "react-redux"
import { useTheme } from "styled-components"

import { color } from "convose-styles"
import { selectIsDarkMode } from "convose-lib/app"
import { changeNavigationBarColor } from "convose-lib/utils"

type Props = {
  isVisible: boolean
}

const NavbarHandlerComponent: React.FC<Props> = ({ isVisible }) => {
  const isDarkMode = useSelector(selectIsDarkMode)
  const theme = useTheme()

  React.useEffect(() => {
    const handleIsShowing = (): void => {
      const navBarColor = theme.messageActions.background
      changeNavigationBarColor(navBarColor, !isDarkMode)
    }
    const handleIsHide = (): void => {
      const navBarColor = isDarkMode ? color.darkLevel1 : color.white
      changeNavigationBarColor(navBarColor, !isDarkMode)
    }
    if (isVisible) {
      handleIsShowing()
    } else {
      handleIsHide()
    }
    return () => {
      handleIsHide()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isVisible])
  return null
}

export const NavbarHandler = React.memo(NavbarHandlerComponent)
