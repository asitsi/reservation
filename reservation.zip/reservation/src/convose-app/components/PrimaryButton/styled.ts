import { TouchableOpacity } from "react-native"
import styled from "styled-components"

import { CenteredText, color, font, Props } from "convose-styles"
import { ButtonType } from "./types"

type ButtonProps = Props & { padding: number }
export const NormalButton = (props: ButtonProps): string => `
    background: ${props.color ? props.color : props.theme.mainBlue};
    min-width: 150px;
    padding: ${props.padding + 2}px;
`

export const OutlineButton = (props: Props): string => `
    background: transparent;
    min-width: 150px;
    borderWidth: 2px;
    borderColor: ${props.color ? props.color : props.theme.mainBlue};
`

export const TextButton = (): string => `
    background: transparent;
    padding: 0px;
`

const applyTypeStyle = (props: Props & { type: ButtonType } & ButtonProps) => {
  switch (props.type) {
    case ButtonType.normal:
      return NormalButton(props)
    case ButtonType.outline:
      return OutlineButton(props)
    case ButtonType.text:
      return TextButton()
    default:
      return NormalButton(props)
  }
}

export const ButtonArea = styled(TouchableOpacity)`
  border-radius: 50px;
  text-align: center;
  justify-content: center;
  padding: ${(props: ButtonProps) => props.padding}px;
  ${(props: Props) => props.height && `height: ${props.height}px;`};
  ${applyTypeStyle};
`

export const Label = styled(CenteredText)`
  font-family: ${(props: { fontFamily: string }) =>
    props.fontFamily ? props.fontFamily : font.semiBold};
  font-size: ${(props: Props) => (props.fontSize ? props.fontSize : 18)}px;
  text-align: center;
  color: ${(props: { isTextMainBlue: boolean } & Props) => {
    if (props.isTextMainBlue) {
      return props.theme.mainBlue
    }
    if (props.color) {
      return props.color
    }
    return color.white
  }};
`
