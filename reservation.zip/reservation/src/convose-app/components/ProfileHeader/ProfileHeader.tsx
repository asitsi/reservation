import React, { useCallback, useEffect, useState } from "react"
import { connect } from "react-redux"
import Animated, {
  FadeIn,
  FadeOut,
  runOnJS,
  useAnimatedStyle,
  useSharedValue,
  withDelay,
  withTiming,
} from "react-native-reanimated"
import { setAdjustResize, setAdjustNothing } from "rn-android-keyboard-adjust"

import { State } from "convose-lib/store"
import {
  selectUserFeature,
  User,
  UserAction,
  UserState,
} from "convose-lib/user"
import { chooseAvatar } from "convose-lib/utils"

import {
  AvatarWrapper,
  Header,
  LoadingSpinner,
  MaxCharAlertText,
  NameInputAndAlertContainer,
} from "./styled"
import { Avatar } from "../../components/Avatar"
import { UsernameInput } from "../../components/inputs/UsernameInput"

type StateToProps = {
  readonly user: UserState
}

type DispatchToProps = {
  readonly updateUser: (payload: Partial<User>) => void
  readonly updateAvatar: (payload: FormData) => void
}
declare global {
  interface IFormDataValue {
    uri: string
    name: string
    type: string
  }

  interface FormData {
    append(name: string, value: IFormDataValue, fileName?: string): void
    set(name: string, value: IFormDataValue, fileName?: string): void
  }
}

type ProfileHeaderProps = StateToProps & DispatchToProps
const MAX_VALID_NAME_CHAR_COUNT = 8
const ProfileHeaderComponent: React.FunctionComponent<ProfileHeaderProps> = ({
  user,
  updateUser,
  updateAvatar,
}) => {
  const opacityOffset = useSharedValue(0)

  const [username, setUsername] = useState("")
  const [showMaxCharAlert, setShowMaxCharAlert] = useState(false)

  useEffect(() => {
    setAdjustNothing()
    return () => {
      setAdjustResize()
    }
  }, [])
  useEffect(() => {
    setUsername(user.username)
  }, [user.username])

  const maxCharStyle = useAnimatedStyle(() => ({
    opacity: opacityOffset.value,
    position: "absolute",
    bottom: -15,
  }))

  const fadeOut = () => {
    opacityOffset.value = withDelay(
      3000,
      withTiming(0, { duration: 300 }, () => {
        runOnJS(setShowMaxCharAlert)(false)
      })
    )
  }
  const fadeIn = () => {
    opacityOffset.value = withTiming(1, { duration: 200 }, () => {
      runOnJS(fadeOut)()
    })
  }

  useEffect(() => {
    if (showMaxCharAlert) {
      fadeIn()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showMaxCharAlert])

  const changeUsername = useCallback(() => {
    const cleanUsername = username.trim().length ? username.trim() : "Guest"
    updateUser({
      username: cleanUsername,
    })
  }, [updateUser, username])

  const handOnChangeText = (val: string): void => {
    if (val.length > MAX_VALID_NAME_CHAR_COUNT) {
      setShowMaxCharAlert(true)
      return
    }
    setUsername(val)
  }

  const handleUpdateAvatar = useCallback(async () => {
    try {
      const file = await chooseAvatar()
      if (!file) {
        return
      }
      const data = new FormData()
      data.append("file", file)

      updateAvatar(data)
    } catch (error) {
      // console.log(error)
    }
  }, [updateAvatar])

  return (
    <Header entering={FadeIn} exiting={FadeOut}>
      <AvatarWrapper onPress={handleUpdateAvatar}>
        {user.updating_avatar ? (
          <LoadingSpinner />
        ) : (
          <Avatar userAvatar={user?.avatar} height={70} />
        )}
      </AvatarWrapper>
      <NameInputAndAlertContainer>
        <UsernameInput
          value={username}
          onChangeText={handOnChangeText}
          onBlur={changeUsername}
          onSubmitEditing={changeUsername}
          color={user.theme_color}
          allowFontScaling
          numberOfLines={1}
          multiline={false}
          textAlign="left"
        />
        <Animated.View style={maxCharStyle}>
          <MaxCharAlertText>
            Maximum {MAX_VALID_NAME_CHAR_COUNT} characters
          </MaxCharAlertText>
        </Animated.View>
      </NameInputAndAlertContainer>
    </Header>
  )
}

const mapStateToProps = (state: State): StateToProps => ({
  user: selectUserFeature(state),
})

const mapDispatchToProps: DispatchToProps = {
  updateAvatar: UserAction.updateAvatar,
  updateUser: UserAction.updateUser,
}
// ProfileHeaderComponent.whyDidYouRender = {
//   logOnDifferentValues: false,
//   customName: "ProfileHeaderComponent",
//   diffNameColor: "red",
// }
export const ProfileHeader = React.memo(
  connect(mapStateToProps, mapDispatchToProps)(ProfileHeaderComponent)
)
