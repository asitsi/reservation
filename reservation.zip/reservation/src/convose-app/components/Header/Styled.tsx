import { TouchableOpacity, View, TouchableHighlight } from "react-native"
import styled from "styled-components/native"
import Animated from "react-native-reanimated"

import { CenteredText, color, font, Props } from "convose-styles"
import MaterialCommunityIcons from "react-native-vector-icons/MaterialCommunityIcons"

export const AppHeader = styled(Animated.View)`
  align-items: center;
  flex-direction: column;
  flex-wrap: nowrap;
  width: 100%;
  background-color: ${(props: Props) =>
    props.color ? props.color : props.theme.header};
  overflow: visible;
  ${(props: { sticky: boolean }) =>
    props.sticky
      ? "position: absolute; z-index: 101; elevation:1001; top: 0px"
      : ""};
`

export const ReturnToCallWrapper = styled(View)`
  flex-direction: column;
  align-items: center;
  justify-content: center;
`

export const AppHeaderContentWrapper = styled(View)`
  padding: ${(props: { paddingTop: boolean }) =>
      props.paddingTop ? props.paddingTop : 0}px
    0px 0px 0px;
  flex-direction: row;
  align-items: center;
  flex-wrap: nowrap;
  height: 60px;
`

export const AppHeaderContent = styled(View)`
  flex-direction: row;
  justify-content: ${(props: { withAvatar: boolean }) =>
    props.withAvatar ? "flex-start" : "center"};
  padding: 5px 0px;
  flex: 1;
  margin: 5px 5px;
  overflow: hidden;
  align-items: center;
`
export const AvatarContainer = styled.View`
  align-items: flex-start;
  justify-content: center;
  margin-right: 5px;
  margin-bottom: 2px;
`
export const RightActionsContainer = styled.View`
  min-width: 60px;
  flex-direction: row;
`
export const TextWrapper = styled(TouchableOpacity)`
  flex-direction: column;
  align-items: center;
  /* justify-content: center; */
  flex: 1;
  align-items: ${(props: { withAvatar: boolean }) =>
    props.withAvatar ? "flex-start" : "center"};
  height: 100%;
`

export const HeaderTextContainer = styled.View`
  flex-direction: row;
`

export const HeaderText = styled(CenteredText)`
  font-family: ${font.semiBold};
  font-size: 20px;
  text-align: ${(props: { withAvatar: boolean }) =>
    props.withAvatar ? "left" : "center"};
  color: ${(props: Props) =>
    props.color && props.color !== "SystemDefault"
      ? props.color
      : props.theme.main.text};
  max-width: 100%;
  text-transform: capitalize;
  padding-left: 1px;
`

export const Subtext = styled(CenteredText)`
  font-family: ${font.light};
  color: ${(props: Props) =>
    props.color && props.color !== "SystemDefault" ? props.color : color.dark};
  font-size: 9px;
  position: absolute;
  bottom: -9px;
`
export const CallText = styled(CenteredText)`
  font-family: ${font.semiBold};
  color: ${color.white};
  font-size: 16px;
  left: 2px;
`

export const ButtonWrapperBase = styled(TouchableHighlight)`
  align-items: center;
  justify-content: center;
  border-radius: 50px;
  flex-direction: row;
  width: ${(props: Props) => (props.width ? props.width : 40)}px;
  height: ${(props: Props) => (props.height ? props.height : 40)}px;
`
export const ButtonWrapper = styled(ButtonWrapperBase)`
  background-color: ${(props: Props) =>
    props.color ? props.color : color.transparent};
`
export const BlueButtonWrapper = styled(ButtonWrapperBase)`
  background-color: ${(props: Props) => props.theme.mainBlue};
`

export const StyledMaterialCommunityIcons = styled(MaterialCommunityIcons)`
  color: ${(props: Props) =>
    props.color && props.color !== "SystemDefault"
      ? props.color
      : props.theme.main.text};
  margin-right: 5px;
`
export const TotalUsersInCall = styled(CenteredText)`
  font-family: ${font.normal};
  font-size: 18px;
  text-align: ${(props: { withAvatar: boolean }) =>
    props.withAvatar ? "left" : "center"};
  color: ${(props: Props) =>
    props.color && props.color !== "SystemDefault"
      ? props.color
      : props.theme.main.text};
`
export const CloseButton = styled.TouchableOpacity``
export const CloseButtonText = styled(CenteredText)`
  padding-left: 15px;
  padding-right: 5px;
  font-family: ${font.semiBold};
  color: ${(props: Props) => props.theme.mainBlue};
  font-size: 15px;
`
export const CallLoadingContainer = styled.View`
  width: 45px;
`
