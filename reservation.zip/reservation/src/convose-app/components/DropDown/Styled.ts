import styled from "styled-components/native"
import Ionicons from "react-native-vector-icons/Ionicons"
import Animated from "react-native-reanimated"

import { CenteredText, Props, font } from "convose-styles"

export const DropDownContainer = styled.View``

export const DropDownTitleContainer = styled.View`
  flex-direction: row;
  align-items: center;
  justify-content: center;
  align-self: center;
`

export const BlueIonicons = styled(Ionicons)`
  color: ${(props: Props) => props.theme.mainBlue};
  margin-left: 1px;
  padding-top: 2px;
`

type DropDownTextProps = {
  title?: boolean
  selected?: boolean
}
export const DropDownText = styled(CenteredText)`
  font-family: ${font.normal};
  font-size: 15px;
  color: ${(props: Props & DropDownTextProps) => {
    if (props.title) {
      return props.theme.mainBlue
    }
    if (props.selected) {
      return props.theme.main.textReverse
    }
    return props.theme.main.text
  }};
`
export const ItemsContainer = styled(Animated.View)`
  position: absolute;
  top: 0px;
  z-index: 1000;
  background-color: ${(props: Props) => props.theme.main.background};
  min-width: 180px;
  right: 0px;
  border-radius: 10px;
  overflow: hidden;
`

export const DropDownItemContainer = styled.View`
  flex-direction: row;
  align-items: center;
  justify-content: center;
  align-self: center;
  background-color: ${(props: Props & { selected: boolean }) =>
    props.selected ? props.theme.mainBlue : "transparent"};
  width: 100%;
  padding-top: 7px;
  padding-bottom: 7px;
`
