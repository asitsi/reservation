import { resolveObjectPath } from "convose-lib/utils"
import { Props } from "convose-styles"
import { TouchableOpacity } from "react-native"
import styled from "styled-components/native"

const CircleButtonBase = styled(TouchableOpacity)`
  border-radius: 50px;
  aspect-ratio: 1;
  height: ${(props: Props) => (props.size ? props.size : 50)}px;
  width: ${(props: Props) => (props.size ? props.size : 50)}px;
  justify-content: center;
  align-items: center;
  margin: ${(props: Props) => (props.margin ? props.margin : 4)}px;
`
export const CircleButton = styled(CircleButtonBase)`
  background: ${(props: Props & { backgroundColorCode: string }) => {
    if (props.backgroundColorCode) {
      return resolveObjectPath(props.backgroundColorCode, props.theme)
    }
    return props.backgroundColor ? props.backgroundColor : "rgba(0, 0 ,0 ,0.2)"
  }};
`
export const BlueCircleButton = styled(CircleButtonBase)`
  background-color: ${(props: Props) => props.theme.mainBlue};
`
