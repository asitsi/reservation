/* eslint-disable react-hooks/exhaustive-deps */
import React from "react"
import { Platform } from "react-native"
import { shallowEqual, useDispatch, useSelector } from "react-redux"

import { openUrl } from "convose-lib/utils/openUrl"
import { AppAction, selectAppVersion } from "convose-lib/app"
import { versionCode } from "../../../../settings"
import { convoseAlertRef } from "../../RootConvoseAlert"

const installedAppVersion = versionCode
const APP_STORE_LINK_ID = 1211836516
const PACKAGE_NAME = "com.convose.convose"
const APP_STORE_LINK = `itms-apps://itunes.apple.com/us/app/id${APP_STORE_LINK_ID}?mt=8`
const PLAY_STORE_LINK = `http://play.google.com/store/apps/details?id=${PACKAGE_NAME}`
const link = Platform.OS === "android" ? PLAY_STORE_LINK : APP_STORE_LINK

const AppVersionControlComponent: React.FC = () => {
  const dispatch = useDispatch()
  const { currentVersion, minAllowedVersion } = useSelector(
    selectAppVersion,
    shallowEqual
  )
  const getAppVersion = React.useCallback(() => {
    dispatch(AppAction.requestAppVersion())
  }, [dispatch])

  React.useEffect(() => {
    getAppVersion()
    const onUpdatePress = () => {
      openUrl(link)
    }
    if (currentVersion && minAllowedVersion && installedAppVersion) {
      if (installedAppVersion < minAllowedVersion) {
        convoseAlertRef?.show({
          canDismiss: false,
          title: "Convose has new updates",
          ioniconName: "sync",
          buttons: [
            {
              title: "Update",
              onPress: onUpdatePress,
              keepAlertOpenAfterPress: true,
            },
          ],
        })
        return
      }
      if (installedAppVersion < currentVersion) {
        convoseAlertRef?.show({
          canDismiss: true,
          title: "Convose has new updates",
          ioniconName: "sync",
          buttons: [
            {
              title: "Update",
              onPress: onUpdatePress,
            },
            {
              title: "Not now",
              type: "cancel",
            },
          ],
        })
      }
    }
  }, [currentVersion])
  return null
}
export const AppVersionControl = React.memo(AppVersionControlComponent)
