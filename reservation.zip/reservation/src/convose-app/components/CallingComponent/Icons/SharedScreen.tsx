import React from "react"
import { ThemeContext } from "styled-components"

import { color } from "convose-styles"
import { SharedScreenSvg } from "../../../../assets/svg/call"

type Props = {
  isEnable?: boolean
  size?: number
}
const SharedScreenIconComponent: React.FC<Props> = ({
  isEnable = true,
  size = 25,
}) => {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const theme = React.useContext<any>(ThemeContext)
  const iconColor = isEnable ? color.white : theme.calling.notActive
  return <SharedScreenSvg color={iconColor} height={size} />
}

export const SharedScreenIcon = React.memo(SharedScreenIconComponent)
