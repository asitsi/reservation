import React from "react"
import { ThemeContext } from "styled-components"

import { color } from "convose-styles"
import { VideoSvg, VideoOffSvg } from "../../../../assets/svg/call"

type Props = {
  isEnable?: boolean
  size?: number
  isLandscape?: boolean
}
const VideoIconComponent: React.FC<Props> = ({
  isEnable = true,
  size = 25,
  isLandscape,
}) => {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const theme = React.useContext<any>(ThemeContext)
  const iconColor = React.useMemo(() => {
    if (isEnable) {
      return color.white
    }
    if (isLandscape) {
      return theme.calling.active
    }
    return theme.calling.notActive
  }, [isEnable, isLandscape, theme.calling.active, theme.calling.notActive])
  if (isEnable) {
    return <VideoSvg height={size} color={iconColor} />
  }
  return <VideoOffSvg height={size} color={iconColor} />
}

export const VideoIcon = React.memo(VideoIconComponent)
