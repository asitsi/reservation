import styled from "styled-components/native"

import { Props } from "convose-styles"

export const InterestComponentWrapper = styled.View`
  background-color: ${(props: Props) => props.theme.statusBar};
  height: 100%;
  width: 100%;
`
export const LoadingSpinnerContainer = styled.View`
  position: absolute;
  padding: 6px;
  background-color: ${(props: Props) => props.theme.main.background};
  border-radius: 50px;
  z-index: 10000000;
  top: ${(props: { insetTop: number }) => props.insetTop + 55}px;
  align-self: center;
`
