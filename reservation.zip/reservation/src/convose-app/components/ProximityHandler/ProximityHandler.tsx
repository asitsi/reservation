import React, { useEffect, useRef } from "react"
import {
  useProximity,
  useNavbarStatusWithPrevious,
} from "../../../convose-lib/utils"
import { BlackScreen } from "./Styled"

type Props = {
  isSpeakerOn: boolean
  isInCallingChat: boolean
  isInVideoMode: boolean
  startEngine?: boolean
  onProximityDetected?: () => void
  onProximityReleased?: () => void
}
const ProximityHandlerComponent: React.FC<Props> = ({
  isInCallingChat,
  isInVideoMode,
  isSpeakerOn,
  startEngine,
  onProximityDetected,
  onProximityReleased,
}) => {
  const { hasProximity, startListeningToProximity, stopListeningToProximity } =
    useProximity(startEngine)
  const { setNewNavbarStatusColor, setPreviousNavbarStatusColor } =
    useNavbarStatusWithPrevious()
  const hasProximityStarted = useRef(false)

  useEffect(() => {
    if (isInCallingChat && !isInVideoMode && !isSpeakerOn) {
      startListeningToProximity()
      hasProximityStarted.current = true
    } else {
      stopListeningToProximity()
      hasProximityStarted.current = false
    }
    return () => {
      stopListeningToProximity()
      hasProximityStarted.current = false
    }
  }, [
    isInCallingChat,
    isInVideoMode,
    isSpeakerOn,
    startListeningToProximity,
    stopListeningToProximity,
  ])

  useEffect(() => {
    if (hasProximity) {
      setNewNavbarStatusColor({ color: "black", style: "light" })
    } else if (hasProximityStarted.current) {
      setPreviousNavbarStatusColor()
    }
  }, [hasProximity, setNewNavbarStatusColor, setPreviousNavbarStatusColor])

  useEffect(() => {
    if (hasProximity) {
      onProximityDetected && onProximityDetected()
    } else {
      onProximityReleased && onProximityReleased()
    }
  }, [hasProximity, onProximityDetected, onProximityReleased])

  if (hasProximity) {
    return <BlackScreen />
  }
  return null
}

export const ProximityHandler = React.memo(ProximityHandlerComponent)
