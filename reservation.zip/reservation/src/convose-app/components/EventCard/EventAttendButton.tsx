import React, { useCallback, useEffect, useState } from "react"
import { SequencedTransition } from "react-native-reanimated"
import { useTheme } from "styled-components"

import { HandSvg } from "../../../assets/svg/call"
import {
  AttendButtonContainer,
  AttendButtonTitle,
  AttendingButtonLoadingContainer,
  Touchable,
} from "./Styled"
import { BlueMaterialIndicator } from "../MaterialIndicator"

const layout = SequencedTransition.duration(400)

type BlueHandProps = {
  useMainTextColor?: boolean
}
const BlueHand: React.FC<BlueHandProps> = ({ useMainTextColor }) => {
  const theme = useTheme()
  const color = useMainTextColor ? theme.main.text : theme.mainBlue
  return <HandSvg color={color} height={17} />
}
type AttendButtonProps = {
  onPress: () => void
  isAttending: boolean
  useMainTextColor?: boolean
}

const EventAttendButtonComponent: React.FC<AttendButtonProps> = ({
  isAttending,
  onPress,
  useMainTextColor,
}) => {
  const [isLoading, setLoading] = useState(false)

  const handleOnPress = useCallback(() => {
    setLoading(true)
    onPress()
  }, [onPress])
  useEffect(() => {
    setLoading(false)
  }, [isAttending])

  const renderContent = () => {
    if (isLoading) {
      return (
        <AttendingButtonLoadingContainer>
          <BlueMaterialIndicator
            useMainTextColor={useMainTextColor}
            size={19}
          />
        </AttendingButtonLoadingContainer>
      )
    }
    return (
      <>
        {!isAttending && <BlueHand useMainTextColor={useMainTextColor} />}
        <AttendButtonTitle
          numberOfLines={1}
          useMainTextColor={useMainTextColor}
        >
          {`Attend${isAttending ? "ing" : ""}`}
        </AttendButtonTitle>
      </>
    )
  }
  return (
    <Touchable onPress={handleOnPress}>
      <AttendButtonContainer
        layout={layout}
        useMainTextColor={useMainTextColor}
      >
        {renderContent()}
      </AttendButtonContainer>
    </Touchable>
  )
}

export const EventAttendButton = React.memo(EventAttendButtonComponent)
