import React from "react"
import { Svg, Path } from "react-native-svg"
import { SvgProps } from "./types"
import { getRatio, getWidth } from "./utils"

const defaultHeight = 23
const defaultWidth = 20
const ratio = getRatio(defaultHeight, defaultWidth)

const Privacy: React.FC<SvgProps> = ({ height, color }) => {
  const svgHeight = height || defaultHeight
  const svgWidth = height ? getWidth(ratio, height) : defaultWidth
  return (
    <Svg width={svgWidth} height={svgHeight} viewBox="0 0 20 23" fill="none">
      <Path
        d="M9.8 10.64C8.96 10.64 8.4 11.2 8.4 12.04C8.4 12.6 8.82 13.02 9.24 13.16L8.82 15.12H10.64L10.22 13.16C10.78 13.02 11.06 12.6 11.06 12.04C11.2 11.2 10.64 10.64 9.8 10.64ZM9.94 4.62C8.96 4.62 7.98 5.32 7.98 6.3V8.4H11.76V6.3C11.62 5.32 10.92 4.62 9.94 4.62ZM9.8 0L0 4.2V8.4C0.14 14.56 4.06 20.02 9.8 22.26C15.54 20.02 19.46 14.56 19.6 8.4V4.2L9.8 0ZM15.4 15.4C15.4 16.24 14.84 16.8 14 16.8H5.6C4.76 16.8 4.2 16.24 4.2 15.4V9.8C4.2 8.96 4.76 8.4 5.6 8.4H6.02V6.3C6.16 4.34 7.84 2.8 9.8 2.8C11.76 2.8 13.44 4.34 13.58 6.3V8.4H14C14.84 8.4 15.4 8.96 15.4 9.8V15.4Z"
        fill={color || "black"}
      />
    </Svg>
  )
}

export const PrivacySvg = React.memo(Privacy)
