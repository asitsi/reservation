import { Pressable } from "react-native"
import styled from "styled-components/native"
import Animated from "react-native-reanimated"
import { CenteredAnimatedText, CenteredText, Props, font } from "convose-styles"

const AnimatedPressable = Animated.createAnimatedComponent(Pressable)

export const StyledPressable = styled(AnimatedPressable)`
  flex-direction: row;
  align-items: center;
  background-color: ${(props: Props) => props.theme.mainBlue};
  border-radius: ${(props: { size: number }) => props.size}px;
  overflow: hidden;
`
export const WaveTitle = styled(CenteredText)`
  font-family: ${font.bold};
  color: white;
  margin-right: 14px;
  font-size: 16px;
`
export const WaveContainer = styled(Animated.View)`
  background-color: ${(props: Props) => props.theme.mainBlue};
  height: ${(props: { size: number }) => props.size}px;
  border-radius: ${(props: { size: number }) => props.size}px;
  aspect-ratio: 1;
  justify-content: center;
  align-items: center;
  flex-direction: row;
`
export const WaveText = styled(CenteredAnimatedText)`
  position: absolute;
  color: ${(props: Props) => props.theme.mainBlue};
  text-align: center;
  font-family: ${font.bold};
  font-size: 35px;
`
export const Container = styled.View`
  justify-content: center;
`
