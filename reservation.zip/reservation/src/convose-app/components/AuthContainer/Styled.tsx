import styled from "styled-components/native"
import Animated from "react-native-reanimated"
import { TouchableWithoutFeedback } from "react-native"

import { CenteredText, color, font, Props } from "convose-styles"

export const FormContainer = styled(Animated.View)``
export const StyledTouchableWithoutFeedback = styled(TouchableWithoutFeedback)`
  background-color: ${(props: Props) => props.theme.main.background};
  height: 100%;
`
export const Container = styled(Animated.View)`
  background-color: ${(props: Props) => props.theme.main.background};
  height: 100%;
  justify-content: center;
  z-index: 10;
`
export const HeaderContainer = styled.View`
  width: 100%;
  position: absolute;
  top: 0px;
  left: 0px;
  right: 0px;
`
export const SocialsLabel = styled(CenteredText)`
  font-family: ${font.normal};
  font-size: 14px;
  align-items: center;
  color: ${color.darkGray};
  margin-bottom: 20px;
  align-self: center;
`
