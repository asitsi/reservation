import { MaterialIndicator } from "react-native-indicators"
import { TouchableOpacity } from "react-native"
import styled from "styled-components/native"

import { InterestLocation } from "convose-lib/interests"
import { CenteredText, font, Props } from "convose-styles"
import { resolveObjectPath } from "convose-lib/utils"
import { CloseIcon } from "../../../assets/Icons/components/CloseIcon"

export type ButtonWrapperProps = {
  readonly location?: InterestLocation
  readonly useSemiBoldFont?: boolean
}

export const DEFAULT_INTEREST_SIZE = 10

// INTEREST BUTTON
type ButtonWrapperViewProps = Props & {
  disabled: boolean
  addBorder: boolean
  transparentBackground: boolean
  backgroundColorCode?: string
}
export const ButtonWrapperView = styled(TouchableOpacity)`
  align-self: flex-start;
  align-items: center;
  background: ${(props: ButtonWrapperViewProps) => {
    if (props.backgroundColorCode) {
      return resolveObjectPath(props.backgroundColorCode, props.theme)
    }
    if (props.disabled) {
      // return props.theme.interests.button.disabledBackground
      return "transparent"
    }
    if (props.transparentBackground) {
      return "transparent"
    }
    return props.theme.interests.button.background
  }};
  border-radius: 50px;
  flex-direction: row;
  justify-content: space-around;
  margin: 5px;
  max-width: 95%;
  padding: ${(props: Props) =>
    props.size ? props.size / 2 : DEFAULT_INTEREST_SIZE / 2}px;
  ${(props: ButtonWrapperViewProps) =>
    props.addBorder &&
    `border-width: 1px;
  border-color: ${props.theme.secondaryBlue};`}
`
type LabelProps = Props & {
  location: InterestLocation
  hasRating: boolean
}
// export const Label = styled.Text`
export const Label = styled(CenteredText)`
  color: ${(props: LabelProps) =>
    props.location === InterestLocation.MyInterests
      ? props.theme.interests.button.text
      : props.theme.main.text};
  flex: 0 1 auto;
  font-size: ${(props: ButtonWrapperProps) =>
    props.location === InterestLocation.MyInterests ? "16px" : "12px"};
  text-shadow: none;
  font-family: ${(props: ButtonWrapperProps) => {
    if (props.location === InterestLocation.CallingScreen) {
      return font.normal
    }
    if (props.useSemiBoldFont) {
      return font.semiBold
    }
    return font.light
  }};
  ${(props: LabelProps) => {
    if (!props.hasRating) {
      return ``
    }
    if (props.location === InterestLocation.MyInterests) {
      return `margin-top: -5.3px`
    }
    return `margin-top: -4px`
  }};
`

export const IconButton = styled(TouchableOpacity)`
  margin-right: ${(props: Props) =>
    (props.size ? props.size : DEFAULT_INTEREST_SIZE) / 2}px;
  align-self: center;
  justify-content: center;
  align-items: center;
`
export const WheelIconButton = styled(IconButton)`
  margin: 0px;
`
export const LoadingSpinner = styled(MaterialIndicator)`
  margin: 0px 13px 0px 13px;
  flex: none;
`

export const LevelRatingContainer = styled.View`
  flex-direction: row;
  margin-top: 1px;
  margin-left: 1.2px;
`
export const LevelRating = styled.View`
  width: ${(props: LabelProps) =>
    props.location === InterestLocation.MyInterests ? 8 : 6}px;
  height: ${(props: LabelProps) =>
    props.location === InterestLocation.MyInterests ? 8 : 6}px;
  background-color: ${(props: LabelProps) =>
    props.location === InterestLocation.MyInterests
      ? props.theme.interests.button.text
      : props.theme.main.text};
  border-radius: 10px;
  margin-right: 2px;
`
export const LabelLevelContainer = styled.View`
  height: ${(props: LabelProps) =>
    props.location === InterestLocation.MyInterests ? 35 : 27}px;
  justify-content: center;
  padding-left: ${(props: ButtonWrapperProps) =>
    props.useSemiBoldFont ? "8px;" : "5px"};
`
export const DeleteButtonContainer = styled.View`
  padding-right: 1px;
  padding-left: 8px;
`
export const IconWrapper = styled.View``

export const EmptyContainer = styled.View`
  height: ${(props: { size?: number }) =>
    (props.size || DEFAULT_INTEREST_SIZE) * 2}px;
  aspect-ratio: 1;
`
export const SecondaryBlueCloseIcon = styled(CloseIcon).attrs(
  (props: Props) => ({
    color: props.theme.secondaryBlue,
  })
)``
