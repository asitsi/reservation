import Animated from "react-native-reanimated"
import styled from "styled-components/native"

export const StyledImage = styled(Animated.Image)`
  width: 126px;
  height: 126px;
  align-self: center;
`
export const EmptyImage = styled.View`
  width: 126px;
  height: 126px;
  align-self: center;
`
