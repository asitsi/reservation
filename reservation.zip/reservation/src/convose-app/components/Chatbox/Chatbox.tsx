/* eslint-disable camelcase, complexity */
import React, { useState } from "react"
import { ViewStyle } from "react-native"
import { connect } from "react-redux"
import _ from "lodash"
import Animated, { ZoomIn, ZoomOut } from "react-native-reanimated"

import { State } from "convose-lib/store"
import {
  ChatUser,
  createChatChannelId,
  getParticipantsInCall,
  GroupInfo,
  selectGroupCallInfo,
  UserStatus,
} from "convose-lib/chat"
import { InterestLocation, UserInterest } from "convose-lib/interests"
import { Routes } from "convose-lib/router"
import { selectMyUuid, Uuid } from "convose-lib/user"
import { AVATAR_SIZE } from "convose-styles"
import { selectIsDarkMode } from "convose-lib/app"
import { CallingAction } from "convose-lib/calling"
import { SuggestedProfile } from "convose-lib/users-list/dto"

import { Avatar, GroupAvatar } from "../../components/Avatar"
import { InterestButton } from "../../components/InterestButton"
import { PresenceIndicator } from "../../components/PresenceIndicator"
import * as RootNavigation from "../../RootNavigation"
import {
  CallButtonWrapper,
  ChatboxAvatar,
  ChatboxInterests,
  ChatboxHeader,
  ChatboxHeaderText,
  ChatboxWrapper,
  HeaderTextWrapper,
  JoinCallText,
  JoinCallContainer,
  HeaderColorBox,
  ChatboxBody,
  GroupJoinButtonContainer,
  WaveContainer,
} from "./Styled"
import MainScreenCallIcon from "../../../assets/Icons/components/MainScreenCallIcon"
import { UpcomingEvent } from "./UpcomingEvent/UpcomingEvent"
import { UsersInCall } from "./UsersInCall"
import { useWaveButton, WaveButton } from "../WaveButton"
import { WaveGradientContainer } from "./WaveGradientContainer"

type ChatboxProps = {
  readonly user: SuggestedProfile
  readonly style?: ViewStyle
}
type StateToProps = {
  readonly groupInfo: GroupInfo
  readonly isDarkMode: boolean | null
  readonly myUuid: Uuid
}
type DispatchToProps = {
  joinQuickCall: (chatChannel: string) => void
}

type AllProps = ChatboxProps & StateToProps & DispatchToProps

const interestStyle = {
  marginLeft: 0,
  marginTop: 0,
  marginRight: 5,
  marginBottom: 5,
}

const mappedInterests = (
  interests: readonly UserInterest[]
): React.ReactNode => {
  const interestsToRender = _.unionBy(interests.slice(0, 10), "name")
  return interestsToRender.map((interest: UserInterest) => (
    <Animated.View
      key={interest.id || interest.name}
      entering={ZoomIn.duration(100)}
      exiting={ZoomOut.duration(100)}
    >
      <InterestButton
        disabled
        interest={interest}
        key={interest.name}
        interestLocation={InterestLocation.Chatbox}
        wrapperStyle={interestStyle}
        useSemiBoldFont
      />
    </Animated.View>
  ))
}
type WaveProps = {
  chatChannel: string
}
const Wave: React.FC<WaveProps> = ({ chatChannel }) => {
  const [showing, setShowing] = useState(true)
  const { onPress, canWave } = useWaveButton(chatChannel)
  const onHide = () => {
    setShowing(false)
  }
  return (
    <WaveContainer>
      <WaveGradientContainer size={showing ? 70 : 0}>
        <WaveButton
          onPress={onPress}
          size={38}
          onDisappeared={onHide}
          disable={!canWave}
          fireOnPressOnDisabled
        />
      </WaveGradientContainer>
    </WaveContainer>
  )
}

const COUNT_OF_GROUP_CALL_AVATARS_TO_SHOW = 2
export class ChatboxComponent extends React.Component<AllProps> {
  public shouldComponentUpdate(prevProps: AllProps): boolean {
    return !_.isEqual(this.props, prevProps)
  }

  public getParticipantsInThisCall = (): ChatUser[] => {
    const {
      groupInfo,
      user: { call_users: callUsers },
    } = this.props
    return getParticipantsInCall(groupInfo, callUsers)
  }

  public isGroupCall = () => {
    const { user } = this.props
    const { type } = user
    return type === "group_call"
  }

  public isSeekCall = () => {
    const { user } = this.props
    const { quick_call_status: quickCallStatus } = user
    return quickCallStatus ? quickCallStatus.active : false
    // TODO handle type
  }

  public isEventSuggestion = () => {
    const { user } = this.props
    const { type, upcoming_event } = user
    return type === "event" || !!upcoming_event
  }

  public isOngoingEvent = () => {
    const { user } = this.props
    const { type, ongoing_event } = user
    return type === "group_call" && !!ongoing_event
  }

  public getOneOnOneChatChannel = () => {
    const { myUuid, user } = this.props
    const { uuid } = user
    return createChatChannelId(myUuid, uuid)
  }

  private readonly startConversation =
    (forRejoinCall?: boolean) => (): void => {
      const { user } = this.props
      const { uuid } = user
      const channel =
        this.isGroupCall() || this.isEventSuggestion() || this.isOngoingEvent()
          ? uuid
          : this.getOneOnOneChatChannel()

      RootNavigation.navigate(Routes.Chat, {
        channel,
        chatUser: user,
        forRejoinCall,
      })
    }

  private joinQuickCall = () => {
    const { user, joinQuickCall } = this.props
    const channel = user.quick_call_status?.channel
    if (channel) {
      joinQuickCall(channel)
    }
  }

  renderJoinButton = (isGroup: boolean): React.ReactNode => {
    return (
      <CallButtonWrapper
        onPress={isGroup ? this.startConversation(true) : this.joinQuickCall}
      >
        <MainScreenCallIcon height={20} />
        <JoinCallText>Join</JoinCallText>
      </CallButtonWrapper>
    )
  }

  renderJoinCallButton = (isGroup: boolean): React.ReactNode => {
    const participantsInCall = this.getParticipantsInThisCall()
    if (isGroup && participantsInCall.length < 1) {
      return null
    }
    const uniqueParticipantsInCall = _.uniqBy(participantsInCall, "uuid")
    return (
      <JoinCallContainer>
        <UsersInCall
          isGroup={isGroup}
          avatarCountToShow={COUNT_OF_GROUP_CALL_AVATARS_TO_SHOW}
          participants={uniqueParticipantsInCall}
          avatarBgColorCode="main.chatBoxBackground"
          showRing
          ringColorCode="main.chatBoxBackground"
        />
        <GroupJoinButtonContainer>
          {this.renderJoinButton(isGroup)}
        </GroupJoinButtonContainer>
      </JoinCallContainer>
    )
  }

  public getBackgroundColorOfUser = (bgColor: string, darkBgColor: string) => {
    const { isDarkMode } = this.props
    if (isDarkMode) {
      return darkBgColor
    }
    return bgColor
  }

  public getBackgroundColor = (isGroup: boolean) => {
    if (isGroup) {
      return undefined
    }
    const { user } = this.props
    const { background_theme_color, dark_background_color } = user
    return this.getBackgroundColorOfUser(
      background_theme_color,
      dark_background_color
    )
  }

  public renderEvents = (
    isOngoingGroupEventCall: boolean,
    isUpcomingEvent: boolean,
    isGroupCallChat: boolean
  ) => {
    const { user } = this.props
    const { upcoming_event: upcomingEvent, ongoing_event: ongoingEvent } = user
    if (isOngoingGroupEventCall && !!ongoingEvent) {
      return (
        <UpcomingEvent
          event={ongoingEvent}
          isOnGoing
          joinCallButton={this.renderJoinButton(isGroupCallChat)}
          participants={this.getParticipantsInThisCall()}
        />
      )
    }
    if (isUpcomingEvent && !!upcomingEvent) {
      return (
        <UpcomingEvent
          event={upcomingEvent}
          isOnGoing={false}
          joinCallButton={this.renderJoinButton(isGroupCallChat)}
          participants={this.getParticipantsInThisCall()}
        />
      )
    }
    return null
  }

  public render(): React.ReactNode {
    const { user, style } = this.props
    const {
      avatar,
      interests,
      status,
      username,
      participants,
      group_name = username,
    } = user

    const isGroupCallChat = this.isGroupCall()
    const isUpcomingEvent = this.isEventSuggestion()
    const isOngoingGroupEventCall = this.isOngoingEvent()
    const isGroupCallWithUpcomingEvent =
      isGroupCallChat && (isUpcomingEvent || isOngoingGroupEventCall)
    const isSeekingForCall = this.isSeekCall()

    const hasJoinCall = isGroupCallChat || isSeekingForCall
    const bgColor = this.getBackgroundColor(
      isGroupCallChat || isUpcomingEvent || isOngoingGroupEventCall
    )
    return (
      <ChatboxWrapper
        style={style}
        onPress={this.startConversation()}
        widthPercentage={100}
        entering={ZoomIn.duration(100)}
        exiting={ZoomOut.duration(100)}
        isUpcomingEvent={isUpcomingEvent || isOngoingGroupEventCall}
        isGroupCallWithUpcomingEvent={isGroupCallWithUpcomingEvent}
      >
        <HeaderColorBox bgColor={bgColor} />
        <ChatboxHeader>
          <ChatboxAvatar>
            <PresenceIndicator
              isOnline={status === UserStatus.Online}
              isGroupCallChat={
                isGroupCallChat || isUpcomingEvent || isOngoingGroupEventCall
              }
              location="chatBoxNear"
              offlineIndicatorColorCode="main.chatBoxBackground"
              ringColorCode="main.chatBoxBackground"
            >
              {isGroupCallChat || isUpcomingEvent || isOngoingGroupEventCall ? (
                <GroupAvatar
                  participants={
                    participants ? Object.values(participants) : undefined
                  }
                  size={AVATAR_SIZE}
                  showRing
                  bgColor="chatBoxBackground"
                  avatar={avatar}
                />
              ) : (
                <Avatar userAvatar={avatar} />
              )}
            </PresenceIndicator>
          </ChatboxAvatar>
          <HeaderTextWrapper
            isGroupCallChat={isGroupCallChat || isUpcomingEvent}
          >
            <ChatboxHeaderText
              numberOfLines={2}
              adjustsFontSizeToFit
              // bgColor={bgColor}
              // themeColor={!isGroupCallChat ? theme_color : undefined}
            >
              {isGroupCallChat || isUpcomingEvent ? group_name : username}
            </ChatboxHeaderText>
          </HeaderTextWrapper>
        </ChatboxHeader>
        <ChatboxBody>
          <ChatboxInterests
            hasJoinCall={hasJoinCall}
            isUpcomingEvent={isUpcomingEvent || isOngoingGroupEventCall}
          >
            {mappedInterests(interests)}
          </ChatboxInterests>
          {!isGroupCallChat && !isUpcomingEvent && (
            <Wave chatChannel={this.getOneOnOneChatChannel()} />
          )}
          {hasJoinCall &&
            !isOngoingGroupEventCall &&
            this.renderJoinCallButton(isGroupCallChat)}

          {this.renderEvents(
            isOngoingGroupEventCall,
            isUpcomingEvent,
            isGroupCallChat
          )}
        </ChatboxBody>
      </ChatboxWrapper>
    )
  }
}
// ChatboxComponent.whyDidYouRender = {
//   logOnDifferentValues: false,
//   customName: "ChatboxComponent",
//   diffNameColor: "red",
// }

const mapStateToProps = (state: State, props: ChatboxProps): StateToProps => ({
  groupInfo: selectGroupCallInfo(props.user.uuid)(state),
  isDarkMode: selectIsDarkMode(state),
  myUuid: selectMyUuid(state),
})
const mapDispatchToProps: DispatchToProps = {
  joinQuickCall: CallingAction.joinQuickCall,
}
export const Chatbox = connect(
  mapStateToProps,
  mapDispatchToProps
)(ChatboxComponent)
