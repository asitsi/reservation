import React from "react"
import { useTheme } from "styled-components"

import { UserMinimum } from "convose-lib/user"
import {
  AttendeesAvatarsContainer,
  AttendeesContainer,
  HostTitle,
} from "./Styled"
import { CallUsersTail } from "../CallUsersTail"

type AttendeesProps = {
  attendees: UserMinimum[]
  title?: string
  showAttendeesFirst?: boolean
  attendeesCount: number
}
const AVATAR_COUNT_TO_SHOW = 3
const EventAttendeesComponent: React.FC<AttendeesProps> = ({
  attendees,
  title = "Attendees:",
  showAttendeesFirst = false,
  attendeesCount = 0,
}) => {
  const theme = useTheme()
  return (
    <AttendeesContainer showAttendeesFirst={showAttendeesFirst}>
      <HostTitle>{title}</HostTitle>
      <AttendeesAvatarsContainer showAttendeesFirst={showAttendeesFirst}>
        <CallUsersTail
          participants={attendees}
          avatarCountToShow={AVATAR_COUNT_TO_SHOW}
          showUsersCount
          size={18}
          textSize={13}
          showRing
          ringColor="transparent"
          avatarBgColor={theme.message.otherMessageBubble}
          restOfUsersCount={
            attendeesCount > AVATAR_COUNT_TO_SHOW
              ? attendeesCount - AVATAR_COUNT_TO_SHOW
              : 0
          }
        />
      </AttendeesAvatarsContainer>
    </AttendeesContainer>
  )
}

export const EventAttendees = React.memo(EventAttendeesComponent)
