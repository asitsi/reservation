import React from "react"
import { Svg, Rect } from "react-native-svg"

import { SvgProps } from "../../svg/types"
import { getRatio, getWidth } from "../../svg/utils"

const defaultHeight = 23
const defaultWidth = 22
const ratio = getRatio(defaultHeight, defaultWidth)

export const CloseIcon: React.FC<SvgProps> = ({ color, height }) => {
  const svgHeight = height || defaultHeight
  const svgWidth = height ? getWidth(ratio, height) : defaultWidth
  return (
    <Svg width={svgWidth} height={svgHeight} viewBox="0 0 22 23" fill="none">
      <Rect
        x="6.06311"
        y="17.3428"
        width="1.76406"
        height="15.3852"
        rx="0.882028"
        transform="rotate(-135 6.06311 17.3428)"
        fill={color || "#3F9AF7"}
      />
      <Rect
        x="4.8158"
        y="6.46387"
        width="1.76406"
        height="15.3852"
        rx="0.882028"
        transform="rotate(-45 4.8158 6.46387)"
        fill={color || "#3F9AF7"}
      />
    </Svg>
  )
}
