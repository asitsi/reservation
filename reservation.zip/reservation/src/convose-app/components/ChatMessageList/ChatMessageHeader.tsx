/* eslint-disable camelcase, default-param-last */
import * as React from "react"
import { TouchableOpacity, useWindowDimensions, ViewStyle } from "react-native"
import { useSelector } from "react-redux"
import _ from "lodash"
import { useTheme } from "styled-components"

import {
  BlockSendContent,
  ChatChannel,
  ChatUser,
  getParticipantsInCall,
  GroupData,
  ParticipantsListObject,
  selectGroupCallInfo,
} from "convose-lib/chat"

import { selectUserFeature } from "convose-lib/users-list"
import { selectIsDarkMode, selectScreenOrientation } from "convose-lib/app"
import { Avatar as AvatarType } from "convose-lib/user"

import { Avatar, GroupAvatar } from "../../components/Avatar"
import { Header } from "../../components/Header"
import { PresenceIndicator } from "../PresenceIndicator"
// import { PresenceIndicator } from "../../components/PresenceIndicator"

const userAvatarStyle = {
  marginTop: 6,
}

const groupAvatarStyle = {
  marginTop: 2,
}

const getParticipants = (
  participants?: ChatUser[],
  groupInfoParticipants?: ParticipantsListObject
): ChatUser[] => {
  if (groupInfoParticipants) {
    return Object.keys(groupInfoParticipants).map(
      (key) => groupInfoParticipants[key]
    )
  }
  if (participants && participants.length) {
    return participants
  }
  return []
}
type ChatMessageHeaderProps = {
  readonly chatChannel: ChatChannel
  readonly chatUser: ChatUser
  readonly participants: ChatUser[] | undefined
  readonly goBack: () => void
  readonly showProfile: () => void
  readonly userIsOnline: boolean
  readonly isGroup: boolean
  readonly startCall: () => void
  readonly canRejoinCall: boolean | null
  readonly rejoinCall: () => void
  readonly isInCallingChat: boolean
  readonly toggleSettingsMenu: () => void
  readonly groupName: string | undefined
  readonly isConnectedToChatChannel: boolean
  readonly groupAvatar?: AvatarType
  readonly isCallingLoading: boolean
} & BlockSendContent

type ChatMessageHeaderType = ChatMessageHeaderProps
const AVATAR_SIZE = 35
const ChatMessageHeaderComponent: React.FC<ChatMessageHeaderType> = ({
  canRejoinCall,
  chatChannel,
  chatUser,
  goBack,
  groupName,
  isBlocked,
  isGroup,
  isInCallingChat,
  participants,
  rejoinCall,
  showBlockAlert,
  showProfile,
  startCall,
  toggleSettingsMenu,
  userIsOnline,
  isConnectedToChatChannel,
  groupAvatar,
  isCallingLoading,
}) => {
  const isDarkMode = useSelector(selectIsDarkMode)
  const { height: windowHeight } = useWindowDimensions()
  const groupData = useSelector(
    selectUserFeature(chatChannel)
  ) as GroupData | null
  const groupInfo = useSelector(selectGroupCallInfo(chatChannel))
  const screenOrientation = useSelector(selectScreenOrientation)
  const theme = useTheme()

  const bgColor = React.useMemo(() => {
    if (isGroup) {
      return undefined
    }
    if (isDarkMode) {
      return chatUser?.dark_background_color
    }
    return chatUser?.background_theme_color
  }, [
    isDarkMode,
    chatUser.background_theme_color,
    chatUser.dark_background_color,
    isGroup,
  ])

  const headerStyle: ViewStyle | undefined = React.useMemo(() => {
    const backgroundColor = bgColor ? { backgroundColor: bgColor } : {}
    if (
      screenOrientation === "LANDSCAPE-LEFT" ||
      screenOrientation === "LANDSCAPE-RIGHT"
    ) {
      return {
        alignSelf: "center",
        width: windowHeight,
        borderBottomLeftRadius: 22,
        borderBottomRightRadius: 22,
        ...backgroundColor,
      }
    }
    return {
      ...backgroundColor,
    }
  }, [screenOrientation, windowHeight, bgColor])

  const renderChatAvatar = (): React.ReactNode => {
    // const showRing = !chatUser?.avatar?.default_avatar
    // const size = showRing ? AVATAR_SIZE : AVATAR_SIZE + 6
    const size = AVATAR_SIZE + 6
    if (isGroup) {
      return (
        <GroupAvatar
          participants={getParticipants(participants, groupData?.participants)}
          size={AVATAR_SIZE}
          iconFunction={showProfile}
          showRing={false}
          bgColor={theme.main.background}
          avatar={groupAvatar}
          singleAvatarStyle={groupAvatarStyle}
        />
      )
    }
    return (
      <TouchableOpacity onPress={showProfile}>
        <PresenceIndicator
          isOnline={userIsOnline}
          location="chat"
          ringColor={bgColor}
          offlineIndicatorColor={bgColor}
        >
          <Avatar
            height={size}
            userAvatar={chatUser?.avatar}
            showRing={false}
            bgColor={theme.main.chatBoxOnlineIndicatorRing}
            isGroup
            ringColor={theme.main.chatBoxOnlineIndicatorRing}
            style={userAvatarStyle}
          />
        </PresenceIndicator>
      </TouchableOpacity>
    )
  }

  const getCanReJoinCall = (): boolean => {
    if (!isGroup) {
      return !!canRejoinCall
    }
    if (canRejoinCall) {
      return canRejoinCall
    }
    const callUsers = groupData ? groupData?.call_users : ""
    return !!getParticipantsInCall(groupInfo, callUsers || "").length
  }

  const handleStartCall = (): void => {
    if (isBlocked) {
      showBlockAlert("Content")
      return
    }
    startCall()
  }

  const getTitle = (): string => {
    if (!isGroup) {
      return chatUser.username
    }
    if (!groupName) {
      return groupData?.group_name || ""
    }
    return groupName
  }

  const onTitlePress = (): void => {
    if (isGroup) {
      showProfile()
      return
    }
    if (isBlocked) {
      showBlockAlert("ViewUser")
      return
    }
    showProfile()
  }

  return (
    <Header
      headerStyle={headerStyle}
      avatar={renderChatAvatar()}
      backgroundColor={bgColor}
      onBackPress={goBack}
      onTitlePress={onTitlePress}
      textColor={!isGroup ? theme.main.chatBoxText : theme.main.text}
      iconColor={!isGroup ? theme.main.chatBoxText : undefined}
      title={getTitle()}
      onMenuPress={toggleSettingsMenu}
      startCall={handleStartCall}
      rejoinCall={rejoinCall}
      isInCallingChat={isInCallingChat}
      isConnectedToChatChannel={isConnectedToChatChannel}
      canRejoinCall={getCanReJoinCall()}
      chatChannel={chatChannel}
      hasMenu
      sticky
      subheader={!isConnectedToChatChannel ? "Connecting..." : undefined}
      isCallingLoading={isCallingLoading}
      // isOnline={isGroup ? undefined : userIsOnline}
    />
  )
}
// ChatMessageHeaderComponent.whyDidYouRender = {
//   logOnDifferentValues: false,
//   customName: "ChatMessageHeaderComponent",
//   diffNameColor: "red",
// }

export default React.memo(
  ChatMessageHeaderComponent,
  (prevProps, nextProps) => {
    return _.isEqual(nextProps, prevProps)
  }
)
