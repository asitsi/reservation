export const allUsers = Array(10)
  .fill(1)
  .map((_, index) => ({
    agoraUuid: index + 1,
    isVideoEnabled: false,
    uuid: index + 1,
    isMuted: !!(index % 2),
    rawAgoraUuid: Number(`${index + 1}888`),
    avatar: {
      url: "https://res.cloudinary.com/hj0txfloi/image/upload/c_fill,h_270,w_270/v1651634003/qdget3vqguht8oogfqhs.png",
    },
    theme_color: "red",
    // username: `username ${index + 1}`,
    username: `ali`,
    isSpeaking: !(index % 2),
    hasSharedScreen: !!(index % 2),
  }))
