import React, { Component } from "react"
import { ActivityIndicator, Platform, ViewStyle } from "react-native"
import Ionicons from "react-native-vector-icons/Ionicons"
import Sound from "react-native-sound"
import { activateKeepAwakeAsync, deactivateKeepAwake } from "expo-keep-awake"
import Slider from "@react-native-community/slider"
import _ from "lodash"
import { withTheme } from "styled-components"

import { AudioMessagePlayer, Message } from "convose-lib/chat"
import {
  DEFAULT_HIT_SLOP,
  LONG_PRESS_DURATION,
  getDurationFromLength,
  secondsToMinutesAndSeconds,
} from "convose-lib/utils"
import { ThemeType, color } from "convose-styles"
import { captureError } from "convose-lib/utils/captureErrors"
import { ProximityHandler } from "../../ProximityHandler"
import {
  AudioIconsWrapper,
  AudioMessageTimer,
  AudioMessageWrapper,
  ButtonContainer,
  SliderContainer,
} from "./style"
import { convoseAlertRef } from "../../../RootConvoseAlert"

const getSoundAsync = async (data: string): Promise<Sound> => {
  return new Promise((resolve, reject) => {
    const audio = new Sound(data, undefined, (error) => {
      if (error) {
        reject(error)
      } else {
        resolve(audio)
      }
    })
  })
}
const sliderStyle: ViewStyle = {
  width: "100%",
}

type AudioMessageProps = {
  isInCallingChat: boolean
  theme: ThemeType
  readonly dismissSelectedMessage: (noToggleHeader?: boolean) => void
  readonly selectMessage: (message: Message) => void
  readonly isMessageSelected: boolean
  readonly message: Message
}
type AudioMessageState = {
  readonly audioMessage: Sound | null
  readonly positionSeconds: number
  readonly isPlaying: boolean
  readonly loading: boolean
  readonly audioDuration: number
}
const minimumInterval = 50
// const sliderStyle = { flex: 1, height: 20 }

const preventAutoLock = (isPlaying: boolean): void => {
  if (isPlaying) {
    activateKeepAwakeAsync().then().catch()
  } else {
    deactivateKeepAwake()
  }
}
Sound.setCategory("Playback")
const onProximityDetected = () => {
  Sound.setCategory("PlayAndRecord")
}

const onProximityReleased = () => {
  Sound.setCategory("Playback")
}

type AllProps = AudioMessageProps & AudioMessagePlayer
// AudioMessagePlayer props are coming from "ChatMessageList.tsx" component!
class AudioMessageComponent extends Component<AllProps, AudioMessageState> {
  public sliderTimeout!: ReturnType<typeof setTimeout>

  public isTouchSliderStarted!: boolean

  public preventMessageSelection!: boolean

  public positionInterval: ReturnType<typeof setInterval> | null = null

  public readonly state: AudioMessageState = {
    isPlaying: false,
    loading: false,
    positionSeconds: 0,
    audioMessage: null,
    audioDuration: 0,
  }

  public shouldComponentUpdate(
    prevProps: AllProps,
    prevState: AudioMessageState
  ): boolean {
    return (
      !_.isEqual(this.props, prevProps) || !_.isEqual(this.state, prevState)
    )
  }

  public componentDidUpdate(prevProps: AllProps, prevState: AudioMessageState) {
    const { shouldPlay } = this.props
    const { isPlaying } = this.state
    if (prevProps.shouldPlay !== shouldPlay) {
      this.handlePlayPauseEffect(shouldPlay, isPlaying)
    }
    if (isPlaying !== prevState.isPlaying) {
      preventAutoLock(isPlaying)
    }
  }

  public componentWillUnmount(): void {
    const { audioMessage } = this.state
    if (audioMessage) {
      audioMessage.release()
    }
    if (this.positionInterval) {
      clearInterval(this.positionInterval)
    }
  }

  public handlePlayPauseEffect = (
    shouldPlay: boolean,
    isPlaying: boolean
  ): void => {
    if (shouldPlay && !isPlaying) {
      this.handlePlay()
    } else if (!shouldPlay && isPlaying) {
      this.handlePauseClick()
    }
  }

  public readonly loadAudioData = async (autoPlay = false): Promise<void> => {
    const { message } = this.props
    const { data } = message
    this.setState({ loading: true })
    try {
      const audioMessage = await getSoundAsync(data)
      this.setState({
        audioMessage,
        loading: false,
        audioDuration: audioMessage.getDuration(),
      })
      if (autoPlay) {
        await this.playAudio(audioMessage)
      }
    } catch (error) {
      this.setState({ loading: false })
      captureError(error)
      convoseAlertRef?.show({
        ioniconName: "warning",
        title: `Playing the audio`,
        description:
          "Sorry, something went wrong while playing the audio file try again later",
      })
    }
  }

  public readonly playAudio = async (audioMessage: Sound): Promise<void> => {
    try {
      this.setState({ isPlaying: true })
      audioMessage.play(() => {
        this.requestForStop()
        this.setState({ isPlaying: false, positionSeconds: 0 })
      })
      this.positionInterval = setInterval(() => {
        audioMessage.getCurrentTime((seconds) => {
          this.setState({ positionSeconds: seconds })
        })
      }, minimumInterval)
    } catch (error) {
      captureError(error)
      convoseAlertRef?.show({
        ioniconName: "warning",
        title: `Playing the audio`,
        description:
          "Sorry, something went wrong while playing the audio file try again later",
      })
    }
  }

  // Event handlers
  public readonly handlePlayClick = async (): Promise<void> => {
    const {
      requestPlay,
      message: { uuid },
      shouldPlay,
    } = this.props
    const { isPlaying } = this.state
    if (shouldPlay && !isPlaying) {
      this.handlePlay()
      return
    }
    requestPlay(uuid)
  }

  public readonly handlePlay = async (): Promise<void> => {
    const { audioMessage } = this.state
    if (audioMessage) {
      await this.playAudio(audioMessage)
    } else {
      this.loadAudioData(true)
    }
  }

  public readonly requestForStop = (pause = false): void => {
    const { requestStop } = this.props
    requestStop(pause)
  }

  public readonly handlePauseClick = async (): Promise<void> => {
    const { audioMessage, isPlaying } = this.state
    if (audioMessage) {
      try {
        audioMessage.pause()
        if (this.positionInterval) {
          clearInterval(this.positionInterval)
          this.positionInterval = null
        }
        this.setState({ isPlaying: !isPlaying })
        this.requestForStop(true)
      } catch (error) {
        // console.log('Pausing audio error', error)
      }
    }
  }

  public shouldCancelMessageSelection = (value: number) => {
    const { positionSeconds } = this.state
    const dragDifference = Math.abs(positionSeconds - value)
    return dragDifference > 0.1
  }

  public readonly onSlidingComplete = async (value: number): Promise<void> => {
    const { isMessageSelected } = this.props
    const { audioMessage } = this.state
    if (this.shouldCancelMessageSelection(value)) {
      this.cancelSliderLongPress()
    }
    if (audioMessage) {
      try {
        audioMessage.setCurrentTime(value)
        if (!isMessageSelected) {
          this.playAudio(audioMessage)
        }
      } catch (error) {
        // console.log(error)
      }
    }
  }

  public readonly onValueChange = (value: number) => {
    // onValueChange has bug on android! so we handle it programmatically
    if (!this.isTouchSliderStarted) {
      return
    }
    if (this.shouldCancelMessageSelection(value)) {
      this.preventMessageSelection = true
    }
  }

  public readonly onPlayPausePress = (): void => {
    const { dismissSelectedMessage } = this.props
    const { isPlaying } = this.state
    dismissSelectedMessage()
    if (isPlaying) {
      this.handlePauseClick()
    } else {
      this.handlePlayClick()
    }
  }

  // Render
  public readonly renderButtons = (): React.ReactNode => {
    const { loading } = this.state
    const { isInCallingChat, message, theme } = this.props
    const { myMessage } = message
    const buttonColor =
      myMessage && !isInCallingChat ? color.white : theme.mainBlue
    if (loading) {
      return (
        <ButtonContainer>
          <ActivityIndicator size="small" color={buttonColor} />
        </ButtonContainer>
      )
    }
    const { isPlaying } = this.state
    const { selectMessage } = this.props
    const iconSize = isPlaying ? 28 : 30

    return (
      <ButtonContainer>
        <AudioIconsWrapper
          onPress={this.onPlayPausePress}
          onLongPress={selectMessage}
          delayLongPress={LONG_PRESS_DURATION}
          hitSlop={DEFAULT_HIT_SLOP}
        >
          <Ionicons
            name={isPlaying ? "pause" : "play"}
            color={buttonColor}
            size={iconSize}
          />
        </AudioIconsWrapper>
      </ButtonContainer>
    )
  }

  public onTouchSliderStarted = (): void => {
    // console.log("onTouchSliderStarted")
    const { isPlaying } = this.state
    if (isPlaying) {
      this.handlePauseClick()
    }
    const { selectMessage, message } = this.props
    this.isTouchSliderStarted = true
    this.sliderTimeout = setTimeout(() => {
      if (!this.preventMessageSelection) {
        selectMessage(message)
      }
    }, LONG_PRESS_DURATION * 2)
  }

  public cancelSliderLongPress = (): void => {
    // console.log("cancelSliderLongPress")
    this.isTouchSliderStarted = false
    this.preventMessageSelection = false
    if (this.sliderTimeout) {
      clearTimeout(this.sliderTimeout)
    }
  }

  // public getThumbImage = () => {
  //   const {
  //     message: { myMessage },
  //     isInCallingChat,
  //     theme,
  //   } = this.props
  //   if (myMessage && !isInCallingChat) {
  //     return slideThumb
  //   }
  //   if (theme.mode === "light") {
  //     return slideThumbBlue
  //   }
  //   return slideThumbBlueDark
  // }

  // eslint-disable-next-line complexity
  public render(): React.ReactNode {
    const { message, isInCallingChat, theme, selectMessage } = this.props
    const { myMessage, length } = message
    const { audioDuration, positionSeconds, isPlaying } = this.state

    const buttonColor =
      myMessage && !isInCallingChat ? color.white : theme.mainBlue

    const durationFromLength = getDurationFromLength(length)
    const soundDuration = audioDuration || durationFromLength || 0

    return (
      <AudioMessageWrapper
        onLongPress={selectMessage}
        delayLongPress={LONG_PRESS_DURATION}
      >
        {isPlaying && Platform.OS === "ios" && (
          <ProximityHandler
            isInCallingChat={isPlaying}
            isInVideoMode={false}
            isSpeakerOn={false}
            startEngine
            onProximityDetected={onProximityDetected}
            onProximityReleased={onProximityReleased}
          />
        )}
        {this.renderButtons()}
        <SliderContainer>
          <Slider
            onResponderStart={this.onTouchSliderStarted}
            onResponderEnd={this.cancelSliderLongPress}
            minimumValue={0}
            maximumValue={soundDuration}
            minimumTrackTintColor={
              myMessage && !isInCallingChat ? color.white : theme.mainBlue
            }
            maximumTrackTintColor={
              myMessage && !isInCallingChat ? color.darkgray : color.darkGray
            }
            thumbTintColor={buttonColor}
            value={positionSeconds}
            onSlidingComplete={this.onSlidingComplete}
            onValueChange={this.onValueChange}
            style={sliderStyle}
            // thumbImage={this.getThumbImage()}
            // audioMessageHasLoaded={!!audioMessage}
          />
        </SliderContainer>
        <AudioMessageTimer myMessage={myMessage && !isInCallingChat}>
          {!isPlaying
            ? length || "0:00"
            : secondsToMinutesAndSeconds(positionSeconds)}
        </AudioMessageTimer>
      </AudioMessageWrapper>
    )
  }
}
// AudioMessageComponent.whyDidYouRender = {
//   logOnDifferentValues: false,
//   customName: "AudioMessageComponent",
//   diffNameColor: "red",
// }
export const AudioMessage: React.FC<Omit<AllProps, "theme">> = withTheme(
  AudioMessageComponent
)
