/* eslint-disable react-perf/jsx-no-new-object-as-prop */
import React, { useEffect } from "react"
import {
  useAnimatedStyle,
  useSharedValue,
  withTiming,
} from "react-native-reanimated"
import { CallingButton } from "../Common/CallingButtons"
import { LandscapeCallingButtonsContainer } from "../Common/Styled"
import { CallingButtonsProps } from "../dto"

const getAnimationValue = (isHeaderHide?: boolean) => (isHeaderHide ? 0 : 1)

type Props = CallingButtonsProps & {
  insetBottom: number
  insetLeft: number
  isLandscapeLeft: boolean
  isHeaderHide?: boolean
  isChatHide?: boolean
}

const LandscapeCallingButtonsComponent: React.FC<Props> = ({
  endCall,
  insetBottom,
  insetLeft,
  isAudioEnabled,
  isGroup,
  isLandscapeLeft,
  isSpeakerActive,
  isVideoEnabled,
  toggleAudio,
  toggleSpeaker,
  toggleVideo,
  unmuteAlert,
  unsetUnmuteAlert,
  isHeaderHide,
  isChatHide,
  isGroupAdmin,
  isHandRaiseEnabled,
  toggleHandRaise,
  myRaisedHandStatus,
}) => {
  const opacityOffset = useSharedValue(getAnimationValue(isHeaderHide))
  const containerStyle = useAnimatedStyle(() => ({
    opacity: opacityOffset.value,
  }))

  useEffect(() => {
    opacityOffset.value = withTiming(
      getAnimationValue(isHeaderHide || !isChatHide),
      { duration: 150 }
    )
  }, [isChatHide, isHeaderHide, opacityOffset])

  return (
    <LandscapeCallingButtonsContainer
      style={containerStyle}
      insetBottom={insetBottom}
      insetLeft={insetLeft}
      isLandscapeLeft={isLandscapeLeft}
    >
      <CallingButton
        isAudioEnabled={isAudioEnabled}
        isSpeakerActive={isSpeakerActive}
        isVideoEnabled={isVideoEnabled}
        endCall={endCall}
        toggleAudio={toggleAudio}
        toggleSpeaker={toggleSpeaker}
        toggleVideo={toggleVideo}
        unmuteAlert={unmuteAlert}
        unsetUnmuteAlert={unsetUnmuteAlert}
        isGroup={isGroup}
        isLandscape
        isGroupAdmin={isGroupAdmin}
        isHandRaiseEnabled={isHandRaiseEnabled}
        toggleHandRaise={toggleHandRaise}
        myRaisedHandStatus={myRaisedHandStatus}
      />
    </LandscapeCallingButtonsContainer>
  )
}

export const LandscapeCallingButtons = React.memo(
  LandscapeCallingButtonsComponent
)
