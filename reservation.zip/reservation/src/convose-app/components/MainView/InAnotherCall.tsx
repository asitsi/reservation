import React from "react"
import { useSelector } from "react-redux"
import { FadeIn, FadeOut } from "react-native-reanimated"

import { selectInAnotherCall } from "convose-lib/calling"
import { UserInOtherCall } from "../user-in-other-call"
import { DisplayTextModal } from "./Styled"

const InAnotherCallComponent: React.FC = () => {
  const inAnotherCall = useSelector(selectInAnotherCall)
  const { username = null, avatar = null } = inAnotherCall
  return username && avatar ? (
    <DisplayTextModal entering={FadeIn} exiting={FadeOut}>
      <UserInOtherCall username={username} avatar={avatar} />
    </DisplayTextModal>
  ) : null
}

export const InAnotherCall = React.memo(InAnotherCallComponent)
