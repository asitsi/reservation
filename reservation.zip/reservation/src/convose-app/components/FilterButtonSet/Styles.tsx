import styled from "styled-components/native"
import Animated from "react-native-reanimated"

import { CenteredText, Props, color, font } from "convose-styles"

type FilterButtonItemProps = {
  selected: boolean
}

export const FilterButtonSetContainer = styled.View`
  width: 100%;
  z-index: 100;
  flex-direction: row;
  justify-content: flex-start;
  align-items: center;
  padding: 10px 5px;
`

export const FilterButton = styled.TouchableOpacity`
  background: ${(props: Props & FilterButtonItemProps) =>
    props.selected
      ? props.theme.mainBlue
      : props.theme.filterButton.background};
  justify-content: center;
  align-items: center;
  padding: 7px 17px;
  margin-left: 5px;
  margin-right: 5px;
  border-radius: 20px;
`
export const FilterButtonText = styled(CenteredText)`
  font-family: ${font.semiBold};
  color: ${(props: Props & FilterButtonItemProps) =>
    props.selected ? color.white : props.theme.main.text};
`
export const BadgeContainer = styled(Animated.View)`
  position: absolute;
  top: -10px;
  right: 0px;
  background-color: ${(props: Props) => props.theme.mainBlue};
  padding: 2px 7px;
  border-radius: 10px;
`
export const BadgeNumber = styled(CenteredText)`
  font-family: ${font.bold};
  color: ${color.white};
  z-index: 10;
  font-size: 12px;
`
