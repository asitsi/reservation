import * as React from "react"
import { Pressable, Share, ViewStyle } from "react-native"
import { connect } from "react-redux"
import { withSafeAreaInsets } from "react-native-safe-area-context"

import {
  ChatAction,
  ChatChannel,
  ChatUser,
  ChatUserUpdate,
  selectCreatingGroupChat,
  selectOpenChatChannel,
} from "convose-lib/chat"
import { State } from "convose-lib/store"
import {
  InviteList,
  selectInviteList,
  UsersListAction,
} from "convose-lib/users-list"
import {
  ScreenOrientationTypes,
  selectScreenOrientation,
} from "convose-lib/app"
import { SafeAreaProps } from "convose-lib/generalTypes"

import { useMainBlue } from "convose-lib/utils/useMainBlue"
import { AddPersonItem } from "../AddPersonItem"
import { InviteUsersButton } from "../InviteUsersButton"
import { BlueMaterialIndicator } from "../MaterialIndicator"
import ShareIcon from "../../../assets/Icons/components/Share"
import {
  SlideUpWrapperList,
  SlideUpWrapperListRefType,
} from "../SlideUpWrapper"
import { DEFAULT_GROUP_NAME, GroupName } from "./GroupName"
import {
  FooterContainer,
  IconButtonContainer,
  InviteToGroupContainer,
  InviteToGroupIconContainer,
  InviteToGroupTitle,
} from "./Styled"

const BlueShareIcon: React.FC = () => {
  const mainBlue = useMainBlue()
  return <ShareIcon color={mainBlue} height={25} />
}
const keyExtract = (item: ChatUserUpdate, index: number): string => {
  return item ? item.uuid : index.toString()
}

type LocalState = {
  selection: string[]
  groupName: string
}

type Props = {
  readonly goBackCallback: () => void
  readonly groupMembers: string[]
  readonly isGroup: boolean
  readonly isFromInbox: boolean
}

type DispatchToProps = {
  readonly createGroupChat: (userIds: string[], groupName: string) => void
  readonly addToGroupChat: (userIds: string[], chatChannel: ChatChannel) => void
  readonly getInviteList: (
    chatChannel: ChatChannel,
    from: number,
    limit: number
  ) => void
  readonly getInviteListCleanup: () => void
}

type StateToProps = {
  readonly creating: boolean
  readonly openChat: ChatChannel | null
  readonly screenOrientation: ScreenOrientationTypes
  readonly inviteList: InviteList
}

type AllProps = StateToProps & DispatchToProps & Props & SafeAreaProps

const INVITE_LIST_LIMIT = 30

export class AddPersonListComponent extends React.Component<
  AllProps,
  LocalState
> {
  public getInviteListCounter = 0

  public slideUpWrapperListRef = React.createRef<SlideUpWrapperListRefType>()

  constructor(props: AllProps) {
    super(props)
    this.state = {
      selection: [],
      groupName: DEFAULT_GROUP_NAME,
    }
  }

  componentDidMount(): void {
    this.getInviteList()
  }

  componentWillUnmount(): void {
    const { getInviteListCleanup } = this.props
    getInviteListCleanup()
  }

  public getInviteList(): void {
    const { getInviteList, openChat } = this.props
    getInviteList(
      openChat || "",
      this.getInviteListCounter * INVITE_LIST_LIMIT,
      INVITE_LIST_LIMIT
    )
    this.getInviteListCounter += 1
  }

  private handleTouch = (userId: string): void => {
    const { selection } = this.state
    if (selection.includes(userId)) {
      this.setState({
        selection: selection.filter((s) => s !== userId),
      })
    } else {
      this.setState({
        selection: [userId, ...selection],
      })
    }
  }

  public getContentContainerStyle = (): ViewStyle => {
    const { insets } = this.props
    return {
      minHeight: "100%",
      paddingBottom: insets.bottom + 75,
      width: "95%",
      alignSelf: "center",
    }
  }

  private readonly handleInvite = () => {
    const {
      creating,
      groupMembers,
      createGroupChat,
      isGroup,
      openChat,
      addToGroupChat,
      isFromInbox,
    } = this.props
    const { selection, groupName } = this.state

    if (isGroup && openChat && !!selection.length) {
      addToGroupChat([...selection], openChat)
      this.slideUpWrapperListRef.current?.slideDown()
    } else if (!creating && !!selection.length) {
      const userIds = [...groupMembers, ...selection]
      createGroupChat(userIds, groupName || "New Group")
      isFromInbox && this.slideUpWrapperListRef.current?.slideDown()
    }
  }

  private readonly handleOnEndReached = () => {
    const { inviteList } = this.props
    const { isLoading, pages_left: pagesLeft, users } = inviteList
    !isLoading && (pagesLeft || !users.length) && this.getInviteList()
  }

  private setGroupName = (groupName: string) => {
    this.setState({
      groupName,
    })
  }

  public onShareGroup = () => {
    const { openChat } = this.props
    const url = `https://convose.com/?id=${openChat}`
    Share.share({
      title: "Share group!",
      message: `I’m part of this awesome Convose group come join us here: ${url}`,
    })
      .then()
      .catch()
  }

  private isSelected(userId: string): boolean {
    const { selection } = this.state
    return selection.includes(userId)
  }

  private renderItem = ({ item }: { readonly item: ChatUserUpdate }) => {
    return (
      <AddPersonItem
        user={item as ChatUser}
        handleTouch={this.handleTouch}
        selected={this.isSelected(item ? item.uuid : "")}
      />
    )
  }

  public renderListHeader = () => {
    const { isGroup } = this.props
    if (isGroup) {
      return (
        <InviteToGroupContainer>
          <InviteToGroupTitle>Invite to group</InviteToGroupTitle>
          <InviteToGroupIconContainer>
            <Pressable onPress={this.onShareGroup}>
              {({ pressed }) => (
                <IconButtonContainer pressed={pressed}>
                  <BlueShareIcon />
                </IconButtonContainer>
              )}
            </Pressable>
          </InviteToGroupIconContainer>
        </InviteToGroupContainer>
      )
    }
    return <GroupName setName={this.setGroupName} />
  }

  public render(): React.ReactNode {
    const { selection } = this.state
    const {
      goBackCallback,
      screenOrientation,
      creating,
      inviteList,
      isFromInbox,
    } = this.props
    const canInvite = isFromInbox ? selection.length > 1 : !!selection.length
    const { isLoading, users } = inviteList

    return (
      <SlideUpWrapperList
        ref={this.slideUpWrapperListRef}
        key={screenOrientation}
        onDismiss={goBackCallback}
        noInsetBottom
        canDismiss
        fullScreenView
        outsideScrollViewChildren={
          <InviteUsersButton
            creating={creating}
            inviteUsers={this.handleInvite}
            disabled={!canInvite}
            label={isFromInbox ? "Create group" : "Invite"}
          />
        }
        // eslint-disable-next-line react-perf/jsx-no-new-object-as-prop
        flatListProps={{
          data: users,
          extraData: selection,
          keyExtractor: keyExtract,
          contentContainerStyle: this.getContentContainerStyle(),
          renderItem: this.renderItem,
          onEndReached: this.handleOnEndReached,
          onEndReachedThreshold: 0.01,
          ListEmptyComponent: <BlueMaterialIndicator />,
          ListFooterComponent:
            isLoading && users && users.length > 0 ? (
              <FooterContainer>
                <BlueMaterialIndicator />
              </FooterContainer>
            ) : null,
          ListHeaderComponent: this.renderListHeader,
        }}
      />
    )
  }
}
const mapStateToProps = (state: State): StateToProps => ({
  creating: selectCreatingGroupChat(state),
  openChat: selectOpenChatChannel(state),
  screenOrientation: selectScreenOrientation(state),
  inviteList: selectInviteList(state),
})

const mapDispatchToProps: DispatchToProps = {
  createGroupChat: ChatAction.createGroupChat,
  addToGroupChat: ChatAction.addToGroupChat,
  getInviteList: UsersListAction.getInviteList,
  getInviteListCleanup: UsersListAction.getInviteListCleanup,
}

export const AddPersonList = connect(
  mapStateToProps,
  mapDispatchToProps
)(withSafeAreaInsets(AddPersonListComponent))
