import React from "react"
import {
  JoinCallDescriptionContainer,
  JoinCallDescriptionText,
  LiveIconContainer,
} from "./Styled"
import { LiveIndicator } from "../LiveIndicator"

type JoinCallDescriptionProps = {
  isGroup: boolean
}
const JoinCallDescriptionComponent: React.FC<JoinCallDescriptionProps> = ({
  isGroup,
}) => {
  return (
    <JoinCallDescriptionContainer>
      <LiveIconContainer>
        <LiveIndicator size={16} />
      </LiveIconContainer>
      <JoinCallDescriptionText>
        {isGroup ? "Live" : "Seeking call"}
      </JoinCallDescriptionText>
    </JoinCallDescriptionContainer>
  )
}
export const JoinCallDescription = React.memo(JoinCallDescriptionComponent)
