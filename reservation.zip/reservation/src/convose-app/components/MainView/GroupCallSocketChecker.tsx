import React, { memo } from "react"
import { connect } from "react-redux"

import {
  JoinCall,
  selectCallingChatId,
  selectIsAutoJoiningOnSignIn,
  selectIsGroup,
  selectJoinCall,
} from "convose-lib/calling"
import { ChatUser, selectGroupCallInfo } from "convose-lib/chat"
import { selectMyUuid } from "convose-lib/user"
import { State } from "convose-lib"
import { isEqual } from "lodash"
import { addUserToGroupCall } from "convose-lib/users-list"

type StateToProps = {
  isGroupCall: boolean
  chatId: string
  groupInfo: {
    audience: ReadonlyArray<ChatUser>
    broadcasters: ReadonlyArray<ChatUser>
  }
  joinCall: JoinCall
  myUuid: string
  isAutoJoiningOnSignIn: boolean
}
type Props = StateToProps
class GroupCallSocketCheckerComponent extends React.Component<Props> {
  shouldComponentUpdate(nextProps: Readonly<StateToProps>): boolean {
    return !isEqual(nextProps, this.props)
  }

  componentDidUpdate(prevProps: Readonly<StateToProps>): void {
    const {
      chatId,
      groupInfo,
      isGroupCall,
      joinCall,
      myUuid,
      isAutoJoiningOnSignIn,
    } = this.props
    if (
      prevProps.joinCall.isJoined &&
      joinCall.isJoined &&
      isGroupCall &&
      !isAutoJoiningOnSignIn
    ) {
      const { audience } = groupInfo
      if (
        Array.isArray(audience) &&
        !audience.find((user) => user.uuid === myUuid)
      ) {
        addUserToGroupCall(chatId)
      }
    }
  }

  render(): React.ReactNode {
    return null
  }
}

const mapStateToProps = (state: State): StateToProps => {
  return {
    isGroupCall: selectIsGroup(state),
    chatId: selectCallingChatId(state),
    groupInfo: selectGroupCallInfo(selectCallingChatId(state))(state),
    myUuid: selectMyUuid(state),
    joinCall: selectJoinCall(state),
    isAutoJoiningOnSignIn: selectIsAutoJoiningOnSignIn(state),
  }
}
export const GroupCallSocketChecker = memo(
  connect(mapStateToProps)(GroupCallSocketCheckerComponent),
  () => true
)
