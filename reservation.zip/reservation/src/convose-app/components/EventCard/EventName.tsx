import React from "react"
import { TitleContainer } from "./Styled"
import { Title } from "../AutosuggestOptionList"

type Props = {
  name: string
  numberOfLines?: number
}
const EventNameComponent: React.FC<Props> = ({ name, numberOfLines = 2 }) => {
  return (
    <TitleContainer>
      <Title numberOfLines={numberOfLines}>{name}</Title>
    </TitleContainer>
  )
}

export const EventName = React.memo(EventNameComponent)
