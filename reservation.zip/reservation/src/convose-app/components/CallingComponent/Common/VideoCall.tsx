/* eslint-disable complexity */
import React, { useRef } from "react"
import { OrderedMap } from "immutable"
import _ from "lodash"

import { ChatUser } from "convose-lib/chat"
import { AgoraUuid, AudioSetting, Peer } from "convose-lib/calling"
import {
  createMobileRawAgoraId,
  iSharedScreenPeer,
  setRemoteVideoQualityToHigh,
  setRemoteVideoQualityToLow,
} from "convose-lib"

import { styles } from "./Styled"
import { VideoCallView } from "./VideoCallComponent"
import { VideoCallContainer } from "./DimensionDependComponents/VideoCallContainer"

type Props = {
  readonly callingFullScreenMode: boolean
  readonly activePeer: number
  readonly me: ChatUser
  readonly isGroup: boolean
  readonly audioSetting: AudioSetting
  readonly peers: OrderedMap<AgoraUuid, Peer>
  readonly channel: string
  readonly setFullScreenUid?: (id: number | null) => void
  readonly isLandscape?: boolean
  readonly videoCallFullScreenUid: number | null
}
const getAgoraUuidsFromPeer = (peer: Peer) => ({
  agoraUuid: peer.agoraUuid,
  rawAgoraUuid: peer.rawAgoraUuid,
})
const getPeerWithActiveVideoPriorityOtherUser = (
  anyOneButMeWithActiveVideo: boolean,
  videoPeers: Peer[],
  myAgoraUuid: number,
  myRawAgoraUuid: number
) => {
  if (anyOneButMeWithActiveVideo) {
    const userWithVideoSharing = videoPeers.find(
      (peer) => peer.agoraUuid !== myAgoraUuid
    )
    return userWithVideoSharing
      ? getAgoraUuidsFromPeer(userWithVideoSharing)
      : null
  }
  return {
    agoraUuid: myAgoraUuid,
    rawAgoraUuid: myRawAgoraUuid,
  }
}
const VideoCallComponent: React.FC<Props> = ({
  callingFullScreenMode,
  activePeer,
  me,
  isGroup,
  audioSetting,
  peers,
  channel,
  setFullScreenUid,
  isLandscape,
  videoCallFullScreenUid,
}) => {
  const myPeer: Peer = React.useMemo(
    () => ({
      agoraUuid: me.id,
      isMuted: !audioSetting.isAudioEnabled,
      isVideoEnabled: audioSetting.isVideoEnabled,
      isActive: true,
      rawAgoraUuid: createMobileRawAgoraId(me.id),
    }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [audioSetting.isAudioEnabled, audioSetting.isVideoEnabled]
  )
  const allPeers: Peer[] = React.useMemo(() => {
    const peersArray = [...peers.values()]
    return [...peersArray, myPeer]
  }, [myPeer, peers])
  const fullscreenUid = React.useMemo(() => {
    if (!callingFullScreenMode) {
      return null
    }
    if (videoCallFullScreenUid && iSharedScreenPeer(videoCallFullScreenUid)) {
      const sharedScreenPeer = allPeers.find(
        (peer) => peer.rawAgoraUuid === videoCallFullScreenUid
      )
      if (sharedScreenPeer) {
        return getAgoraUuidsFromPeer(sharedScreenPeer)
      }
    }
    const activePeerVideos = allPeers.filter(
      (peer) => peer.isVideoEnabled && !iSharedScreenPeer(peer.rawAgoraUuid)
    )
    if (!activePeerVideos.length) {
      return null
    }
    const anyOneButMeWithActiveVideo = activePeerVideos.some(
      (peer) => peer.rawAgoraUuid !== myPeer.rawAgoraUuid
    )
    // 1:1 call
    if (!isGroup) {
      return getPeerWithActiveVideoPriorityOtherUser(
        anyOneButMeWithActiveVideo,
        activePeerVideos,
        myPeer.agoraUuid,
        myPeer.rawAgoraUuid
      )
    }
    // group call
    if (!activePeer) {
      return getPeerWithActiveVideoPriorityOtherUser(
        anyOneButMeWithActiveVideo,
        activePeerVideos,
        myPeer.agoraUuid,
        myPeer.rawAgoraUuid
      )
    }
    const activePeerSharingVideo = allPeers.find(
      (peer) => peer.agoraUuid === activePeer
    )
    if (activePeerSharingVideo) {
      return getAgoraUuidsFromPeer(activePeerSharingVideo)
    }
    const userWithVideoSharing = allPeers.find((peer) => peer.isVideoEnabled)
    return userWithVideoSharing
      ? getAgoraUuidsFromPeer(userWithVideoSharing)
      : null
  }, [
    activePeer,
    allPeers,
    callingFullScreenMode,
    isGroup,
    myPeer.rawAgoraUuid,
    myPeer.agoraUuid,
    videoCallFullScreenUid,
  ])

  React.useEffect(() => {
    setFullScreenUid && setFullScreenUid(fullscreenUid?.rawAgoraUuid || null)
    // if (
    //   fullscreenUid?.rawAgoraUuid &&
    //   !iSharedScreenPeer(fullscreenUid.rawAgoraUuid)
    // ) {
    //   enableRemoteSuperResolution(fullscreenUid.rawAgoraUuid)
    // }
  }, [fullscreenUid, setFullScreenUid])

  const thumbnailVideoRawAgoraIdsRef = useRef<number[]>([])
  const fullscreenRawAgoraIdRef = useRef<number | null>(null)

  const peersWithVideo = React.useMemo(() => {
    return allPeers
      .filter((peer) => peer.isVideoEnabled)
      .map((peer) => peer.rawAgoraUuid)
      .sort()
  }, [allPeers])

  const thumbnailVideoPeers = React.useMemo(() => {
    return peersWithVideo.filter(
      (rawAgoraUuid) => rawAgoraUuid !== fullscreenUid?.rawAgoraUuid
    )
  }, [peersWithVideo, fullscreenUid?.rawAgoraUuid])

  React.useEffect(() => {
    if (
      fullscreenUid?.rawAgoraUuid &&
      fullscreenUid.rawAgoraUuid !== fullscreenRawAgoraIdRef.current
    ) {
      fullscreenRawAgoraIdRef.current = fullscreenUid.rawAgoraUuid
      setRemoteVideoQualityToHigh(fullscreenUid.rawAgoraUuid)
    }
    if (!_.isEqual(thumbnailVideoPeers, thumbnailVideoRawAgoraIdsRef.current)) {
      thumbnailVideoRawAgoraIdsRef.current = thumbnailVideoPeers
      thumbnailVideoPeers.map((rawAgoraUuid) =>
        setRemoteVideoQualityToLow(rawAgoraUuid)
      )
    }
  }, [fullscreenUid?.rawAgoraUuid, thumbnailVideoPeers])

  const iAmSharingVideo = React.useMemo((): boolean => {
    return (
      fullscreenUid?.agoraUuid === 0 ||
      fullscreenUid?.rawAgoraUuid === myPeer.rawAgoraUuid
    )
  }, [fullscreenUid, myPeer.rawAgoraUuid])

  if (fullscreenUid === null) {
    return null
  }

  const isShareScreen = iSharedScreenPeer(fullscreenUid.rawAgoraUuid)

  return (
    <VideoCallContainer
      isShareScreen={isShareScreen}
      keyboardHeight={0}
      isLandscape={isLandscape}
    >
      <VideoCallView
        isLocal={iAmSharingVideo}
        agoraId={fullscreenUid.rawAgoraUuid}
        channel={channel}
        isFullScreen
        style={styles.video}
      />
    </VideoCallContainer>
  )
}

export const VideoCall = React.memo(
  VideoCallComponent,
  (prevProps, nextProps) => {
    return _.isEqual(nextProps, prevProps)
  }
)
