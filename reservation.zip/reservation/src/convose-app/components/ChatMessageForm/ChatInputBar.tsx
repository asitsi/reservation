import React, { PropsWithChildren, memo, useEffect, useRef } from "react"
import { useSafeAreaInsets } from "react-native-safe-area-context"
import {
  useAnimatedStyle,
  useSharedValue,
  withTiming,
} from "react-native-reanimated"

import { useKeyboard } from "convose-lib/utils/useKeyboard"
import { ChatInputBarView } from "./Styled"
import { isAndroid } from "../../../../settings"

type Props = {
  transparentBackground: boolean
  hasSelectedMessage: boolean
}

const ChatInputBarComponent: React.FC<PropsWithChildren<Props>> = ({
  transparentBackground,
  hasSelectedMessage,
  children,
}) => {
  const insets = useSafeAreaInsets()
  const [keyboardHeight, keyboardAnimationDuration] = useKeyboard()
  const height = useSharedValue(0)
  const openKeyboardHeight = useRef(0)

  useEffect(() => {
    openKeyboardHeight.current = Math.max(
      openKeyboardHeight.current,
      keyboardHeight
    )
  }, [keyboardHeight])

  const style = useAnimatedStyle(() => ({
    paddingBottom: height.value,
  }))
  useEffect(() => {
    if (!hasSelectedMessage) {
      height.value = withTiming(
        isAndroid ? 0 : keyboardHeight || insets.bottom,
        { duration: keyboardAnimationDuration || 200 }
      )
    }
    if (hasSelectedMessage && isAndroid && keyboardHeight) {
      height.value = Math.max(openKeyboardHeight.current, keyboardHeight)
    }
  }, [
    hasSelectedMessage,
    height,
    insets.bottom,
    keyboardAnimationDuration,
    keyboardHeight,
  ])
  return (
    <ChatInputBarView
      style={style}
      transparentBackground={transparentBackground}
    >
      {children}
    </ChatInputBarView>
  )
}

export const ChatInputBar = memo(ChatInputBarComponent)
