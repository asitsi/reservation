import React, { useEffect, useRef } from "react"
import { useSelector } from "react-redux"

import { selectChatTyping } from "convose-lib/chat"
import { TypingIndicatorHolder } from "./Styled"
import { TypingIndicator } from "./TypingIndicator"

type Props = {
  chatChannel: string
  scrollToBottom: () => void
}
const ChatListTypingIndicatorComponent: React.FC<Props> = ({
  chatChannel,
  scrollToBottom,
}) => {
  const typing = useSelector(selectChatTyping(chatChannel)) || []
  const hasTyping = !!typing.length
  const prevHasTyping = useRef(hasTyping)

  useEffect(() => {
    if (!hasTyping && prevHasTyping.current) {
      scrollToBottom()
    }
  }, [hasTyping, scrollToBottom])

  useEffect(() => {
    prevHasTyping.current = hasTyping
  }, [hasTyping])

  return (
    <TypingIndicatorHolder>
      <TypingIndicator typingUsers={typing} />
    </TypingIndicatorHolder>
  )
}

export const ChatListTypingIndicator = React.memo(
  ChatListTypingIndicatorComponent
)
