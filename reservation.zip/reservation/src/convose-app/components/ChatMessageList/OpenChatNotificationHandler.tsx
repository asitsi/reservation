import React, { useCallback, useEffect, useRef } from "react"
import { useDispatch } from "react-redux"

import { ChatAction } from "convose-lib/chat"

type Props = {
  isChatHide: boolean
}

const OpenChatNotificationHandlerComponent: React.FC<Props> = ({
  isChatHide,
}) => {
  const dispatch = useDispatch()
  const isFirstRun = useRef(true)
  const showOpenChatNotification = useCallback(
    () => dispatch(ChatAction.showInAppNotificationForOpenChat()),
    [dispatch]
  )
  const hideOpenChatNotification = useCallback(
    () => dispatch(ChatAction.hideInAppNotificationForOpenChat()),
    [dispatch]
  )

  useEffect(() => {
    if (isChatHide) {
      showOpenChatNotification()
    } else if (isFirstRun.current) {
      isFirstRun.current = false
    } else {
      hideOpenChatNotification()
    }
    return () => {
      hideOpenChatNotification()
    }
  }, [isChatHide, showOpenChatNotification, hideOpenChatNotification])

  return null
}

export const OpenChatNotificationHandler = React.memo(
  OpenChatNotificationHandlerComponent
)
