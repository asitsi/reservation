import { TouchableOpacity } from "react-native-gesture-handler"
import Animated from "react-native-reanimated"
import styled from "styled-components/native"

export const CallButtonWrapper = styled.View`
  width: ${(props: { size: number }) => props.size}px;
  height: ${(props: { size: number }) => props.size}px;
  border-radius: ${(props: { size: number }) => props.size}px;
`

export const ButtonContainer = styled(TouchableOpacity)`
  width: ${(props: { size: number }) => props.size}px;
  height: ${(props: { size: number }) => props.size}px;
  border-radius: ${(props: { size: number }) => props.size}px;
`
export const Button = styled(Animated.View)`
  width: ${(props: { size: number }) => props.size}px;
  height: ${(props: { size: number }) => props.size}px;
  border-radius: ${(props: { size: number }) => props.size}px;
  justify-content: center;
  align-items: center;
`
