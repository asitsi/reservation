import React from "react"
import { Svg, Path } from "react-native-svg"
import { SvgProps } from "./types"

const defaultHeight = 33

export const BasketballSvg: React.FunctionComponent<SvgProps> = ({
  color,
  height,
}) => {
  const svgHeight = height || defaultHeight
  const svgWidth = svgHeight
  return (
    <Svg width={svgHeight} height={svgWidth} viewBox="0 0 33 33" fill="none">
      <Path
        d="M16.5 32C25.0604 32 32 25.2843 32 17C32 8.71573 25.0604 2 16.5 2C7.93959 2 1 8.71573 1 17C1 25.2843 7.93959 32 16.5 32Z"
        fill={color || "#F4AA41"}
      />
      <Path
        d="M1 16.479H32.0406"
        stroke="black"
        strokeWidth="1.5"
        strokeMiterlimit="10"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M16.5203 0.958984V31.9996"
        stroke="black"
        strokeWidth="1.5"
        strokeMiterlimit="10"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M26.796 28.0927C23.799 25.0957 21.9794 21.0283 21.9794 16.4258C21.9794 11.8767 23.799 7.75581 26.796 4.75879"
        stroke="black"
        strokeWidth="1.5"
        strokeMiterlimit="10"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M6.29846 4.8125C9.29548 7.80952 11.1151 11.9304 11.1151 16.4795C11.1151 21.0285 9.29548 25.1494 6.29846 28.1464"
        stroke="black"
        stroke-width="1.5"
        stroke-miterlimit="10"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
      <Path
        d="M16.5203 31.9996C25.0919 31.9996 32.0406 25.0509 32.0406 16.4793C32.0406 7.90765 25.0919 0.958984 16.5203 0.958984C7.94867 0.958984 1 7.90765 1 16.4793C1 25.0509 7.94867 31.9996 16.5203 31.9996Z"
        stroke="black"
        strokeWidth="1.5"
        strokeMiterlimit="10"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </Svg>
  )
}
