/* eslint-disable react-perf/jsx-no-new-array-as-prop */
import React, { forwardRef, useImperativeHandle, useRef } from "react"
import { TouchableWithoutFeedback, ViewStyle } from "react-native"
import Animated, {
  useSharedValue,
  withTiming,
  FadeIn,
  runOnJS,
  useAnimatedRef,
  useAnimatedReaction,
  scrollTo,
  useAnimatedScrollHandler,
  FlatListPropsWithLayout,
  useAnimatedProps,
  measure,
  useAnimatedStyle,
} from "react-native-reanimated"
import { useSafeAreaInsets } from "react-native-safe-area-context"
import {
  GestureDetector,
  Gesture,
  GestureType,
  FlatList,
} from "react-native-gesture-handler"
import _ from "lodash"

import { hardShadow } from "convose-styles"
import { AlertStatusBarAuto } from "../ConvoseAlert/AlertStatusBarAuto"
import { HandleBackPress } from "../ConvoseAlert/HandleBackPress"
import {
  BackgroundEmptyView,
  Container,
  PADDING_TOP,
  ScrollViewWrapper,
  Wrapper,
} from "./Styles"
import { Pill } from "./Pill"
import {
  DISMISS_DURATION,
  HIDE_VALUE,
  PERCENTAGE_OF_CONTAINER_HEIGHT_TO_SLIDE_DOWN,
  SHOW_VALUE,
  SLIDE_DURATION,
  TRANSLATION_Y_LIMIT_TO_SLIDE_DOWN,
  VELOCITY_SLIDE_DOWN_LIMIT,
} from "./constants"
import { SlideInEntering, SlideOutExiting, layout } from "./EnteringExiting"

const AnimatedFlatList = Animated.createAnimatedComponent(FlatList)

type Props<T> = {
  canDismiss?: boolean
  onDismiss: () => void
  wrapperStyle?: ViewStyle
  noInsetBottom?: boolean
  containerStyle?: ViewStyle
  scrollViewContainerStyle?: ViewStyle
  hideSlidePill?: boolean
  fullScreenView?: boolean
  lockScroll?: boolean
  onScrollStart?: () => void
  onScrollToDismissCanceled?: () => void
  outsideScrollViewChildren?: React.ReactNode
  keyboardShouldPersistTaps?: "always" | "never" | "handled"
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  // data: ArrayLike<any> | null | undefined
  // // eslint-disable-next-line @typescript-eslint/no-explicit-any
  // renderItem: ListRenderItem<any> | null | undefined
  // keyExtractor?: (item: unknown, index: number) => string
  flatListProps: FlatListPropsWithLayout<T>
}

type Callback = () => void

export type SlideUpWrapperListRefType = {
  slideDown: (callBack?: () => void) => void
  scrollToTop: (callback?: Callback, duration?: number) => void
}

const SlideUpWrapperListComponent = forwardRef<
  SlideUpWrapperListRefType,
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  Props<any>
>(
  (
    {
      canDismiss,
      onDismiss,
      wrapperStyle,
      noInsetBottom,
      containerStyle,
      hideSlidePill,
      fullScreenView,
      lockScroll,
      onScrollStart,
      onScrollToDismissCanceled,
      outsideScrollViewChildren,
      scrollViewContainerStyle,
      keyboardShouldPersistTaps = "never",
      flatListProps,
    },
    ref
  ) => {
    const insets = useSafeAreaInsets()
    const isDismissed = useRef(false)
    const insetBottom = insets.bottom
    const insetTop = insets.top
    const translateY = useSharedValue(SHOW_VALUE)
    const panGestureRef = useRef<GestureType>(Gesture.Pan())
    const scrollViewRef = useAnimatedRef<FlatList>()
    const scrollViewPosition = useSharedValue(0)
    const bounces = useSharedValue(true)
    const hasScrollToTopCallback = useSharedValue(false)
    const forceEnableSlide = useSharedValue(false) // enable slide down on large scroll views when user slide their finger on the pill
    const containerRef = useAnimatedRef<Animated.View>()
    const prevTranslationY = useSharedValue(0)
    const isSlidingUp = useSharedValue(false)
    const backgroundOpacity = useSharedValue(1)

    const backgroundStyle = useAnimatedStyle(() => ({
      opacity: backgroundOpacity.value,
    }))
    const slideDown = (callback: () => void): void => {
      backgroundOpacity.value = withTiming(0, {
        duration: DISMISS_DURATION,
      })
      translateY.value = withTiming(
        HIDE_VALUE,
        {
          duration: DISMISS_DURATION,
        },
        () => {
          runOnJS(callback)()
        }
      )
    }

    const handleDragDownDismiss = (): void => {
      "worklet"

      if (isDismissed.current) {
        return
      }
      isDismissed.current = true
      runOnJS(slideDown)(onDismiss)
    }
    const animatedProps = useAnimatedProps(() => ({
      bounces: bounces.value,
    }))
    const panMain = Gesture.Pan()
      .onTouchesDown((event) => {
        if (event.allTouches[0].y <= PADDING_TOP) {
          forceEnableSlide.value = true
        } else {
          forceEnableSlide.value = false
        }
      })
      .onTouchesMove((event, state) => {
        if (scrollViewPosition.value > 0 && !forceEnableSlide.value) {
          state.fail()

          if (!bounces.value) {
            bounces.value = true
          }
        } else if (bounces.value) {
          bounces.value = false
        }
      })
      .onUpdate(({ translationY }) => {
        if (translationY > 0 && canDismiss) {
          isSlidingUp.value = prevTranslationY.value > translationY
          prevTranslationY.value = translationY
          translateY.value = translationY
          onScrollStart && runOnJS(onScrollStart)()
        }
      })
      .onFinalize(({ translationY, velocityY }) => {
        const canSlideDown = (() => {
          if (isSlidingUp.value) {
            return false
          }
          if (velocityY > VELOCITY_SLIDE_DOWN_LIMIT) {
            return true
          }
          const containerMeasure = measure(containerRef)
          const containerHeight = containerMeasure?.height || 0
          if (containerHeight) {
            return (
              translationY >
              containerHeight * PERCENTAGE_OF_CONTAINER_HEIGHT_TO_SLIDE_DOWN
            )
          }
          return translationY > TRANSLATION_Y_LIMIT_TO_SLIDE_DOWN
        })()
        if (canDismiss && canSlideDown) {
          handleDragDownDismiss()
        } else {
          translateY.value = withTiming(SHOW_VALUE)
          onScrollToDismissCanceled && runOnJS(onScrollToDismissCanceled)()
        }
      })
      .withRef(panGestureRef)

    const scrollHandler = useAnimatedScrollHandler((event) => {
      if (!hasScrollToTopCallback.value) {
        scrollViewPosition.value = event.contentOffset.y
      }
    })

    const handleDismiss = (callBack?: () => void): void => {
      isDismissed.current = true
      slideDown(() => {
        onDismiss()
        typeof callBack === "function" && callBack()
      })
    }

    const scrollToTop = (callback?: () => void, duration?: number) => {
      if (scrollViewPosition.value <= 0 && callback) {
        if (duration) {
          setTimeout(() => {
            callback()
          }, duration)
        } else {
          callback()
        }
        return
      }
      if (callback) {
        hasScrollToTopCallback.value = true
      }
      scrollViewPosition.value = withTiming(
        0,
        { duration: duration || 200 },
        () => {
          if (callback) {
            runOnJS(callback)()
            hasScrollToTopCallback.value = false
          }
        }
      )
    }

    useAnimatedReaction(
      () => scrollViewPosition.value,
      (currentValue) => {
        scrollTo(scrollViewRef, 0, currentValue, false)
      }
    )

    useImperativeHandle(ref, () => ({
      slideDown: handleDismiss,
      scrollToTop,
    }))

    const onDismissOnBackground = (): void => {
      canDismiss && handleDismiss()
    }

    return (
      <Wrapper style={wrapperStyle}>
        <TouchableWithoutFeedback onPress={onDismissOnBackground}>
          <BackgroundEmptyView
            entering={FadeIn.duration(SLIDE_DURATION)}
            style={backgroundStyle}
          />
        </TouchableWithoutFeedback>

        <AlertStatusBarAuto />
        <HandleBackPress
          canDismiss={canDismiss || false}
          onDismiss={handleDismiss}
        />
        <GestureDetector gesture={panMain}>
          <Container
            entering={SlideInEntering}
            exiting={SlideOutExiting}
            layout={layout}
            style={[
              hardShadow,
              {
                transform: [{ translateY }],
              },
              containerStyle,
            ]}
            insetTop={insetTop}
            isFullScreen={fullScreenView}
            ref={containerRef}
          >
            <ScrollViewWrapper
              layout={layout}
              insetBottom={noInsetBottom ? 0 : insetBottom}
              style={scrollViewContainerStyle}
            >
              <AnimatedFlatList
                // key={String(
                //   !!(
                //     Array.isArray(flatListProps.data) ? flatListProps.data : []
                //   ).length
                // )}
                // eslint-disable-next-line react/jsx-props-no-spreading
                {...flatListProps}
                animatedProps={animatedProps}
                ref={scrollViewRef}
                simultaneousHandlers={[panGestureRef]}
                scrollEventThrottle={1}
                onScroll={scrollHandler}
                showsVerticalScrollIndicator={false}
                scrollEnabled={!lockScroll}
                keyboardShouldPersistTaps={keyboardShouldPersistTaps}
              />
            </ScrollViewWrapper>
            {!!outsideScrollViewChildren && outsideScrollViewChildren}
            {canDismiss && !hideSlidePill && <Pill top={10} />}
          </Container>
        </GestureDetector>
      </Wrapper>
    )
  }
)

export const SlideUpWrapperList = React.memo(
  SlideUpWrapperListComponent,
  (prevProps, nextProps) => {
    return _.isEqual(nextProps, prevProps)
  }
)
// SlideUpWrapperList.whyDidYouRender = {
//   logOnDifferentValues: false,
//   customName: "SlideUpWrapperList",
//   diffNameColor: "red",
// }
