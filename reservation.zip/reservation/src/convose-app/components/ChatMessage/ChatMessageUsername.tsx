import React, { PropsWithChildren } from "react"
import { useTheme } from "styled-components"

import { TextWithStroke } from "../TextWithStroke"

type Props = {
  color?: string
  hasStroke?: boolean
}
const ChatMessageUsernameComponent: React.FC<PropsWithChildren<Props>> = ({
  color,
  hasStroke,
  children,
}) => {
  const theme = useTheme()
  const fill = color || theme.chatInfo
  return (
    <TextWithStroke color={fill} hasStroke={hasStroke}>
      {children}
    </TextWithStroke>
  )
}
export const ChatMessageUsername = React.memo(ChatMessageUsernameComponent)
