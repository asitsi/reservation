/* eslint-disable @typescript-eslint/no-explicit-any, @typescript-eslint/no-var-requires, global-require, complexity */
import React from "react"
import { connect } from "react-redux"

import {
  AudioVolumeInfo,
  ConnectionChangedReasonType,
  ConnectionStateType,
  RemoteAudioState,
  RemoteAudioStateReason,
  RemoteVideoState,
  RemoteVideoStateReason,
} from "react-native-agora"
import { OrderedMap } from "immutable"

import {
  millisToMinutesAndSeconds,
  quickUuid,
  startProximityEngine,
  stopProximityEngine,
} from "convose-lib/utils"
import { State } from "convose-lib"
import {
  AgoraUuid,
  AgoraUuidType,
  AudioSetting,
  CallDisplayText,
  CallingAction,
  CallSignal,
  JoinCall,
  Peer,
  selectAudioSetting,
  selectCallingChannel,
  selectCallingChatId,
  selectInAnotherCall,
  selectIsCalling,
  selectIsGroup,
  selectJoinCall,
  selectPeers,
  SetMuteType,
  SetSpeakingType,
  SetVideoType,
} from "convose-lib/calling"
import {
  ChatSummary,
  IS_SPEAKING_VOLUME_THRESHOLD,
  MessageType,
  checkIsGroupByChannel,
  parseCallUsers,
} from "convose-lib/chat"
import {
  getAgoraToken,
  clearAgoraChannel,
  getCallingEngine,
  iSharedScreenPeer,
  checkIsSpeakerOn,
  renewAgoraToken,
} from "convose-lib/services/agora"
import { selectChatSummary } from "convose-lib/users-list/selector"
import { addUserToGroupCall, publishMessage } from "convose-lib/users-list/dao"
import { User } from "convose-lib/user"

function getSizeOfArray<T>(arr: Array<T>): number {
  if (!Array.isArray(arr)) {
    return 0
  }
  return arr.length
}
function getTotalAudienceCount(
  chatSummary: ChatSummary | null,
  peers: OrderedMap<AgoraUuid, Peer>
): number {
  const defaultSize = peers.size
  if (!chatSummary) {
    return defaultSize
  }
  const { call_users: callUsers } = chatSummary
  if (!callUsers) {
    return defaultSize
  }
  const usersInCall = parseCallUsers(callUsers)
  return getSizeOfArray(usersInCall)
}

function checkIsPeerActive(peer: Peer) {
  return !peer.isMuted
}

type PeerVolume = {
  agoraUuid: number
  isSpeaking: boolean
}
const hasPeerVolume = (item: PeerVolume | undefined): item is PeerVolume => {
  return !!item
}
const ONE_MINUTE = 60000
const AUTO_END_TIME_OUT = ONE_MINUTE
const INACTIVITY_AUTO_END_TIME_OUT = ONE_MINUTE * 5

type StateToProps = {
  readonly channel: string
  readonly chatId: string
  readonly peers: OrderedMap<AgoraUuid, Peer>
  readonly isCalling: boolean
  readonly isGroup: boolean
  readonly joinCall: JoinCall
  readonly chatSummary: ChatSummary | null
  readonly me: User
  readonly audioSetting: AudioSetting
  readonly inAnotherCall: { username?: string; avatar?: string }
}

type CallingState = {
  readonly durationTime: string
}

type DispatchToProps = {
  readonly setJoinCallSuccessful: (currentTime: number) => void
  readonly setPeerJoinIn: (props: AgoraUuidType) => void
  readonly setVideoMode: (props: SetVideoType) => void
  readonly setMuteMode: (props: SetMuteType) => void
  readonly setPeerOffline: (props: AgoraUuidType) => void
  readonly setPeersVolume: (props: SetSpeakingType) => void
  readonly setCallDisplayText: (displayText: string) => void
  readonly callingChannelLeft: () => void
  readonly setSpeakerMode: (payload: { speakerMode: number }) => void
  readonly setMeIsSpeaking: (isSpeaking: boolean) => void
  readonly autoJoinOnSignInSuccess: () => void
}

type CallingNotificationType = StateToProps & DispatchToProps

class CallingEngineComponent extends React.PureComponent<
  CallingNotificationType,
  CallingState
> {
  private autoHangupTimeoutId!: ReturnType<typeof setTimeout> | null

  private inactivityTimeout!: ReturnType<typeof setTimeout> | undefined

  constructor(props: CallingNotificationType) {
    super(props)
    const { joinCall } = this.props
    this.state = {
      // eslint-disable-next-line react/no-unused-state
      durationTime: millisToMinutesAndSeconds(Date.now() - joinCall.joinedTime),
    }
  }

  public componentDidMount() {
    const {
      setJoinCallSuccessful,
      callingChannelLeft,
      setSpeakerMode,
      setVideoMode,
      setMuteMode,
      setPeerOffline,
      setPeerJoinIn,
      peers,
      autoJoinOnSignInSuccess,
    } = this.props
    const callingEngine = getCallingEngine()
    callingEngine.registerEventHandler({
      onJoinChannelSuccess: (connection) => {
        if (
          connection.channelId &&
          checkIsGroupByChannel(connection.channelId)
        ) {
          addUserToGroupCall(connection.channelId)
        }
        setJoinCallSuccessful(0)
        autoJoinOnSignInSuccess()
        // this.updateSpeaker()
      },
      onRemoteVideoStateChanged: (
        _,
        uid: number,
        state: RemoteVideoState,
        reason: RemoteVideoStateReason
      ) => {
        if (
          reason === RemoteVideoStateReason.RemoteVideoStateReasonRemoteOffline
        ) {
          return
        }
        setVideoMode({
          agoraUuid: uid,
          isVideoEnabled: !(state === 0 || state === 4),
        })
      },
      onRemoteAudioStateChanged: (
        _,
        uid: number,
        state: RemoteAudioState,
        reason: RemoteAudioStateReason
      ) => {
        if (
          iSharedScreenPeer(uid) ||
          reason === RemoteAudioStateReason.RemoteAudioReasonRemoteOffline
        ) {
          return
        }
        const isMuted = !!(state === 0 || state === 4)
        const peer = peers.get(uid)

        if (!peer || peer?.isMuted !== isMuted) {
          setMuteMode({
            agoraUuid: uid,
            isMuted: !!(state === 0 || state === 4),
          })
        }
      },
      onUserOffline: (_, uid: number) => {
        setPeerOffline({
          agoraUuid: uid,
        })
      },
      // add peer to state
      onUserJoined: (_, uid: number) => {
        // this.updateSpeaker()
        setPeerJoinIn({
          agoraUuid: uid,
        })
      },
      onLeaveChannel: () => {
        this.clearAutoHangupTimeout()
        this.clearInactivityTimeout()
        callingChannelLeft()
      },
      onAudioVolumeIndication: (_, speakers: AudioVolumeInfo[]) => {
        this.setPeersVolume(speakers)
      },
      onAudioRoutingChanged: (routing: number) => {
        setSpeakerMode({ speakerMode: routing })
      },
      onTokenPrivilegeWillExpire: () => {
        this.renewAgoraToken()
      },
      onConnectionStateChanged: (
        _,
        state: ConnectionStateType,
        reason: ConnectionChangedReasonType
      ) => {
        if (
          reason === ConnectionChangedReasonType.ConnectionChangedTokenExpired
        ) {
          this.renewAgoraToken()
        }
      },
      // onError: (err: ErrorCodeType, msg: string) => {
      //   console.log(JSON.stringify({ err, msg }, null, 2))
      // },
    })
  }

  public async componentDidUpdate(prevProps: CallingNotificationType) {
    const {
      joinCall,
      peers,
      isCalling,
      setCallDisplayText,
      chatSummary,
      me,
      audioSetting,
      isGroup,
      inAnotherCall,
      chatId,
      channel,
    } = this.props
    if (!channel && !!prevProps.channel) {
      // if banner is not showing, we should kick user out of agora
      clearAgoraChannel()
    }
    const isHost = audioSetting.isAudioEnabled
    const prevIsHost = prevProps.audioSetting.isAudioEnabled
    const activePeerSize = peers.filter(checkIsPeerActive).size
    const prevActivePeerSize = prevProps.peers.filter(checkIsPeerActive).size
    const total = activePeerSize + getTotalAudienceCount(chatSummary, peers)
    const prevTotal =
      prevActivePeerSize + getTotalAudienceCount(prevProps.chatSummary, peers)
    if (inAnotherCall?.username) {
      clearAgoraChannel().then()
    }
    if (!prevProps.joinCall.isJoined && joinCall.isJoined && total === 0) {
      !this.autoHangupTimeoutId &&
        (this.autoHangupTimeoutId = setTimeout(() => {
          const callNoAnswerMessage = {
            data: "No answer",
            action: CallSignal.callEndNoAnswer,
            isTyping: false,
            sender: me.uuid,
            avatar: me?.avatar,
            senderUsername: me.username,
            message_type: MessageType.Call,
            uuid: quickUuid(),
          }
          clearAgoraChannel().then()
          setCallDisplayText(CallDisplayText.noAnswer)
          publishMessage(callNoAnswerMessage, chatId)
        }, AUTO_END_TIME_OUT))
    }
    if (
      (joinCall.isJoined &&
        activePeerSize === 0 &&
        !isHost &&
        (prevActivePeerSize !== 0 || prevIsHost)) ||
      (!prevProps.joinCall.isJoined &&
        joinCall.isJoined &&
        activePeerSize === 0 &&
        !isHost)
    ) {
      this.inactivityEndCall()
    }

    if (
      prevActivePeerSize === 0 &&
      !prevIsHost &&
      (activePeerSize !== 0 || isHost)
    ) {
      this.clearAutoHangupTimeout()
      this.clearInactivityTimeout()
    }

    if (
      (prevProps.peers.size === 0 && total > 0) ||
      (prevProps.isCalling && !isCalling)
    ) {
      this.clearAutoHangupTimeout()
    }
    if (!isGroup && prevTotal !== 0 && total === 0 && joinCall.isJoined) {
      clearAgoraChannel().then()
      setCallDisplayText(CallDisplayText.callEnded)
    }
    if (!prevProps.joinCall.isJoined && joinCall.isJoined) {
      startProximityEngine()
    }
    if (prevProps.joinCall.isJoined && !joinCall.isJoined) {
      stopProximityEngine()
    }
  }

  public componentWillUnmount() {
    this.clearAutoHangupTimeout()
  }

  private setPeersVolume(speakers: AudioVolumeInfo[]) {
    if (!Array.isArray(speakers)) {
      return
    }
    const { setMeIsSpeaking, peers, audioSetting, setPeersVolume } = this.props
    const mySpeakerInfo = speakers.find((speaker) => speaker.uid === 0)
    if (mySpeakerInfo && audioSetting.isAudioEnabled) {
      const mySpeakerThreshold = checkIsSpeakerOn(audioSetting.speakerMode)
        ? IS_SPEAKING_VOLUME_THRESHOLD - 30
        : IS_SPEAKING_VOLUME_THRESHOLD
      const wasSpeaking = audioSetting.isSpeaking
      const isSpeaking = (mySpeakerInfo.volume || 0) > mySpeakerThreshold
      const shouldUpdateMeState = wasSpeaking !== isSpeaking
      shouldUpdateMeState && setMeIsSpeaking(isSpeaking)
    }
    const peerVolumes = speakers
      .map((speaker) => {
        if (!speaker.uid) {
          return undefined
        }
        const peer = peers.get(speaker.uid)
        if (!peer) {
          return undefined
        }
        const wasSpeaking = !!peer.isSpeaking
        const isSpeaking = (speaker.volume || 0) > IS_SPEAKING_VOLUME_THRESHOLD
        const shouldUpdatePeerState = wasSpeaking !== isSpeaking
        if (shouldUpdatePeerState) {
          return {
            agoraUuid: peer.rawAgoraUuid,
            isSpeaking,
          }
        }
        return undefined
      })
      .filter(hasPeerVolume)
    peerVolumes.forEach(setPeersVolume)
  }

  private inactivityEndCall = () => {
    const { me, setCallDisplayText, chatId } = this.props
    const inactivityEndCallMessage = {
      data: CallDisplayText.inactivityEndCall,
      action: CallSignal.inactivityEndCall,
      isTyping: false,
      sender: me.uuid,
      avatar: me?.avatar,
      senderUsername: me.username,
      message_type: MessageType.Call,
      uuid: quickUuid(),
    }
    !this.inactivityTimeout &&
      (this.inactivityTimeout = setTimeout(() => {
        clearAgoraChannel().then()
        setCallDisplayText(CallDisplayText.inactivityEndCall)
        publishMessage(inactivityEndCallMessage, chatId)
      }, INACTIVITY_AUTO_END_TIME_OUT))
  }

  public clearInactivityTimeout = () => {
    if (this.inactivityTimeout) {
      clearTimeout(this.inactivityTimeout)
      this.inactivityTimeout = undefined
    }
  }

  public clearAutoHangupTimeout = () => {
    this.autoHangupTimeoutId && clearTimeout(this.autoHangupTimeoutId)
    this.autoHangupTimeoutId = null
  }

  public renewAgoraToken = async () => {
    const { me, channel } = this.props
    const { authentication_token: authenticationToken = "", id } = me
    const agoraToken = await getAgoraToken({
      authenticationToken,
      id,
      channelName: channel,
    })
    renewAgoraToken(agoraToken.token)
  }

  // public async updateSpeaker() {
  //   const { audioSetting } = this.props
  //   const { speakerMode } = audioSetting
  //   try {
  //     await toggleAgoraSpeaker(speakerMode)
  //   } catch (error) {
  //     //
  //   }
  // }

  public render() {
    return null
  }
}

const mapStateToProps = (state: State): StateToProps => ({
  me: state.user,
  channel: selectCallingChannel(state),
  chatId: selectCallingChatId(state),
  peers: selectPeers(state),
  isCalling: selectIsCalling(state),
  isGroup: selectIsGroup(state),
  joinCall: selectJoinCall(state),
  chatSummary: selectChatSummary(state.calling.callingChannel)(state),
  audioSetting: selectAudioSetting(state),
  inAnotherCall: selectInAnotherCall(state),
})

const mapDispatchToProps: DispatchToProps = {
  setJoinCallSuccessful: CallingAction.setJoinCallSuccessful,
  setCallDisplayText: CallingAction.setDisplayText,
  callingChannelLeft: CallingAction.callingChannelLeft,
  setSpeakerMode: CallingAction.setSpeakerModeSuccess,
  setMeIsSpeaking: CallingAction.setMeIsSpeaking,
  setPeerJoinIn: CallingAction.setPeerJoinIn,
  setVideoMode: CallingAction.setVideoMode,
  setMuteMode: CallingAction.setMuteMode,
  setPeerOffline: CallingAction.setPeerOffline,
  setPeersVolume: CallingAction.setPeersVolume,
  autoJoinOnSignInSuccess: CallingAction.autoJoinOnSignInSuccess,
}

export const CallingEngine = connect(
  mapStateToProps,
  mapDispatchToProps
)(CallingEngineComponent)
