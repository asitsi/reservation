import React, { useCallback, useEffect, useRef } from "react"
import { Appearance, NativeEventSubscription, AppState } from "react-native"
import { useDispatch, useSelector } from "react-redux"

import { AppAction, selectDarkMode, selectIsDarkMode } from "convose-lib/app"
import { changeNavigationBarColor } from "convose-lib/utils"
import { debounce } from "lodash"

import { color } from "convose-styles"

const ThemeHandlerComponent: React.FC = () => {
  const dispatch = useDispatch()
  const changeTheme = useCallback(
    (isDark: boolean) => {
      dispatch(AppAction.changeTheme(isDark))
    },
    [dispatch]
  )
  const isDarkMode = useSelector(selectIsDarkMode)
  const darkMode = useSelector(selectDarkMode)
  const appearanceListener = useRef<NativeEventSubscription | null>(null)
  /* Bug with Appearance.addChangeListener. it sends wrong info when ios app goes to background */
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const debouncedChangeTheme = useCallback(debounce(changeTheme, 500), [])

  useEffect(() => {
    const appState = AppState.addEventListener("change", (state) => {
      if (state === "active" && darkMode === "system") {
        const systemTheme = Appearance.getColorScheme()
        const isSystemDark = systemTheme === "dark"
        if (isDarkMode !== isSystemDark) {
          changeTheme(isSystemDark)
        }
      }
    })
    return () => appState.remove()
  }, [changeTheme, darkMode, isDarkMode])

  useEffect(() => {
    if (isDarkMode === null) {
      const systemColorScheme = Appearance.getColorScheme()
      changeTheme(systemColorScheme === "dark")
    }
    if (isDarkMode) {
      changeNavigationBarColor(color.darkLevel1, false)
    } else {
      changeNavigationBarColor(color.white, true)
    }
  }, [isDarkMode, changeTheme])

  useEffect(() => {
    if (darkMode === "system") {
      appearanceListener.current = Appearance.addChangeListener(
        ({ colorScheme }) => {
          debouncedChangeTheme(colorScheme === "dark")
        }
      )
    }
    return () => {
      if (appearanceListener.current) {
        appearanceListener.current.remove()
        appearanceListener.current = null
      }
    }
  }, [darkMode, debouncedChangeTheme])
  return null
}

export const ThemeHandler = React.memo(ThemeHandlerComponent)
