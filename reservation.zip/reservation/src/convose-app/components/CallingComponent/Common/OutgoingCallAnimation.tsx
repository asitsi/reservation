import React, { useEffect } from "react"
import MaterialIcons from "react-native-vector-icons/MaterialIcons"
import {
  cancelAnimation,
  runOnJS,
  useAnimatedStyle,
  useSharedValue,
  withDelay,
  withTiming,
} from "react-native-reanimated"

import { color } from "convose-styles"

import { CircleButton } from "../../CircleButton"
import { OutgoingCallWrapper, RippleCircle } from "./Styled"

const START_ANIMATION_VALUE = 1
const END_ANIMATION_VALUE = 1.7
const duration = 2000

export const OutgoingCallAnimation: React.FunctionComponent = () => {
  const rippleOneOffset = useSharedValue(START_ANIMATION_VALUE)
  const rippleTwoOffset = useSharedValue(START_ANIMATION_VALUE)
  const rippleThreeOffset = useSharedValue(START_ANIMATION_VALUE)
  const rippleOneStyle = useAnimatedStyle(() => ({
    transform: [
      {
        scale: rippleOneOffset.value,
      },
    ],
    opacity: END_ANIMATION_VALUE - rippleOneOffset.value,
  }))
  const rippleTwoStyle = useAnimatedStyle(() => ({
    transform: [
      {
        scale: rippleTwoOffset.value,
      },
    ],
    opacity: END_ANIMATION_VALUE - rippleTwoOffset.value,
  }))
  const rippleThreeStyle = useAnimatedStyle(() => ({
    transform: [
      {
        scale: rippleThreeOffset.value,
      },
    ],
    opacity: END_ANIMATION_VALUE - rippleThreeOffset.value,
  }))
  useEffect(() => {
    const startAnimation = () => {
      rippleOneOffset.value = START_ANIMATION_VALUE
      rippleTwoOffset.value = START_ANIMATION_VALUE
      rippleThreeOffset.value = START_ANIMATION_VALUE
      rippleOneOffset.value = withTiming(END_ANIMATION_VALUE, { duration })
      rippleTwoOffset.value = withDelay(
        300,
        withTiming(END_ANIMATION_VALUE, { duration })
      )
      rippleThreeOffset.value = withDelay(
        600,
        withTiming(END_ANIMATION_VALUE, { duration }, () => {
          runOnJS(startAnimation)()
        })
      )
    }
    startAnimation()
    return () => {
      cancelAnimation(rippleOneOffset)
      cancelAnimation(rippleTwoOffset)
      cancelAnimation(rippleThreeOffset)
    }
  }, [rippleOneOffset, rippleThreeOffset, rippleTwoOffset])
  return (
    <OutgoingCallWrapper>
      <RippleCircle style={rippleOneStyle} />
      <RippleCircle style={rippleTwoStyle} />
      <RippleCircle style={rippleThreeStyle} />
      <CircleButton backgroundColor={color.green}>
        <MaterialIcons name="call" size={28} color="white" />
      </CircleButton>
    </OutgoingCallWrapper>
  )
}
