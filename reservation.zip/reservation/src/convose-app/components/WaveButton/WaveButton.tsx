import React, { memo, useCallback, useMemo, useState } from "react"
import Animated, {
  runOnJS,
  useAnimatedStyle,
  useSharedValue,
  withDelay,
  withSequence,
  withTiming,
} from "react-native-reanimated"
import { useDispatch, useSelector } from "react-redux"

import { selectMyUuid } from "convose-lib/user"
import {
  ChatAction,
  MessageToPublish,
  MessageType,
  ReplyMessageType,
} from "convose-lib/chat"
import { quickUuid } from "convose-lib/utils"
import { AppAction, selectWaveCount } from "convose-lib/app"
import { WAVE_LIMIT, isWaveCountInSameDay } from "convose-lib/app/utils"
import { StopSvg } from "../../../assets/svg/Stop"
import { WaveSvg } from "../../../assets/svg/Wave"
import {
  Container,
  StyledPressable,
  WaveContainer,
  WaveText,
  WaveTitle,
} from "./Styled"
import { convoseAlertRef } from "../../RootConvoseAlert"

type Props = {
  onPress?: () => void
  size?: number
  isWaveBack?: boolean
  onDisappeared?: () => void
  text?: string
  noWaveTextFeedback?: boolean
  disable?: boolean
  fireOnPressOnDisabled?: boolean
}
const WaveButtonComponent: React.FC<Props> = ({
  onPress,
  size = 38,
  isWaveBack,
  onDisappeared,
  text,
  noWaveTextFeedback,
  disable,
  fireOnPressOnDisabled,
}) => {
  const [showing, setShowing] = useState(true)
  const rotateOffset = useSharedValue(0)
  const scaleOffset = useSharedValue(1)
  const textScaleOffset = useSharedValue(0)
  const textOpacityOffset = useSharedValue(1)
  const translateXOffset = useSharedValue(0)
  const waveStyle = useAnimatedStyle(() => ({
    transform: [
      {
        rotate: `${rotateOffset.value}deg`,
      },
    ],
  }))
  const pressableStyle = useAnimatedStyle(() => ({
    transform: [
      {
        scale: scaleOffset.value,
      },
      { translateX: translateXOffset.value },
    ],
  }))
  const waveTextStyle = useAnimatedStyle(() => ({
    transform: [
      {
        scale: textScaleOffset.value,
      },
    ],
    opacity: textOpacityOffset.value,
  }))

  const handleOnDisappeared = useCallback(() => {
    !!onDisappeared && onDisappeared()
    setShowing(false)
  }, [onDisappeared])
  const onPressEnabled = useCallback(() => {
    rotateOffset.value = withSequence(
      withTiming(30, { duration: 100 }),
      withTiming(-10, { duration: 150 }),
      withTiming(0, { duration: 150 }, () => {
        scaleOffset.value = withTiming(0, { duration: 100 })
        textScaleOffset.value = withTiming(1, { duration: 100 }, () => {
          if (noWaveTextFeedback) {
            runOnJS(handleOnDisappeared)()
          }
        })
        if (!noWaveTextFeedback) {
          textOpacityOffset.value = withDelay(
            2000,
            withTiming(0, { duration: 300 }, () => {
              runOnJS(handleOnDisappeared)()
            })
          )
        }
      })
    )
    onPress && onPress()
  }, [
    handleOnDisappeared,
    noWaveTextFeedback,
    onPress,
    rotateOffset,
    scaleOffset,
    textOpacityOffset,
    textScaleOffset,
  ])
  const onPressDisabled = useCallback(() => {
    translateXOffset.value = withSequence(
      withTiming(3, { duration: 50 }),
      withTiming(-3, { duration: 50 }),
      withTiming(3, { duration: 50 }),
      withTiming(0, { duration: 50 }, () => {
        fireOnPressOnDisabled && onPress && runOnJS(onPress)()
      })
    )
  }, [fireOnPressOnDisabled, onPress, translateXOffset])
  const handleOnPress = useCallback(() => {
    if (disable) {
      onPressDisabled()
      return
    }
    onPressEnabled()
  }, [disable, onPressDisabled, onPressEnabled])

  if (!showing) {
    return null
  }
  return (
    <Container>
      <StyledPressable
        // eslint-disable-next-line react-perf/jsx-no-new-array-as-prop
        style={[
          ({ pressed }: { pressed: boolean }) => ({
            opacity: pressed ? 0.5 : 1,
          }),
          pressableStyle,
        ]}
        onPress={handleOnPress}
        size={size}
      >
        <WaveContainer size={size}>
          <Animated.View style={waveStyle}>
            <WaveSvg height={size / 2} color="white" />
          </Animated.View>
        </WaveContainer>
        {!!text && <WaveTitle>{text}</WaveTitle>}
      </StyledPressable>
      {!noWaveTextFeedback && (
        <WaveText
          numberOfLines={isWaveBack ? 3 : 2}
          allowFontScaling
          style={waveTextStyle}
          adjustsFontSizeToFit
          textBreakStrategy="simple"
        >
          You waved {isWaveBack ? "back" : ""}
        </WaveText>
      )}
    </Container>
  )
}

export const WaveButton = memo(WaveButtonComponent)

export const useWaveButton = (
  chatChannel: string,
  reply?: ReplyMessageType
) => {
  const dispatch = useDispatch()
  const waveCount = useSelector(selectWaveCount)
  const myUuid = useSelector(selectMyUuid)
  const publishMessage = useCallback(
    (message: MessageToPublish, channel: string) =>
      dispatch(ChatAction.publishMessage(message, channel)),
    [dispatch]
  )
  const responseToWave = useCallback(
    (channel: string, messageUuid: string) =>
      dispatch(ChatAction.responseToWave(channel, messageUuid)),
    [dispatch]
  )
  const addWaveCount = useCallback(
    () => dispatch(AppAction.addWaveCount()),
    [dispatch]
  )

  const canWave = useMemo(() => {
    return !(
      waveCount.count >= WAVE_LIMIT &&
      isWaveCountInSameDay(waveCount.date) &&
      !reply?.reply_to_id
    )
  }, [reply?.reply_to_id, waveCount.count, waveCount.date])
  const onPress = useCallback(() => {
    const message: MessageToPublish = {
      data: "👋",
      isTyping: false,
      message_type: MessageType.Wave,
      sender: myUuid,
      uuid: quickUuid(),
      ...(reply || {}),
    }
    if (reply?.reply_to_id) {
      responseToWave(chatChannel, reply.reply_to_id)
    } else if (!canWave) {
      convoseAlertRef?.show({
        icon: <StopSvg height={47} />,
        title: "Slow down",
        description: `You can only wave ${WAVE_LIMIT} times a day`,
        buttons: [
          {
            title: "Ok",
          },
        ],
        canDismiss: true,
      })
    } else {
      addWaveCount()
    }
    publishMessage(message, chatChannel)
  }, [
    addWaveCount,
    canWave,
    chatChannel,
    myUuid,
    publishMessage,
    reply,
    responseToWave,
  ])
  return { onPress, canWave }
}
