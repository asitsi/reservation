import React from "react"
import Animated, { ZoomIn } from "react-native-reanimated"
import { EmojiIcon, EmojiItem, EmojisContainer } from "./Styled"

const emojis = ["❤️", "😂", "😢", "😡", "👍", "🤩", "😯"]

type EmojiProps = {
  onPress: (emoji: string) => void
  emoji: string
  index: number
}
const Emoji: React.FC<EmojiProps> = ({ emoji, onPress, index }) => {
  const handleOnPress = () => {
    onPress(emoji)
  }
  return (
    // <Animated.View entering={ZoomIn.delay(index * 20).duration(100)}>
    <Animated.View
      entering={ZoomIn.delay(index * 20)
        .springify(100)
        .damping(5)}
    >
      <EmojiItem onPress={handleOnPress}>
        <EmojiIcon>{emoji}</EmojiIcon>
      </EmojiItem>
    </Animated.View>
  )
}

type Props = {
  onAddReaction: (emoji: string) => void
}
const EmojisComponent: React.FC<Props> = ({ onAddReaction }) => {
  return (
    <EmojisContainer>
      {emojis.map((emoji, index) => (
        <Emoji
          key={emoji}
          emoji={emoji}
          onPress={onAddReaction}
          index={index}
        />
      ))}
    </EmojisContainer>
  )
}
export const Emojis = React.memo(EmojisComponent)
