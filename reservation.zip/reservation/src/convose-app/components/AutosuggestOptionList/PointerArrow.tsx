import React from "react"
import { Path } from "react-native-svg"
import { useSelector } from "react-redux"
import { selectIsDarkMode } from "convose-lib/app"
import { getRatio, getWidth } from "../../../assets/svg/utils"
import { StyledSvg } from "./Styled"

type Props = { height?: number }

const defaultHeight = 116
const defaultWidth = 40
const ratio = getRatio(defaultHeight, defaultWidth)

const PointerArrowComponent: React.FunctionComponent<Props> = ({ height }) => {
  const isDarkMode = useSelector(selectIsDarkMode)
  const fillColor = isDarkMode ? "#ffffff" : "#1D1D1B"
  const svgHeight = height || defaultHeight
  const svgWidth = height ? getWidth(ratio, height) : defaultWidth
  return (
    <StyledSvg
      width={svgWidth}
      height={svgHeight}
      viewBox="0 0 40 116"
      fill="none"
    >
      <Path
        d="M39.1355 112.026L39.1353 112.03C39.134 112.035 39.1328 112.04 39.1305 112.046C39.0905 112.415 38.9641 112.773 38.7999 113.117C38.7506 113.223 38.6949 113.314 38.6359 113.412C38.4904 113.656 38.3164 113.883 38.1098 114.093C38.0354 114.172 37.9711 114.254 37.887 114.326C37.8448 114.364 37.8165 114.409 37.7735 114.444C37.5081 114.657 37.2185 114.826 36.9186 114.955C36.8886 114.97 36.8542 114.97 36.8223 114.984C36.4857 115.118 36.1411 115.186 35.7932 115.213C35.7446 115.216 35.6999 115.243 35.6503 115.246L12.9285 115.868C11.1892 115.916 9.92416 114.557 10.1049 112.826C10.2865 111.099 11.8445 109.66 13.5878 109.612L25.8376 109.275C16.8897 101.667 11.0096 91.55 10.7354 91.0691C-8.27106 60.6053 -1.06594 20.3541 26.7959 1.34109C28.1756 0.399921 29.8844 0.534086 30.8379 1.5877C30.9399 1.7004 31.0324 1.82168 31.1174 1.95367C31.9772 3.3338 31.4394 5.29422 29.9156 6.33675C5.09803 23.2716 -1.02899 59.592 16.3064 87.3811C16.3802 87.5135 22.451 97.9708 31.2091 105.064L28.3239 91.0873C27.9871 89.4484 29.1076 87.6743 30.8244 87.1204C32.5424 86.5636 34.201 87.4452 34.548 89.0805L39.0962 111.112C39.1553 111.412 39.1666 111.719 39.1355 112.026Z"
        fill={fillColor}
      />
    </StyledSvg>
  )
}

export const PointerArrow = PointerArrowComponent
