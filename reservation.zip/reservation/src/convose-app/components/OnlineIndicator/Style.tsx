import { Props } from "convose-styles"
import styled from "styled-components/native"

export const IndicatorRing = styled.View`
  width: ${(props: { size: number }) => props.size}px;
  aspect-ratio: 1;
  border-radius: ${(props: { size: number }) => props.size}px;
  background-color: ${(props: Props & { isOnline: boolean }) =>
    props.isOnline ? props.theme.main.online : props.theme.main.offline};
  align-self: center;
  justify-self: center;
  align-items: center;
  justify-content: center;
`
export const Indicator = styled.View`
  width: ${(props: { size: number }) => props.size}px;
  aspect-ratio: 1;
  border-radius: ${(props: { size: number }) => props.size}px;
  background-color: ${(
    props: Props & {
      offlineIndicatorColor: string
      isOnline: boolean
    }
  ) =>
    props.isOnline
      ? props.theme.main.online
      : props.offlineIndicatorColor || props.theme.main.offline};
`
