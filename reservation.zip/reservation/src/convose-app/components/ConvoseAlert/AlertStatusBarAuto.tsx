import React from "react"
import { StatusBarAuto } from "../StatusBarAuto"

const AlertStatusBarAutoComponent: React.FC = () => {
  return <StatusBarAuto animated={false} />
}

export const AlertStatusBarAuto = React.memo(AlertStatusBarAutoComponent)
