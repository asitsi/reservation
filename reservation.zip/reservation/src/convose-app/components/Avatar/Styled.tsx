// import { TouchableOpacity, View } from "react-native"
import styled from "styled-components/native"
import FastImage from "react-native-fast-image"
import { AVATAR_SIZE, Props } from "convose-styles"

export const StyledAvatar = styled.View`
  background: transparent;
  overflow: hidden;
  height: ${(props: Props) => (props.height ? props.height : 60)}px;
  width: ${(props: Props) => (props.height ? props.height : 60)}px;
  border-radius: ${(props: Props & { noRadius: boolean }) => {
    if (props.noRadius) {
      return 0
    }
    return props.height ? props.height / 2 : 30
  }}px;
`
export const AvatarRing = styled(StyledAvatar)`
  border-width: ${(props: { showRing: boolean; ringSize: number }) =>
    props.showRing ? `${props.ringSize}px` : `0px`};
  border-color: ${(props: Props & { bgColor?: string; ringColor?: string }) => {
    if (props.ringColor) {
      return props.ringColor
    }
    if (props.bgColor && props.bgColor === "chatBoxBackground") {
      return props.theme.main.chatBoxBackground
    }
    if (props.bgColor === undefined) {
      return "transparent"
    }
    return props.theme.main.background
  }};
  background-color: ${(
    props: Props & { bgColor?: string; isGroup?: boolean; showRing: boolean }
  ) => {
    if (!props.showRing) {
      return undefined
    }
    if (props.bgColor && props.bgColor === "background") {
      return props.theme.main.background
    }
    if (props.bgColor && props.bgColor === "chatBoxBackground") {
      return props.theme.main.chatBoxBackground
    }
    if (props.bgColor === undefined) {
      return "transparent"
    }
    if (props.bgColor && props.bgColor !== "default") {
      return props.bgColor
    }
    if (props.isGroup) {
      return props.theme.main.groupChatBox
    }
    return undefined
  }};
`

export const StyledImage = styled(FastImage)`
  height: ${(props: Props) => (props.height ? props.height : 60)}px;
  width: ${(props: Props) => (props.height ? props.height : 60)}px;
  border-radius: ${(props: Props & { noRadius: boolean }) => {
    if (props.noRadius) {
      return 0
    }
    return props.height ? props.height / 2 : 30
  }}px;
`
export const GroupAvatarContainer = styled.TouchableOpacity`
  width: ${(props: Props) => (props.size ? props.size : AVATAR_SIZE)}px;
  height: ${(props: Props) => (props.size ? props.size : AVATAR_SIZE)}px;
`

export const GroupAvatarWrapper = styled.View`
  bottom: ${(props: Props) => (props.size ? props.size * 0.5 : AVATAR_SIZE)}px;
  left: ${(props: Props) => (props.size ? props.size * 0.25 : AVATAR_SIZE)}px;
`
