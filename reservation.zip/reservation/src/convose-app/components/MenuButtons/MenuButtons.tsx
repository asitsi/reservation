import React from "react"
import { useWindowDimensions } from "react-native"
import FontAwesome5 from "react-native-vector-icons/FontAwesome5"

import { DEFAULT_HIT_SLOP } from "convose-lib/utils"
import { color } from "convose-styles"
import {
  IconWrapper,
  MenuItemButton,
  MenuItemLabel,
  MenuWrapper,
} from "./Styled"

export type Item = {
  readonly onPress: () => void
  readonly label: string
  readonly icon: string | React.ReactNode
  readonly rightToLeft?: boolean
}
type MenuButtonsProps = {
  readonly items: ReadonlyArray<Item>
}
const size = 24
const renderItem = (
  item: Item,
  index: number,
  windowWidth: number,
  noMargin?: boolean
): React.ReactNode => (
  <MenuItemButton
    key={index}
    withMargin={!noMargin}
    onPress={item.onPress}
    hitSlop={DEFAULT_HIT_SLOP}
    rightToLeft={item.rightToLeft}
  >
    <IconWrapper>
      {typeof item.icon === "string" ? (
        <FontAwesome5 name={item.icon} size={size} color={color.black} />
      ) : (
        item.icon
      )}
    </IconWrapper>

    <MenuItemLabel windowWidth={windowWidth}>{item.label}</MenuItemLabel>
  </MenuItemButton>
)

export const MenuButtons: React.FC<MenuButtonsProps> = ({ items }) => {
  const { width } = useWindowDimensions()
  return (
    <MenuWrapper>
      {items.map((item, index) =>
        renderItem(item, index, width, items.length === 1 && items.length > 1)
      )}
    </MenuWrapper>
  )
}
