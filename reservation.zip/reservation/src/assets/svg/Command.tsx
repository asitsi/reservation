import React from "react"
import { Svg, Path } from "react-native-svg"
import { SvgProps } from "./types"

type Props = SvgProps & {
  strokeColor?: string
}
const CommandSvgComponent: React.FunctionComponent<Props> = ({
  color,
  height,
  strokeColor,
}) => {
  const svgSize = height || 19

  return (
    <Svg width={svgSize} height={svgSize} viewBox="0 0 19 19" fill="none">
      <Path
        d="M3.5 2.6H15.5C15.9971 2.6 16.4 3.00294 16.4 3.5V15.5C16.4 15.9971 15.9971 16.4 15.5 16.4H3.5C3.00294 16.4 2.6 15.9971 2.6 15.5V3.5C2.6 3.00294 3.00294 2.6 3.5 2.6ZM3.5 0.9C2.06406 0.9 0.9 2.06406 0.9 3.5V15.5C0.9 16.9359 2.06406 18.1 3.5 18.1H15.5C16.9359 18.1 18.1 16.9359 18.1 15.5V3.5C18.1 2.06406 16.9359 0.9 15.5 0.9H3.5Z"
        fill={color || "#458AF7"}
        stroke={strokeColor || "none"}
        strokeWidth="0.5"
      />
      <Path
        d="M13.671 5.52188C13.9592 5.15133 13.8924 4.61729 13.5219 4.32909C13.1513 4.04088 12.6173 4.10763 12.3291 4.47818L5.32909 13.4782C5.04088 13.8487 5.10763 14.3828 5.47818 14.671C5.84874 14.9592 6.38277 14.8924 6.67098 14.5219L13.671 5.52188Z"
        fill={color || "#458AF7"}
        stroke={strokeColor || "none"}
        strokeWidth="0.5"
        strokeLinecap="round"
      />
    </Svg>
  )
}

export const CommandSvg = React.memo(CommandSvgComponent)
