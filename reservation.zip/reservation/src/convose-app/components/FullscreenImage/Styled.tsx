import { StyleSheet } from "react-native"
import styled from "styled-components/native"
import Animated from "react-native-reanimated"

import { Props, width, height, CenteredText, font, color } from "convose-styles"

export const styles = StyleSheet.create({
  imageStyle: {
    width,
    height,
  },
})
export const FullscreenImageWrapper = styled(Animated.View)`
  position: absolute;
  height: 100%;
  width: 100%;
  align-items: center;
  justify-content: center;
  elevation: 101;
  z-index: 101;
  background-color: ${color.darkLevel1};
`

export const ButtonActionContainer = styled(Animated.View)`
  background-color: ${(props: Props) =>
    props.color ? props.color : props.theme.header};
  position: absolute;
  width: 100%;
  bottom: 0px;
`
export const ButtonAction = styled.View`
  height: 50px;
  margin-bottom: ${(props: { insetBottom: number }) => props.insetBottom}px;
  width: 100%;
  flex-direction: row;
  align-items: center;
  justify-content: center;
`
export const Action = styled.TouchableOpacity`
  padding-horizontal: 20px;
  justify-content: center;
  align-items: center;
`
export const ActionLabel = styled(CenteredText)`
  font-family: ${font.normal};
  font-size: 17px;
  color: ${(props: Props) => props.theme.mainBlue};
`
