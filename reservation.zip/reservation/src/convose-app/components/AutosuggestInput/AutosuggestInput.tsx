import React, {
  FunctionComponent,
  useCallback,
  useEffect,
  useRef,
  useState,
} from "react"
import _ from "lodash"
import { Keyboard, TextInput } from "react-native"
import { useSelector } from "react-redux"
import Ionicons from "react-native-vector-icons/Ionicons"
import { ZoomIn, ZoomOut } from "react-native-reanimated"
import { MaterialIndicator } from "react-native-indicators"

import { Interest, InterestType } from "convose-lib/interests"
import { selectIsDarkMode } from "convose-lib/app"
import { color } from "convose-styles"

import { convoseAlertRef } from "../../RootConvoseAlert"
import { NewInterestIcon } from "../../../assets/svg/NewInterest"
import {
  AddButton,
  AutosuggestWrapper,
  NewInterestConfirmationContainer,
  NewInterestConfirmationDescription,
  StyledAutosuggestInput,
} from "./Styled"

type NewInterestDescriptionProps = {
  interestName: string
}
const NewInterestDescription: React.FC<NewInterestDescriptionProps> = ({
  interestName,
}) => {
  return (
    <NewInterestConfirmationContainer>
      <NewInterestConfirmationDescription>
        This will add “{interestName}” to your profile & also to the main
        interests list (so others will be able to search for this interest too).
      </NewInterestConfirmationDescription>
    </NewInterestConfirmationContainer>
  )
}

export type AutosuggestInputProps = {
  readonly onAddInterest: (interest: Interest) => void
  readonly onSearch: (text: string) => void
  readonly searchResults: ReadonlyArray<Interest> | null
  readonly setInterestValue: (text: string) => void
  readonly interestValue: string
  readonly isLoadingInterests: boolean
}

const randomInterestList: ReadonlyArray<string> = [
  "English",
  "Football",
  "Swimming",
  "Paris, France",
  "Programming ",
]

export const AutosuggestInput: FunctionComponent<AutosuggestInputProps> = ({
  onAddInterest,
  onSearch,
  searchResults,
  interestValue,
  setInterestValue,
  isLoadingInterests,
}) => {
  const inputRef = useRef<TextInput>(null)
  const applyAddInterest = useRef(false)
  const [waitingToAddInterest, setWaitingToAddInterest] = useState(false)
  const [placeholder, setPlaceholder] = useState(randomInterestList[0])
  // eslint-disable-next-line react-hooks/exhaustive-deps
  // const debounceSearch = useCallback(
  //   _.debounce(onSearch, DEFAULT_DEBOUNCE_TIME),
  //   []
  // )
  useEffect(() => {
    onSearch(interestValue)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [interestValue])

  useEffect(() => {
    const timer = setInterval(
      () =>
        setPlaceholder(_.sample(randomInterestList) || randomInterestList[0]),
      2000
    )
    return () => {
      clearTimeout(timer)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const onNewInterestAlertClosed = () => {
    inputRef.current?.focus()
  }
  const handleOnPress = useCallback((): void => {
    const handleOnAddInterest = () => {
      onAddInterest({
        match: 0,
        name: interestValue.trim(),
        type: InterestType.General,
        avatar: null,
        color: "",
        id: 0,
      })
      setInterestValue("")
      onSearch("")
      applyAddInterest.current = false
      setWaitingToAddInterest(false)
    }
    if (!interestValue.replace(/\s/g, "").length) {
      setInterestValue("")
      onSearch("")
      return
    }
    if (isLoadingInterests) {
      setWaitingToAddInterest(true)
      applyAddInterest.current = true
      return
    }
    setWaitingToAddInterest(false)
    applyAddInterest.current = false
    const foundInterestInSearch = searchResults?.find(
      (interest) => interest.name.toLowerCase() === interestValue.toLowerCase()
    )
    if (foundInterestInSearch) {
      onAddInterest(foundInterestInSearch)
      return
    }
    Keyboard.dismiss()
    convoseAlertRef?.show({
      title: `Create new interest \n “${interestValue.trim()}”`,
      icon: <NewInterestIcon />,
      description: (
        <NewInterestDescription interestName={interestValue.trim()} />
      ),
      onDismiss: onNewInterestAlertClosed,
      buttons: [
        {
          title: "Add & Create",
          onPress: handleOnAddInterest,
        },
        {
          title: "Cancel",
          type: "cancel",
        },
      ],
    })
  }, [
    interestValue,
    isLoadingInterests,
    onAddInterest,
    onSearch,
    searchResults,
    setInterestValue,
  ])

  useEffect(() => {
    if (
      !isLoadingInterests &&
      waitingToAddInterest &&
      applyAddInterest.current
    ) {
      handleOnPress()
      applyAddInterest.current = false
    }
  }, [handleOnPress, isLoadingInterests, waitingToAddInterest])
  const handleChangeText = (text: string) => {
    if (waitingToAddInterest) {
      applyAddInterest.current = false
      setWaitingToAddInterest(false)
    }
    setInterestValue(text)
  }

  const isDarkMode = useSelector(selectIsDarkMode)

  return (
    <AutosuggestWrapper>
      <StyledAutosuggestInput
        placeholder={`E.g., ${placeholder}`}
        value={interestValue}
        onChangeText={handleChangeText}
        autoFocus
        onSubmitEditing={handleOnPress}
        spellCheck={false}
        autoCorrect={false}
        ref={inputRef}
        keyboardAppearance={isDarkMode ? "dark" : "light"}
        enterKeyHint="enter"
        blurOnSubmit={false}
      />
      {!!interestValue.replace(/\s/g, "").length && (
        <AddButton
          onPress={handleOnPress}
          entering={ZoomIn.duration(70)}
          exiting={ZoomOut.duration(70)}
        >
          {waitingToAddInterest ? (
            <MaterialIndicator size={23} color="white" />
          ) : (
            <Ionicons name="add" size={23} color={color.white} />
          )}
        </AddButton>
      )}
    </AutosuggestWrapper>
  )
}
