import React from "react"
import FastImage from "react-native-fast-image"
import { useTheme } from "styled-components"
import Animated, {
  useAnimatedStyle,
  useSharedValue,
} from "react-native-reanimated"

import { useSkeleton } from "../../Skeleton"
import PlayIcon from "../../../../assets/Icons/components/PlayIcon"
import ExpandIcon from "../../../../assets/Icons/components/ExpandIcon"
import NoPhotoIcon from "../../../../assets/Icons/components/NoPhotoIcon"
import {
  ActionButton,
  ButtonsContainer,
  ButtonsContainerBackground,
  PreviewImage,
} from "./Styled"

type Props = {
  uri: string
  videoId?: string
  onPlayPress?: () => void
  onOpenPress?: () => void
  imageRatio: number | null
}
const ImagePreviewComponent: React.FC<Props> = ({
  uri,
  videoId,
  onOpenPress,
  onPlayPress,
  imageRatio,
}) => {
  const theme = useTheme()

  const [animatedStyles, startLoading, stopLoading] = useSkeleton()
  const hasError = useSharedValue(false)

  const errorContainerStyled = useAnimatedStyle(() => ({
    position: "absolute",
    alignSelf: "center",
    opacity: hasError.value ? 0.5 : 0,
  }))

  const onLoadStart = () => {
    startLoading()
  }
  const onLoadEnd = () => {
    stopLoading()
  }
  const onError = () => {
    hasError.value = true
    stopLoading()
  }
  return (
    // eslint-disable-next-line react-perf/jsx-no-new-array-as-prop
    <Animated.View style={[animatedStyles, { justifyContent: "center" }]}>
      <PreviewImage
        // eslint-disable-next-line react-perf/jsx-no-new-object-as-prop
        source={{
          uri,
          priority: FastImage.priority.normal,
        }}
        resizeMode={FastImage.resizeMode.cover}
        onLoadStart={onLoadStart}
        onLoad={onLoadEnd}
        onError={onError}
        imageRatio={imageRatio}
      />
      <Animated.View style={errorContainerStyled}>
        <NoPhotoIcon height={120} color={theme.main.text} />
      </Animated.View>
      {!!videoId && (
        <ButtonsContainer>
          <ButtonsContainerBackground />
          <ActionButton onPress={onPlayPress} disabled={!onPlayPress}>
            <PlayIcon height={40} color="white" />
          </ActionButton>
          <ActionButton onPress={onOpenPress} disabled={!onOpenPress}>
            <ExpandIcon height={40} color="white" />
          </ActionButton>
        </ButtonsContainer>
      )}
    </Animated.View>
  )
}

export const ImagePreview = React.memo(ImagePreviewComponent)
