import React from "react"
import { connect } from "react-redux"

import {
  PushNotificationToken,
  UserAction,
  selectExpoPushToken,
  selectIsGettingExpoPushToken,
  selectToken,
} from "convose-lib/user"
import { State } from "convose-lib"
import { isDevice } from "expo-device"

type DispatchToProps = {
  readonly registerPushNotifications: () => void
}
type StateToProps = {
  readonly expoPushToken: PushNotificationToken
  readonly isGettingExpoPushToken: boolean
  readonly token: string
}
type Props = StateToProps & DispatchToProps
class RegisterPNComponent extends React.Component<Props> {
  componentDidMount(): void {
    this.tryRegisterPN()
  }

  componentDidUpdate(prevProps: Props): void {
    const { token } = this.props
    if (prevProps.token !== token) {
      // to make sure if prev user hasn't PN_TOKEN, the new user will have a new one
      this.tryRegisterPN()
    }
    this.tryRegisterPN()
  }

  public shouldRegisterNewPushNotificationToken = (): boolean => {
    const { isGettingExpoPushToken, expoPushToken } = this.props
    return !isGettingExpoPushToken && !expoPushToken && isDevice
  }

  public tryRegisterPN = () => {
    const { registerPushNotifications } = this.props
    if (this.shouldRegisterNewPushNotificationToken()) {
      registerPushNotifications()
    }
  }

  render(): React.ReactNode {
    return null
  }
}
const mapStateToProps = (state: State): StateToProps => ({
  expoPushToken: selectExpoPushToken(state),
  isGettingExpoPushToken: selectIsGettingExpoPushToken(state),
  token: selectToken(state),
})

const mapDispatchToProps: DispatchToProps = {
  registerPushNotifications: UserAction.registerPushNotifications,
}

export const RegisterRN = React.memo(
  connect(mapStateToProps, mapDispatchToProps)(RegisterPNComponent)
)
