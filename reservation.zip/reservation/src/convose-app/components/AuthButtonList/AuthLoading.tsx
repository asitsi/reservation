import React from "react"
import { connect } from "react-redux"
import _ from "lodash"

import { selectAuthLoading, State } from "convose-lib"
import { ConvoseLoading } from "../ConvoseLoading"

type Props = {
  authLoading: boolean
}
const AuthLoadingComponent: React.FC<Props> = ({ authLoading }) => {
  return <ConvoseLoading isShowing={authLoading} />
}

const mapStateToProps = (state: State): Props => ({
  authLoading: selectAuthLoading(state),
})

export const AuthLoading = React.memo(
  connect(mapStateToProps)(AuthLoadingComponent),
  (prevProps, nextProps) => {
    return _.isEqual(nextProps, prevProps)
  }
)
