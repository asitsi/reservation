import React from "react"
import { Svg, Path } from "react-native-svg"
import { SvgProps } from "../../svg/types"
import { getRatio, getWidth } from "../../svg/utils"

const defaultHeight = 16
const defaultWidth = 22
const ratio = getRatio(defaultHeight, defaultWidth)

export const EmailIcon: React.FC<SvgProps> = ({ color, height = 24 }) => {
  const svgHeight = height || defaultHeight
  const svgWidth = height ? getWidth(ratio, height) : defaultWidth
  return (
    <Svg width={svgWidth} height={svgHeight} viewBox="0 0 22 16" fill="none">
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M0.456026 1.03622L3.62125 4.15865L7.31606 7.80351L9.83146 10.2849C10.4998 10.9442 11.5723 10.9433 12.2395 10.283L21.56 1.05897C21.1154 0.418892 20.376 0 19.539 0H2.46102C1.63399 0 0.902246 0.408983 0.456026 1.03622ZM22 2.72465L16.3284 8.33757L19.1217 11.1139L21.9664 13.9412C21.9885 13.8084 22 13.6719 22 13.5327V2.72465ZM21.2354 15.3202L18.0716 12.1759L15.2669 9.38811L13.2873 11.3472C12.0399 12.5818 10.0348 12.5833 8.78538 11.3508L6.7955 9.38781L3.99666 12.1753L0.802955 15.356C1.24037 15.756 1.82228 16 2.46102 16H19.539C20.1965 16 20.7939 15.7415 21.2354 15.3202ZM0.0447303 14.0034L2.94549 11.1145L5.73228 8.33899L2.57514 5.22452L0 2.68419V13.5327C0 13.6937 0.015374 13.8511 0.0447303 14.0034Z"
        fill={color || "white"}
      />
    </Svg>
  )
}
