import React, { useMemo } from "react"
import { useWindowDimensions } from "react-native"
import { useSafeAreaInsets } from "react-native-safe-area-context"
import { useSelector } from "react-redux"

import { ScreenOrientationTypes } from "convose-lib/app"
import {
  selectHasMessageToEdit,
  selectHasMessageToReply,
  selectIsSuggestedRepliesOpen,
} from "convose-lib/chat"
import { useAnimatedStyle, withTiming } from "react-native-reanimated"
import { useKeyboard } from "convose-lib/utils/useKeyboard"
import { StyledMainChatWrapper } from "./Styled"

type Props = {
  screenOrientation: ScreenOrientationTypes
}
const SUGGESTED_REPLIES_HEIGHT = 65
const REPLY_EDIT_PANEL_HEIGHT = 53

const MainChatWrapperComponent: React.FC<React.PropsWithChildren<Props>> = ({
  screenOrientation,
  children,
}) => {
  const window = useWindowDimensions()
  const [keyboardHeight, keyboardAnimationDuration] = useKeyboard()
  const insets = useSafeAreaInsets()
  const isSuggestedRepliesOpen = useSelector(selectIsSuggestedRepliesOpen)
  const hasMessageToReply = useSelector(selectHasMessageToReply)
  const hasMessageToEdit = useSelector(selectHasMessageToEdit)

  const heightToDecrease = useMemo(() => {
    if (hasMessageToEdit || hasMessageToReply) {
      return isSuggestedRepliesOpen
        ? SUGGESTED_REPLIES_HEIGHT + REPLY_EDIT_PANEL_HEIGHT
        : REPLY_EDIT_PANEL_HEIGHT
    }
    return isSuggestedRepliesOpen ? SUGGESTED_REPLIES_HEIGHT : 0
  }, [isSuggestedRepliesOpen, hasMessageToReply, hasMessageToEdit])

  const style = useAnimatedStyle(
    () => ({
      height: withTiming(window.height - heightToDecrease - keyboardHeight, {
        duration: keyboardAnimationDuration,
      }),
    }),
    [window.height, heightToDecrease, keyboardHeight, keyboardAnimationDuration]
  )
  return (
    <StyledMainChatWrapper
      style={style}
      leftInset={insets.left}
      isLandscapeRight={screenOrientation === "LANDSCAPE-RIGHT"}
      isLandscapeLeft={screenOrientation === "LANDSCAPE-LEFT"}
    >
      {children}
    </StyledMainChatWrapper>
  )
}

export const MainChatWrapper = React.memo(MainChatWrapperComponent)
