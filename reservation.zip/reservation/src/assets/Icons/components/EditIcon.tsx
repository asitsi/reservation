import React from "react"
import { Svg, Path } from "react-native-svg"
import { SvgProps } from "../../svg/types"

type Props = SvgProps & { opacity?: number }
const EditIcon: React.FC<Props> = ({ color, height = 11, opacity = 0.7 }) => {
  return (
    <Svg width={height} height={height} viewBox="0 0 11 11" fill="none">
      <Path
        d="M6.66736 1.78069L8.84851 3.96181L3.32742 9.4829L1.14751 7.30178L6.66736 1.78069ZM10.5036 1.25465L9.53088 0.281939C9.15496 -0.0939796 8.54454 -0.0939796 8.16735 0.281939L7.23559 1.2137L9.41674 3.39485L10.5036 2.308C10.7951 2.01642 10.7951 1.54621 10.5036 1.25465ZM0.00606962 10.3675C-0.0336245 10.5462 0.127666 10.7062 0.30633 10.6628L2.73686 10.0735L0.556942 7.89236L0.00606962 10.3675Z"
        fill={color || "#AAAAAA"}
        fillOpacity={opacity}
      />
    </Svg>
  )
}

export default React.memo(EditIcon)
