import React, { useCallback, useEffect, useMemo, useState } from "react"
import { TouchableOpacity, ViewStyle } from "react-native"
import Animated, {
  ZoomOut,
  ZoomIn,
  LinearTransition,
  useAnimatedStyle,
  withTiming,
  useSharedValue,
  runOnJS,
} from "react-native-reanimated"
import { useSelector, useDispatch } from "react-redux"
import { selectUserRole } from "convose-lib/user"

import {
  ChatAction,
  MessageType,
  selectIsSuggestedRepliesOpen,
} from "convose-lib/chat"
import { runWithDelay } from "convose-lib/utils"
import {
  AnimatedFlatList,
  SuggestItemContainer,
  SuggestItemMessage,
} from "./Styled"

const layout = LinearTransition.damping(14).springify()

const usersReplies = [
  {
    messages: [
      {
        data: "Hey",
        type: MessageType.Text,
      },
    ],
  },
  {
    messages: [
      {
        data: "Where are you from?",
        type: MessageType.Text,
      },
    ],
  },
  {
    messages: [
      {
        data: "What do you do? are you a student?",
        type: MessageType.Text,
      },
    ],
  },
  {
    messages: [
      {
        data: "What do you think of this Convose app?",
        type: MessageType.Text,
      },
    ],
  },
  {
    messages: [
      {
        data: "What do you do for fun?",
        type: MessageType.Text,
      },
    ],
  },
].map((messages, id) => ({
  messages: messages.messages,
  id,
}))
const marketerReplies = [
  {
    messages: [
      {
        data: "What do you do? Are u a student?",
        type: MessageType.Text,
      },
    ],
  },
  {
    messages: [
      {
        data: "I’m part of the team building this app, Convose, what do you think of it?",
        type: MessageType.Text,
      },
    ],
  },
  {
    messages: [
      { data: "This is our team", type: MessageType.Text },
      {
        data: "https://res.cloudinary.com/hj0txfloi/image/upload/c_pad,b_auto:predominant,fl_preserve_transparency/v1704367839/Convose/Frame_625.jpg",
        type: MessageType.Image,
        ratio: 1,
      },
    ],
  },
  {
    messages: [
      {
        data: "Do u understand our goal with our app Convose (How it will help people & be different to other apps)?",
        type: MessageType.Text,
      },
    ],
  },
  {
    messages: [
      {
        data: "Our goal for Convose is to make it a great place to practice English with people who share your interests & instant conversations about any topic. Does it make sense?",
        type: MessageType.Text,
      },
      {
        data: "https://res.cloudinary.com/hj0txfloi/image/upload/v1704440064/Convose/tenor.gif",
        type: MessageType.Image,
        ratio: 498 / 280,
      },
    ],
  },
  {
    messages: [
      {
        data: "You should add more interests here. U can add anything to your interests: languages, locations, skills, hobbies, sports, video games, tv series, religions, anything. I'm asking everyone to add lots of interests, if we all do this then it will help to make instant conversations about any topic here on Convose.",
        type: MessageType.Text,
      },
      {
        data: "https://res.cloudinary.com/hj0txfloi/image/upload/c_pad,b_auto:predominant,fl_preserve_transparency/v1704367838/Convose/Frame_1675__4.jpg",
        type: MessageType.Image,
        ratio: 375 / 812,
      },
    ],
  },
  {
    messages: [
      {
        data: "I'm part of this great group for practicing English: https://convose.com/?id=ab0f9bed4dd64b101345 we can talk together and with other people, if you want to join us?",
        type: MessageType.Text,
      },
    ],
  },
  {
    messages: [
      {
        data: "Add your name here too so I, and others, can recognize u.",
        type: MessageType.Text,
      },
      {
        data: "https://res.cloudinary.com/hj0txfloi/image/upload/c_pad,b_auto:predominant,fl_preserve_transparency/v1704367838/Convose/Frame_1676.jpg",
        type: MessageType.Image,
        ratio: 375 / 812,
      },
    ],
  },
  {
    messages: [
      {
        data: "Keep trying to add lots of interests, it will help you find interesting conversations & make new friends. You can see in my profile I added 50+ interests. It will also help me make Convose a place to find conversations about anything.",
        type: MessageType.Text,
      },
      {
        data: "https://res.cloudinary.com/hj0txfloi/image/upload/c_pad,b_auto:predominant,fl_preserve_transparency/v1704367838/Convose/Frame_1675__4.jpg",
        type: MessageType.Image,
        ratio: 375 / 812,
      },
    ],
  },
  {
    messages: [
      {
        data: "You can also add knowledge levels to your interests. Then you will find knowledge exchanges and language exchanges on Convose. Like this:",
        type: MessageType.Text,
      },
      {
        data: "https://res.cloudinary.com/hj0txfloi/image/upload/v1704440064/Convose/tenor_1.gif",
        type: MessageType.Image,
        ratio: 498 / 492,
      },
    ],
  },
].map((messages, id) => ({
  messages: messages.messages,
  id,
}))

type Reply = {
  data: string
  type: MessageType
  ratio?: number
}
type SuggestedMessageType = {
  messages: Reply[]
  id: number
}
type SuggestedRepliesItemProps = {
  suggestedMessage: SuggestedMessageType
  onPress: (message: SuggestedMessageType) => void
  fixedWidth?: boolean
}
const SuggestedRepliesItem: React.FC<SuggestedRepliesItemProps> = ({
  suggestedMessage,
  onPress,
  fixedWidth,
}) => {
  const handleOnPress = () => {
    onPress(suggestedMessage)
  }
  return (
    <TouchableOpacity onPress={handleOnPress}>
      <SuggestItemContainer
        layout={layout}
        exiting={ZoomOut.duration(100)}
        entering={ZoomIn.duration(100)}
        fixedWidth={fixedWidth}
      >
        <SuggestItemMessage numberOfLines={2}>
          {suggestedMessage.messages[0].data}
        </SuggestItemMessage>
      </SuggestItemContainer>
    </TouchableOpacity>
  )
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const renderCell = (props: any) => (
  <Animated.View
    // eslint-disable-next-line react/jsx-props-no-spreading
    {...props}
    layout={layout}
    entering={ZoomIn.duration(100)}
    exiting={ZoomOut.duration(100)}
  />
)
const contentContainerStyle: ViewStyle = {
  paddingHorizontal: 10,
  alignItems: "center",
  paddingTop: 10,
}
type SuggestedRepliesProps = {
  onPress: (message: string, messageType: MessageType, ratio?: number) => void
  transparentBackgroundColor: boolean
}
const DEFAULT_SUGGESTION_HEIGHT = 55
const VOLUNTEER_MARKETER_DEFAULT_SUGGESTION_HEIGHT = 75
const SuggestedRepliesComponent: React.FC<SuggestedRepliesProps> = ({
  onPress,
  transparentBackgroundColor,
}) => {
  const dispatch = useDispatch()
  const userRole = useSelector(selectUserRole)
  const isVolunteer = useMemo(() => userRole.includes("volunteer"), [userRole])
  const isSuggestedRepliesOpen = useSelector(selectIsSuggestedRepliesOpen)
  const [suggestions, setSuggestions] = React.useState(
    isVolunteer ? marketerReplies : usersReplies
  )
  const [isShowing, setShowing] = useState(true)
  const suggestionHeight = useMemo(
    () =>
      isVolunteer
        ? VOLUNTEER_MARKETER_DEFAULT_SUGGESTION_HEIGHT
        : DEFAULT_SUGGESTION_HEIGHT,
    [isVolunteer]
  )
  const heightOffset = useSharedValue(suggestionHeight)

  const setIsSuggestedRepliesOpen = useCallback(
    (isRepliesOpen: boolean) =>
      dispatch(ChatAction.setIsSuggestedRepliesOpen(isRepliesOpen)),
    [dispatch]
  )
  const style = useAnimatedStyle(() => ({
    height: heightOffset.value,
  }))

  useEffect(() => {
    if (!suggestions.length) {
      heightOffset.value = withTiming(
        suggestions.length ? suggestionHeight : 0,
        {
          duration: 200,
        },
        () => {
          runOnJS(setShowing)(false)
        }
      )
    }
  }, [heightOffset, suggestionHeight, suggestions.length])
  // const isShowing = useMemo(() => {
  //   return !!suggestions.length
  //   // return !(!userRole.includes("volunteer") || !suggestions.length)
  // }, [suggestions.length])

  useEffect(() => {
    if (isSuggestedRepliesOpen !== isShowing) {
      setIsSuggestedRepliesOpen(isShowing)
    }
  }, [isShowing, isSuggestedRepliesOpen, setIsSuggestedRepliesOpen])
  useEffect(() => {
    return () => {
      setIsSuggestedRepliesOpen(false)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])
  const handleOnMessagePress = (reply: SuggestedMessageType) => {
    if (onPress) {
      const replyPromises = reply.messages.map((message, index) =>
        runWithDelay(
          () => onPress(message.data, message.type, message.ratio),
          index * 100
        )
      )
      Promise.all(replyPromises)
        .then()
        .catch()
        .finally(() => {
          setSuggestions(
            suggestions.filter((suggest) => suggest.id !== reply.id)
          )
        })
    }
  }

  if (!isShowing) {
    return null
  }
  return (
    <AnimatedFlatList
      style={style}
      contentContainerStyle={contentContainerStyle}
      scrollEnabled
      data={suggestions}
      renderItem={(item: { item: SuggestedMessageType }) => (
        <SuggestedRepliesItem
          suggestedMessage={item.item}
          onPress={handleOnMessagePress}
          fixedWidth={isVolunteer}
        />
      )}
      itemLayoutAnimation={layout}
      keyExtractor={(item: { id: unknown }) => String(item.id)}
      horizontal
      showsHorizontalScrollIndicator={false}
      keyboardDismissMode="interactive"
      keyboardShouldPersistTaps="handled"
      CellRendererComponent={renderCell}
      transparentBackgroundColor={transparentBackgroundColor}
    />
  )
}

export const SuggestedReplies = React.memo(SuggestedRepliesComponent)
