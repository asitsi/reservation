import React, { memo, useMemo } from "react"

import { Avatar as AvatarType } from "convose-lib/user"
import { noop } from "lodash"
import { BlockAlertValue } from "convose-lib/chat"
import { Routes } from "convose-lib/router"
import { Avatar } from "../../components/Avatar"
import { ChatMessageUsername } from "./ChatMessageUsername"
import * as RootNavigation from "../../RootNavigation"

import {
  AvatarContainer,
  ChatMessageUsernameContainer,
  UserWrapper,
} from "./Styled"

type Props = {
  avatar: AvatarType
  senderUsername: string
  replyId: string | undefined
  deleted: boolean | undefined
  themeColor: string
  isFullScreenVideoCall: boolean
  isBlocked: boolean
  showBlockAlert: (type: BlockAlertValue) => void
  sender: string
  isGroupAdmin: boolean
  chatChannel: string
  myUuid: string
  sameSender: boolean
  myMessage: boolean
}
export const SenderUsernameAvatarComponent: React.FC<Props> = ({
  avatar,
  deleted,
  isFullScreenVideoCall,
  replyId,
  senderUsername,
  themeColor,
  isBlocked,
  sender,
  showBlockAlert,
  chatChannel,
  isGroupAdmin,
  myUuid,
  sameSender,
  myMessage,
}) => {
  const messageAvatar = avatar && avatar?.url ? avatar : undefined
  const messageName = senderUsername
  const hasReply = !!replyId && !deleted

  const openUserProfile = (): void => {
    if (isBlocked) {
      showBlockAlert("ViewUser")
      return
    }
    if (sender === "YzNlZWRiMjA5NDZhNDdmMQ-Y2QxZjhhNjdlZGIyOGQwNw") {
      return
    }
    RootNavigation.navigate(Routes.UserProfile, {
      chatUserId: sender,
      myUuid,
      canBlock: isGroupAdmin,
      chatChannel,
    })
  }

  const showAvatar = useMemo(
    () => !myMessage && !!avatar && !sameSender,
    [avatar, myMessage, sameSender]
  )
  if (!showAvatar) {
    return null
  }
  return (
    <UserWrapper>
      <AvatarContainer onPress={openUserProfile} onLongPress={noop}>
        <Avatar height={30} userAvatar={messageAvatar} />
      </AvatarContainer>
      {messageName && !hasReply && (
        <ChatMessageUsernameContainer
          onPress={openUserProfile}
          onLongPress={noop}
        >
          <ChatMessageUsername
            color={themeColor}
            hasStroke={isFullScreenVideoCall}
          >
            {messageName.charAt(0).toUpperCase() + messageName.slice(1)}
          </ChatMessageUsername>
        </ChatMessageUsernameContainer>
      )}
    </UserWrapper>
  )
}

export const SenderUsernameAvatar = memo(SenderUsernameAvatarComponent)
