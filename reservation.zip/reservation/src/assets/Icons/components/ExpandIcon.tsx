import React from "react"
import { Svg, Path } from "react-native-svg"
import { SvgProps } from "../../svg/types"

const ExpandIcon: React.FC<SvgProps> = ({ color, height = 24 }) => {
  return (
    <Svg
      width={height}
      height={height}
      viewBox="0 0 24 24"
      data-name="Expand 2"
      id="expand"
    >
      <Path fill="none" d="M0 0h24v24H0Z" data-name="Path 3670" />
      <Path
        fill={color || "#525863"}
        d="M21.6 4.2v6.3a.9.9 0 1 1-1.8 0V5.9l-9.051 9.048a1.202 1.202 0 0 1-1.7-1.7L18.1 4.2h-4.6a.9.9 0 0 1 0-1.8h6.3a1.805 1.805 0 0 1 1.8 1.8Zm-.9 10.5a.9.9 0 0 0-.9.9v4.2H4.2V4.2h4.2a.9.9 0 1 0 0-1.8H4.2a1.805 1.805 0 0 0-1.8 1.8v15.6a1.805 1.805 0 0 0 1.8 1.8h15.6a1.805 1.805 0 0 0 1.8-1.8v-4.2a.9.9 0 0 0-.9-.9Z"
        data-name="Path 3562"
      />
    </Svg>
  )
}

export default ExpandIcon
