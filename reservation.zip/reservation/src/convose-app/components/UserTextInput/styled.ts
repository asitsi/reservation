import { TextField } from "rn-material-ui-textfield"
import styled from "styled-components"

import { color, Props, softShadows } from "convose-styles"

export const labelTextStyle = { textTransform: "uppercase" }

export const containerStyle = {
  backgroundColor: color.white,
  height: 60,
  width: 300,
  ...softShadows,
}

export const UserInput = styled(TextField).attrs((props: Props) => ({
  baseColor: props.theme.interests.input.placeholder,
}))`
  color: ${(props: Props) => props.theme.textInput.color};
`
