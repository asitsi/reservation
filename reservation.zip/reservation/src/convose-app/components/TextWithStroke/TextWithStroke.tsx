import { font } from "convose-styles"
import React, { PropsWithChildren } from "react"
import Svg, { Text } from "react-native-svg"

type Props = {
  color: string
  hasStroke?: boolean
  height?: number | string
  width?: number | string
  fontSize?: number
  x?: number
  y?: number
  textAnchor?: "end" | "middle" | "start"
}
const TextWithStrokeComponent: React.FC<PropsWithChildren<Props>> = ({
  color = "black",
  hasStroke,
  children,
  fontSize = 15,
  height = 21,
  width = 130,
  x = 3,
  y = 17,
  textAnchor = "start",
}) => {
  return (
    <Svg height={height} width={width}>
      <Text
        fill={color}
        stroke={hasStroke ? "black" : color}
        fontSize={fontSize}
        fontWeight="bold"
        x={x}
        y={y}
        textAnchor={textAnchor}
        strokeWidth={0.3}
        fontFamily={font.semiBold}
        strokeOpacity={0.8}
      >
        {children}
      </Text>
    </Svg>
  )
}
export const TextWithStroke = React.memo(TextWithStrokeComponent)
