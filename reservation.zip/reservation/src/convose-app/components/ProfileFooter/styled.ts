// import { TouchableOpacity, View, TouchableOpacityProps } from "react-native"
import styled from "styled-components/native"
import Animated from "react-native-reanimated"
import { CenteredText, Props, font } from "convose-styles"
import Ionicons from "react-native-vector-icons/Ionicons"

import { MoonSvg } from "../../../assets/svg/Moon"
import { PrivacySvg } from "../../../assets/svg/Privacy"
import { InfoSvg } from "../../../assets/svg/Info"

export const Footer = styled(Animated.View)`
  width: 100%;
  background: ${(props: Props) => props.theme.main.background};
  justify-content: flex-start;
  align-items: center;
  z-index: -1;
  padding-left: 20px;
  padding-right: 20px;
`

export const FooterItemWrapper = styled.TouchableOpacity`
  width: 100%;
  z-index: 10;
  margin-bottom: 10px;
  padding-vertical: 10px;
  flex-direction: row;
  justify-content: space-between;
`

export const FooterItem = styled.View`
  margin-left: 5px;
  flex-direction: row;
  align-items: center;
`

export const FooterText = styled(CenteredText)`
  position: absolute;
  color: ${(props: Props & { disabled: boolean }) => {
    if (props.disabled) {
      return props.theme.interests.input.placeholder
    }
    if (props.color) {
      return props.color
    }
    return props.theme.main.text
  }};
  font-family: ${font.normal};
  font-size: 15px;
  left: 50px;
`
export const StyledIcon = styled(Ionicons)`
  color: ${(props: Props & { disabled: boolean }) =>
    props.disabled
      ? props.theme.interests.input.placeholder
      : props.theme.main.text};
`

export const StyledMoonSvg = styled(MoonSvg).attrs((props: Props) => ({
  color: props.theme.main.text,
}))``
export const StyledPrivacySvg = styled(PrivacySvg).attrs((props: Props) => ({
  color: props.theme.main.text,
}))``
export const StyledInfoSvg = styled(InfoSvg).attrs((props: Props) => ({
  color: props.theme.main.text,
}))``
