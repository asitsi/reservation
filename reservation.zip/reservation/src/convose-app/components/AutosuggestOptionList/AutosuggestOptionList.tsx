/* eslint-disable @typescript-eslint/no-var-requires */
import React, { useRef, useEffect } from "react"
import {
  ActivityIndicator,
  FlatList,
  ListRenderItem,
  ListRenderItemInfo,
  Platform,
  Dimensions,
} from "react-native"

import {
  Interest,
  AutoSuggestInterest,
  LIMIT_OF_INTERESTS,
  UserInterest,
  InterestType,
} from "convose-lib/interests"
import { color } from "convose-styles"
import { useKeyboard } from "convose-lib/utils/useKeyboard"

import { NewInterestBG, NewInterestFG } from "../../../assets/svg"
import { AutosuggestOption } from "../AutosuggestOption/AutosuggestOption"
import {
  AutosuggestOptionListFooterContainer,
  EmptyListContainer,
  EmptyListScrollView,
  FlatListWrapper,
  InfoText,
  NewInterestContainer,
  NewInterestForeground,
  styles,
  Title,
} from "./Styled"
import { PointerArrow } from "./PointerArrow"

const { height: screenHeight } = Dimensions.get("screen")

export interface IAutosuggestOptionListProps {
  readonly results: ReadonlyArray<AutoSuggestInterest>
  readonly onSelect: (interest: Interest) => void
  readonly hasMoreInterests: boolean
  readonly onLoadMoreInterest?: () => void
  readonly searchText: string
  readonly hasSelectedInterest: boolean
  readonly onRemove: (interest: UserInterest | Interest) => void
  readonly renderNewInterest: boolean
  readonly isLoadingSearchResults: boolean
  readonly newInterestInfoDescription?: string
  readonly currentInterests: ReadonlyArray<UserInterest>
}
const loadingResults: AutoSuggestInterest[] = Array(15)
  .fill(1)
  .map((_, index) => ({
    match: 0,
    name: "name",
    type: InterestType.General,
    avatar: null,
    color: color.mainBlue,
    id: -(index + 1),
  }))
const isAndroid = Platform.OS === "android"
const keyExtractor = (interest: Interest) => String(interest.id)

const AutosuggestOptionListComponent: React.FunctionComponent<
  IAutosuggestOptionListProps
> = ({
  results,
  onSelect,
  hasMoreInterests,
  onLoadMoreInterest,
  searchText,
  hasSelectedInterest,
  onRemove,
  renderNewInterest,
  isLoadingSearchResults,
  newInterestInfoDescription,
  currentInterests,
}) => {
  const flatListRef = useRef<FlatList>(null)
  const [keyboardHeight] = useKeyboard()

  const newInterestsHeights = React.useMemo(() => {
    const base = keyboardHeight ? 2.2 : 1.4
    const NEW_INTERESTS_BG_HEIGHT =
      ((screenHeight - keyboardHeight) * base) / 10
    const NEW_INTERESTS_FG_HEIGHT = (NEW_INTERESTS_BG_HEIGHT * 6.5) / 10
    return {
      NEW_INTERESTS_BG_HEIGHT,
      NEW_INTERESTS_FG_HEIGHT,
    }
  }, [keyboardHeight])

  useEffect(() => {
    if (flatListRef.current) {
      flatListRef.current.scrollToOffset({ animated: true, offset: 0 })
    }
  }, [searchText])

  const renderRow: ListRenderItem<AutoSuggestInterest> = (
    info: ListRenderItemInfo<AutoSuggestInterest>
  ) => {
    return (
      <AutosuggestOption
        onSelect={onSelect}
        interest={info.item}
        onRemove={onRemove}
        isLoading={isLoadingSearchResults}
      />
    )
  }

  const renderEmptyList = () => {
    return (
      <EmptyListContainer>
        <EmptyListScrollView
          // eslint-disable-next-line react-perf/jsx-no-new-object-as-prop
          style={{
            bottom: hasSelectedInterest ? -65 : -10,
          }}
          keyboardShouldPersistTaps="none"
          keyboardDismissMode="none"
          contentContainerStyle={styles.scrollContainer}
        >
          <NewInterestContainer>
            <NewInterestBG
              height={newInterestsHeights.NEW_INTERESTS_BG_HEIGHT}
            />
            <NewInterestForeground>
              <NewInterestFG
                height={newInterestsHeights.NEW_INTERESTS_FG_HEIGHT}
              />
            </NewInterestForeground>
          </NewInterestContainer>
          <Title>You found a new interest!</Title>
          <InfoText>{newInterestInfoDescription}</InfoText>
          <PointerArrow height={50} />
        </EmptyListScrollView>
      </EmptyListContainer>
    )
  }
  const renderFooter = (): React.ReactElement | null => {
    if (hasMoreInterests && !!results.length) {
      return (
        <AutosuggestOptionListFooterContainer>
          <ActivityIndicator size={isAndroid ? 25 : 8} color={color.dusk} />
        </AutosuggestOptionListFooterContainer>
      )
    }
    return null
  }

  const onLoadMore = () => {
    !!onLoadMoreInterest && onLoadMoreInterest()
  }

  const resultsToRender = isLoadingSearchResults
    ? loadingResults
    : results.map((interest) => ({
        ...interest,
        existing: !!currentInterests.find(
          (myInterest) => interest.name === myInterest.name
        ),
      }))
  return (
    <FlatListWrapper>
      {!renderNewInterest ? (
        <FlatList
          ref={flatListRef}
          data={resultsToRender}
          inverted
          renderItem={renderRow}
          keyExtractor={keyExtractor}
          keyboardShouldPersistTaps="handled"
          alwaysBounceVertical
          removeClippedSubviews={isAndroid}
          maxToRenderPerBatch={LIMIT_OF_INTERESTS}
          initialNumToRender={LIMIT_OF_INTERESTS}
          onEndReached={onLoadMore}
          onEndReachedThreshold={0.01}
          ListFooterComponent={renderFooter()}
        />
      ) : (
        renderEmptyList()
      )}
    </FlatListWrapper>
  )
}
// AutosuggestOptionListComponent.whyDidYouRender = {
//   logOnDifferentValues: false,
//   customName: "AutosuggestOptionListComponent",
//   diffNameColor: "red",
// }
export const AutosuggestOptionList = React.memo(AutosuggestOptionListComponent)
