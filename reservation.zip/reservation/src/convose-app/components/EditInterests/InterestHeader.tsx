import React from "react"
import { withTheme } from "styled-components"

import { ThemeType } from "convose-styles"
import { StatusBarAuto } from "../StatusBarAuto"
import { Header, HeaderProps } from "../Header/Header"

type InterestHeaderProps = Omit<
  HeaderProps,
  | "startCall"
  | "rejoinCall"
  | "canRejoinCall"
  | "theme"
  | "isInCallingChat"
  | "chatChannel"
>
type HeaderPropsWithTheme = {
  theme: ThemeType
} & InterestHeaderProps
const HeaderComponent: React.FunctionComponent<HeaderPropsWithTheme> = (
  props
) => {
  const { theme, ...otherProps } = props
  const isDark = theme.mode === "dark"
  const backgroundColor = isDark
    ? "rgba(45, 45, 45, 1)"
    : "rgba(243, 243, 243, 1)"
  return (
    <>
      <StatusBarAuto />
      {/* eslint-disable-next-line react/jsx-props-no-spreading */}
      <Header {...otherProps} backgroundColor={backgroundColor} />
    </>
  )
}
// HeaderComponent.whyDidYouRender = {
//   logOnDifferentValues: false,
//   customName: "HeaderComponent",
//   diffNameColor: "red",
// }

export const InterestHeader: React.FunctionComponent<InterestHeaderProps> =
  React.memo(withTheme(HeaderComponent))
