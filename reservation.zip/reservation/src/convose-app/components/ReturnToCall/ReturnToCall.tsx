import React, { useCallback, useEffect, useMemo, useRef, useState } from "react"
import Ionicons from "react-native-vector-icons/Ionicons"
import { useSelector } from "react-redux"
import { useSafeAreaInsets } from "react-native-safe-area-context"

import { millisToMinutesAndSeconds } from "convose-lib/utils"
import { Routes } from "convose-lib/router"
import {
  selectCallingChannel,
  selectCallingChatId,
  selectIsCaller,
  selectIsCalling,
  selectIsSeekingQuickCall,
  selectJoinCall,
} from "convose-lib/calling"
import { checkIsInCall } from "convose-lib/calling/utils"
import { useAnimatedStyle, withTiming } from "react-native-reanimated"
import { useTheme } from "styled-components"
import { ThemeType } from "convose-styles"
import * as RootNavigation from "../../RootNavigation"
import { ButtonWrapper, Container, Label, TextWrapper } from "./styled"

const iconStyle = { marginRight: 8 }
const BANNER_HEIGHT = 35
type Props = {
  hideReturnToCall?: boolean
}

const ReturnToCallComponent: React.FC<Props> = ({ hideReturnToCall }) => {
  const insets = useSafeAreaInsets()
  const theme: ThemeType = useTheme()
  const isCaller = useSelector(selectIsCaller)
  const joinCall = useSelector(selectJoinCall)
  const isCalling = useSelector(selectIsCalling)
  const chatId = useSelector(selectCallingChatId)
  const isSeekingQuickCall = useSelector(selectIsSeekingQuickCall)
  const callingChannel = useSelector(selectCallingChannel)

  const callingDurationInterval = useRef<ReturnType<typeof setInterval> | null>(
    null
  )
  const [callingDuration, setCallingDuration] = useState("")

  const shouldShowBanner = useMemo(() => {
    return (
      (checkIsInCall({
        isCaller,
        isCalling,
        isJoined: joinCall.isJoined,
        callingChannel,
      }) ||
        isSeekingQuickCall) &&
      !hideReturnToCall
    )
  }, [
    callingChannel,
    hideReturnToCall,
    isCaller,
    isCalling,
    isSeekingQuickCall,
    joinCall.isJoined,
  ])

  const containerStyle = useAnimatedStyle(
    () => ({
      height: withTiming(
        shouldShowBanner ? insets.top + BANNER_HEIGHT : insets.top,
        {
          duration: 200,
        }
      ),
      backgroundColor: withTiming(
        shouldShowBanner ? theme.mainBlue : "transparent"
      ),
    }),
    [shouldShowBanner]
  )

  useEffect(() => {
    if (
      joinCall.isJoined &&
      joinCall.joinedTime > 0 &&
      !callingDurationInterval.current
    ) {
      callingDurationInterval.current = setInterval(() => {
        const duration = millisToMinutesAndSeconds(
          Date.now() - joinCall.joinedTime
        )
        setCallingDuration(duration)
      }, 1000)
    }
    if (!joinCall.isJoined && callingDurationInterval.current) {
      clearInterval(callingDurationInterval.current)
      callingDurationInterval.current = null
    }
  }, [joinCall.isJoined, joinCall.joinedTime])

  const returnToCall = useCallback(() => {
    if (isSeekingQuickCall) {
      RootNavigation.navigate(Routes.SearchingConversation, {})
      return
    }
    RootNavigation.navigate(Routes.Chat, {
      channel: chatId,
      chatUser: {},
    })
  }, [chatId, isSeekingQuickCall])

  const label = useMemo(
    () =>
      isSeekingQuickCall ? `Seeking call partner` : `Tap to return to call`,
    [isSeekingQuickCall]
  )
  return (
    <Container
      style={containerStyle}
      onPress={returnToCall}
      disable={!shouldShowBanner}
    >
      {shouldShowBanner && (
        <ButtonWrapper>
          <TextWrapper isTimerOn={joinCall.joinedTime > 0}>
            {isSeekingQuickCall && (
              <Ionicons
                name="search"
                size={17}
                color="white"
                style={iconStyle}
              />
            )}
            <Label>{label}</Label>
            {joinCall.joinedTime > 0 && (
              <Label timerText>{callingDuration}</Label>
            )}
          </TextWrapper>
        </ButtonWrapper>
      )}
    </Container>
  )
}

export const ReturnToCall = React.memo(ReturnToCallComponent)
