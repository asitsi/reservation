/* eslint-disable react/jsx-props-no-spreading */
import React, { PropsWithChildren } from "react"
import { ScrollViewProps, useWindowDimensions } from "react-native"
import { ScrollView } from "react-native-gesture-handler"

import { StyledCallingUsersContainer } from "../Styled"

type Props = ScrollViewProps & {
  isLandscape?: boolean
  ref?: React.ForwardedRef<ScrollView>
}

export const CallingUsersContainer = React.forwardRef<
  ScrollView,
  PropsWithChildren<Props>
>((props, ref) => {
  const { height } = useWindowDimensions()

  return (
    <StyledCallingUsersContainer {...props} height={height} ref={ref}>
      {props.children}
    </StyledCallingUsersContainer>
  )
})
