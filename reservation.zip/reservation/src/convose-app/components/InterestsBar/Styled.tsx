import styled from "styled-components/native"
import Animated from "react-native-reanimated"

import { interestsBarHeight, Props } from "convose-styles"

export const StyledInterestsBarView = styled(Animated.View)`
  background: ${(props: Props) =>
    props.theme.interests.inputAndCurrentInterests.background};
  width: 100%;
  /* padding: 10px 15px; */
  z-index: 102;
  border-top-left-radius: 5px;
  border-top-right-radius: 5px;
  overflow: hidden;
`
// padding-bottom: ${(props: InsetProps) => props.insetBottom}px;
type BarViewProps = Props & { renderNewInterest: boolean }
export const InterestBarContainer = styled.View`
  background: ${(props: BarViewProps) =>
    props.renderNewInterest
      ? props.theme.interests.autocompleteList.newInterestBackground
      : "transparent"};
  flex-direction: column;
  width: 100%;
  padding-bottom: 10px;
  padding-top: 10px;
`
export const InterestBarActionsContainer = styled.View`
  align-content: center;
  align-items: center;
  justify-content: space-evenly;
  flex-direction: row;
  flex-wrap: nowrap;
  width: 100%;
  padding-left: 15px;
  padding-right: 15px;
  /* height: ${interestsBarHeight}px; */
`
export const CurrentInterestsWrapper = styled(Animated.View)`
  width: 100%;
  padding-left: 12px;
  overflow: visible;
  flex-direction: row;
`
