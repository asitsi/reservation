import React from "react"
import {
  Gesture,
  GestureDetector,
  GestureStateChangeEvent,
  PanGestureHandlerEventPayload,
} from "react-native-gesture-handler"
import Animated, {
  Extrapolation,
  interpolate,
  runOnJS,
  useAnimatedStyle,
  useDerivedValue,
  useSharedValue,
  withTiming,
} from "react-native-reanimated"
import { trigger } from "react-native-haptic-feedback"
import {
  MessageReplyContainer,
  ReplyArrowContainer,
  StyledIonicons,
} from "./Styled"

const ACTIVE_X_OFFSET = 10
const FAIL_Y_OFFSET = 5
const VELOCITY_SLIDE_DOWN_LIMIT = 1200
const ACTIVATE_OFFSET = 70
const START_ACTIVATE_OFFSET = 50
const MESSAGE_BUBBLE_START_LOCATION = 45

type Props = React.PropsWithChildren & {
  lockSwipeRight?: boolean
  lockSwipeLeft?: boolean
  onSwipeRight?: () => void
  onSwipeLeft?: () => void
  hapticOnActivation?: boolean
}
const SwipeToReplyComponent: React.FC<Props> = ({
  children,
  lockSwipeLeft,
  lockSwipeRight,
  onSwipeLeft,
  onSwipeRight,
  hapticOnActivation,
}) => {
  const translateXOffset = useSharedValue(0)
  const hapticTriggered = useSharedValue(false)
  const touchStart = useSharedValue(0)

  const opacityValue = useDerivedValue(() =>
    interpolate(
      Math.abs(translateXOffset.value),
      [START_ACTIVATE_OFFSET, ACTIVATE_OFFSET],
      [0, 1],
      Extrapolation.CLAMP
    )
  )
  const replyIconMoveDerivedValue = useDerivedValue(() =>
    interpolate(
      Math.abs(translateXOffset.value),
      [START_ACTIVATE_OFFSET - 10, ACTIVATE_OFFSET],
      [0, 10],
      Extrapolation.CLAMP
    )
  )
  const replyIconStyleLeft = useAnimatedStyle(() => ({
    position: "absolute",
    left: replyIconMoveDerivedValue.value,
    opacity: opacityValue.value,
  }))
  const replyIconStyleRight = useAnimatedStyle(() => ({
    position: "absolute",
    right: replyIconMoveDerivedValue.value,
    opacity: opacityValue.value,
  }))

  const hapticEffect = () => {
    "worklet"

    if (!hapticTriggered.value) {
      hapticTriggered.value = true
      runOnJS(trigger)("impactLight", {
        enableVibrateFallback: true,
      })
    }
  }
  const clearHapticEffect = () => {
    "worklet"

    hapticTriggered.value = false
  }
  const onSwiping = (value: number) => {
    "worklet"

    translateXOffset.value = value
    if (Math.abs(value) > ACTIVATE_OFFSET && hapticOnActivation) {
      hapticEffect()
    }
  }
  const setTranslateXOffset = (value: number) => {
    "worklet"

    if (value > 0 && !lockSwipeRight) {
      // swiping right
      onSwiping(value)
      return
    }
    if (value < 0 && !lockSwipeLeft) {
      // swiping left
      onSwiping(value)
    }
  }
  const onGestureEnd = ({
    velocityX,
  }: GestureStateChangeEvent<PanGestureHandlerEventPayload>) => {
    "worklet"

    clearHapticEffect()
    touchStart.value = 0
    if (
      translateXOffset.value > ACTIVATE_OFFSET &&
      velocityX > -VELOCITY_SLIDE_DOWN_LIMIT
    ) {
      onSwipeRight && runOnJS(onSwipeRight)()
    }
    if (
      translateXOffset.value < -ACTIVATE_OFFSET &&
      velocityX < VELOCITY_SLIDE_DOWN_LIMIT
    ) {
      onSwipeLeft && runOnJS(onSwipeLeft)()
    }
    translateXOffset.value = withTiming(0, { duration: 70 })
  }

  const gesture = Gesture.Pan()
    .onTouchesDown((event) => {
      touchStart.value = event.allTouches[0].absoluteX
    })
    .onTouchesMove((event, stateManager) => {
      if (lockSwipeRight && touchStart.value < event.allTouches[0].absoluteX) {
        stateManager.fail()
      }
      if (lockSwipeLeft && touchStart.value < MESSAGE_BUBBLE_START_LOCATION) {
        stateManager.fail()
      }
    })
    .activeOffsetX([-ACTIVE_X_OFFSET, ACTIVE_X_OFFSET])
    .failOffsetY([-FAIL_Y_OFFSET, FAIL_Y_OFFSET])
    .onChange(({ translationX }) => {
      setTranslateXOffset(translationX)
    })
    .onEnd(onGestureEnd)

  const style = useAnimatedStyle(() => ({
    transform: [{ translateX: translateXOffset.value }],
  }))

  return (
    <GestureDetector gesture={gesture}>
      <MessageReplyContainer>
        <Animated.View style={style}>{children}</Animated.View>
        {lockSwipeLeft && (
          <ReplyArrowContainer style={replyIconStyleLeft}>
            <StyledIonicons name="arrow-undo" size={20} />
          </ReplyArrowContainer>
        )}
        {lockSwipeRight && (
          <ReplyArrowContainer style={replyIconStyleRight}>
            <StyledIonicons name="arrow-undo" size={20} />
          </ReplyArrowContainer>
        )}
      </MessageReplyContainer>
    </GestureDetector>
  )
}

export const SwipeToReply = React.memo(SwipeToReplyComponent)
