/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { useCallback, useEffect } from "react"
import { StatusBar } from "expo-status-bar"
import { useSelector, useDispatch } from "react-redux"
import SplashScreen from "react-native-splash-screen"

import { selectIsDarkMode } from "convose-lib/app"
import { clearAgoraChannel } from "convose-lib"
import { CallingAction } from "convose-lib/calling"

type Props = {
  barStyle?: "light" | "dark"
  animated?: boolean
  hideSplash?: boolean
}
const StatusBarAutoComponent: React.FC<Props> = ({
  barStyle,
  animated,
  hideSplash,
}) => {
  const isDarkMode = useSelector(selectIsDarkMode)
  const dispatch = useDispatch()
  const setCallingToDefault = useCallback(
    () => dispatch(CallingAction.setCallingToDefault()),
    [dispatch]
  )
  useEffect(() => {
    if (hideSplash) {
      // on slow devices, user may put the app in background and when they come back
      // app starts all over again but the is still happening without any track from us
      // clearing call will prevent this issue
      setCallingToDefault()
      clearAgoraChannel().then().catch()
      SplashScreen.hide()
    }
  }, [hideSplash, setCallingToDefault])

  function getStyle() {
    if (barStyle) {
      return barStyle
    }
    return isDarkMode ? "light" : "dark"
  }
  return (
    <StatusBar
      hideTransitionAnimation="slide"
      translucent
      animated={animated === undefined ? true : animated}
      style={getStyle()}
    />
  )
}

export const StatusBarAuto = React.memo(StatusBarAutoComponent)
