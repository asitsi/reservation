import React, { useEffect, useRef } from "react"
import { TouchableWithoutFeedback, Keyboard, View } from "react-native"
import { connect } from "react-redux"
import { trigger } from "react-native-haptic-feedback"
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSequence,
  withTiming,
  runOnJS,
} from "react-native-reanimated"

import {
  Message,
  // UserStatus,
  AudioMessagePlayer,
  BlockSendContent,
  selectIsMessageSelected,
  ChatAction,
  MessageToPublish,
  SelectedMessage,
} from "convose-lib/chat"
import { LONG_PRESS_DURATION, MENTION_EVERYONE_ID } from "convose-lib/utils"
import { Routes } from "convose-lib/router"
import { State } from "convose-lib"

import { MessageContainer, MessageContent } from "./Styled"
import * as RootNavigation from "../../RootNavigation"
import { RepliedMessage } from "./Messages/RepliedMessage"
import { MessageReactions } from "./Reactions"
import { MessageBubble } from "./Messages/MessageBubble"
import { SwipeToReply } from "./SwipeToReply"
import { SenderUsernameAvatar } from "./SenderUsernameAvatar"

type ChatMessageProps = {
  readonly sameSender: boolean
  readonly isFullScreenVideoCall: boolean
  readonly setFullScreenImage: (uri: { uri: string } | undefined) => void
  readonly myUuid: string
  scrollToReply: (uuid: string) => void
  messageUuidToScaleAnimation?: string
  clearMessageUuidToScaleAnimation: () => void
  isGroupAdmin: boolean
  chatChannel: string
  readonly onUpdateReaction: (
    emoji: string,
    messageUuid: string,
    reacted: boolean
  ) => void
  readonly dismissSelectedMessage: (noToggleHeader?: boolean) => void
  readonly message: Message | MessageToPublish
} & BlockSendContent

type StateProps = {
  readonly isThisMessageSelected: boolean
}
type DispatchProps = {
  readonly setSelectedMessage: (message: SelectedMessage | null) => void
  readonly onReply: (message: Message | null) => void
}
type ParentProps = ChatMessageProps & AudioMessagePlayer
type AllProps = ParentProps & DispatchProps & StateProps

// eslint-disable-next-line complexity
const ChatMessageComponent: React.FC<AllProps> = ({
  chatChannel,
  clearMessageUuidToScaleAnimation,
  dismissSelectedMessage,
  isBlocked,
  isFullScreenVideoCall,
  isGroupAdmin,
  isThisMessageSelected,
  message,
  myUuid,
  onReply,
  onUpdateReaction,
  requestPlay,
  requestStop,
  sameSender,
  scrollToReply,
  setFullScreenImage,
  setSelectedMessage,
  shouldPlay,
  showBlockAlert,
  messageUuidToScaleAnimation,
}) => {
  const {
    myMessage,
    avatar,
    publishing,
    deleted,
    reply_to_id: replyId,
    reply_to_message: replyMessage,
    reply_to_username: replyUsername,
    reply_to_message_type: replyMessageType,
    reply_to_image_ratio: replyImageRatio,
    reply_to_user_id: replyToUserId,
    senderUsername,
    sender,
    data,
    reactions,
    uuid,
    theme_color: themeColor,
    preview,
  } = message as Message

  const messageComponentRef = useRef<View>(null)

  const scaleOffset = useSharedValue(1)
  const translateXOffset = useSharedValue(0)

  const animatedStyle = useAnimatedStyle(() => ({
    paddingHorizontal: 9,
    transform: [
      { translateX: translateXOffset.value },
      { scale: scaleOffset.value },
    ],
  }))

  useEffect(() => {
    if (messageUuidToScaleAnimation) {
      scaleOffset.value = withSequence(
        withTiming(1.2, { duration: 150 }),
        withTiming(1, { duration: 150 }, () => {
          runOnJS(clearMessageUuidToScaleAnimation)()
        })
      )
      translateXOffset.value = withSequence(
        withTiming(myMessage ? -25 : 25, { duration: 150 }),
        withTiming(0, { duration: 150 })
      )
    }
  }, [
    clearMessageUuidToScaleAnimation,
    message,
    messageUuidToScaleAnimation,
    myMessage,
    scaleOffset,
    translateXOffset,
  ])

  const shakeMessage = () => {
    translateXOffset.value = withSequence(
      withTiming(10, { duration: 100 }),
      withTiming(-10, { duration: 100 }),
      withTiming(10, { duration: 100 }),
      withTiming(0, { duration: 100 })
    )
  }

  const showProfile = (userId: string | undefined): void => {
    userId &&
      userId !== myUuid &&
      userId !== MENTION_EVERYONE_ID &&
      RootNavigation.navigate(Routes.UserProfile, {
        chatUserId: userId,
        myUuid,
      })
  }

  const onLongPressToSelectMessage = (): void => {
    requestAnimationFrame(() => {
      if (publishing || deleted) {
        trigger("notificationError", {
          enableVibrateFallback: true,
        })
        shakeMessage()
        return
      }

      messageComponentRef.current?.measure(
        // eslint-disable-next-line max-params
        (x, y, width, height, pageX, pageY) => {
          trigger("impactLight", {
            enableVibrateFallback: true,
          })
          setSelectedMessage({
            ...message,
            pageX,
            pageY,
            width,
            height,
            isEditing: false,
            view: messageComponentRef.current,
          } as SelectedMessage)
          Keyboard.dismiss()
        }
      )
    })
  }

  const onImagePress = () => {
    dismissSelectedMessage()
    setFullScreenImage({ uri: data })
  }

  const onDismissSelectedMessagePress = () => {
    dismissSelectedMessage()
  }

  const closeAndReplySwipe = () => {
    onReply(message as Message)
  }

  return (
    <TouchableWithoutFeedback
      onLongPress={onLongPressToSelectMessage}
      onPress={onDismissSelectedMessagePress}
      delayLongPress={LONG_PRESS_DURATION}
    >
      <MessageContainer>
        <Animated.View style={animatedStyle}>
          <SenderUsernameAvatar
            avatar={avatar}
            chatChannel={chatChannel}
            deleted={deleted}
            isBlocked={isBlocked}
            isFullScreenVideoCall={isFullScreenVideoCall}
            isGroupAdmin={isGroupAdmin}
            myMessage={myMessage}
            myUuid={myUuid}
            replyId={replyId}
            sameSender={sameSender}
            sender={sender}
            senderUsername={senderUsername}
            showBlockAlert={showBlockAlert}
            themeColor={themeColor}
          />

          <RepliedMessage
            reply_to_id={replyId}
            reply_to_message={replyMessage}
            reply_to_message_type={replyMessageType}
            reply_to_username={replyUsername}
            reply_to_image_ratio={replyImageRatio}
            reply_to_user_id={replyToUserId}
            myMessage={myMessage}
            senderUsername={senderUsername}
            publishing={!!publishing}
            scrollToReply={scrollToReply}
            deleted={deleted}
            myUuid={myUuid}
            senderThemeColor={themeColor}
            senderUuid={sender}
            sameSender={sameSender}
          >
            <SwipeToReply
              lockSwipeRight={myMessage || publishing}
              lockSwipeLeft={!myMessage || publishing}
              onSwipeLeft={closeAndReplySwipe}
              onSwipeRight={closeAndReplySwipe}
              hapticOnActivation
            >
              <MessageContent
                myMessage={myMessage}
                hasReply={!!replyId && !deleted}
                hasPreview={!!preview?.image}
              >
                <MessageBubble
                  ref={messageComponentRef}
                  isMessageSelected={isThisMessageSelected}
                  message={message}
                  onImagePress={onImagePress}
                  dismissSelectedMessage={dismissSelectedMessage}
                  onLongPressToSelectMessage={onLongPressToSelectMessage}
                  requestPlay={requestPlay}
                  requestStop={requestStop}
                  shouldPlay={shouldPlay}
                  showProfile={showProfile}
                />
              </MessageContent>
            </SwipeToReply>
            <MessageReactions
              deleted={deleted}
              messageUuid={uuid}
              myMessage={myMessage}
              onUpdateReaction={onUpdateReaction}
              reactions={reactions}
              hasReply={!!replyId && !deleted}
            />
          </RepliedMessage>
        </Animated.View>
      </MessageContainer>
    </TouchableWithoutFeedback>
  )
}

// ChatMessageComponent.whyDidYouRender = {
//   logOnDifferentValues: true,
//   customName: "ChatMessageComponent",
//   diffNameColor: "red",
// }
const mapStateToProps = (state: State, ownProps: ParentProps): StateProps => {
  return {
    isThisMessageSelected: selectIsMessageSelected(ownProps.message.uuid)(
      state
    ),
  }
}
const mapDispatchToProps: DispatchProps = {
  setSelectedMessage: ChatAction.setSelectedMessage,
  onReply: ChatAction.setMessageToReply,
}

export const ChatMessage = connect(
  mapStateToProps,
  mapDispatchToProps
)(React.memo(ChatMessageComponent))
