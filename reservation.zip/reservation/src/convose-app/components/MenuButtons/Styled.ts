import { CenteredText, Props, font } from "convose-styles"
import { TouchableOpacity, View } from "react-native"
import styled from "styled-components"

const messageBorderRadius = 10

const menuWrapperPaddingTop = 10
const menuWrapperPaddingHorizontal = 25
const iconWrapperWidth = 50

export const MenuWrapper = styled(View)`
  flex-direction: column;
  border-radius: ${messageBorderRadius}px;
  background: ${(props: Props) => props.theme.main.background};
  padding-top: ${menuWrapperPaddingTop}px;
  padding-horizontal: ${menuWrapperPaddingHorizontal}px;
  z-index: 20;
`

export const MenuItemButton = styled(TouchableOpacity)`
  flex-direction: ${(props: { rightToLeft: boolean }) =>
    props.rightToLeft ? "row-reverse" : "row"};
  align-items: center;
  margin: ${(props: { withMargin: boolean }) =>
    props.withMargin ? "15px 0px" : "0px"};
  justify-content: flex-start;
`

export const IconWrapper = styled(View)`
  width: ${iconWrapperWidth}px;
  align-items: center;
  justify-content: center;
`

export const MenuItemLabel = styled(CenteredText)`
  font-family: ${font.normal};
  font-style: normal;
  font-size: 15px;
  line-height: 20px;
  color: ${(props: Props) => props.theme.main.text};
  margin-left: 10px;
  text-align: left;
  width: ${(props: { windowWidth: number }) =>
    props.windowWidth -
    (menuWrapperPaddingHorizontal * 2 + iconWrapperWidth)}px;
`
