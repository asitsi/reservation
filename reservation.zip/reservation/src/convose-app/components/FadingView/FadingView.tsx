/* eslint-disable react/jsx-no-useless-fragment */
import React from "react"
import { StyleProp, ViewStyle } from "react-native"
import MaskedView from "@react-native-masked-view/masked-view"
import { LinearGradient } from "expo-linear-gradient"

const LINEAR_GRADIENT_COLORS = ["transparent", "black"]

const maskViewStyle: StyleProp<ViewStyle> = {
  height: "100%",
}
const linearGradientStyle: StyleProp<ViewStyle> = {
  backgroundColor: "transparent",
  justifyContent: "center",
  alignItems: "center",
  height: "100%",
}

const gradientLocations = {
  fadeTop: [0.65, 0.75],
  fadeDown: [0.75, 0.65],
}

type Props = {
  fade: boolean
  fadingPosition: "fadeTop" | "fadeDown"
}
const FadingViewComponent: React.FC<React.PropsWithChildren<Props>> = ({
  fade,
  fadingPosition = "fadeTop",
  children,
}) => {
  if (!fade) {
    return <>{children}</>
  }
  return (
    <MaskedView
      style={maskViewStyle}
      maskElement={
        <LinearGradient
          colors={LINEAR_GRADIENT_COLORS}
          locations={gradientLocations[fadingPosition]}
          style={linearGradientStyle}
        />
      }
    >
      {children}
    </MaskedView>
  )
}
export const FadingView = FadingViewComponent

// <MaskedView
//           style={{ height: "100%" }}
//           maskElement={
//             <LinearGradient
//               colors={["transparent", "black"]}
//               locations={[0.6, 1]}
//               style={{
//                 // Transparent background because mask is based off alpha channel.
//                 backgroundColor: "transparent",
//                 // flex: 1,
//                 justifyContent: "center",
//                 alignItems: "center",
//                 height: "100%",
//               }}
//             />
//           }
//         >
