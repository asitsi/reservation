/* eslint-disable no-nested-ternary */
import { View } from "react-native"
import styled from "styled-components/native"

import { CenteredText, Props, font } from "convose-styles"
import MaterialCommunityIcons from "react-native-vector-icons/MaterialCommunityIcons"

export const TextWrapper = styled(View)`
  align-self: center;
  background: ${(props: Props & { withBgColor: boolean }) =>
    props.withBgColor
      ? props.theme.textInput.background
      : props.theme.statusBar};
  justify-content: center;
  align-items: center;
  flex-direction: row;
  margin-vertical: 2px;
  padding: 5px 10px;
  border-radius: 10px;
`
export const CallStatusMessageWrapper = styled.View`
  justify-content: center;
  align-items: center;
`

export const Label = styled(CenteredText)`
  font-family: ${font.medium};
  font-style: italic;
  font-size: 10px;
  text-align: center;
  color: ${(props: Props) => props.theme.callStatusMsg};
`
export const CallStatusIcon = styled(MaterialCommunityIcons)`
  margin-right: 4px;
  align-self: center;
  color: ${(props: Props) => props.theme.callStatusMsg};
`
