import React from "react"
import { ViewStyle } from "react-native"

import { Indicator, IndicatorRing } from "./Style"

type Props = {
  isOnline: boolean
  offlineIndicatorColor?: string
  size?: number
  style?: ViewStyle
  offlineRingSize?: number
}
const OnlineIndicatorComponent: React.FC<Props> = ({
  isOnline,
  offlineIndicatorColor,
  size = 30,
  offlineRingSize = 4,
  style,
}) => {
  return (
    <IndicatorRing isOnline={isOnline} size={size} style={style}>
      <Indicator
        offlineIndicatorColor={offlineIndicatorColor}
        isOnline={isOnline}
        size={size - offlineRingSize}
      />
    </IndicatorRing>
  )
}

export const OnlineIndicator = React.memo(OnlineIndicatorComponent)
