import React, { useCallback } from "react"
import { useSelector, useDispatch } from "react-redux"

import { ChatUser } from "convose-lib/chat"
import { UsersListAction, selectUserFeature } from "convose-lib/users-list"

type Props = {
  chatUserId?: string
  chatChannel?: string
  chatUser?: ChatUser | null
  goBack: () => void
  isGroup?: boolean
}
export const useChatMenuProfile = ({
  chatUserId = "",
  chatChannel,
  chatUser,
  goBack,
  isGroup,
}: Props) => {
  const requestedProfileUpdate = React.useRef(false)
  const dispatch = useDispatch()
  const chatUserFromState = useSelector(selectUserFeature(chatUserId))
  const getParticipantProfile = useCallback(
    (userUuid: string, channel: string) =>
      dispatch(UsersListAction.getParticipantProfile(userUuid, channel)),
    [dispatch]
  )

  const userProfile = chatUserFromState || chatUser

  React.useEffect(() => {
    if (isGroup) {
      return
    }
    if (!userProfile) {
      if (chatChannel && chatUserId) {
        getParticipantProfile(chatUserId, chatChannel)
      } else {
        goBack()
      }
    } else if (chatChannel && !requestedProfileUpdate.current) {
      requestedProfileUpdate.current = true
      getParticipantProfile(userProfile.uuid, chatChannel)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userProfile, isGroup])
  return userProfile
}
