import React, { FunctionComponent } from "react"
import { TouchableOpacityProps } from "react-native"
import { DEFAULT_HIT_SLOP } from "convose-lib/utils"
import { MaterialIndicator } from "react-native-indicators"
import { color, softShadows } from "convose-styles"
import {
  interpolateColor,
  useAnimatedStyle,
  withTiming,
} from "react-native-reanimated"
import { useSafeAreaInsets } from "react-native-safe-area-context"

import { useKeyboard } from "convose-lib/utils/useKeyboard"
import { useTheme } from "styled-components"
import { ButtonWrapper, Label } from "./Styled"

type SearchInterestsProps = TouchableOpacityProps & Props

type Props = {
  readonly inviteUsers: () => void
  readonly creating: boolean
  readonly label: string
}

export const InviteUsersButton: FunctionComponent<SearchInterestsProps> = ({
  inviteUsers,
  creating,
  label,
  ...touchableOpacityProps
}) => {
  const insets = useSafeAreaInsets()
  const { disabled } = touchableOpacityProps
  const [keyboardHeight] = useKeyboard()
  const theme = useTheme()

  const style = useAnimatedStyle(
    () => ({
      backgroundColor: withTiming(
        interpolateColor(
          Number(disabled),
          [1, 0],
          [theme.inviteToGroup.buttonDisabled, theme.mainBlue]
        ),
        { duration: 200 }
      ),
      ...softShadows,
    }),
    [disabled, theme]
  )

  return !keyboardHeight ? (
    <ButtonWrapper
      insetBottom={insets.bottom}
      style={style}
      onPress={() => {
        if (!creating) {
          inviteUsers()
        }
      }}
      hitSlop={DEFAULT_HIT_SLOP}
      // eslint-disable-next-line react/jsx-props-no-spreading
      {...touchableOpacityProps}
    >
      {!creating ? (
        <Label disabled={disabled}>{label}</Label>
      ) : (
        <MaterialIndicator color={color.white} />
      )}
    </ButtonWrapper>
  ) : null
}
