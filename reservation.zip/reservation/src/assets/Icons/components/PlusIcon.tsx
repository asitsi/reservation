import React from "react"
import { Svg, Rect } from "react-native-svg"
import { SvgProps } from "../../svg/types"

const PlusIcon: React.FC<SvgProps> = ({ color, height = 17 }) => {
  return (
    <Svg width={height} height={height} viewBox="0 0 17 17" fill="none">
      <Rect
        y="7"
        width="16.6753"
        height="2.5013"
        rx="1.25065"
        fill={color || "white"}
      />
      <Rect
        y="7"
        width="16.6753"
        height="2.5013"
        rx="1.25065"
        fill={color || "white"}
      />
      <Rect
        y="7"
        width="16.6753"
        height="2.5013"
        rx="1.25065"
        fill={color || "white"}
      />
      <Rect
        x="7.08691"
        y="16.6753"
        width="16.6753"
        height="2.5013"
        rx="1.25065"
        transform="rotate(-90 7.08691 16.6753)"
        fill={color || "white"}
      />
      <Rect
        x="7.08691"
        y="16.6753"
        width="16.6753"
        height="2.5013"
        rx="1.25065"
        transform="rotate(-90 7.08691 16.6753)"
        fill={color || "white"}
      />
      <Rect
        x="7.08691"
        y="16.6753"
        width="16.6753"
        height="2.5013"
        rx="1.25065"
        transform="rotate(-90 7.08691 16.6753)"
        fill={color || "white"}
      />
    </Svg>
  )
}

export default PlusIcon
