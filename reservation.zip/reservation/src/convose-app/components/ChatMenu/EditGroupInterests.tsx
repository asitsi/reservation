import React, { useState } from "react"
import { ViewStyle } from "react-native"
import Animated, { LinearTransition, ZoomOut } from "react-native-reanimated"

import { InterestLocation, UserInterest } from "convose-lib"
import { softShadows } from "convose-styles"
import {
  GroupInterests,
  EditGroupInterestsContainer,
  EditGroupInterestsDescription,
  EditGroupInterestsScrollContainer,
} from "./Styled"
import { InterestButton } from "../InterestButton"

const layout = LinearTransition.damping(18).duration(50).springify()

const interestStyle: ViewStyle = {
  marginLeft: 0,
  marginTop: 0,
  marginRight: 10,
  marginBottom: 10,
  ...softShadows,
}

type Props = {
  interests: readonly UserInterest[]
  channel: string
  editGroupInterests: (channel: string, interests: UserInterest[]) => void
}
const EditGroupInterestsComponent: React.FC<Props> = ({
  interests,
  channel,
  editGroupInterests,
}) => {
  const [groupInterests, setGroupInterests] = useState(interests)

  const onDeleteInterest = (interest: UserInterest) => {
    const newGroupInterests = groupInterests.filter(
      (groupInterest) => groupInterest.id !== interest.id
    )
    editGroupInterests(channel, newGroupInterests)
    setGroupInterests(newGroupInterests)
  }

  return (
    <EditGroupInterestsContainer layout={layout}>
      <EditGroupInterestsDescription>
        Users will find your group based on these interests and the order they
        are in. They will be displayed on the groups card.
      </EditGroupInterestsDescription>
      <EditGroupInterestsScrollContainer
        layout={layout}
        showsVerticalScrollIndicator={false}
      >
        <GroupInterests layout={layout}>
          {groupInterests.map((interest) => (
            <Animated.View
              exiting={ZoomOut}
              key={interest.name}
              layout={layout}
            >
              <InterestButton
                interest={interest}
                key={interest.name}
                interestLocation={InterestLocation.CallingScreen}
                wrapperStyle={interestStyle}
                size={6}
                onDelete={onDeleteInterest}
              />
            </Animated.View>
          ))}
        </GroupInterests>
      </EditGroupInterestsScrollContainer>
    </EditGroupInterestsContainer>
  )
}

export const EditGroupInterests = React.memo(EditGroupInterestsComponent)
