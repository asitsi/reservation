import React from "react"
import { connect } from "react-redux"
import NetInfo, { NetInfoSubscription } from "@react-native-community/netinfo"

import { ToastAction, ToastProps, ToastType } from "convose-lib/toast"
import { ChatAction, selectOpenChatChannel } from "convose-lib/chat"
import { selectToken } from "convose-lib/user"
import {
  UsersListAction,
  selectUnreadLoadingPartnerFeature,
} from "convose-lib/users-list"
import { State, selectOnboarding } from "convose-lib"
import { CallingAction } from "convose-lib/calling"

type DispatchToProps = {
  showPersistentToast: (toast: ToastProps) => void
  dismissToast: () => void
  setShouldFetchAfterNetRecover: () => void
  getUnreadPartnersList: () => void
  startNotifying: () => void
  getUsersList: () => void
  setGroupCallChannelStatusOnConnecting: () => void
}
type StateToProps = {
  openChat: string | null
  authToken: string
  loadingUnreadPartners: boolean
  onboarding: boolean
}
type Props = StateToProps & DispatchToProps
class NetRecoveryComponent extends React.Component<Props> {
  public unsubscribeNetInfo!: NetInfoSubscription

  // prevent multiple handleNetRecovery call
  public prevIsConnected = false

  // prevent multiple handleNetRecovery call
  public isFirstRun = true

  componentDidMount(): void {
    this.unsubscribeNetInfo = NetInfo.addEventListener((state) => {
      if (!state.isConnected) {
        if (this.isFirstRun) {
          this.isFirstRun = false
        }
        this.prevIsConnected = false
        this.handleNetLost()
      } else {
        if (this.isFirstRun) {
          this.isFirstRun = false
          this.prevIsConnected = true
          return
        }
        if (!this.prevIsConnected) {
          this.prevIsConnected = true
          this.handleNetRecovery()
        }
      }
    })
  }

  componentWillUnmount(): void {
    this.unsubscribeNetInfo && this.unsubscribeNetInfo()
  }

  handleNetLost = () => {
    const { showPersistentToast } = this.props
    showPersistentToast({
      message: "No internet connection",
      type: ToastType.error,
    })
  }

  handleNetRecovery = () => {
    const {
      authToken,
      dismissToast,
      getUnreadPartnersList,
      loadingUnreadPartners,
      onboarding,
      openChat,
      setShouldFetchAfterNetRecover,
      startNotifying,
      getUsersList,
      setGroupCallChannelStatusOnConnecting,
    } = this.props
    setGroupCallChannelStatusOnConnecting()
    dismissToast()
    openChat && setShouldFetchAfterNetRecover()
    authToken &&
      !loadingUnreadPartners &&
      !onboarding &&
      getUnreadPartnersList()
    authToken && !onboarding && startNotifying()
    getUsersList()
  }

  render(): React.ReactNode {
    return null
  }
}

const mapStateToProps = (state: State): StateToProps => ({
  openChat: selectOpenChatChannel(state),
  authToken: selectToken(state),
  loadingUnreadPartners: selectUnreadLoadingPartnerFeature(state),
  onboarding: selectOnboarding(state),
})
const mapDispatchToProps: DispatchToProps = {
  showPersistentToast: ToastAction.showPersistentToast,
  dismissToast: ToastAction.hideToast,
  setShouldFetchAfterNetRecover: ChatAction.setShouldFetchAfterNetRecover,
  getUnreadPartnersList: UsersListAction.getUnreadPartnersList,
  startNotifying: ChatAction.startNotifying,
  getUsersList: UsersListAction.getUsersList,
  setGroupCallChannelStatusOnConnecting:
    CallingAction.setGroupCallChannelStatusOnConnecting,
}

export const NetRecovery = React.memo(
  connect(mapStateToProps, mapDispatchToProps)(NetRecoveryComponent)
)
