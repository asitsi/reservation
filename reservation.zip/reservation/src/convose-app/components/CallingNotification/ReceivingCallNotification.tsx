import React, { PureComponent } from "react"
import { Platform } from "react-native"
import { connect } from "react-redux"
import MaterialIcons from "react-native-vector-icons/MaterialIcons"

import { color, softShadows } from "convose-styles"
import { Routes } from "convose-lib/router"
import {
  ChatSummary,
  ChatUser,
  MessageToPublish,
  MessageType,
} from "convose-lib/chat"
import { CallingAction, CallSignal } from "convose-lib/calling"
import {
  RequestProgressType,
  getAndroidMicPermission,
  permissionNotAllowed,
  quickUuid,
} from "convose-lib/utils"
import { State } from "convose-lib"
import {
  selectChatSummary,
  selectParticipantsArray,
} from "convose-lib/users-list"
import { AppAction, selectIsDarkMode } from "convose-lib/app"
import { selectMyUuid } from "convose-lib/user"
import { Avatar, GroupAvatar } from "../Avatar"
import * as RootNavigation from "../../RootNavigation"
import { CircleButton, BlueCircleButton } from "../CircleButton"
import {
  Body,
  Description,
  Section,
  Username,
} from "../InboxConversationBox/Styled"
import {
  AvatarBackground,
  // GroupAcceptCallButton,
  // GroupAcceptCallButtonContainer,
  // GroupAcceptCallButtonText,
  ReceivingCallUIContainer,
  TouchableWrapperNoFeedback,
} from "./Styled"
import { InAppNotification } from "../InAppNotification"

const ICON_SIZE = 23
const AVATAR_SIZE = 30
const iconStyle = { height: ICON_SIZE, width: ICON_SIZE }
// const countOfUsersToShowAvatar = 2

type ReceivingCallNotificationProps = {
  readonly chatId: string
  readonly isGroup: boolean
  readonly publishMessage: (message: MessageToPublish, chatId: string) => void
  readonly delayOnTouchResponseInMs?: number
  readonly transparentBackground?: boolean
}

type StateToProps = {
  participantsArray: ChatUser[]
  readonly myUuid: string
  readonly chatSummary: ChatSummary | null
  // readonly groupInfo: {
  //   audience: ReadonlyArray<ChatUser>
  //   broadcasters: ReadonlyArray<ChatUser>
  // }
  readonly isDarkMode: boolean | null
}

type DispatchToProps = {
  readonly leaveChannel: () => void
  readonly dismissGroupCall: () => void
  readonly setRequestingPermission: (isRequesting: boolean) => void
}

type AllProps = ReceivingCallNotificationProps & StateToProps & DispatchToProps

export class ReceivingCallNotification extends PureComponent<AllProps> {
  public timeout?: ReturnType<typeof setTimeout> | null = null

  componentDidMount(): void {
    const { delayOnTouchResponseInMs } = this.props
    if (delayOnTouchResponseInMs) {
      this.timeout = setTimeout(() => {
        this.timeout = null
      }, delayOnTouchResponseInMs)
    }
  }

  componentWillUnmount(): void {
    if (this.timeout) {
      clearTimeout(this.timeout)
      this.timeout = null
    }
  }

  private getCallerName(chatUser: { username: string }): string {
    const { isGroup, chatSummary } = this.props
    if (!isGroup) {
      return chatUser.username
    }
    return chatSummary?.group_name || "Group"
  }

  private readonly runConversation = () => {
    const { chatId, dismissGroupCall } = this.props
    dismissGroupCall()
    RootNavigation.navigate(Routes.Chat, {
      channel: chatId,
      chatUser: {},
    })
  }

  private runGroupConversation = () => {
    requestAnimationFrame(() => {
      if (this.timeout) {
        return
      }
      const { isGroup } = this.props
      if (isGroup) {
        this.runConversation()
      }
    })
  }

  private declineCall = async () => {
    requestAnimationFrame(async () => {
      if (this.timeout) {
        return
      }
      const { myUuid, chatId, publishMessage, leaveChannel, dismissGroupCall } =
        this.props
      const declineCallMessage = {
        data: "Declined call",
        action: CallSignal.callEndDecline,
        isTyping: false,
        sender: myUuid,
        message_type: MessageType.Call,
        uuid: quickUuid(),
        senderUsername: "",
      }
      dismissGroupCall()
      await leaveChannel()
      publishMessage(declineCallMessage, chatId)
    })
  }

  private permissionRequestCallback = (
    requestProgress: RequestProgressType
  ) => {
    const { setRequestingPermission } = this.props
    setRequestingPermission(requestProgress === "BEFORE_REQUEST")
  }

  private acceptCall = async () => {
    requestAnimationFrame(async () => {
      if (this.timeout) {
        return
      }
      const { isGroup } = this.props
      if (Platform.OS === "android" && !isGroup) {
        const { status } = await getAndroidMicPermission(
          this.permissionRequestCallback
        )
        if (status !== "granted") {
          permissionNotAllowed("MICROPHONE")
          return
        }
      }
      this.returnToCall()
    })
  }

  private onDismissCall = () => {
    const { dismissGroupCall, isGroup } = this.props
    if (isGroup) {
      dismissGroupCall()
    } else {
      this.declineCall()
    }
  }

  private returnToCall = () => {
    const { chatId, isGroup } = this.props
    RootNavigation.navigate(Routes.Chat, {
      channel: chatId,
      chatUser: {},
      forRejoinCall: true,
      forceMicOn: !isGroup,
      callStartTime: new Date().getTime(),
    })
  }

  private renderCallStarter = () => {
    const { isGroup, chatSummary } = this.props
    const callStarterInfo = chatSummary?.last_message?.sender_username
    return isGroup && !!callStarterInfo ? (
      <Section>
        <Description fontSize={14}>
          {callStarterInfo} started a call
        </Description>
      </Section>
    ) : null
  }

  private renderActionButtons(): React.ReactNode {
    const { isGroup } = this.props
    if (isGroup) {
      // const allUsers = [...groupInfo.broadcasters, ...groupInfo.audience]
      // const avatars = allUsers
      //   .slice(0, countOfUsersToShowAvatar)
      //   .map((user) => user.avatar)
      // const otherUsersCount = allUsers.length - countOfUsersToShowAvatar
      return (
        <BlueCircleButton
          size={AVATAR_SIZE + 5}
          style={softShadows}
          onPress={this.acceptCall}
        >
          <MaterialIcons
            name="call"
            size={ICON_SIZE}
            color="white"
            style={iconStyle}
          />
        </BlueCircleButton>
        // <GroupAcceptCallButton onPress={this.acceptCall}>
        //   <GroupAcceptCallButtonContainer height={AVATAR_SIZE}>
        //     <MaterialIcons
        //       name="call"
        //       size={ICON_SIZE}
        //       color="white"
        //       style={iconStyle}
        //     />
        //     <GroupAcceptCallButtonText />
        //     <GroupAvatar avatarSize={ICON_SIZE} avatars={avatars} />
        //     {otherUsersCount > 0 && (
        //       <GroupAcceptCallButtonText>
        //         +{otherUsersCount}
        //       </GroupAcceptCallButtonText>
        //     )}
        //   </GroupAcceptCallButtonContainer>
        // </GroupAcceptCallButton>
      )
    }
    return (
      <>
        <CircleButton
          size={AVATAR_SIZE + 5}
          backgroundColor={color.red}
          style={softShadows}
          margin={0}
          onPress={this.declineCall}
        >
          <MaterialIcons
            name="call-end"
            size={ICON_SIZE}
            color="white"
            style={iconStyle}
          />
        </CircleButton>
        <BlueCircleButton
          size={AVATAR_SIZE + 5}
          style={softShadows}
          onPress={this.acceptCall}
        >
          <MaterialIcons
            name="call"
            size={ICON_SIZE}
            color="white"
            style={iconStyle}
          />
        </BlueCircleButton>
      </>
    )
  }

  // eslint-disable-next-line complexity
  render(): React.ReactNode {
    const {
      isGroup,
      participantsArray,
      chatSummary,
      isDarkMode,
      transparentBackground,
    } = this.props
    const participants =
      chatSummary && chatSummary.participants
        ? Object.values(chatSummary.participants)
        : participantsArray

    const chatUser = participants[0] || {
      avatar: "",
      interests: [],
      status: "",
      username: "",
      theme_color: "SystemDefault",
    }
    const bgColor = (() => {
      if (isGroup) {
        return undefined
      }
      if (isDarkMode) {
        return chatUser?.dark_background_color
      }
      return chatUser?.background_theme_color
    })()
    return (
      <InAppNotification
        persistNotification={!isGroup}
        lockSwipe={false}
        hideDurationInMs={10000}
        onCloseNotification={this.onDismissCall}
        useBlur
      >
        <TouchableWrapperNoFeedback
          transparentBackground={transparentBackground}
          onPress={this.runGroupConversation}
        >
          {({ pressed }: { pressed: boolean }) => (
            <ReceivingCallUIContainer pressEffect={pressed && isGroup}>
              <AvatarBackground bgColor={bgColor} size={AVATAR_SIZE * 1.48}>
                {isGroup ? (
                  <GroupAvatar
                    participants={participants}
                    size={AVATAR_SIZE}
                    showRing
                    isDarkMode={!!isDarkMode}
                    avatar={chatSummary?.avatar}
                  />
                ) : (
                  <Avatar
                    height={AVATAR_SIZE}
                    userAvatar={chatUser?.avatar}
                    bgColor={bgColor}
                    showRing={!chatUser?.avatar?.default_avatar}
                  />
                )}
              </AvatarBackground>
              <Body>
                <Section>
                  <Username
                    fontSize={16}
                    color={isGroup ? "SystemDefault" : chatUser.theme_color}
                  >
                    {this.getCallerName(chatUser)}
                  </Username>
                </Section>
                {this.renderCallStarter()}
              </Body>
              {this.renderActionButtons()}
            </ReceivingCallUIContainer>
          )}
        </TouchableWrapperNoFeedback>
      </InAppNotification>
    )
  }
}

const mapStateToProps = (
  state: State,
  ownProps: ReceivingCallNotificationProps
): StateToProps => ({
  myUuid: selectMyUuid(state),
  participantsArray: selectParticipantsArray(ownProps.chatId)(state),
  chatSummary: selectChatSummary(ownProps.chatId)(state),
  // groupInfo: selectGroupCallInfo(ownProps.chatId)(state),
  isDarkMode: selectIsDarkMode(state),
})

const mapDispatchToProps: DispatchToProps = {
  leaveChannel: CallingAction.leaveChannel,
  dismissGroupCall: CallingAction.dismissGroupCall,
  setRequestingPermission: AppAction.setRequestingPermission,
}

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(ReceivingCallNotification)
