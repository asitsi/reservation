import React from "react"
import { useSelector, useDispatch } from "react-redux"
import SwitchWithIcons from "react-native-switch-with-icons"

import { selectChatPermissions, UsersListAction } from "convose-lib/users-list"
import { useMainBlue } from "convose-lib/utils/useMainBlue"
import { color } from "convose-styles"
import { Item, MenuButtons } from "../MenuButtons"
import { SlideUpWrapper } from "../SlideUpWrapper"
import { SettingIcon } from "./SettingIcon"
import {
  iconColor,
  ParticipantsPermissionsContainer,
  ParticipantsPermissionsHeader,
  ParticipantsPermissionsHeaderContainer,
  pnSwitchButtonStyle,
} from "./Styled"
import { useTrackColor } from "./useTrackColor"

const PermissionsSwitchButton: React.FC<{
  isEnabled: boolean
  onToggle: () => void
}> = ({ isEnabled, onToggle }) => {
  const mainBlue = useMainBlue()
  // eslint-disable-next-line react-perf/jsx-no-new-object-as-prop
  const thumbColor = { true: mainBlue, false: color.bittersweet }
  const trackColor = useTrackColor()
  return (
    <SwitchWithIcons
      value={isEnabled}
      noIcon
      thumbColor={thumbColor}
      trackColor={trackColor}
      iconColor={iconColor}
      onValueChange={onToggle}
      style={pnSwitchButtonStyle}
      animationDuration={0}
    />
  )
}

const menuItemsParticipantPermissions = (
  toggleSignUpRequired: () => void,
  isSignUpRequired: boolean
): ReadonlyArray<Item> => [
  {
    label:
      "Users need to signup to Convose to provide any form of content (msgs, audio, video) in chat or calls.",
    icon: (
      <PermissionsSwitchButton
        isEnabled={!isSignUpRequired}
        onToggle={toggleSignUpRequired}
      />
    ),
    onPress: toggleSignUpRequired,
    rightToLeft: true,
  },
]

type Props = {
  channel: string
  showPermissions: boolean
  closePermissions: () => void
}

const ParticipantsPermissionsComponent: React.FC<Props> = ({
  showPermissions,
  closePermissions,
  channel,
}) => {
  const dispatch = useDispatch()
  const setGuestUsersPermissionInGroup = React.useCallback(
    (chatChannel: string, isSignUpRequired: boolean) => {
      dispatch(
        UsersListAction.setGuestUsersPermissionInGroup(
          chatChannel,
          isSignUpRequired
        )
      )
    },
    [dispatch]
  )
  const permissions = useSelector(selectChatPermissions(channel))
  const groupPermission = {
    owner: false,
    allow_guests: true,
    blocked: false,
    ...permissions,
  }

  const toggleSignUpRequired = () => {
    setGuestUsersPermissionInGroup(channel, !groupPermission.allow_guests)
  }
  if (!showPermissions) {
    return null
  }
  return (
    <SlideUpWrapper canDismiss onDismiss={closePermissions}>
      <ParticipantsPermissionsContainer>
        <ParticipantsPermissionsHeaderContainer>
          <SettingIcon height={60} />
          <ParticipantsPermissionsHeader>
            Participant permissions
          </ParticipantsPermissionsHeader>
        </ParticipantsPermissionsHeaderContainer>
        <MenuButtons
          items={menuItemsParticipantPermissions(
            toggleSignUpRequired,
            groupPermission.allow_guests
          )}
        />
      </ParticipantsPermissionsContainer>
    </SlideUpWrapper>
  )
}

export const ParticipantsPermissions = React.memo(
  ParticipantsPermissionsComponent
)
