import React, { useCallback, useRef } from "react"
import { useSelector, useDispatch } from "react-redux"
import { CallingAction, selectIsSeekingQuickCall } from "convose-lib/calling"
import {
  FadeInLeft,
  FadeOutRight,
  LinearTransition,
} from "react-native-reanimated"
import { CallButton } from "../../components/CallButton"
import { RandomAvatar } from "../../components/RandomAvatar"
import {
  AvatarContainer,
  CallButtonContainer,
  Container,
  Label,
  LabelContainer,
} from "./Styled"

const layout = LinearTransition.damping(18).duration(50).springify()

const Avatars = () => (
  <AvatarContainer>
    <RandomAvatar />
  </AvatarContainer>
)

type TitleProps = {
  isSeeking: boolean
}
const Title: React.FC<TitleProps> = ({ isSeeking }) => (
  <LabelContainer layout={layout}>
    {!isSeeking && (
      <Label entering={FadeInLeft} exiting={FadeOutRight}>
        Press the call button
      </Label>
    )}
    {!isSeeking && (
      <Label entering={FadeInLeft} exiting={FadeOutRight}>
        to searching for a
      </Label>
    )}
    {isSeeking && (
      <Label entering={FadeInLeft} exiting={FadeOutRight}>
        Searching for a
      </Label>
    )}
    <Label>conversation partner</Label>
  </LabelContainer>
)
type Props = {
  goBack: () => void
}
const SearchingConversationComponent: React.FC<Props> = ({ goBack }) => {
  const dispatch = useDispatch()
  const isSeekingQuickCall = useSelector(selectIsSeekingQuickCall)
  const isCallEndedByPressingEndCall = useRef(false)

  const cancelQuickCall = React.useCallback(() => {
    dispatch(CallingAction.cancelQuickCall())
  }, [dispatch])
  const startQuickCall = React.useCallback(() => {
    dispatch(CallingAction.startQuickCall())
  }, [dispatch])

  const onPressCallButton = useCallback(() => {
    if (isSeekingQuickCall) {
      isCallEndedByPressingEndCall.current = true
      cancelQuickCall()
    } else {
      isCallEndedByPressingEndCall.current = false
      startQuickCall()
    }
  }, [cancelQuickCall, isSeekingQuickCall, startQuickCall])

  const onEndCall = useCallback(() => {
    if (isCallEndedByPressingEndCall.current) {
      goBack()
    }
  }, [goBack])

  return (
    <Container>
      <Avatars />
      <Title isSeeking={isSeekingQuickCall} />
      <CallButtonContainer>
        <CallButton
          isCalling={isSeekingQuickCall}
          onPress={onPressCallButton}
          onEndCall={onEndCall}
        />
      </CallButtonContainer>
    </Container>
  )
}

export const SearchingConversation = SearchingConversationComponent
