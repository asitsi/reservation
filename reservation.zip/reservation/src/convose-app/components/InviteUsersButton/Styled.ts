import { TouchableOpacity } from "react-native"
import styled from "styled-components"
import Animated from "react-native-reanimated"

import { CenteredText, Props, color, font } from "convose-styles"

const AnimatedTouchableOpacity =
  Animated.createAnimatedComponent(TouchableOpacity)

export const ButtonWrapper = styled(AnimatedTouchableOpacity)`
  border-radius: 50px;
  text-align: center;
  padding: 15px 30px;
  /* overflow: hidden; */
  width: 60%;
  max-width: 500px;
  position: absolute;
  bottom: ${(props: { insetBottom: number }) => props.insetBottom + 40}px;
  align-self: center;
  justify-content: center;
  align-items: center;
  flex-direction: row;
  z-index: 10000;
`

export const Label = styled(CenteredText)`
  font-family: ${font.semiBold};
  font-size: 18px;
  text-align: center;
  color: ${(props: Props & { disabled: boolean }) =>
    props.disabled
      ? props.theme.inviteToGroup.buttonTitleDisabled
      : color.white};
`
