import React from "react"
import { Pressable } from "react-native"
import { NavActionButton } from "./Styled"

type Props = {
  onPress?: () => void
  children: React.ReactElement
  childrenPosition?: "flex-start" | "flex-end" | "center"
}

const NavButtonComponent: React.FC<Props> = ({
  onPress,
  children,
  childrenPosition = "center",
}) => {
  return (
    <Pressable
      onPress={onPress}
      // eslint-disable-next-line react-perf/jsx-no-new-object-as-prop
      style={{
        flex: 1,
        justifyContent: "center",
        alignItems: childrenPosition,
      }}
    >
      {({ pressed }) => {
        return <NavActionButton pressed={pressed}>{children}</NavActionButton>
      }}
    </Pressable>
  )
}

export const NavButton = React.memo(NavButtonComponent)
