/* eslint-disable @typescript-eslint/no-explicit-any */
import { OrderedMap } from "immutable"
import * as React from "react"

import { ChatChannel, Notification } from "convose-lib/chat"
import { InAppNotification } from "../../components/InAppNotification"
import { InboxConversationBox } from "../InboxConversationBox"

type Props = {
  notifications: OrderedMap<ChatChannel, Notification>
  closeNotification: (notification: Notification) => void
}

export const Notifications: React.FC<Props> = ({
  closeNotification,
  notifications,
}) => {
  return (
    <>
      {notifications
        .toList()
        .filter((notification) => notification && !notification.showed)
        .map((notification) => {
          const onClose = () => {
            closeNotification(notification)
          }
          return (
            <InAppNotification
              key={notification.channel}
              onCloseNotification={onClose}
              useBlur
            >
              <InboxConversationBox
                chatSummary={notification as any}
                hideDate
                hideOnlineIndicator
                size="small"
                useDefaultBackgroundForGroups={false}
                forceDefaultTextColor
                delayOnTouchResponseInMs={300 + 200} // 200 is notification animation duration to show
                onTouchEnd={onClose}
                transparentBackground
              />
            </InAppNotification>
          )
        })}
    </>
  )
}
