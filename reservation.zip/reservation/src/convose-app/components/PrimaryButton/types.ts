export enum ButtonType {
  normal = "normal",
  outline = "outline",
  text = "text",
}
