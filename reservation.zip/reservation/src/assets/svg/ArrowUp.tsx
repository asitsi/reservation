import React from "react"
import { Svg, Path } from "react-native-svg"
import { SvgProps } from "./types"
import { getRatio, getWidth } from "./utils"

const defaultHeight = 11
const defaultWidth = 16
const ratio = getRatio(defaultHeight, defaultWidth)

export const ArrowUpSvg: React.FunctionComponent<SvgProps> = ({
  height,
  color,
}) => {
  const svgHeight = height || defaultHeight
  const svgWidth = height ? getWidth(ratio, height) : defaultWidth
  return (
    <Svg width={svgWidth} height={svgHeight} viewBox="0 0 16 11" fill="none">
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M12.1412 10.279C13.0216 11.2403 14.5357 11.2403 15.4161 10.279C16.1946 9.42889 16.1946 8.12414 15.4161 7.27405L9.39807 0.702629C8.522 -0.253997 7.00801 -0.230478 6.16202 0.7529L0.531488 7.29784C-0.194065 8.14122 -0.17463 9.39453 0.576721 10.215C1.47433 11.1951 3.02932 11.1584 3.87972 10.1369L7.51357 5.77213C7.63964 5.6207 7.87016 5.61526 8.00322 5.76056L12.1412 10.279Z"
        fill={color || "white"}
      />
    </Svg>
  )
}
