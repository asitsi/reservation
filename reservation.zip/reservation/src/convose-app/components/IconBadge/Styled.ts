import { View } from "react-native"
import styled from "styled-components"

import { CenteredText, color, font, Props } from "convose-styles"

type StyledBadgeProps = {
  readonly inboxIndicator: boolean
  readonly withBorder: boolean
  readonly width: number
  readonly height: number
  readonly useMainBlue?: boolean
}

export const BadgeContainer = styled(View)`
  position: absolute;
  right: -5px;
  top: -5px;
  justify-content: center;
  align-items: center;
  overflow: hidden;
`
export const BadgeOuter = styled(View)`
  border-radius: ${(props: StyledBadgeProps) => Number(props.height / 2)}px;
  height: ${(props: StyledBadgeProps) => props.height}px;
  width: ${(props: StyledBadgeProps) => props.width}px;
  background: ${(props: Props) => props.theme.statusBar};
  justify-content: center;
  align-items: center;
`
export const BadgeInner = styled(View)`
  background: ${(props: Props & StyledBadgeProps) => {
    if (props.inboxIndicator) {
      if (props.useMainBlue) {
        return props.theme.mainBlue
      }
      return color.red
    }
    return color.darkGray
  }};
  border-radius: ${(props: StyledBadgeProps) => Number(props.height / 2)}px;
  height: ${(props: StyledBadgeProps) => props.height}px;
  width: ${(props: StyledBadgeProps) => props.width}px;
  align-self: center;
  justify-content: center;
  align-items: center;
`
export const StyledBadge = styled(CenteredText)`
  color: ${color.white};
  font-size: 9px;
  text-align: center;
  justify-content: center;
  font-family: ${font.normal};
`
