import styled from "styled-components/native"
import Animated from "react-native-reanimated"

import { CenteredText, Props, font } from "convose-styles"

export const Container = styled.View`
  background: ${(props: Props) => props.theme.main.background};
  flex: 1;
  width: 100%;
  height: 100%;
  justify-content: center;
  align-items: center;
`
export const LabelContainer = styled(Animated.View)`
  padding-horizontal: 10%;
`
const AnimatedCenteredText = Animated.createAnimatedComponent(CenteredText)
export const Label = styled(AnimatedCenteredText)`
  color: ${(props: Props) => props.theme.main.text};
  font-family: ${font.semiBold};
  font-size: 20px;
  text-align: center;
`
export const AvatarContainer = styled.View`
  width: 250px;
  align-self: center;
  overflow: hidden;
  margin-bottom: 40px;
`
export const CallButtonContainer = styled.View`
  margin-top: 60px;
  margin-bottom: 90px;
`
