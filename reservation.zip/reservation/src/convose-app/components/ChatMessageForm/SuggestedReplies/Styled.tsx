import Animated from "react-native-reanimated"
import styled from "styled-components/native"

import { CenteredText, Props, font } from "convose-styles"

export const SuggestItemContainer = styled(Animated.View)`
  border-radius: 25px;
  border-width: 1px;
  border-color: ${(props: Props) => props.theme.mainBlue};
  padding: 10px 15px;
  margin-right: 10px;
  ${(props: { fixedWidth: boolean }) =>
    props.fixedWidth ? `max-width: 200px;` : ``}
  justify-content: center;
  align-items: center;
`

export const SuggestItemMessage = styled(CenteredText)`
  font-family: ${font.bold};
  color: ${(props: Props) => props.theme.mainBlue};
  font-size: 14px;
`
export const AnimatedFlatList = styled(Animated.FlatList)`
  background-color: ${(
    props: Props & { transparentBackgroundColor: boolean }
  ) =>
    props.transparentBackgroundColor
      ? "transparent"
      : props.theme.main.background};
`
