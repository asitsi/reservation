import { TouchableOpacity } from "react-native"
import styled from "styled-components/native"
import Animated from "react-native-reanimated"

import { CenteredText, Props, color, font } from "convose-styles"

const AnimatedTouchableOpacity =
  Animated.createAnimatedComponent(TouchableOpacity)
export const Container = styled(AnimatedTouchableOpacity)`
  position: absolute;
  right: 30px;
  bottom: ${(props: { insetBottom: number }) => props.insetBottom + 20}px;
  background-color: ${(props: Props) => props.theme.mainBlue};
  justify-content: space-between;
  flex-direction: row;
  align-items: center;
  padding: 15px 20px;
  border-radius: 100px;
  height: 60px;
`

const AnimatedCenteredText = Animated.createAnimatedComponent(CenteredText)
export const Title = styled(AnimatedCenteredText)`
  font-family: ${font.semiBold};
  color: ${color.white};
  font-size: 20px;
`
