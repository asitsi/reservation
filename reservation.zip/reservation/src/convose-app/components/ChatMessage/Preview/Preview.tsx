import React from "react"

import { LinkPreviewType } from "convose-lib/chat"
import { openUrl } from "convose-lib/utils/openUrl"
import { Routes } from "convose-lib/router"
import { LONG_PRESS_DURATION } from "convose-lib/utils"
import { ImagePreview } from "./ImagePreview"
import { navigate } from "../../../RootNavigation"
import { PreviewContainer, PreviewTitle } from "./Styled"

type Props = {
  preview?: LinkPreviewType
  onLongPress?: () => void
}
const PreviewComponent: React.FC<Props> = ({ preview, onLongPress }) => {
  if (!preview) {
    return null
  }
  const openLink = () => {
    openUrl(preview?.url)
  }
  const onPlay = () => {
    navigate(Routes.YouTubePlayer, {
      videoId: preview.videoId,
      thumbnail: preview.image,
    })
  }

  return (
    <PreviewContainer
      onLongPress={onLongPress}
      delayLongPress={LONG_PRESS_DURATION}
      onPress={openLink}
      disabled={!!preview.videoId}
    >
      <ImagePreview
        uri={preview.image}
        videoId={preview.videoId}
        onOpenPress={openLink}
        onPlayPress={onPlay}
        imageRatio={preview.ratio || 1}
      />
      <PreviewTitle numberOfLines={2} ellipsizeMode="tail">
        {preview.title}
      </PreviewTitle>
    </PreviewContainer>
  )
}

export const Preview = React.memo(PreviewComponent)
