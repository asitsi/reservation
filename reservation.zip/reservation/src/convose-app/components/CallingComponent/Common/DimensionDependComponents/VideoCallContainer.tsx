import React, { PropsWithChildren } from "react"
import { useWindowDimensions } from "react-native"
import { useSafeAreaInsets } from "react-native-safe-area-context"

import { StyledVideoCallContainer } from "../Styled"

type Props = {
  isShareScreen: boolean
  keyboardHeight: number
  isLandscape?: boolean
}
const VideoCallContainerComponent: React.FC<PropsWithChildren<Props>> = ({
  isShareScreen,
  keyboardHeight,
  isLandscape,
  children,
}) => {
  const { width, height } = useWindowDimensions()
  const { left, right } = useSafeAreaInsets()
  const shareScreenDivisor = 3.5
  const shareScreenHeight = height / shareScreenDivisor
  const translateYOnSharedScreen = (height - shareScreenHeight) / 2
  const horizontalPaddingInLandscape = Math.max(left, right)
  return (
    <StyledVideoCallContainer
      isShareScreen={isShareScreen}
      keyboardHeight={keyboardHeight}
      isLandscape={isLandscape}
      shareScreenHeight={shareScreenHeight}
      width={width}
      height={height}
      translateYOnSharedScreen={translateYOnSharedScreen}
      horizontalPaddingInLandscape={horizontalPaddingInLandscape}
    >
      {children}
    </StyledVideoCallContainer>
  )
}
export const VideoCallContainer = React.memo(VideoCallContainerComponent)
