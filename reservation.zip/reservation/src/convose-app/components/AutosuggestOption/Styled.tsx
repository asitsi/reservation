import { TouchableOpacity, View } from "react-native"
import styled from "styled-components"
import FontAwesome from "react-native-vector-icons/FontAwesome"

import { CenteredText, Props, font } from "convose-styles"
import Animated from "react-native-reanimated"

export const StyledOptionView = styled(TouchableOpacity)`
  align-self: flex-end;
  flex-direction: row;
  justify-content: flex-start;
  min-height: 30px;
  padding: 5px 10px;
  width: 100%;
`
export const StyledOptionText = styled(CenteredText)`
  color: ${(props: Props) => props.theme.interests.autocompleteList.color};
  font-size: 14px;
  margin: 10px 0px;
  font-family: ${font.light};
`
type ExistingIndicatorProps = Props & { removed: boolean }
export const StyledExistingIndicatorText = styled(StyledOptionText)`
  font-size: 11px;
  font-family: ${font.semiBold};
  color: ${(props: ExistingIndicatorProps) =>
    props.removed
      ? props.theme.interests.autocompleteList.removed
      : props.theme.mainBlue};
  margin: 0px;
`
export const AddedMarkerWrapper = styled(Animated.View)`
  flex-direction: row;
  justify-content: center;
  align-items: center;
  position: absolute;
  top: -9px;
  left: 30px;
  padding: 0px 2px;
  background: ${(props: Props) =>
    props.theme.interests.autocompleteList.background};
`
export const StyledFontAwesomeAddedMarker = styled(FontAwesome)`
  margin-right: 4px;
  color: ${(props: ExistingIndicatorProps) =>
    props.removed
      ? props.theme.interests.autocompleteList.removed
      : props.theme.mainBlue};
`

export const InterestTextWrapper = styled(View)`
  max-width: 100%;
  margin-left: 10px;
`
type InterestWrapperProps = Props & {
  hasAdded: boolean
  removed: boolean
}
export const InterestWrapper = styled(View)`
  flex-direction: row;
  justify-content: flex-start;
  border-width: 1px;
  width: 100%;
  border-radius: 11px;
  padding: 3px 10px;
  position: relative;
  border-color: ${(props: InterestWrapperProps) => {
    if (props.hasAdded) {
      return props.theme.mainBlue
    }
    if (props.removed) {
      return props.theme.interests.autocompleteList.removed
    }
    return "transparent"
  }};
  align-items: center;
`
