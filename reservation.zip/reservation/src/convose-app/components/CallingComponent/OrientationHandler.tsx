/* eslint-disable react/jsx-props-no-spreading */
import React, { useMemo } from "react"
import { useSelector, useDispatch } from "react-redux"
import { omit } from "lodash"

import { selectScreenOrientation } from "convose-lib/app"
import { BlockSendContent } from "convose-lib/chat"
import {
  selectIsGroupAdmin,
  selectIsHandRaiseEnabled,
} from "convose-lib/users-list/selector"
import { UsersListAction } from "convose-lib/users-list/actions"
import { CallingAction } from "convose-lib/calling/actions"
import { HandRaiseTypes } from "convose-lib/users-list/dto"
import { selectMyRaisedHandStatus } from "convose-lib/calling/selector"

import { PortraitCallingComponent } from "./Portrait/PortraitCallingComponent"
import { CallingProps } from "./dto"
import { LandscapeCallingComponent } from "./Landscape/LandscapeCallingComponent"

const OrientationHandlerComponent: React.FC<CallingProps & BlockSendContent> = (
  props
) => {
  const { channel } = props
  const dispatch = useDispatch()
  const enableHandRaise = React.useCallback(
    (chatChannel: string) => {
      dispatch(UsersListAction.enableHandRaise(chatChannel))
    },
    [dispatch]
  )
  const disableHandRaise = React.useCallback(
    (chatChannel: string) => {
      dispatch(UsersListAction.disableHandRaise(chatChannel))
    },
    [dispatch]
  )

  const requestHandRaise = React.useCallback(
    (status: HandRaiseTypes | null, chatId: string) => {
      dispatch(CallingAction.requestHandRaise(status, chatId))
    },
    [dispatch]
  )

  const myRaisedHandStatus = useSelector(selectMyRaisedHandStatus)
  const isGroupAdmin = useSelector(selectIsGroupAdmin(channel))
  const isHandRaiseEnabled = useSelector(selectIsHandRaiseEnabled(channel))
  const propsWithoutAuth = useMemo(() => {
    return omit(props, ["isBlocked", "showBlockAlert"])
  }, [props])

  const screenOrientation = useSelector(selectScreenOrientation)
  const authorizedToggleAudio = () => {
    const { isBlocked, showBlockAlert, toggleAudio, audioSetting } = props
    if (isBlocked && !audioSetting.isAudioEnabled) {
      showBlockAlert("Content")
      return
    }
    toggleAudio()
  }
  const authorizedToggleVideo = () => {
    const { isBlocked, showBlockAlert, toggleVideo, audioSetting } = props
    if (isBlocked && !audioSetting.isVideoEnabled) {
      showBlockAlert("Content")
      return
    }
    toggleVideo()
  }
  const toggleHandRaise = () => {
    const { isBlocked, showBlockAlert, audioSetting } = props
    if (isBlocked && !audioSetting.isVideoEnabled) {
      showBlockAlert("Content")
      return
    }
    if (isGroupAdmin) {
      if (isHandRaiseEnabled) {
        disableHandRaise(channel)
      } else {
        enableHandRaise(channel)
      }
    } else if (myRaisedHandStatus === null) {
      requestHandRaise("request_handraise", channel)
    } else {
      requestHandRaise("cancelled_handraise", channel)
    }
  }

  if (
    screenOrientation === "LANDSCAPE-LEFT" ||
    screenOrientation === "LANDSCAPE-RIGHT"
  ) {
    return (
      <LandscapeCallingComponent
        {...propsWithoutAuth}
        toggleAudio={authorizedToggleAudio}
        toggleVideo={authorizedToggleVideo}
        isLandscapeRight={screenOrientation === "LANDSCAPE-RIGHT"}
        isGroupAdmin={isGroupAdmin}
        isHandRaiseEnabled={isHandRaiseEnabled}
        toggleHandRaise={toggleHandRaise}
        myRaisedHandStatus={myRaisedHandStatus}
      />
    )
  }
  return (
    <PortraitCallingComponent
      {...propsWithoutAuth}
      toggleAudio={authorizedToggleAudio}
      toggleVideo={authorizedToggleVideo}
      isGroupAdmin={isGroupAdmin}
      isHandRaiseEnabled={isHandRaiseEnabled}
      toggleHandRaise={toggleHandRaise}
      myRaisedHandStatus={myRaisedHandStatus}
    />
  )
}
export const CallingComponent = React.memo(OrientationHandlerComponent)
