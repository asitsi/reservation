/* eslint-disable react-perf/jsx-no-new-object-as-prop */
import React from "react"
import { Keyboard, TouchableWithoutFeedback } from "react-native"
import FastImage from "react-native-fast-image"

import { MessageType, ReplyMessageType } from "convose-lib/chat"
import {
  RepliedMessageText,
  RepliedUserDetailsContainer,
  RepliedUserDetailsText,
  ReplyWrapper,
  StyledIcon,
  RepliedMessageContainer,
  ReplyImageContainer,
  ReplyImage,
  AttachmentContainer,
} from "./style"
import { TextMessage } from "./TextMessage"

const AttachmentReply: React.FC = () => (
  <AttachmentContainer>
    <RepliedMessageText isAttachment>Attachment </RepliedMessageText>
    <StyledIcon name="attach" size={17} isText />
  </AttachmentContainer>
)

type Props = {
  myMessage: boolean
  senderUsername: string
  publishing: boolean
  scrollToReply: (uuid: string) => void
  deleted?: boolean
  myUuid: string
  senderUuid: string
  senderThemeColor?: string
  sameSender: boolean
} & ReplyMessageType

const RepliedMessageComponent: React.FC<React.PropsWithChildren<Props>> = ({
  reply_to_id: replyId,
  reply_to_message: replyMessage,
  reply_to_message_type: replyMessageType,
  reply_to_username: replyUsername,
  reply_to_image_ratio: replyImageRatio,
  reply_to_user_id: replyToUserId,
  myMessage,
  senderUsername,
  publishing,
  children,
  scrollToReply,
  deleted,
  myUuid,
  senderThemeColor,
  senderUuid,
  sameSender,
}) => {
  if (!replyId || deleted) {
    // eslint-disable-next-line react/jsx-no-useless-fragment
    return <>{children}</>
  }
  const scrollToRepliedMessage = () => {
    Keyboard.dismiss()
    scrollToReply(replyId)
  }
  const renderMessage = (): React.ReactNode => {
    if (replyMessageType === MessageType.Image && replyMessage) {
      return (
        <ReplyImageContainer publishing={publishing}>
          <ReplyImage
            source={{ uri: replyMessage }}
            resizeMode={FastImage.resizeMode.cover}
            ratio={replyImageRatio || 1}
            width={85}
          />
        </ReplyImageContainer>
      )
    }

    return (
      <RepliedMessageContainer publishing={publishing}>
        {replyMessageType === "audio" ? (
          <AttachmentReply />
        ) : (
          <TextMessage
            message={replyMessage || ""}
            myUid={myUuid}
            myMessage={myMessage}
            isReply
          />
        )}
      </RepliedMessageContainer>
    )
  }
  const them = (() => {
    if (myMessage && replyToUserId === myUuid) {
      return "yourself"
    }
    if (!myMessage && replyToUserId === myUuid) {
      return "you"
    }
    if (replyToUserId === senderUuid) {
      return "themselves"
    }
    return replyUsername
  })()

  return (
    <ReplyWrapper myMessage={myMessage} sameSender={sameSender}>
      <RepliedUserDetailsContainer>
        <StyledIcon name="arrow-undo" size={13} />
        <RepliedUserDetailsText textColor={!myMessage && senderThemeColor}>
          {" "}
          {myMessage ? "You" : senderUsername}{" "}
        </RepliedUserDetailsText>
        <RepliedUserDetailsText>replied to </RepliedUserDetailsText>
        <RepliedUserDetailsText>{them}</RepliedUserDetailsText>
      </RepliedUserDetailsContainer>
      <TouchableWithoutFeedback onPress={scrollToRepliedMessage}>
        {renderMessage()}
      </TouchableWithoutFeedback>
      {children}
    </ReplyWrapper>
  )
}

export const RepliedMessage = React.memo(RepliedMessageComponent)
