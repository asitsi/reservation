import styled from "styled-components/native"
import Animated from "react-native-reanimated"
import { BlurView } from "@react-native-community/blur"

export const InAppNotificationContainer = styled(Animated.View)`
  position: absolute;
  z-index: 999;
  top: 0px;
  width: 95%;
  align-self: center;
  background-color: transparent;
  border-radius: 15px;
`
// ${(props: Props & { flatShadow: boolean }) => {
//   if (props.flatShadow) {
//     return `background-color: ${props.theme.main.inAppNotificationShadow};
// margin-vertical: ${9 - props.theme.main.chatBoxShadowSize}px;
// padding-bottom: ${props.theme.main.chatBoxShadowSize}px;
// align-self: center;`
//   }
//   return null
// }}
export const ChildrenContainer = styled.View`
  border-radius: 15px;
  overflow: hidden;
`

export const InAppNotificationView = styled(BlurView)`
  width: 100%;
  height: 100%;
  border-radius: 15px;
`
export const InAppNotificationViewContainer = styled.View`
  border-radius: 15px;
  overflow: hidden;
`
