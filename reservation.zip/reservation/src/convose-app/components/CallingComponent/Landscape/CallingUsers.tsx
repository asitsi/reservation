import React, { useEffect } from "react"
import {
  useAnimatedStyle,
  useSharedValue,
  withTiming,
} from "react-native-reanimated"
import { CallingUsers } from "../Common/CallingUsers"
import { LandscapeCallingUsersContainer } from "../Common/Styled"
import { CallingUsersProps } from "../dto"

const getAnimationValue = (isHeaderHide?: boolean) => (isHeaderHide ? 120 : 0)

type Props = CallingUsersProps & { insetRight: number; isHeaderHide?: boolean }
const LandscapeCallingUsersComponent: React.FC<Props> = ({
  audioSetting,
  channel,
  groupInfo,
  insetRight,
  isGroup,
  me,
  muteRemoteUser,
  participants,
  peers,
  setUserScrollRef,
  videoCallFullScreenUid,
  isHeaderHide,
  isGroupAdmin,
  isHandRaiseEnabled,
}) => {
  const translateXOffset = useSharedValue(getAnimationValue(isHeaderHide))
  const containerStyle = useAnimatedStyle(() => ({
    transform: [{ translateX: translateXOffset.value }],
  }))

  useEffect(() => {
    translateXOffset.value = withTiming(getAnimationValue(isHeaderHide), {
      duration: 100,
    })
  }, [isHeaderHide, translateXOffset])

  return (
    <LandscapeCallingUsersContainer
      insetRight={insetRight}
      style={containerStyle}
    >
      <CallingUsers
        isCalling={false}
        isHide={false}
        groupInfo={groupInfo}
        me={me}
        peers={peers}
        channel={channel}
        isGroup={isGroup}
        muteRemoteUser={muteRemoteUser}
        audioSetting={audioSetting}
        videoCallFullScreenUid={videoCallFullScreenUid}
        setUserScrollRef={setUserScrollRef}
        participants={participants}
        isLandscape
        isGroupAdmin={isGroupAdmin}
        isHandRaiseEnabled={isHandRaiseEnabled}
      />
    </LandscapeCallingUsersContainer>
  )
}

export const LandscapeCallingUsers = React.memo(LandscapeCallingUsersComponent)
