/* eslint-disable react-perf/jsx-no-new-object-as-prop */
import React, { useCallback, useMemo } from "react"
import { FlatList, ListRenderItemInfo, Platform } from "react-native"
import { SlideInDown, SlideOutDown } from "react-native-reanimated"

import { Avatar as UserAvatar } from "convose-lib/user"
import { useSafeAreaInsets } from "react-native-safe-area-context"
import { useKeyboard } from "convose-lib/utils/useKeyboard"
import { Avatar } from "../../Avatar"
import {
  AvatarTitleContainer,
  CommandDescription,
  CommandTitle,
  CommandsContainer,
  EmptyCommand,
  TitleDescriptionContainer,
  TouchableCommand,
} from "./Styled"

const isAndroid = Platform.OS === "android"
export type CommandType = {
  command: string
  description: string
  avatar: string
}

const AVATAR_SIZE = 50

type Props = {
  isShowing: boolean
  onCommandSelect: (command: string) => void
  commands: CommandType[]
}

const CommandsComponent: React.FC<Props> = ({
  isShowing,
  onCommandSelect,
  commands,
}) => {
  const insets = useSafeAreaInsets()
  const [keyboardHeight] = useKeyboard()

  const onCommandSelectPress = useCallback(
    (command: string) => () => {
      onCommandSelect(command)
    },
    [onCommandSelect]
  )
  const insetBottom = useMemo(() => {
    if (isAndroid) {
      return 0
    }
    return keyboardHeight || insets.bottom
  }, [insets.bottom, keyboardHeight])

  if (!isShowing) {
    return null
  }

  const renderItem = ({ item }: ListRenderItemInfo<CommandType>) => {
    return (
      <TouchableCommand onPress={onCommandSelectPress(item.command)}>
        <AvatarTitleContainer>
          <Avatar
            height={AVATAR_SIZE}
            userAvatar={{ url: item?.avatar } as UserAvatar}
          />
          <TitleDescriptionContainer>
            <CommandTitle>{item.command}</CommandTitle>
            <CommandDescription>{item.description}</CommandDescription>
          </TitleDescriptionContainer>
        </AvatarTitleContainer>
      </TouchableCommand>
    )
  }

  return (
    <CommandsContainer
      entering={SlideInDown.duration(100)}
      exiting={SlideOutDown.duration(100)}
      insetBottom={insetBottom}
    >
      <FlatList
        data={commands}
        renderItem={renderItem}
        keyExtractor={(val) => val.command}
        keyboardShouldPersistTaps="always"
        ListEmptyComponent={
          <EmptyCommand>
            <CommandTitle>No command</CommandTitle>
          </EmptyCommand>
        }
      />
    </CommandsContainer>
  )
}

export const Commands = React.memo(CommandsComponent)
