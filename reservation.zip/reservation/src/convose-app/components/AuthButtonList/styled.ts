import { Platform, TouchableOpacity } from "react-native"
import styled from "styled-components/native"

import { CenteredText, font, Props } from "convose-styles"

import { AppleIcon } from "../../../assets/Icons/components/AppleIcon"
import { EmailIcon } from "../../../assets/Icons/components/EmailIcon"

export const ButtonWrapper = styled(TouchableOpacity)`
  border-radius: 50px;
  width: 100%;
  max-width: 500px;
  text-align: center;
  align-self: center;
  border-color: ${(props: Props) => props.theme.main.text};
  background-color: ${(props: Props) => props.theme.main.background};
  border-width: 1px;
  overflow: visible;
  margin-bottom: ${(props: { noBottomMargin: boolean }) =>
    props.noBottomMargin ? 0 : 15}px;
  justify-content: space-between;
  align-items: center;
  flex-direction: row;
  padding: 15px 10px;
`
export const CenterContent = styled.View``
export const Label = styled(CenteredText)`
  font-family: ${font.semiBold};
  font-size: 16px;
  text-align: center;
  color: ${(props: Props) => props.theme.main.text};
  margin-left: ${Platform.OS === "android" ? 13 : 7}px;
  include-font-padding: false;
  text-align-vertical: center;
`
export const SideContainer = styled.View`
  align-self: center;
  justify-content: center;
  align-items: center;
  width: 25px;
  aspect-ratio: 1;
  margin-left: 5px;
  /* border-width: 1px;
  border-radius: 30px;
  border-color: red; */
`
export const ButtonsContainer = styled.View`
  width: 100%;
  flex-direction: column;
  justify-content: center;
`

export const StyledAppleIcon = styled(AppleIcon).attrs((props: Props) => ({
  color: props.theme.main.text,
}))``
export const StyledEmailIcon = styled(EmailIcon).attrs((props: Props) => ({
  color: props.theme.main.text,
}))``
