import React from "react"
import { Svg, Path } from "react-native-svg"
import { SvgProps } from "./types"
import { getRatio, getWidth } from "./utils"

const defaultHeight = 14
const defaultWidth = 8
const ratio = getRatio(defaultHeight, defaultWidth)

const ArrowRightSvgComponent: React.FunctionComponent<SvgProps> = ({
  color,
  height,
}) => {
  const svgHeight = height || defaultHeight
  const svgWidth = height ? getWidth(ratio, height) : defaultWidth
  return (
    <Svg width={svgWidth} height={svgHeight} viewBox="0 0 8 14" fill="none">
      <Path
        d="M1 13L7 7L1 1"
        stroke={color || "#19AAEB"}
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </Svg>
  )
}

export const ArrowRightSvg = React.memo(ArrowRightSvgComponent)
