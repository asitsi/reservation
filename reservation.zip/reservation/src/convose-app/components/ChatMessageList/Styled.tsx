/* eslint-disable react/jsx-props-no-spreading */
import { View, TouchableOpacity, Pressable } from "react-native"
import styled from "styled-components/native"
import Animated from "react-native-reanimated"
import Ionicons from "react-native-vector-icons/Ionicons"

import { CenteredText, color, font, Props } from "convose-styles"
import SimpleEditIcon from "../../../assets/Icons/components/SimpleEditIcon"
import AddGroupIcon from "../../../assets/Icons/components/AddGroupBlueIcon"
import GroupParticipantsIcon from "../../../assets/Icons/components/GroupParticipants"
import {
  MESSAGE_BUBBLE_PADDING,
  MESSAGE_HORIZONTAL_MARGIN,
} from "../ChatMessage/Styled"

interface CallingScreenProps {
  isInCallingChat: boolean
  keyboardHeight?: number
  topInset: number
  bottomInset: number
  leftInset: number
  isLandscapeRight: boolean
  isLandscapeLeft: boolean
  isSuggestedRepliesOpen: boolean
}

export const StyledMainChatWrapper = styled(Animated.View)`
  justify-content: flex-end;
  ${(props: CallingScreenProps) => {
    if (props.isLandscapeLeft || props.isLandscapeRight) {
      return `width: 30%;`
    }
    return ``
  }}
  margin-left: ${(props: CallingScreenProps) =>
    props.isLandscapeLeft ? props.leftInset : 0}px;
  margin-bottom: -58px;
  padding-top: 10px;
  z-index: 0;
  elevation: 0;
`

export const CommonInterests = styled(View)`
  align-content: center;
  justify-content: center;
`

export const CommonInterestsList = styled(View)`
  flex-direction: row;
  flex-wrap: wrap;
  justify-content: center;
  margin-top: -5px;
  margin-bottom: -5px;
`

export const MessageWrapper = styled(Animated.View)``

export const RetrievingHistoryText = styled(CenteredText)`
  color: ${(props: Props) => props.theme.chatInfo};
  align-content: center;
  font-size: 11px;
  justify-content: center;
  margin-bottom: 10px;
  margin-top: 10px;
  text-align: center;
  font-family: ${font.light};
`
type BlankType = Props & { topInsets: number }
const BLANK_HEIGHT = 80
export const Blank = styled(View)`
  height: ${(props: BlankType) => {
    const topInsets = props.topInsets || 0
    return BLANK_HEIGHT + topInsets
  }}px;
`

export const ButtonWrapper = styled(TouchableOpacity)`
  border-radius: 50px;
  text-align: center;
  background: ${(props: Props) => props.theme.mainBlue};
  overflow: visible;
  justify-content: center;
  align-items: center;
  flex-direction: row;
  position: absolute;
  ${(props: Props) =>
    props.top && props.top !== 0
      ? `top: ${props.top}px`
      : "bottom: 100px; padding-right: 15px"};
  align-self: center;
`

export const Label = styled(CenteredText)`
  font-family: ${font.medium};
  font-size: 15px;
  text-align: center;
  color: ${color.white};
  include-font-padding: false;
  text-align-vertical: center;
`
export const MessageListEmptyContainer = styled.View`
  align-items: center;
  justify-content: flex-end;
`
export const MessageListEmpty = styled.View``
// const TOP_MARGIN = isAndroid ? 40 : 0

/* margin-top: ${(props: { insetTop: number }) =>
  (props.insetTop || 0) + TOP_MARGIN}px; */
export const MessageListFooter = styled.Pressable`
  margin-bottom: 20px;
`
export const TypingIndicatorHolder = styled.View`
  padding-left: 9px;
  padding-top: 2px;
  background-color: transparent;
`
export const TypingIndicatorContainer = styled(Animated.View)`
  flex-direction: row;
  align-items: center;
  overflow: hidden;
  padding-bottom: 5px;
  background-color: transparent;
`
export const TypingIndicatorUsersLoadingContainer = styled.View`
  flex-direction: row;
  align-items: center;
`
export const MessageTypingContainer = styled.View`
  background-color: ${(props: Props) => props.theme.message.otherMessageBubble};
  height: 30px;
  width: 50px;
  border-radius: 20px;
  margin-left: ${(props: { hideProfilePictures: boolean }) =>
    props.hideProfilePictures ? 0 : 5}px;
`
export const StyledIonicons = styled(Ionicons)`
  color: ${(props: Props) => props.theme.message.backToBottom.icon};
`
export const BackToBottomContainer = styled(Animated.View)`
  background-color: ${(props: Props) =>
    props.theme.message.backToBottom.background};
  height: 40px;
  aspect-ratio: 1;
  border-radius: 40px;
  align-items: center;
  justify-content: center;
  opacity: ${(props: { pressed: boolean }) => (props.pressed ? 0.5 : 1)};
`
const AnimatedTouchableOpacity = Animated.createAnimatedComponent(Pressable)
export const BackToBottomTouchable = styled(AnimatedTouchableOpacity)`
  position: absolute;
  /* bottom: 75px; */
  bottom: 0px;
  align-self: center;
  height: 40px;
  aspect-ratio: 1;
  align-items: center;
  justify-content: center;
`

export const UnreadBadge = styled.View`
  width: 15px;
  height: 15px;
  border-radius: 15px;
  background-color: ${color.red};
  position: absolute;
  top: -5px;
  right: -1px;
`

export const EditGroupInterestsContainer = styled.View`
  align-self: center;
  margin-top: 15px;
`
export const EditGroupInterestsTitleWrapper = styled.View`
  flex-direction: row;
  justify-content: flex-start;
  padding: 9px 12px;
`

export const EditGroupInterestsTitle = styled(CenteredText)`
  color: ${color.white};
  font-family: ${font.semiBold};
  font-size: 14px;
  line-height: 20px;
`
export const EditGroupInterestsIconContainer = styled.View`
  margin-right: 15px;
  justify-content: center;
`
export const GroupInterestTitle = styled(CenteredText)`
  font-family: ${font.bold};
  color: ${(props: Props) => props.theme.main.text};
  align-self: center;
  font-size: 16px;
`
export const EditGroupQuickButtons = styled.View`
  flex-direction: row;
  justify-content: space-evenly;
  align-self: center;
  margin: 0px 70px;
  margin-bottom: 15px;
`
export const EditButtonContainer = styled.View`
  justify-content: center;
  align-items: center;
  width: 70px;
`
export const EditButtonCircle = styled.View`
  width: 40px;
  aspect-ratio: 1;
  background-color: ${(props: Props) => props.theme.message.otherMessageBubble};
  border-radius: 40px;
  justify-content: center;
  align-items: center;
`
export const EditButtonTitle = styled(CenteredText)`
  font-family: ${font.medium};
  color: ${(props: Props) => props.theme.main.text};
  margin-top: 3px;
`

export const GroupAvatarNameContainer = styled.View`
  width: 100%;
  justify-content: center;
  align-items: center;
  margin-bottom: 15px;
`
export const GroupName = styled(CenteredText)`
  color: ${(props: Props) => props.theme.main.text};
  font-family: ${font.bold};
  font-size: 24px;
  margin-top: 5px;
  text-align: center;
  padding: 0px 30px;
`
export const GroupCreator = styled(CenteredText)`
  color: ${(props: Props) => props.theme.main.text};
  font-family: ${font.semiBold};
  font-size: 16px;
`
export const WaveMessageContainer = styled.View`
  width: 100%;
  justify-content: center;
  align-items: ${(props: { myMessage: boolean }) =>
    props.myMessage ? "flex-end" : "flex-start"};
  margin-bottom: 2px;
  padding: 0px ${MESSAGE_BUBBLE_PADDING}px;
`
export const WaveMessageBox = styled(Animated.View)`
  flex-direction: row;
  justify-content: center;
  align-items: center;
  padding: 0px
    ${(props: { myMessage: boolean }) =>
      props.myMessage ? MESSAGE_BUBBLE_PADDING : MESSAGE_HORIZONTAL_MARGIN}px;
`
export const WaveButtonContainer = styled.View`
  margin-left: 10px;
`

export const StyledSimpleEditIcon = styled(SimpleEditIcon).attrs(
  (props: Props) => ({
    color: props.theme.main.text,
  })
)``
export const StyledAddGroupIcon = styled(AddGroupIcon).attrs(
  (props: Props) => ({
    color: props.theme.main.text,
  })
)``
export const StyledGroupParticipantsIcon = styled(GroupParticipantsIcon).attrs(
  (props: Props) => ({
    color: props.theme.main.text,
  })
)``
