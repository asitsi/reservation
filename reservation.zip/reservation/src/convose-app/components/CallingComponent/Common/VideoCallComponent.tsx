/* eslint-disable react-perf/jsx-no-new-array-as-prop, react-perf/jsx-no-new-object-as-prop */
import React from "react"
import { ViewStyle } from "react-native"
import { RtcSurfaceView, VideoSourceType } from "react-native-agora"

import { shortenChannelId } from "convose-lib/chat"
import { sleep } from "convose-lib/utils/date"

type Props = {
  isLocal?: boolean
  agoraId?: number
  channel: string
  style?: ViewStyle
  isFullScreen?: boolean
}

const VideoCallViewComponent: React.FC<Props> = ({
  isLocal,
  channel,
  agoraId,
  style,
  isFullScreen,
}) => {
  // for video calls, a quick refresh is needed to show the video!
  const [key, setKey] = React.useState(0)
  const handleKeyChange = () => {
    setKey(Math.random() * 100)
    sleep(300).then(() => {
      setKey(Math.random() * 100)
    })
  }
  React.useEffect(() => {
    handleKeyChange()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isLocal, agoraId, channel, isFullScreen, style])

  if (!agoraId) {
    return null
  }
  return (
    <RtcSurfaceView
      key={key}
      connection={{
        channelId: shortenChannelId(channel),
        localUid: isLocal ? agoraId : undefined,
      }}
      canvas={{
        uid: isLocal ? undefined : agoraId,
        sourceType: isLocal
          ? VideoSourceType.VideoSourceCamera
          : VideoSourceType.VideoSourceRemote,
      }}
      style={style}
    />
  )
}

export const VideoCallView = React.memo(VideoCallViewComponent)
