import React from "react"
import { Pill as PillComponent } from "./Styles"

type Props = {
  top?: number
  bottom?: number
}
export const Pill: React.FC<Props> = ({ bottom, top }) => (
  <PillComponent top={top} bottom={bottom} />
)
