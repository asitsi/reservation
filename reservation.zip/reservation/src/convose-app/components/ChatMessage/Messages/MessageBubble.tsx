import React, { forwardRef, useMemo } from "react"
import { View } from "react-native"
import FastImage from "react-native-fast-image"
import { useSelector } from "react-redux"

import { Message, MessageToPublish, MessageType } from "convose-lib/chat"
import { selectMyUuid } from "convose-lib/user"
import { LONG_PRESS_DURATION } from "convose-lib/utils"
import Animated, { useAnimatedStyle, withTiming } from "react-native-reanimated"
import {
  EmojiMessage,
  EmojiOnlyText,
  ImageWrapper,
  MessageBubbleContainer,
} from "../Styled"
import { TextMessage } from "./TextMessage"
import { emojiRegex } from "../Messages/utils"
import { ImageMessage } from "./ImageMessage"
import { AudioMessage } from "./AudioMessage"
import { Preview } from "../Preview"
import { VideoMessage } from "./VideoMessage"

const getMessageBubble = (isOnlyEmojiMessage: boolean) => {
  if (isOnlyEmojiMessage) {
    return EmojiMessage
  }
  return MessageBubbleContainer
}

function isOnlyEmojiText(message: string): boolean {
  if (typeof message !== "string" || !message) {
    return false
  }
  // eslint-disable-next-line prefer-regex-literals
  const starRegex = new RegExp("⭐️", "g")
  const noSpaceMessage = message.replace(/ /g, "")
  const hasStar = starRegex.test(noSpaceMessage)
  const cleanMessage = hasStar ? message.replace(starRegex, "") : noSpaceMessage
  const emojisLength = (cleanMessage.match(emojiRegex) || []).length
  const stringsLength = cleanMessage.split(emojiRegex).filter((x) => x).length
  return (!!emojisLength || !!hasStar) && !stringsLength
}

type Props = {
  message: Message | MessageToPublish
  showProfile?: (userId?: string) => void
  dismissSelectedMessage?: () => void
  onLongPressToSelectMessage?: () => void
  onImagePress?: () => void
  isMessageSelected: boolean
  requestPlay?: (uuid: string) => void
  requestStop?: (isPause: boolean) => void
  shouldPlay?: boolean
}

const MessageBubbleComponent = forwardRef<View, Props>(
  (
    {
      message,
      showProfile,
      dismissSelectedMessage,
      onLongPressToSelectMessage,
      onImagePress,
      isMessageSelected,
      requestPlay,
      requestStop,
      shouldPlay,
    },
    ref
  ) => {
    const {
      myMessage,
      data,
      message_type: messageType,
      publishing,
      deleted,
      preview,
    } = message as Message
    const myUuid = useSelector(selectMyUuid)
    const containerStyle = useAnimatedStyle(
      () => ({
        opacity: withTiming(Number(!isMessageSelected), { duration: 50 }),
      }),
      [isMessageSelected]
    )

    const isOnlyEmojiMessage =
      messageType === MessageType.Text ? isOnlyEmojiText(data) : false
    const MessageComponent = getMessageBubble(isOnlyEmojiMessage)

    const handleOnImagePress = () => {
      !!onImagePress && onImagePress()
    }
    const handleDismissSelectedMessage = () => {
      !!dismissSelectedMessage && dismissSelectedMessage()
    }
    const handleOnLongPressToSelectMessage = () => {
      !!onLongPressToSelectMessage && onLongPressToSelectMessage()
    }
    const handleRequestPlay = (uuid: string) => {
      !!requestPlay && requestPlay(uuid)
    }
    const handleRequestStop = (isPause: boolean) => {
      !!requestStop && requestStop(isPause)
    }

    const renderText = (): React.ReactNode => {
      if (isOnlyEmojiMessage) {
        return <EmojiOnlyText>{data}</EmojiOnlyText>
      }
      return (
        <TextMessage
          message={data}
          myMessage={myMessage}
          myUid={myUuid}
          deleted={deleted}
          onPress={handleDismissSelectedMessage}
          onLongPress={onLongPressToSelectMessage}
          showProfile={showProfile}
        />
      )
    }

    const renderImage = (): React.ReactNode => {
      const { ratio } = message as Message
      if (!data) return null

      return (
        <ImageWrapper
          myMessage={myMessage}
          onPress={handleOnImagePress}
          onLongPress={onLongPressToSelectMessage}
          delayLongPress={LONG_PRESS_DURATION}
        >
          <ImageMessage
            // eslint-disable-next-line react-perf/jsx-no-new-object-as-prop
            uri={{ uri: data }}
            ratio={ratio}
            resizeMode={FastImage.resizeMode.cover}
          />
        </ImageWrapper>
      )
    }

    const renderMessage = (): React.ReactNode => {
      switch (messageType) {
        case MessageType.Image:
          return renderImage()
        case MessageType.Audio:
          return (
            <AudioMessage
              message={message as Message}
              isInCallingChat={false}
              requestPlay={handleRequestPlay}
              shouldPlay={!!shouldPlay}
              requestStop={handleRequestStop}
              selectMessage={handleOnLongPressToSelectMessage}
              dismissSelectedMessage={handleDismissSelectedMessage}
              isMessageSelected={isMessageSelected}
            />
          )
        case MessageType.Video:
          return (
            <VideoMessage
              message={message as Message}
              selectMessage={handleOnLongPressToSelectMessage}
            />
          )
        default:
          return renderText()
      }
    }
    const hasPreview = useMemo(
      () => !!preview?.image && !deleted,
      [deleted, preview?.image]
    )

    return (
      <Animated.View style={containerStyle} ref={ref}>
        <MessageComponent
          type={messageType}
          publishing={publishing}
          myMessage={myMessage}
          deleted={deleted}
          hasPreview={hasPreview}
        >
          {renderMessage()}
        </MessageComponent>
        {hasPreview && (
          <Preview preview={preview} onLongPress={onLongPressToSelectMessage} />
        )}
      </Animated.View>
    )
  }
)

export const MessageBubble = React.memo(MessageBubbleComponent)
