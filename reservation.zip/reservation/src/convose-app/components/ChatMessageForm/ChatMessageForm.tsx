/* eslint-disable complexity */
import * as React from "react"
import {
  Keyboard,
  TextInput,
  KeyboardEvent,
  Platform,
  StyleSheet,
  EmitterSubscription,
  AppState,
  AppStateStatus,
  Image,
  NativeEventSubscription,
} from "react-native"
import { Audio } from "expo-av"
import { withSafeAreaInsets } from "react-native-safe-area-context"
import { activateKeepAwakeAsync, deactivateKeepAwake } from "expo-keep-awake"
import { BehaviorSubject, Subscription } from "rxjs"
import {
  debounceTime,
  distinctUntilChanged,
  throttleTime,
} from "rxjs/operators"
import _ from "lodash"
import { connect } from "react-redux"
import { StackNavigationProp } from "@react-navigation/stack"
import {
  LinearTransition,
  SlideInDown,
  SlideOutDown,
} from "react-native-reanimated"

import { RootStackParamList } from "convose-app/router"
import { Routes } from "convose-lib/router"
import {
  BlockSendContent,
  ChatAction,
  ChatChannel,
  ChatUser,
  Message,
  MessageToPublish,
  MessageType,
  selectEditingSelectedMessage,
  SelectedMessage,
  selectHasSelectedMessage,
  selectIsPickingImage,
  selectMessageToReply,
  selectSelectedMessage,
} from "convose-lib/chat"
import {
  millisToMinutesAndSeconds,
  quickUuid,
  startRecordingAudio,
  millisToMinutesAndSecondsToMillis,
  stopRecordingAudio,
  chooseImage,
  takePicture,
  getExtensionFromURL,
  getAudioPermission,
  ImageResultType,
  RequestCallback,
} from "convose-lib/utils"

import { color } from "convose-styles"
import { SafeAreaProps } from "convose-lib/generalTypes"
import { disableMic, enableMicAndMuteMic, State } from "convose-lib"
import {
  ScreenOrientationTypes,
  selectIsDarkMode,
  selectScreenOrientation,
} from "convose-lib/app"

import {
  AudioFormWrapper,
  SquareButton,
  TimerText,
  ExtraTimerText,
  RecordingIndicatorWrapper,
  Icon,
  StyledInput,
  ChatInputWrapper,
} from "./Styled"
// import { RenderSuggestions } from "./ChatMessageFormSearcher"
// import { replaceMentionValues } from "../../../../self-maintained-packages/react-native-controlled-mentions/src"
import { LeftPanel } from "./LeftPanel"
import { RightPanel } from "./RightPanel"
import { ReplyAndEditField } from "./ReplyField/ReplyAndEdit"
import { ConfirmChooseImage } from "./ConfirmChooseImage"
import { ConvoseLoading } from "../ConvoseLoading"
import { Commands, CommandType } from "./Commands"
import { HideMessage } from "../HideMessage"
import { SuggestedReplies } from "./SuggestedReplies"
import { convoseAlertRef } from "../../RootConvoseAlert"
import { ChatInputBar } from "./ChatInputBar"

const urlExpression =
  // eslint-disable-next-line no-useless-escape
  /[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_\+.~#?&//=]*)/

const urlRegex = new RegExp(urlExpression)

const COMMANDS: CommandType[] = [
  {
    command: "/topic",
    description: "Generates a new topic",
    avatar:
      "https://res.cloudinary.com/dd2yzt80v/image/upload/v1712137822/Frame_1722_10_1_bffjb8.png",
  },
]
const isAndroid = Platform.OS === "android"
const LANDSCAPES = ["LANDSCAPE-RIGHT", "LANDSCAPE-LEFT"]

type ChatMessageFormProps = {
  readonly channel: ChatChannel
  readonly publishMessage: (
    message: MessageToPublish,
    channel: ChatChannel
  ) => void
  readonly setDisplayMessage: (message: MessageToPublish) => void
  readonly isInCallingChat: boolean
  readonly me: ChatUser
  readonly setIsPickingImage: (isPickingImage: boolean) => void
  readonly setIsTakingImage: (isTakingImage: boolean) => void
  readonly fetchUnreadMsgAndPartner: () => void
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  readonly messageListRef: any
  readonly transparentBackground?: boolean
  readonly showChat: () => void
  readonly hideChat: () => void
  // readonly isGroup: boolean
  readonly isChatHide?: boolean
  readonly isHeaderHide?: boolean
  readonly requestCallBack: RequestCallback
  readonly navigation: StackNavigationProp<
    RootStackParamList,
    Routes.Chat,
    undefined
  >
  readonly dismissSelectedMessage: () => void
  readonly onDeleteMessage: (selectedMessage: SelectedMessage) => void
  readonly isAudioEnabled: boolean
  readonly isOnGoingCallHappening: boolean
  readonly isGroup: boolean
} & BlockSendContent

type ChatMessageFormState = {
  readonly isInputFocused: boolean
  readonly audioRecord: Audio.Recording | null
  readonly isRecording: boolean
  readonly permissionGranted: boolean
  readonly shouldShowFullLeftPanel: boolean
  readonly chosenImage: ImageResultType | null
  readonly inputFormHeight: number
  readonly hasCommand: boolean
  readonly isSendButton: boolean
  readonly commands: CommandType[]
}
type StateToPropsType = {
  isDarkMode: boolean | null
  isPickingImage: boolean
  screenOrientation: ScreenOrientationTypes
  editingSelectedMessage: SelectedMessage | null
  selectedMessage: SelectedMessage | null
  messageToReply: Message | null
  hasSelectedMessage: boolean
}

type DispatchToProps = {
  readonly setReplyMessage: (message: Message | null) => void
  readonly setEditMessage: (message: Message | null) => void
}

// type Mention = {
//   id: string
//   readonly name: string
// }

const isTypingThrottleTime = 10000
const styles = StyleSheet.create({
  hitSlop: { top: 0, bottom: 30, left: 0, right: 0 },
  recordingIndicatorStyle: {
    borderRadius: 50,
    height: 10,
    width: 10,
    backgroundColor: color.red,
    marginRight: 4,
  },
  recording: { backgroundColor: color.darkGreen },
  stopRecording: { backgroundColor: color.red },
  emojiSearcherStyle: {
    position: "absolute",
  },
})

const minimumInterval = 10

// const textStyle = { backgroundColor: color.mentionBlue }

const preventAutoLock = (isRecording: boolean): void => {
  if (isRecording) {
    activateKeepAwakeAsync().catch().then()
  } else {
    deactivateKeepAwake()
  }
}
const layout = LinearTransition.damping(25).springify(150)

const setAllowsRecordingIOS = (enable: boolean) => {
  if (Platform.OS !== "ios") {
    return Promise.resolve()
  }
  return Audio.setAudioModeAsync({
    allowsRecordingIOS: enable,
  })
}

type AllProps = ChatMessageFormProps &
  SafeAreaProps &
  StateToPropsType &
  DispatchToProps
class ChatMessageForm extends React.Component<AllProps, ChatMessageFormState> {
  private appStateSubscription!: NativeEventSubscription

  public readonly state: ChatMessageFormState = {
    audioRecord: null,
    isRecording: false,
    isInputFocused: false,
    permissionGranted: false,
    shouldShowFullLeftPanel: true,
    chosenImage: null,
    inputFormHeight: 0,
    hasCommand: false,
    isSendButton: false,
    commands: [],
  }

  private readonly inputRef: React.RefObject<TextInput> =
    React.createRef<TextInput>()

  private readonly isTyping$: BehaviorSubject<string> = new BehaviorSubject("")

  private readonly isNotTypingSub: Subscription = this.isTyping$
    .pipe(distinctUntilChanged(), debounceTime(isTypingThrottleTime))
    .subscribe(() => {
      this.publishIsTyping(false)
    })

  private readonly isTypingSub: Subscription = this.isTyping$
    .pipe(throttleTime(isTypingThrottleTime))
    .subscribe((value) => {
      this.publishIsTyping && this.publishIsTyping(!!value)
    })

  private keyboardShowListener: EmitterSubscription | null = null

  private keyboardHideListener: EmitterSubscription | null = null

  private timerTextRef: React.RefObject<TextInput> =
    React.createRef<TextInput>()

  private extraTimerTextRef: React.RefObject<TextInput> =
    React.createRef<TextInput>()

  private recordingTime = 0

  private value = ""

  private firstRun = true

  private unsubscribeNavigationListener?: () => void

  private lockKeyboard = false

  // eslint-disable-next-line react/sort-comp
  keyboardShow(e: KeyboardEvent): void {
    this.setInputFormHeight(e.endCoordinates.height)
    this.lockKeyboard = false
  }

  keyboardHide(): void {
    if (!this.lockKeyboard) {
      this.setInputFormHeight(0)
    }
  }

  public componentDidMount(): void {
    this.appStateSubscription = AppState.addEventListener(
      "change",
      this.handleAppState
    )
    const keyboardShowListener = isAndroid
      ? "keyboardDidShow"
      : "keyboardWillShow"

    const keyboardHideListener = isAndroid
      ? "keyboardDidHide"
      : "keyboardWillHide"

    this.setTimerText(0, `00`, `00`)
    this.keyboardShowListener = Keyboard.addListener(
      keyboardShowListener,
      this.keyboardShow.bind(this)
    )
    this.keyboardHideListener = Keyboard.addListener(
      keyboardHideListener,
      this.keyboardHide.bind(this)
    )
    const { navigation } = this.props
    this.unsubscribeNavigationListener = navigation.addListener(
      "transitionStart",
      this.handSwipeBack
    )
  }

  public shouldComponentUpdate(
    prevProps: AllProps,
    prevState: ChatMessageFormState
  ): boolean {
    return (
      !_.isEqual(this.props, prevProps) || !_.isEqual(this.state, prevState)
    )
  }

  public componentDidUpdate(
    prevProps: AllProps,
    prevState: ChatMessageFormState
  ): void {
    const {
      channel,
      messageToReply,
      editingSelectedMessage,
      setReplyMessage,
      setEditMessage,
      isAudioEnabled,
    } = this.props
    const { isRecording, isInputFocused } = this.state
    if (
      prevProps.messageToReply?.uuid !== messageToReply?.uuid &&
      !!messageToReply
    ) {
      this.focusInput()
    }
    if (prevProps.editingSelectedMessage !== editingSelectedMessage) {
      if (editingSelectedMessage) {
        this.focusInput()
        this.setValue(editingSelectedMessage.data)
        setReplyMessage(null)
        setEditMessage(null)
      }
    }
    if (prevState.isInputFocused !== isInputFocused) {
      this.handleLeftPanelOnInputFocusChange()
    }
    if (isRecording !== prevState.isRecording) {
      preventAutoLock(isRecording)
    }
    if (prevProps.channel !== channel) {
      if (isRecording) {
        this.handleStopRecording(true)
      }
      // eslint-disable-next-line react/no-did-update-set-state
      this.setValue("")
    }
    if (!prevProps.isAudioEnabled && isAudioEnabled && isRecording) {
      this.stopRecording(true)
    }
  }

  public componentWillUnmount(): void {
    this.appStateSubscription.remove()
    this.keyboardHideListener?.remove()
    this.keyboardShowListener?.remove()
    this.handleStopRecording(true)
    this.publishIsTyping(false)
    this.isNotTypingSub.unsubscribe()
    this.isTypingSub.unsubscribe()
    this.unsubscribeNavigationListener && this.unsubscribeNavigationListener()
  }

  public handSwipeBack = () => {
    const { inputFormHeight } = this.state
    if (inputFormHeight) {
      this.lockKeyboard = true
    }
  }

  public setValue = (value: string) => {
    const { hasCommand: hadCommand, isSendButton: wasSendButton } = this.state
    const { messageToReply } = this.props
    const hasCommand = !!value && /^\//.test(value) && !messageToReply
    const isSendButton = !!value
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const newState: any = {}

    if (hasCommand !== hadCommand) {
      newState.hasCommand = hasCommand
    }
    if (isSendButton !== wasSendButton) {
      newState.isSendButton = isSendButton
    }
    if (hasCommand) {
      const commands = COMMANDS.filter((cmd) => cmd.command.startsWith(value))
      newState.commands = commands
    }
    this.value = value
    this.inputRef.current?.setNativeProps({ text: value })
    this.setState(newState)
  }

  public setInputFormHeight = (inputFormHeight: number) => {
    this.setState({
      inputFormHeight,
    })
  }

  public handleAppState = (appState: AppStateStatus): void => {
    if (appState.match(/inactive|background/)) {
      this.publishIsTyping(false)
    }
  }

  public focusInput = (): void => {
    this.inputRef.current?.focus()
  }

  public hideFullLeftPanel = (): void => {
    const { shouldShowFullLeftPanel } = this.state
    if (!shouldShowFullLeftPanel) {
      return
    }
    this.setState({
      shouldShowFullLeftPanel: false,
    })
  }

  public handleLeftPanelOnInputFocusChange = (): void => {
    const { isInCallingChat } = this.props
    if (isInCallingChat) {
      return
    }
    const { isInputFocused } = this.state
    this.setState({
      shouldShowFullLeftPanel: !isInputFocused,
    })
  }

  private scrollToBottom = (): void => {
    const { messageListRef } = this.props
    if (messageListRef) {
      messageListRef.scrollToEnd(true)
    }
  }

  private handleOnFocus = (): void => {
    const { showChat } = this.props
    showChat()
    this.scrollToBottom()
    this.setState({ isInputFocused: true })
  }

  private handleOnBlur = (): void => {
    const { hideChat } = this.props
    this.setState({ isInputFocused: false })
    hideChat()
  }

  private onImageChange = (event: {
    nativeEvent: { uri: string; linkUri?: string; mime: string; data: string }
  }) => {
    const { mime, data, linkUri } = event.nativeEvent
    const base64 = `data:${mime};base64,${data}`
    const extension = linkUri ? getExtensionFromURL(linkUri) : ""
    const isGif = extension === "gif"
    const dataToSend = isGif && linkUri ? linkUri : base64

    Image.getSize(
      dataToSend,
      (width: number, height: number) => {
        const ratio = width / height
        this.publishBase64(dataToSend, MessageType.Image, undefined, ratio)
      },
      () => {
        this.publishBase64(dataToSend, MessageType.Image)
      }
    )
  }

  private readonly renderTextInput = (): React.ReactNode => {
    const { isDarkMode, channel } = this.props
    // const partTypes = isGroup
    //   ? [
    //       {
    //         trigger: "@",
    //         renderSuggestions: RenderSuggestions,
    //         isInsertSpaceAfterMention: true,
    //         textStyle,
    //       },
    //     ]
    //   : undefined

    return (
      <StyledInput
        maxLength={1000}
        key={channel}
        // containerStyle={InputStyle}
        autoCorrect
        ref={this.inputRef}
        placeholder="Aa"
        placeholderTextColor={color.textInput.placeholder}
        underlineColorAndroid="transparent"
        onChangeText={this.changeValue}
        multiline
        onFocus={this.handleOnFocus}
        onBlur={this.handleOnBlur}
        spellCheck
        hitSlop={styles.hitSlop}
        // partTypes={partTypes}
        textAlignVertical="center"
        keyboardAppearance={isDarkMode ? "dark" : "light"}
        onImageChange={this.onImageChange}
        disableFullscreenUI
      />
    )
  }

  private onHandleStopRecordingPress = () => {
    requestAnimationFrame(() => {
      this.handleStopRecording(true)
    })
  }

  private onHandleSendRecordingPress = () => {
    requestAnimationFrame(() => {
      this.handleStopRecording(false)
    })
  }

  private readonly renderAudioBar = (insetBottom: number): React.ReactNode => {
    return (
      <AudioFormWrapper
        entering={SlideInDown.duration(150)}
        exiting={SlideOutDown.duration(150)}
        insetBottom={insetBottom}
        keyboardPadding={this.getKeyboardPadding()}
      >
        <SquareButton
          style={styles.stopRecording}
          onPress={this.onHandleStopRecordingPress}
        >
          <Icon name="close" color={color.white} />
        </SquareButton>
        <RecordingIndicatorWrapper>
          {this.renderAudioTimer()}
        </RecordingIndicatorWrapper>
        <SquareButton
          style={styles.recording}
          onPress={this.onHandleSendRecordingPress}
        >
          <Icon name="send" color={color.white} />
        </SquareButton>
      </AudioFormWrapper>
    )
  }

  private readonly renderAudioTimer = () => {
    return (
      <>
        <TimerText editable={false} ref={this.timerTextRef} />
        <ExtraTimerText editable={false} ref={this.extraTimerTextRef} />
      </>
    )
  }

  private readonly changeValue = (value: string) => {
    const { isBlocked } = this.props
    const { isRecording } = this.state
    if (isRecording) {
      return
    }
    this.hideFullLeftPanel()
    this.setValue(value)
    !isBlocked && value.length !== 0 && this.isTyping$.next(value)
  }

  private readonly handleOnSend = (value?: string) => {
    requestAnimationFrame(() => {
      const { isBlocked, showBlockAlert } = this.props
      if (isBlocked) {
        showBlockAlert("Content")
        return
      }
      this.publishText(value || this.value)
      this.setValue("")
    })
  }

  private readonly handleSendSmartReply = (
    value: string,
    messageType: MessageType,
    ratio?: number
  ) => {
    switch (messageType) {
      case MessageType.Text:
        this.handleOnSend(value)
        break
      case MessageType.Image:
        this.publishBase64(value, MessageType.Image, undefined, ratio)
        break
      default:
        break
    }
  }

  private readonly handleOnEdit = (value?: string) => {
    requestAnimationFrame(() => {
      const {
        isBlocked,
        showBlockAlert,
        dismissSelectedMessage,
        onDeleteMessage,
        selectedMessage,
      } = this.props
      if (isBlocked) {
        showBlockAlert("Content")
        return
      }
      const isEmpty = !(value || this.value)
      if (isEmpty && selectedMessage) {
        onDeleteMessage(selectedMessage)
      }
      // this.publishText(value || this.value)
      this.setValue("")
      dismissSelectedMessage()
    })
  }

  private readonly handleChoosePicture = async (): Promise<void> => {
    requestAnimationFrame(async () => {
      const {
        setIsPickingImage,
        fetchUnreadMsgAndPartner,
        isBlocked,
        showBlockAlert,
      } = this.props

      if (isBlocked) {
        showBlockAlert("Content")
        return
      }
      const leftAppTime = Date.now()
      setIsPickingImage(true)
      const chosenImage = await chooseImage()
      setIsPickingImage(false)
      const backToAppTime = Date.now()
      // For android user, if the user leaves app too long, it should fetch unread msg and partner
      backToAppTime - leftAppTime >= 60000 &&
        isAndroid &&
        fetchUnreadMsgAndPartner()
      this.setState({
        chosenImage: chosenImage || null,
      })
    })
  }

  private readonly handleTakePicture = async (): Promise<void> => {
    requestAnimationFrame(async () => {
      const {
        setIsPickingImage,
        setIsTakingImage,
        fetchUnreadMsgAndPartner,
        isBlocked,
        showBlockAlert,
        requestCallBack,
      } = this.props

      if (isBlocked) {
        showBlockAlert("Content")
        return
      }
      const leftAppTime = Date.now()
      setIsPickingImage(true)
      setIsTakingImage(true)
      const image = await takePicture(requestCallBack)

      setIsPickingImage(false)
      setIsTakingImage(false)
      const backToAppTime = Date.now()
      // For android user, if the user leaves app too long, it should fetch unread msg and partner
      backToAppTime - leftAppTime >= 60000 &&
        isAndroid &&
        fetchUnreadMsgAndPartner()
      image &&
        this.publishBase64(
          image.data,
          MessageType.Image,
          undefined,
          image.ratio
        )
    })
  }

  private readonly handleStartRecording = (): void => {
    requestAnimationFrame(() => {
      const { isBlocked, showBlockAlert, isAudioEnabled } = this.props
      if (isBlocked) {
        showBlockAlert("Content")
        return
      }
      if (isAudioEnabled) {
        Keyboard.dismiss()
        convoseAlertRef?.show({
          ioniconName: "warning",
          title: "Your mic is on in a call",
          description: "Please mute yourself first.",
        })
        return
      }
      this.startRecording()
    })
  }

  private readonly handleStopRecording = async (
    canceled: boolean
  ): Promise<void> => {
    this.stopRecording(canceled)
    setAllowsRecordingIOS(false).then().catch()
  }

  private readonly setTimerText = (
    minutes: number | string,
    seconds: number | string,
    milliseconds: number | string
  ) => {
    this.timerTextRef.current?.setNativeProps({ text: `${minutes}:${seconds}` })
    this.extraTimerTextRef.current?.setNativeProps({ text: milliseconds })
  }

  private readonly onRecordingStatusUpdate = async (
    status: Audio.RecordingStatus
  ) => {
    const [minutes, seconds, milliseconds] = millisToMinutesAndSecondsToMillis(
      status.durationMillis
    )
    this.recordingTime =
      status.durationMillis > 0 ? status.durationMillis : this.recordingTime
    this.setTimerText(minutes, seconds, milliseconds)
    this.timerTextRef.current?.setNativeProps({ text: `${minutes}:${seconds}` })
    this.extraTimerTextRef.current?.setNativeProps({ text: milliseconds })

    if (status.durationMillis >= 60000) {
      this.handleStopRecording(false)
    }
  }

  private sendMessage = (
    message: MessageToPublish,
    channel: ChatChannel,
    isTypingMessage?: boolean
  ) => {
    const { publishMessage, messageToReply, setDisplayMessage } = this.props
    if (isTypingMessage) {
      publishMessage(message, channel)
      return
    }
    const messageToSend = !messageToReply
      ? message
      : {
          ...message,
          reply_to_id: messageToReply.uuid,
          reply_to_message: messageToReply.data,
          reply_to_username: messageToReply.senderUsername,
          reply_to_message_type: messageToReply.message_type,
          reply_to_image_ratio: messageToReply.ratio,
          reply_to_user_id: messageToReply.sender,
        }

    publishMessage(messageToSend, channel)
    setDisplayMessage(messageToSend)
  }

  private readonly publishIsTyping = (isTyping: boolean) => {
    if (this.firstRun) {
      this.firstRun = false
      return
    }

    const { channel, me } = this.props
    this.sendMessage(
      {
        data: "",
        isTyping,
        sender: me?.uuid,
        avatar: me?.avatar,
        theme_color: me.theme_color,
        message_type: MessageType.Activity,
        uuid: quickUuid(),
        senderUsername: me.username,
      },
      channel,
      true
    )
  }

  private readonly publishText = (value: string) => {
    const { me, channel } = this.props
    this.scrollToBottom()
    const words = value.trim().split(" ")
    const mentionedIds: string[] = []
    // const mentionText = replaceMentionValues(value, ({ id, name }: Mention) => {
    //   mentionedIds.push(id)
    //   return `@${name}`
    // })

    const data = words.join(" ")

    if (data) {
      const regexResult = value.match(urlRegex)
      const previewUrl = regexResult ? regexResult[0] : null
      const rawMessage = {
        data,
        isTyping: false,
        sender: me.uuid,
        theme_color: me.theme_color,
        message_type: MessageType.Text,
        avatar: me?.avatar,
        senderUsername: me.username,
        uuid: quickUuid(),
        mentionedIds,
      }

      const message = previewUrl
        ? { ...rawMessage, preview_url: previewUrl }
        : rawMessage
      // const message =
      //   mentionedIds.length > 0
      //     ? {
      //         data,
      //         isTyping: false,
      //         sender: me.uuid,
      //         message_type: MessageType.Text,
      //         avatar: me.avatar,
      //         senderUsername: me.username,
      //         uuid: quickUuid(),
      //         mentionedIds,
      //         mentionText,
      //       }
      //     : {
      //         data,
      //         isTyping: false,
      //         sender: me.uuid,
      //         message_type: MessageType.Text,
      //         avatar: me.avatar,
      //         senderUsername: me.username,
      //         uuid: quickUuid(),
      //         mentionedIds,
      //       }
      this.sendMessage(message, channel)
    }
  }

  private readonly publishBase64 = (
    base64: string,
    messageType: MessageType,
    length?: number,
    ratio?: number
  ) => {
    const { me, channel } = this.props
    this.scrollToBottom()

    const message = {
      data: base64,
      isTyping: false,
      sender: me.uuid,
      theme_color: me.theme_color,
      message_type:
        messageType === MessageType.Image
          ? MessageType.Image
          : MessageType.Audio,
      length:
        messageType === MessageType.Audio && length
          ? millisToMinutesAndSeconds(length)
          : 0,
      ratio: messageType === MessageType.Image && ratio ? ratio : 1,
      avatar: me?.avatar,
      senderUsername: me.username,
      uuid: quickUuid(),
    }
    this.sendMessage(message, channel)
  }

  private readonly startRecording = async (): Promise<void> => {
    const { audioRecord, isRecording } = this.state
    if (isRecording) {
      return
    }
    const { requestCallBack, isOnGoingCallHappening } = this.props
    const audioPermission = await getAudioPermission(requestCallBack)
    if (audioPermission !== "granted") {
      return
    }
    if (isOnGoingCallHappening) {
      disableMic()
    }
    this.setState({ isRecording: true })
    if (audioRecord === null) {
      this.setState({ permissionGranted: true })
      await setAllowsRecordingIOS(true)

      const recording = await startRecordingAudio()

      if (recording) {
        this.setState({ audioRecord: recording, isRecording: true })
        recording.setProgressUpdateInterval(minimumInterval)
        recording.setOnRecordingStatusUpdate(this.onRecordingStatusUpdate)
      }
    } else {
      this.setState({ isRecording: false })
    }
  }

  private readonly stopRecording = async (canceled: boolean): Promise<void> => {
    const { audioRecord } = this.state
    const { isOnGoingCallHappening, isAudioEnabled } = this.props
    if (isOnGoingCallHappening && !isAudioEnabled) {
      enableMicAndMuteMic()
    }
    if (canceled) {
      if (audioRecord) {
        await stopRecordingAudio(audioRecord)
      }
      this.recordingTime = 0
      this.setState({
        audioRecord: null,
        isRecording: false,
      })
      return
    }
    if (audioRecord) {
      const base64 = await stopRecordingAudio(audioRecord)
      if (base64) {
        this.publishBase64(base64, MessageType.Audio, this.recordingTime)
      }
    }
    this.recordingTime = 0
    this.setState({
      audioRecord: null,
      isRecording: false,
    })
  }

  public toggleLeftPanel = (): void => {
    this.setState((prevState) => ({
      shouldShowFullLeftPanel: !prevState.shouldShowFullLeftPanel,
    }))
  }

  public sendChosenImage = (image: ImageResultType): void => {
    this.publishBase64(image.data, MessageType.Image, undefined, image.ratio)
  }

  public dismissChosenImage = (): void => {
    this.setState({ chosenImage: null })
  }

  public onCommandPress = (): void => {
    requestAnimationFrame(() => {
      this.setValue("/")
      this.focusInput()
    })
  }

  public onCommandSelect = (command: string): void => {
    this.handleOnSend(command)
  }

  public hideForm = (isLandscape: boolean): boolean => {
    const { isChatHide, isHeaderHide } = this.props
    if (!isLandscape) {
      return false
    }
    return !(!isChatHide || !isHeaderHide)
  }

  public onCloseReplyAndEdit = () => {
    const {
      editingSelectedMessage,
      setReplyMessage,
      setEditMessage,
      dismissSelectedMessage,
    } = this.props
    if (editingSelectedMessage) {
      this.setValue("")
      dismissSelectedMessage()
      return
    }
    setReplyMessage(null)
    setEditMessage(null)
  }

  getKeyboardPadding = () => {
    const { inputFormHeight } = this.state
    return isAndroid ? 0 : inputFormHeight
  }

  public render(): React.ReactNode {
    const {
      insets,
      isInCallingChat,
      messageToReply,
      transparentBackground = false,
      isPickingImage,
      screenOrientation,
      editingSelectedMessage,
      isGroup,
      hasSelectedMessage,
    } = this.props
    const {
      isRecording,
      permissionGranted,
      shouldShowFullLeftPanel,
      chosenImage,
      inputFormHeight,
      hasCommand,
      isSendButton,
      commands,
    } = this.state

    const canShowAudioBar = isRecording && permissionGranted
    const noInsetBottom = !!inputFormHeight
    const insetBottom = !noInsetBottom ? insets.bottom : 0
    const insetLeft = insets.left || 0
    const isLandscape =
      screenOrientation === "LANDSCAPE-RIGHT" ||
      screenOrientation === "LANDSCAPE-LEFT"
    const hideForm = this.hideForm(isLandscape)
    const fullWidthInput = isLandscape && !!inputFormHeight

    return (
      <>
        <ConvoseLoading isShowing={isPickingImage} />
        <HideMessage hide={hideForm}>
          <ChatInputWrapper
            layout={layout}
            insetLeft={insetLeft}
            isLandscapeRight={screenOrientation === "LANDSCAPE-RIGHT"}
            isLandscapeLeft={screenOrientation === "LANDSCAPE-LEFT"}
            fullWidthInput={fullWidthInput}
            transparentBackground={transparentBackground}
          >
            {!LANDSCAPES.includes(screenOrientation) && !isGroup && (
              <SuggestedReplies
                onPress={this.handleSendSmartReply}
                transparentBackgroundColor={transparentBackground}
              />
            )}
            <ConfirmChooseImage
              chosenImage={chosenImage}
              dismissChosenImage={this.dismissChosenImage}
              sendChosenImage={this.sendChosenImage}
            />
            <ReplyAndEditField
              message={(messageToReply || editingSelectedMessage) as Message}
              onClose={this.onCloseReplyAndEdit}
              isEdit={!!editingSelectedMessage}
            />
            <ChatInputBar
              transparentBackground={transparentBackground}
              hasSelectedMessage={hasSelectedMessage}
            >
              {!isLandscape && (
                <LeftPanel
                  shouldShowFullPanel={shouldShowFullLeftPanel}
                  isInCallingChat={isInCallingChat}
                  onChoosePicturePress={this.handleChoosePicture}
                  onTakePicturePress={this.handleTakePicture}
                  toggleFullPanel={this.toggleLeftPanel}
                  onCommandPress={this.onCommandPress}
                  strokeIcons={transparentBackground}
                />
              )}
              <Commands
                commands={commands}
                isShowing={hasCommand}
                onCommandSelect={this.onCommandSelect}
              />
              {this.renderTextInput()}
              <RightPanel
                handleStartRecording={this.handleStartRecording}
                handleOnSend={this.handleOnSend}
                handleOnEdit={this.handleOnEdit}
                shouldShowSendButton={isSendButton}
                shouldShowEditButton={!!editingSelectedMessage}
                strokeIcons={transparentBackground}
              />
            </ChatInputBar>
          </ChatInputWrapper>
        </HideMessage>
        {canShowAudioBar && this.renderAudioBar(insetBottom)}
      </>
    )
  }

  // Render functions
}
// ChatMessageForm.whyDidYouRender = {
//   logOnDifferentValues: true,
//   customName: "ChatMessageForm",
// }

const mapStateToProps = (state: State): StateToPropsType => {
  return {
    isDarkMode: selectIsDarkMode(state),
    isPickingImage: selectIsPickingImage(state),
    screenOrientation: selectScreenOrientation(state),
    editingSelectedMessage: selectEditingSelectedMessage(state),
    selectedMessage: selectSelectedMessage(state),
    messageToReply: selectMessageToReply(state),
    hasSelectedMessage: selectHasSelectedMessage(state),
  }
}
const mapDispatchToProps: DispatchToProps = {
  setReplyMessage: ChatAction.setMessageToReply,
  setEditMessage: ChatAction.setMessageToEdit,
}
const ClassComponentWithInsets = withSafeAreaInsets(React.memo(ChatMessageForm))

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(ClassComponentWithInsets)
