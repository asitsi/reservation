import React from "react"

import { ImageResultType } from "convose-lib/utils"
import { convoseAlertRef } from "../../RootConvoseAlert"
import { ChosenImage, ChosenImageContainer } from "./Styled"

type Props = {
  chosenImage: ImageResultType | null
  sendChosenImage: (image: ImageResultType) => void
  dismissChosenImage: () => void
}
const ConfirmChooseImageComponent: React.FC<Props> = ({
  chosenImage,
  dismissChosenImage,
  sendChosenImage,
}) => {
  React.useEffect(() => {
    if (chosenImage) {
      convoseAlertRef?.show({
        canDismiss: true,
        onDismiss: dismissChosenImage,
        title: "Send image?",
        description: (
          <ChosenImageContainer>
            <ChosenImage
              ratio={chosenImage.ratio || 1}
              // eslint-disable-next-line react-perf/jsx-no-new-object-as-prop
              source={{ uri: chosenImage.uri }}
            />
          </ChosenImageContainer>
        ),
        buttons: [
          {
            title: "Send image",
            onPress: () => sendChosenImage(chosenImage),
          },
          {
            title: "Don't send image",
            onPress: dismissChosenImage,
            type: "cancel",
          },
        ],
      })
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [chosenImage])
  return null
}

export const ConfirmChooseImage = React.memo(ConfirmChooseImageComponent)
