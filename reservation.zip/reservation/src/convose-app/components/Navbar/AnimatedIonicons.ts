import Ionicons from "react-native-vector-icons/Ionicons"
import Animated from "react-native-reanimated"

export const AnimatedIonicons = Animated.createAnimatedComponent(Ionicons)
