import React from "react"

import {
  TextWrapper,
  Label,
  CallStatusIcon,
  CallStatusMessageWrapper,
} from "./Styled"

type CallStatusMessageProps = {
  readonly message: Array<string>
  readonly withBgColor?: boolean
}

export const CallStatusMessage: React.FunctionComponent<
  CallStatusMessageProps
> = ({ message, withBgColor }) => (
  <CallStatusMessageWrapper>
    <TextWrapper withBgColor={withBgColor}>
      {!!message[1] && <CallStatusIcon name={message[1]} size={11} />}
      <Label>{message[0]}</Label>
    </TextWrapper>
  </CallStatusMessageWrapper>
)
