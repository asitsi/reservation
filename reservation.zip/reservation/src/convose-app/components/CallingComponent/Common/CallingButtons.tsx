/* eslint-disable complexity */
import React from "react"
import MaterialIcons from "react-native-vector-icons/MaterialIcons"
import { useSelector } from "react-redux"

import { selectIsChangingHandRaise } from "convose-lib/users-list/selector"
import { CallingButtonHolder, CallingButtonsContainer } from "./Styled"
import { CircleButton } from "./CircleButton"
import { SpeakerIcon } from "../Icons/Speaker"
import { CallingButtonsProps } from "../dto"
import {
  DEFAULT_ICON_SIZE,
  HandRaiseButton,
  MuteButton,
  VideoButton,
  getButtonBackgroundColor,
} from "./Buttons"

// const SHOW_LOADING_UNMUTE_TIMEOUT = 2500
const CallingButtonComponent: React.FC<CallingButtonsProps> = ({
  isAudioEnabled,
  isVideoEnabled,
  isSpeakerActive,
  endCall,
  toggleAudio,
  toggleSpeaker,
  toggleVideo,
  unmuteAlert,
  unsetUnmuteAlert,
  isGroup,
  isLandscape,
  isGroupAdmin,
  isHandRaiseEnabled,
  toggleHandRaise,
  myRaisedHandStatus,
}) => {
  const showOnHandRaiseNonOwner = !(isHandRaiseEnabled && !isGroupAdmin)

  const isChangingHandRaise = useSelector(selectIsChangingHandRaise)
  const showMediaButtons =
    isGroupAdmin ||
    !isHandRaiseEnabled ||
    (!isGroupAdmin &&
      isHandRaiseEnabled &&
      myRaisedHandStatus === "accepted_handraise")

  // const isHost = useSelector(selectIsHost)

  // const unmuteLoadingTimeout = React.useRef<ReturnType<
  //   typeof setTimeout
  // > | null>(null)
  // const [isShowingUnmuteLoading, setShowingUnmuteLoading] =
  //   React.useState(false)

  // const clearUnmuteLoadingTimeout = () => {
  //   unmuteLoadingTimeout.current && clearTimeout(unmuteLoadingTimeout.current)
  //   unmuteLoadingTimeout.current = null
  // }
  // React.useEffect(() => {
  //   if (isShowingUnmuteLoading) {
  //     unmuteLoadingTimeout.current = setTimeout(() => {
  //       setShowingUnmuteLoading(false)
  //       clearUnmuteLoadingTimeout()
  //     }, SHOW_LOADING_UNMUTE_TIMEOUT)
  //   }
  //   return () => clearUnmuteLoadingTimeout()
  // }, [isShowingUnmuteLoading])

  const onAudioPress = () => {
    requestAnimationFrame(() => {
      if (unmuteAlert) {
        unsetUnmuteAlert()
      }
      // if (!isAudioEnabled && !isHost) {
      //   setShowingUnmuteLoading(true)
      // }
      toggleAudio()
    })
  }
  const onSpeakerPress = () => {
    requestAnimationFrame(() => {
      if (unmuteAlert) {
        unsetUnmuteAlert()
      }
      toggleSpeaker()
    })
  }
  const onHandRaisePress = () => {
    requestAnimationFrame(() => {
      if (isChangingHandRaise) {
        return
      }
      if (unmuteAlert) {
        unsetUnmuteAlert()
      }
      toggleHandRaise()
    })
  }
  const onVideoPress = () => {
    requestAnimationFrame(() => {
      if (unmuteAlert) {
        unsetUnmuteAlert()
      }
      toggleVideo()
    })
  }
  return (
    <CallingButtonsContainer>
      {(showOnHandRaiseNonOwner || showMediaButtons) && (
        <CallingButtonHolder>
          <MuteButton
            isAudioEnabled={isAudioEnabled}
            onPress={onAudioPress}
            showAlert={isGroup && unmuteAlert}
            onCloseMuteAlert={unsetUnmuteAlert}
            // isLoading={isShowingUnmuteLoading}
            isLoading={false}
            isLandscape={isLandscape}
          />
        </CallingButtonHolder>
      )}
      <CallingButtonHolder>
        <CircleButton
          backgroundColorCode={getButtonBackgroundColor(
            isSpeakerActive,
            isLandscape
          )}
          onPress={onSpeakerPress}
          active={isSpeakerActive}
          isLandscape={isLandscape}
        >
          <SpeakerIcon
            size={DEFAULT_ICON_SIZE}
            isEnable={isSpeakerActive}
            isLandscape={isLandscape}
          />
        </CircleButton>
      </CallingButtonHolder>
      {(showOnHandRaiseNonOwner || showMediaButtons) && (
        <CallingButtonHolder>
          <VideoButton
            isVideoEnabled={isVideoEnabled}
            onPress={onVideoPress}
            isLandscape={isLandscape}
          />
        </CallingButtonHolder>
      )}
      {isGroupAdmin && isGroup && (
        <CallingButtonHolder>
          <HandRaiseButton
            isHandRaised={isChangingHandRaise || isHandRaiseEnabled}
            isLoading={isChangingHandRaise}
            onPress={onHandRaisePress}
            isLandscape={isLandscape}
          />
        </CallingButtonHolder>
      )}
      {!showOnHandRaiseNonOwner && (
        <CallingButtonHolder>
          <HandRaiseButton
            isHandRaised={!!myRaisedHandStatus}
            isLoading={false}
            onPress={onHandRaisePress}
            isLandscape={isLandscape}
          />
        </CallingButtonHolder>
      )}
      <CallingButtonHolder>
        <CircleButton
          backgroundColorCode="calling.endCall"
          onPress={endCall}
          active
          isLandscape={isLandscape}
        >
          <MaterialIcons
            name="call-end"
            size={DEFAULT_ICON_SIZE}
            color="white"
          />
        </CircleButton>
      </CallingButtonHolder>
    </CallingButtonsContainer>
  )
}

export const CallingButton = React.memo(CallingButtonComponent)
