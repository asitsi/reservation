/* eslint-disable max-params, @typescript-eslint/no-var-requires */
import React from "react"
import SwitchWithIcons from "react-native-switch-with-icons"

import { color } from "convose-styles"
import { Routes } from "convose-lib/router"

import { useMainBlue } from "convose-lib/utils/useMainBlue"

import * as RootNavigation from "../../RootNavigation"
import { BlockIcon } from "../../../assets/Icons/components/BlockIcon"
import { LeaveGroupIcon } from "../../../assets/Icons/components/LeaveGroupIcon"
import GroupParticipantsIcon from "../../../assets/Icons/components/GroupParticipants"
import AddGroupIcon from "../../../assets/Icons/components/AddGroupBlueIcon"
import ShareIcon from "../../../assets/Icons/components/Share"

import InboxIcon from "../../../assets/Icons/components/InboxIcon"
import { Item } from "../MenuButtons"

import { pnSwitchButtonStyle, iconColor } from "./Styled"
import { SettingIcon } from "./SettingIcon"
import { EventIcon } from "./EventIcon"
import { useTrackColor } from "./useTrackColor"

const PnOnIcon = require("../../../assets/Icons/pnOn.png")
const PnOffIcon = require("../../../assets/Icons/pnOff.png")

const pnIcons = {
  true: PnOnIcon,
  false: PnOffIcon,
}

const PnSwitchButton: React.FC<{
  showPushNotifications: boolean
  togglePushNotificationsSetting: () => void
}> = ({ showPushNotifications, togglePushNotificationsSetting }) => {
  const mainBlue = useMainBlue()
  // eslint-disable-next-line react-perf/jsx-no-new-object-as-prop
  const thumbColor = { true: mainBlue, false: color.bittersweet }
  const trackColor = useTrackColor()
  return (
    <SwitchWithIcons
      value={showPushNotifications}
      icon={pnIcons}
      thumbColor={thumbColor}
      trackColor={trackColor}
      iconColor={iconColor}
      onValueChange={togglePushNotificationsSetting}
      style={pnSwitchButtonStyle}
      animationDuration={0}
    />
  )
}
const BlueAddGroupIcon: React.FC = () => {
  const mainBlue = useMainBlue()
  return <AddGroupIcon color={mainBlue} />
}
const BlueGroupParticipantsIcon: React.FC = () => {
  const mainBlue = useMainBlue()
  return <GroupParticipantsIcon color={mainBlue} height={22} />
}

const BlueInboxIcon: React.FC = () => {
  const mainBlue = useMainBlue()
  return <InboxIcon color={mainBlue} height={25} />
}
const BlueShareIcon: React.FC = () => {
  const mainBlue = useMainBlue()
  return <ShareIcon color={mainBlue} height={25} />
}
type MenuItemsOneToOne = {
  createGroup: () => void
  toggleLocalPNSettings: () => void
  confirmToBlockUser: () => void
  showPushNotifications: boolean
}
export const menuItemsOneToOne = ({
  confirmToBlockUser,
  createGroup,
  showPushNotifications,
  toggleLocalPNSettings,
}: MenuItemsOneToOne): ReadonlyArray<Item> => [
  {
    label: "Create group",
    icon: <BlueAddGroupIcon />,
    onPress: createGroup,
  },
  {
    label: "Notifications",
    icon: (
      <PnSwitchButton
        showPushNotifications={showPushNotifications}
        togglePushNotificationsSetting={toggleLocalPNSettings}
      />
    ),
    onPress: toggleLocalPNSettings,
  },
  {
    label: "Block & report",
    icon: <BlockIcon />,
    onPress: confirmToBlockUser,
  },
]
type MenuItemsGroup = {
  inviteToGroup: () => void
  toggleLocalPNSettings: () => void
  confirmToLeaveGroup: () => void
  showPushNotifications: boolean
  openGroupParticipants: () => void
  onGroupEventsPress: () => void
  onShareGroup: () => void
  participantPermissions?: () => void
}
export const menuItemsGroup = ({
  confirmToLeaveGroup,
  inviteToGroup,
  onGroupEventsPress,
  openGroupParticipants,
  showPushNotifications,
  toggleLocalPNSettings,
  participantPermissions,
  onShareGroup,
}: MenuItemsGroup): ReadonlyArray<Item> => {
  const menuItems = [
    { label: "Invite", icon: <BlueAddGroupIcon />, onPress: inviteToGroup },
    { label: "Share group", icon: <BlueShareIcon />, onPress: onShareGroup },
    {
      label: "Group events",
      icon: <EventIcon height={24} />,
      onPress: onGroupEventsPress,
    },
    {
      label: "Push notifications",
      icon: (
        <PnSwitchButton
          showPushNotifications={showPushNotifications}
          togglePushNotificationsSetting={toggleLocalPNSettings}
        />
      ),
      onPress: toggleLocalPNSettings,
    },

    {
      label: "Participant permissions",
      icon: <SettingIcon height={23} />,
      // eslint-disable-next-line @typescript-eslint/no-empty-function
      onPress: participantPermissions || (() => {}),
    },
    {
      label: "Group participants",
      icon: <BlueGroupParticipantsIcon />,
      onPress: openGroupParticipants,
    },
    {
      label: "Leave group",
      icon: <LeaveGroupIcon />,
      onPress: confirmToLeaveGroup,
    },
  ]
  if (!participantPermissions) {
    return menuItems.filter((item) => item.label !== "Participant permissions")
  }
  return menuItems
}

export const menuItemsUserProfile = (startConversation: () => void) => {
  return [
    {
      icon: <BlueInboxIcon />,
      label: "Chat",
      onPress: startConversation,
    },
  ]
}
export const createGroupAction = (isGroup: boolean, members?: string[]) => {
  RootNavigation.navigate(Routes.CreateGroup, {
    members: members || [],
    isGroup,
  })
}
