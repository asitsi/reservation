import { Dimensions } from "react-native"

const WINDOW_HEIGHT = Dimensions.get("window").height
export const HIDE_VALUE = WINDOW_HEIGHT
export const SHOW_VALUE = 0
export const USER_THEME_BANNER_LIMIT = 86
export const TRANSLATION_Y_LIMIT_TO_SLIDE_DOWN = 50
export const PERCENTAGE_OF_CONTAINER_HEIGHT_TO_SLIDE_DOWN = 0.55
export const DISMISS_DURATION = 200
export const SLIDE_DURATION = 280
export const VELOCITY_SLIDE_DOWN_LIMIT = 1200
