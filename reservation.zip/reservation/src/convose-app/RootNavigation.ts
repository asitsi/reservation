/* eslint-disable @typescript-eslint/no-explicit-any, import/no-extraneous-dependencies */
import {
  StackActions,
  createNavigationContainerRef,
} from "@react-navigation/native"
import { NavigationAction, Route } from "@react-navigation/routers"

export const navigationRef = createNavigationContainerRef()

const retryOnFailedNavigation = (name: string, params?: any) => {
  const interval = setInterval(() => {
    if (navigationRef.isReady()) {
      clearInterval(interval)
      navigationRef.navigate(...([name, params] as never))
    }
  }, 500)
}

// eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
export function navigate(
  name: string,
  params?: any,
  forceOnFail?: boolean
): void {
  if (navigationRef.isReady()) {
    navigationRef.navigate(...([name, params] as never))
  } else if (forceOnFail) {
    retryOnFailedNavigation(name, params)
  }
}

export function push(name: string, ...args: any[]): void {
  navigationRef.current?.dispatch(StackActions.push(name, ...args))
}

export function goBack(): void {
  navigationRef.current?.goBack()
}

export function dispatch(action: NavigationAction): void {
  navigationRef.current?.dispatch(action)
}

export function getCurrentRouteName(): // eslint-disable-next-line @typescript-eslint/ban-types
Route<string, object | undefined> | undefined {
  return navigationRef.current?.getCurrentRoute()
}

export function popOne() {
  navigationRef.current?.dispatch(StackActions.pop(1))
}

export const replace = (name: string, params?: any): void => {
  navigationRef.current?.dispatch(StackActions.replace(name, params))
}
