import React from "react"
import { useSelector } from "react-redux"

import { selectToast } from "convose-lib/toast"
import { Toast } from "../Toast"

const AppToastComponent: React.FC = () => {
  const toast = useSelector(selectToast)

  return toast ? (
    <Toast
      message={toast.message}
      type={toast.type}
      position={toast.position}
    />
  ) : null
}

export const AppToast = React.memo(AppToastComponent)
