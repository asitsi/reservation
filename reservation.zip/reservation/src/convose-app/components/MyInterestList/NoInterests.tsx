import React from "react"
import {
  BasketballSvg,
  LocationSvg,
  MusicNoteSvg,
  LanguageSvg,
} from "../../../assets/svg"

import { IconContainer, NoInterestsImageContainer } from "./styled"

const icons = [
  <BasketballSvg />,
  <LocationSvg />,
  <MusicNoteSvg />,
  <LanguageSvg />,
]
type Props = {
  iconHeight?: number
}
export const NoInterests: React.FC<Props> = ({ iconHeight = 40 }) => {
  return (
    <NoInterestsImageContainer>
      {icons.map((icon, index) => (
        // eslint-disable-next-line react/no-array-index-key
        <IconContainer key={index} stepUp={index % 2}>
          {React.cloneElement(icon, { height: iconHeight })}
        </IconContainer>
      ))}
    </NoInterestsImageContainer>
  )
}
