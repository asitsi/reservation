import React, { useCallback, useEffect, useMemo, useRef } from "react"
import { Pressable, View, ViewStyle, useWindowDimensions } from "react-native"
import { useSelector, useDispatch } from "react-redux"
import Animated, {
  FadeIn,
  FadeOut,
  useAnimatedStyle,
  useSharedValue,
  withTiming,
} from "react-native-reanimated"
import _ from "lodash"
import { BlurView } from "@react-native-community/blur"
import { useSafeAreaInsets } from "react-native-safe-area-context"

import {
  ChatAction,
  Message,
  MessageActionType,
  MessageType,
  SelectedMessage,
  selectSelectedMessage,
  MEDIA_TYPES,
} from "convose-lib/chat"
import { selectIsDarkMode } from "convose-lib/app"
// import { selectMyUuid } from "convose-lib/user"
import { PressableDismiss } from "./Styled"
import { MessageBubble } from "../ChatMessage/Messages/MessageBubble"
import { Options } from "./Options"
import { Emojis } from "./Emojis"

const AnimatedPressable = Animated.createAnimatedComponent(Pressable)
const AnimatedBlurView = Animated.createAnimatedComponent(BlurView)

const animationDuration = 80
const blurStyle: ViewStyle = {
  width: "100%",
  height: "100%",
  justifyContent: "center",
  alignItems: "center",
  position: "absolute",
  top: 0,
  left: 0,
}
export type SelectedMessageActionsType = {
  onAddReaction?: (emoji: string, selectedMessage: SelectedMessage) => void
  onDeleteMessage: (selectedMessage: SelectedMessage) => void
  onReportMessage: (selectedMessage: SelectedMessage) => void
  onCopyMessage: (selectedMessage: SelectedMessage) => void
  onDownloadMessage: (selectedMessage: SelectedMessage) => void
}
const SelectedMessageActionsComponent: React.FC<SelectedMessageActionsType> = ({
  onCopyMessage,
  onDeleteMessage,
  onDownloadMessage,
  onReportMessage,
  onAddReaction,
}) => {
  const windowDimensions = useWindowDimensions()
  const insets = useSafeAreaInsets()
  const dispatch = useDispatch()
  const actionsContainerRef = useRef<View>(null)
  const isDarkMode = useSelector(selectIsDarkMode)
  const selectedMessage = useSelector(selectSelectedMessage)
  // const myUuid = useSelector(selectMyUuid)
  const setSelectedMessage = useCallback(
    (message: SelectedMessage | null) =>
      dispatch(ChatAction.setSelectedMessage(message)),
    [dispatch]
  )
  const onReply = useCallback(
    (message: Message | null) =>
      dispatch(ChatAction.setMessageToReply(message)),
    [dispatch]
  )

  const dismissSelectedMessage = useCallback(() => {
    setSelectedMessage(null)
  }, [setSelectedMessage])

  const bottomStart = useMemo(() => insets.bottom + 40, [insets.bottom])
  const maxHeight = useMemo(
    () => windowDimensions.height * 0.4,
    [windowDimensions.height]
  )

  const leftOffset = useSharedValue(0)
  const bottomOffset = useSharedValue(0)
  const widthOffset = useSharedValue(0)
  const heightOffset = useSharedValue(0)
  const scaleOffset = useSharedValue(1)

  const style = useAnimatedStyle(
    () => ({
      position: "absolute",
      left: leftOffset.value,
      bottom: bottomOffset.value,
      width: widthOffset.value,
      height: heightOffset.value,
      transform: [{ scale: scaleOffset.value }],
      opacity: withTiming(Number(!!selectedMessage), { duration: 60 }),
    }),
    [selectedMessage]
  )
  const actionsStyle = useAnimatedStyle(
    () => ({
      width: "100%",
      position: "absolute",
      bottom: bottomStart,
    }),
    [bottomStart]
  )

  useEffect(() => {
    if (selectedMessage && !selectedMessage.isEditing) {
      leftOffset.value = selectedMessage.pageX
      bottomOffset.value =
        windowDimensions.height - selectedMessage.pageY - selectedMessage.height
      widthOffset.value = selectedMessage.width
      heightOffset.value = selectedMessage.height
      scaleOffset.value = 1

      actionsContainerRef.current?.measure((x, y, w, height) => {
        const hasScale = selectedMessage.height > maxHeight
        if (hasScale) {
          const scale = maxHeight / selectedMessage.height
          scaleOffset.value = withTiming(scale, { duration: animationDuration })
        }
        const messageBottomRaw = height + bottomStart + 20
        const messageBottom = hasScale
          ? messageBottomRaw - (selectedMessage.height - maxHeight) / 2
          : messageBottomRaw
        bottomOffset.value = withTiming(messageBottom, {
          duration: animationDuration,
        })
        leftOffset.value = withTiming(
          windowDimensions.width / 2 - selectedMessage.width / 2,
          { duration: animationDuration }
        )
      })
    }
  }, [
    bottomOffset,
    bottomStart,
    heightOffset,
    leftOffset,
    maxHeight,
    scaleOffset,
    selectedMessage,
    widthOffset,
    windowDimensions.height,
    windowDimensions.width,
  ])

  const handleHide = useCallback(
    (callback?: () => void) => {
      if (selectedMessage) {
        // eslint-disable-next-line max-params
        selectedMessage.view.measure((x, y, width, height, pageX, pageY) => {
          leftOffset.value = withTiming(pageX, {
            duration: animationDuration,
          })
          bottomOffset.value = withTiming(
            windowDimensions.height - pageY - height,
            {
              duration: animationDuration,
            }
          )
          widthOffset.value = withTiming(width, {
            duration: animationDuration,
          })
          heightOffset.value = withTiming(height, {
            duration: animationDuration,
          })
        })

        scaleOffset.value = withTiming(1, { duration: animationDuration })
        if (callback) {
          setTimeout(() => {
            callback()
          }, animationDuration)
        }
      }
    },
    [
      bottomOffset,
      heightOffset,
      leftOffset,
      scaleOffset,
      selectedMessage,
      widthOffset,
      windowDimensions.height,
    ]
  )

  const handleOnDismiss = () => {
    handleHide(dismissSelectedMessage)
  }

  const actions: MessageActionType[] = useMemo(() => {
    if (!selectedMessage) {
      return []
    }
    const handleOnReply = () => {
      handleHide(() => {
        onReply(selectedMessage)
        dismissSelectedMessage()
      })
    }
    const handleOnDeleteMessage = () => {
      handleHide(() => onDeleteMessage(selectedMessage))
    }
    const handleOnReportMessage = () => {
      handleHide(() => onReportMessage(selectedMessage))
    }
    const handleOnCopyMessage = () => {
      handleHide(() => onCopyMessage(selectedMessage))
    }
    const handleOnDownloadMessage = () => {
      handleHide(() => onDownloadMessage(selectedMessage))
    }
    // const handleOnEditMessage = () => {
    //   handleHide(() =>
    //     setSelectedMessage({ ...selectedMessage, isEditing: true })
    //   )
    // }
    // eslint-disable-next-line react-perf/jsx-no-new-array-as-prop
    const messageMainActions: MessageActionType[] = [
      {
        ioniconName: "arrow-undo",
        title: "Reply",
        onPress: handleOnReply,
      },
      {
        ioniconName: "flag",
        title: "Report",
        onPress: handleOnReportMessage,
      },
      {
        ioniconName: "trash",
        title: "Delete",
        onPress: handleOnDeleteMessage,
        warn: true,
      },
    ]
    if (selectedMessage) {
      if (selectedMessage.message_type === MessageType.Text) {
        const textOptions = [
          {
            ioniconName: "copy",
            title: "Copy",
            onPress: handleOnCopyMessage,
          },
        ]
        // if (selectedMessage.sender === myUuid) {
        //   textOptions.push({
        //     ioniconName: "pencil",
        //     title: "Edit",
        //     onPress: handleOnEditMessage,
        //   })
        // }
        return [...textOptions, ...messageMainActions]
      }
      if (MEDIA_TYPES.includes(selectedMessage.message_type)) {
        return [
          {
            ioniconName: "cloud-download",
            title: "Get",
            onPress: handleOnDownloadMessage,
          },
          ...messageMainActions,
        ]
      }
    }
    return messageMainActions
  }, [
    dismissSelectedMessage,
    handleHide,
    onCopyMessage,
    onDeleteMessage,
    onDownloadMessage,
    onReply,
    onReportMessage,
    selectedMessage,
  ])

  const handleOnAddReaction = (emoji: string) => {
    if (selectedMessage && onAddReaction) {
      handleHide(() => onAddReaction(emoji, selectedMessage))
    }
  }

  if (!selectedMessage || selectedMessage.isEditing) {
    return null
  }
  return (
    <PressableDismiss onPress={handleOnDismiss}>
      <AnimatedBlurView
        blurType={isDarkMode ? "light" : "dark"}
        blurAmount={1}
        style={blurStyle}
        entering={FadeIn.duration(150)}
        exiting={FadeOut.duration(200)}
      />
      <AnimatedPressable
        onPress={handleOnDismiss}
        style={style}
        pointerEvents="box-only"
      >
        <MessageBubble
          isMessageSelected={false}
          message={selectedMessage as Message}
        />
      </AnimatedPressable>
      <Animated.View ref={actionsContainerRef} style={actionsStyle}>
        {!!onAddReaction && <Emojis onAddReaction={handleOnAddReaction} />}
        <Options actions={actions} />
      </Animated.View>
    </PressableDismiss>
  )
}
export const SelectedMessageActions = React.memo(
  SelectedMessageActionsComponent,
  (prevProps, nextProps) => _.isEqual(prevProps, nextProps)
)
// SelectedMessageActions.whyDidYouRender = {
//   logOnDifferentValues: false,
//   customName: "SelectedMessageActions",
//   diffNameColor: "red",
// }
