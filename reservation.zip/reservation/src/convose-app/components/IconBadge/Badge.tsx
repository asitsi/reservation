import React from "react"
import { BadgeContainer, BadgeInner, BadgeOuter } from "./Styled"

type Props = {
  width: number
  height: number
  inboxIndicator: boolean
  withBorder: boolean
  children?: React.ReactElement
  useMainBlue?: boolean
}
const BadgeComponent: React.FC<Props> = ({
  height,
  inboxIndicator,
  width,
  withBorder,
  children,
  useMainBlue,
}) => {
  return (
    <BadgeContainer>
      <BadgeOuter withBorder={withBorder} width={width} height={height}>
        <BadgeInner
          width={withBorder ? width - 5 : width}
          height={withBorder ? height - 5 : height}
          inboxIndicator={inboxIndicator}
          useMainBlue={useMainBlue}
        >
          {children}
        </BadgeInner>
      </BadgeOuter>
    </BadgeContainer>
  )
}

export const Badge = React.memo(BadgeComponent)
