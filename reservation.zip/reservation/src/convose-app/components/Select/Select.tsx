import React, { useCallback } from "react"
import { ZoomIn, ZoomOut } from "react-native-reanimated"

import {
  CheckMarkContainer,
  SelectContainer,
  SelectItemContainer,
  SelectItemText,
  StyledCheckMarkSvg,
} from "./Styled"

type SelectItemType<T> = {
  title: string
  value: T
  selected: boolean
  onPress: (value: T) => void
}
type SelectItemProps = SelectItemType<string | boolean | number> & {
  isLast: boolean
}
const SelectItem: React.FC<SelectItemProps> = ({
  onPress,
  value,
  selected,
  title,
  isLast,
}) => {
  const handleOnPress = useCallback(() => {
    requestAnimationFrame(() => {
      onPress(value)
    })
  }, [value, onPress])

  return (
    <SelectItemContainer onPress={handleOnPress} isLast={isLast}>
      <SelectItemText>{title}</SelectItemText>
      {selected && (
        <CheckMarkContainer
          entering={ZoomIn.duration(150)}
          exiting={ZoomOut.duration(150)}
        >
          <StyledCheckMarkSvg />
        </CheckMarkContainer>
      )}
    </SelectItemContainer>
  )
}

type SelectType<T> = {
  items: SelectItemType<T>[]
}
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const SelectComponent: React.FC<SelectType<any>> = ({ items }) => {
  return (
    <SelectContainer>
      {items.map((item, index, array) => (
        <SelectItem
          key={item.title}
          onPress={item.onPress}
          selected={item.selected}
          title={item.title}
          value={item.value}
          isLast={index === array.length - 1}
        />
      ))}
    </SelectContainer>
  )
}

export const Select = React.memo(SelectComponent)
