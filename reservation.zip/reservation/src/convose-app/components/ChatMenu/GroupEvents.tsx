import React, { useCallback, useEffect } from "react"
import { useDispatch, useSelector } from "react-redux"
import { LinearTransition, ZoomIn, ZoomOut } from "react-native-reanimated"

import {
  EventType,
  UsersListAction,
  selectGroupEvents,
  selectLoadingEvents,
  selectUpdatingEvent,
} from "convose-lib/users-list"

import { BlueLoading } from "../ConvoseLoading"
import {
  GroupEventsContainer,
  GroupEventsNoEvent,
  GroupEventsSavingChanges,
  LoadingGroupEventsContainer,
  LoadingGroupEventsWrapper,
} from "./Styled"
import { EventCard } from "../EventCard"

const layout = LinearTransition.damping(20).springify(150)

type Props = {
  setSelectedGroupEvent: (event: EventType) => void
  chatChannel: string
}
const GroupEventsComponent: React.FC<Props> = ({
  setSelectedGroupEvent,
  chatChannel,
}) => {
  const dispatch = useDispatch()
  const isLoading = useSelector(selectLoadingEvents)
  const updatingEvent = useSelector(selectUpdatingEvent)
  const events = useSelector(selectGroupEvents(chatChannel))

  const listGroupEvents = useCallback(
    () => dispatch(UsersListAction.listEventsOfGroup(chatChannel)),
    [dispatch, chatChannel]
  )
  const onAttendEvent = useCallback(
    (eventId: number) => dispatch(UsersListAction.attendEvent(eventId)),
    [dispatch]
  )
  const onUnAttendEvent = useCallback(
    (eventId: number) => dispatch(UsersListAction.unAttendEvent(eventId)),
    [dispatch]
  )

  useEffect(() => {
    if (!updatingEvent) {
      listGroupEvents()
    }
  }, [listGroupEvents, updatingEvent])

  const handleOnAttendPress = useCallback(
    (event: EventType) => {
      event.status === "attending"
        ? onUnAttendEvent(event.id)
        : onAttendEvent(event.id)
    },
    [onAttendEvent, onUnAttendEvent]
  )

  const render = () => {
    if ((isLoading && !events.length) || updatingEvent) {
      return (
        <LoadingGroupEventsContainer layout={layout}>
          <LoadingGroupEventsWrapper
            entering={ZoomIn.duration(150)}
            exiting={ZoomOut.duration(150)}
          >
            <BlueLoading />
          </LoadingGroupEventsWrapper>
          {updatingEvent && (
            <GroupEventsSavingChanges
              entering={ZoomIn.duration(150)}
              exiting={ZoomOut.duration(150)}
            >
              Saving changes
            </GroupEventsSavingChanges>
          )}
        </LoadingGroupEventsContainer>
      )
    }
    if (!events.length) {
      return (
        <GroupEventsNoEvent
          entering={ZoomIn.duration(150)}
          exiting={ZoomOut.duration(150)}
        >
          No events yet
        </GroupEventsNoEvent>
      )
    }
    return events.map((event) => (
      <EventCard
        key={event.id}
        event={event as EventType}
        setSelectedGroupEvent={setSelectedGroupEvent}
        onAttendPress={handleOnAttendPress}
      />
    ))
  }

  return <GroupEventsContainer>{render()}</GroupEventsContainer>
}

export const GroupEvents = React.memo(GroupEventsComponent)
