import { TouchableOpacity } from "react-native"
import styled from "styled-components"
import Animated from "react-native-reanimated"

import { CenteredText, Props, font } from "convose-styles"

export const CONTAINER_HEIGHT = 70
export const CommandsContainer = styled(Animated.View)`
  max-height: ${CONTAINER_HEIGHT}px;
  background-color: ${(props: Props) => props.theme.main.background};
  border-top-width: 0.5px;
  border-top-color: ${(props: Props) => props.theme.reply.topBorder};
  width: 100%;
  overflow: hidden;
  position: absolute;
  bottom: ${(props: { insetBottom: number }) => props.insetBottom + 55}px;
  padding-bottom: 10px;
`
export const TouchableCommand = styled(TouchableOpacity)``
export const CommandTitle = styled(CenteredText)`
  font-family: ${font.semiBold};
  font-size: 17px;
  color: ${(props: Props) => props.theme.main.text};
`
export const CommandDescription = styled(CenteredText)`
  font-family: ${font.normal};
  font-size: 12px;
  color: ${(props: Props) => props.theme.chatInfo};
`
export const AvatarTitleContainer = styled.View`
  flex-direction: row;
  justify-content: flex-start;
  align-items: center;
  margin: 10px 0px 0px 10px;
`
export const TitleDescriptionContainer = styled.View`
  padding-left: 10px;
  padding-top: 5px;
`
export const EmptyCommand = styled.View`
  justify-content: center;
  align-items: center;
  width: 100%;
  height: ${CONTAINER_HEIGHT}px;
  align-self: center;
`
