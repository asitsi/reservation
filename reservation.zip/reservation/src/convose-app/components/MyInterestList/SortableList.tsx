import React, { useCallback, useEffect } from "react"
import { ViewStyle } from "react-native"
import { SharedValue, useSharedValue } from "react-native-reanimated"
import { noop } from "lodash"

import { InterestLocation, UserInterest } from "convose-lib"
import { MY_INTEREST_SIZE } from "convose-styles"

// import { InterestsList } from "./styled"
import { InterestButton } from "../InterestButton"
import { List, getItemPositions } from "./List"
import { ListItem } from "./ListItem"

const iconWrapperStyle: ViewStyle = {
  marginLeft: 3,
}
const interestWrapperStyle: ViewStyle = {
  marginBottom: 7,
  marginTop: 0,
  marginLeft: 0,
}
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const isItemType = (obj: any): obj is UserInterest => !!obj

type Props = {
  interests: UserInterest[]
  onDelete: (interest: UserInterest) => void
  openRatingWheel: (interest: UserInterest) => void
  deleteSuccess: () => void
  setInterests: (interests: UserInterest[]) => void
  listMarginBottom: SharedValue<number>
  onSortDone?: () => void
}

const KEY = "id"
const ITEM_HEIGHT = 50

const SortableInterestListComponent: React.FC<Props> = ({
  interests,
  deleteSuccess,
  onDelete,
  openRatingWheel,
  setInterests,
  listMarginBottom,
  onSortDone,
}) => {
  const positions = useSharedValue(getItemPositions(interests, KEY))

  const sortInterests = useCallback(() => {
    onSortDone && onSortDone()
    const newSortedItems = Object.keys(positions.value)
      .map((key) => ({
        [KEY]: key,
        position: positions.value[key],
      }))
      .sort((a, b) => (a.position > b.position ? 1 : -1))
      .map((item) =>
        interests.find(
          (existingItem) => String(existingItem[KEY]) === item[KEY]
        )
      )
      .filter(isItemType)
    setInterests(newSortedItems)
  }, [positions.value, setInterests, interests, onSortDone])

  useEffect(() => {
    positions.value = getItemPositions(interests, KEY)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [interests.length])

  return (
    <List
      itemsCount={interests.length}
      isSorting
      itemHeight={ITEM_HEIGHT}
      // eslint-disable-next-line react-perf/jsx-no-new-object-as-prop
      wrapperStyle={{ marginBottom: listMarginBottom.value }}
    >
      {interests.map((interest) => {
        return (
          <ListItem
            key={interest.id}
            enableSorting={noop}
            isSorting
            index={interest.id}
            positions={positions}
            itemCount={interests.length}
            itemHeight={ITEM_HEIGHT}
            onSortEnded={sortInterests}
          >
            <InterestButton
              key={interest.id}
              size={MY_INTEREST_SIZE}
              interestLocation={InterestLocation.MyInterests}
              interest={interest}
              onDelete={onDelete}
              onPress={openRatingWheel}
              deleteSuccess={deleteSuccess}
              addBorder
              backgroundColorCode="main.background"
              iconSize={30}
              iconWrapperStyle={iconWrapperStyle}
              wrapperStyle={interestWrapperStyle}
            />
          </ListItem>
        )
      })}
    </List>
  )
}

export const SortableInterestList = React.memo(SortableInterestListComponent)
