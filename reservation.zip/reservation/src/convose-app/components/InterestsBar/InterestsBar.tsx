/* eslint-disable react-perf/jsx-no-new-object-as-prop */
import React, { FunctionComponent } from "react"
import { Platform, Dimensions } from "react-native"
import {
  useAnimatedStyle,
  withClamp,
  withTiming,
} from "react-native-reanimated"

import { Interest, UserInterest } from "convose-lib/interests"
import { softShadows } from "convose-styles"

import { useKeyboard } from "convose-lib/utils/useKeyboard"
import {
  StyledInterestsBarView,
  InterestBarActionsContainer,
  InterestBarContainer,
} from "./Styled"
import { AutosuggestInput } from "../../components/AutosuggestInput"
import { InterestsList } from "./InterestsList"

type InterestsBarProps = {
  readonly onSearch: (text: string) => void
  readonly onAddInterest: (interest: Interest) => void
  readonly searchResults: ReadonlyArray<Interest> | null
  readonly currentInterests: ReadonlyArray<UserInterest>
  readonly onDeleteInterest: (interest: UserInterest) => void
  readonly openRatingWheel: (interest: UserInterest) => void
  readonly setInterestValue: (text: string) => void
  readonly interestValue: string
  readonly renderNewInterest: boolean
  readonly insetBottom: number
  readonly setInterests?: (interests: UserInterest[]) => void
  readonly isLoadingInterests: boolean
}
const isAndroid = Platform.OS === "android"
const MAX_CLAMP_KEYBOARD = Dimensions.get("window").height
const InterestsBarComponent: FunctionComponent<InterestsBarProps> = ({
  onAddInterest,
  onSearch,
  searchResults,
  currentInterests,
  onDeleteInterest,
  openRatingWheel,
  interestValue,
  setInterestValue,
  renderNewInterest,
  insetBottom,
  setInterests,
  isLoadingInterests,
}) => {
  const [keyboardHeight, keyboardAnimationDuration] = useKeyboard()
  const style = useAnimatedStyle(
    () => ({
      paddingBottom: withClamp(
        { max: MAX_CLAMP_KEYBOARD, min: insetBottom },
        withTiming(isAndroid ? 0 : keyboardHeight, {
          duration: keyboardAnimationDuration,
        })
      ),
      ...softShadows,
    }),
    [keyboardAnimationDuration, keyboardHeight]
  )

  return (
    <StyledInterestsBarView style={style}>
      <InterestBarContainer renderNewInterest={renderNewInterest}>
        <InterestsList
          // eslint-disable-next-line react-perf/jsx-no-new-array-as-prop
          interests={[...currentInterests]}
          onDeleteInterestPress={onDeleteInterest}
          onInterestPress={openRatingWheel}
          setInterests={setInterests}
        />
        <InterestBarActionsContainer>
          <AutosuggestInput
            onAddInterest={onAddInterest}
            onSearch={onSearch}
            searchResults={searchResults}
            interestValue={interestValue}
            setInterestValue={setInterestValue}
            isLoadingInterests={isLoadingInterests}
          />
        </InterestBarActionsContainer>
      </InterestBarContainer>
    </StyledInterestsBarView>
  )
}
// InterestsBarComponent.whyDidYouRender = {
//   logOnDifferentValues: false,
//   customName: "InterestsBarComponent",
//   diffNameColor: "red",
// }
export const InterestsBar = React.memo(InterestsBarComponent)
