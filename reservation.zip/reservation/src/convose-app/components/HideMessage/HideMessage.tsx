/* eslint-disable react-perf/jsx-no-new-array-as-prop */
import React from "react"
import { ViewStyle } from "react-native"
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
} from "react-native-reanimated"

type Props = {
  hide: boolean
  style?: ViewStyle
}

const HideMessageComponent: React.FC<React.PropsWithChildren<Props>> = ({
  children,
  hide,
  style,
}) => {
  const offset = useSharedValue(hide ? 0 : 1)
  React.useEffect(() => {
    if (hide) {
      offset.value = 0
    } else {
      offset.value = 1
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hide])

  const animatedStyles = useAnimatedStyle(() => {
    return {
      opacity: withTiming(offset.value),
    }
  })
  return (
    <Animated.View style={[style, animatedStyles]}>{children}</Animated.View>
  )
}

export const HideMessage = React.memo(HideMessageComponent)
