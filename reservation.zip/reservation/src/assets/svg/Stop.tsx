import React from "react"
import { Svg, Path } from "react-native-svg"
import { SvgProps } from "./types"

export const StopSvg: React.FunctionComponent<SvgProps> = ({
  height,
  color = "#FF6060",
}) => {
  return (
    <Svg width={height} height={height} viewBox="0 0 47 47" fill="none">
      <Path
        d="M23.5 0C10.5163 0 0 10.5163 0 23.5C0 36.4837 10.5163 47 23.5 47C36.4837 47 47 36.4837 47 23.5C47 10.5163 36.4837 0 23.5 0ZM35.25 25.85H11.75V21.15H35.25V25.85Z"
        fill={color}
      />
    </Svg>
  )
}
