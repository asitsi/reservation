import React from "react"
import { useSelector } from "react-redux"
import { ZoomIn, ZoomOut } from "react-native-reanimated"
import { useTheme } from "styled-components"

import { ChatUser } from "convose-lib/chat"
import { selectIsDarkMode } from "convose-lib/app"
import { UserMinimum } from "convose-lib/user/dto/user"
import { resolveObjectPath } from "convose-lib/utils"
import {
  CallProfileRow,
  CallProfileWrapper,
  InCallUsersNumberText,
} from "./Styled"
import { Avatar } from "../Avatar"

type Props = {
  participants: ChatUser[] | UserMinimum[]
  avatarCountToShow?: number
  showUsersCount?: boolean
  size?: number
  textColor?: string
  textSize?: number
  noAvatarBg?: boolean
  showRing?: boolean
  ringColor?: string
  avatarBgColor?: string
  avatarBgColorCode?: string
  ringSize?: number
  ringColorCode?: string
  restOfUsersCount?: number
}

const CallUsersTailComponent: React.FC<Props> = ({
  participants,
  avatarCountToShow = 2,
  showUsersCount = true,
  size = 30,
  textColor,
  textSize,
  noAvatarBg,
  showRing,
  ringColor,
  avatarBgColor,
  avatarBgColorCode,
  ringSize = 1,
  ringColorCode,
  restOfUsersCount,
}) => {
  const theme = useTheme()
  const isDarkMode = useSelector(selectIsDarkMode)
  const getBackgroundColorOfUser = (bgColor: string, darkBgColor: string) => {
    if (isDarkMode) {
      return darkBgColor
    }
    return bgColor
  }
  const marginLeft = size / 2.5
  const finalRingColor = (() => {
    if (ringColorCode) {
      return resolveObjectPath(ringColorCode, theme)
    }
    return ringColor
  })()
  const shouldShowCountTail =
    showUsersCount &&
    (participants.length > avatarCountToShow || restOfUsersCount)

  return (
    <CallProfileRow>
      {participants.slice(0, avatarCountToShow).map((participant, index) => {
        const style = (() => {
          if (noAvatarBg || !!avatarBgColor) {
            return undefined
          }
          if (avatarBgColorCode) {
            return {
              backgroundColor: resolveObjectPath(avatarBgColorCode, theme),
            }
          }
          return {
            backgroundColor: getBackgroundColorOfUser(
              participant.background_theme_color,
              participant.dark_background_color
            ),
          }
        })()
        return (
          <CallProfileWrapper
            key={participant.uuid}
            // eslint-disable-next-line react-perf/jsx-no-new-object-as-prop
            style={{ left: -marginLeft * index }}
            entering={ZoomIn.duration(150)}
            exiting={ZoomOut.duration(150)}
          >
            <Avatar
              userAvatar={participant?.avatar}
              style={style}
              height={size}
              showRing={showRing}
              ringColor={finalRingColor}
              isGroup
              ringSize={ringSize}
              bgColor={avatarBgColor}
            />
          </CallProfileWrapper>
        )
      })}
      {!!shouldShowCountTail && (
        <InCallUsersNumberText
          // eslint-disable-next-line react-perf/jsx-no-new-object-as-prop
          style={{
            left: -(marginLeft * avatarCountToShow) / (size / 10),
          }}
          color={textColor}
          size={textSize || size / 1.5}
        >
          {`+${restOfUsersCount || participants.length - avatarCountToShow}`}
        </InCallUsersNumberText>
      )}
    </CallProfileRow>
  )
}

export const CallUsersTail = React.memo(CallUsersTailComponent)
