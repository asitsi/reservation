import {
  CenteredText,
  color,
  font,
  ongoingCallHeight,
  Props,
} from "convose-styles"
import { TouchableOpacity, View } from "react-native"
import Animated from "react-native-reanimated"
import styled from "styled-components"

interface TimerText {
  timerText: boolean
}
const AnimatedTouchableOpacity =
  Animated.createAnimatedComponent(TouchableOpacity)
export const Container = styled(AnimatedTouchableOpacity)`
  align-items: center;
  justify-content: flex-end;
  width: 100%;
  top: 0px;
  z-index: 20;
`

export const ButtonWrapper = styled(Animated.View)`
  width: 100%;
  height: ${ongoingCallHeight}px;
  justify-content: center;
  align-items: center;
  flex-direction: row;
  height: 35px;
`
export const PressableButtonWrapper = styled(AnimatedTouchableOpacity)`
  width: 100%;
  height: ${ongoingCallHeight}px;
  justify-content: center;
  align-items: center;
  flex-direction: row;
  height: 35px;
  background-color: ${(props: Props) => props.theme.mainBlue};
`

export const TextWrapper = styled(View)`
  overflow: visible;
  justify-content: center;
  align-items: center;
  flex-direction: row;
`

export const Label = styled(CenteredText)`
  font-family: ${font.medium};
  height: 21px;
  justify-content: center;
  font-size: 15px;
  text-align: center;
  color: ${(props: Props) => props.color || color.white};
  ${(props: Props) => props.italic && "font-style: italic;"};
  ${(props: TimerText) => props.timerText && "width: 40px; left:10px"};
`
export const LiveContainer = styled.View`
  padding-left: 10px;
`
