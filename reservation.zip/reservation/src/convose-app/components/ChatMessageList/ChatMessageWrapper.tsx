/* eslint-disable no-nested-ternary, complexity */
import React from "react"
import { TouchableWithoutFeedback } from "react-native"

import {
  ChatUser,
  Message,
  MessageToPublish,
  setCallStatusMessage,
  AudioMessagePlayer,
  BlockSendContent,
  MessageType,
  createChatInfoText,
  createChatIdleText,
  isMessage,
} from "convose-lib/chat"

import { CallStatusMessage } from "../CallStatusMessage"
import { ChatInfo } from "../ChatInfo"
import { ChatMessage } from "../ChatMessage"
import { MessageWrapper } from "./Styled"
import {
  // checkIsNotSameSenderWithDownMsg,
  // checkIsSameSenderWithDownMsg,
  checkIsSameSenderWithUpMsg,
} from "./utils"
import { WaveMessage } from "./WaveMessage"

type ChatMessageWrapperProps = {
  message: Message | MessageToPublish
  isFullScreenVideoCall: boolean | undefined
  isGroup: boolean
  me: ChatUser
  readonly setFullScreenImage: (uri: { uri: string } | undefined) => void
  scrollToReply: (uuid: string) => void
  messageUuidToScaleAnimation?: string
  clearMessageUuidToScaleAnimation: () => void
  isGroupAdmin: boolean
  chatChannel: string
  readonly onUpdateReaction: (
    emoji: string,
    messageUuid: string,
    reacted: boolean
  ) => void
  readonly dismissSelectedMessage: (noToggleHeader?: boolean) => void
  nextMessage: Message | MessageToPublish
  prevMessage: Message | MessageToPublish
} & BlockSendContent
type AllProps = ChatMessageWrapperProps & AudioMessagePlayer

export class ChatMessageWrapper extends React.Component<AllProps> {
  shouldComponentUpdate(nextProps: AllProps): boolean {
    const {
      isFullScreenVideoCall,
      message,
      shouldPlay,
      messageUuidToScaleAnimation,
      isBlocked,
      isGroupAdmin,
      chatChannel,
      nextMessage,
      prevMessage,
    } = this.props
    const { data } = message
    const reactions = "reactions" in message ? message.reactions : null
    const prevReactions =
      "reactions" in nextProps.message ? nextProps.message.reactions : null
    const { data: oldData } = nextProps.message
    const hasMessageResponse = () => {
      if (isMessage(message) && isMessage(nextProps.message)) {
        const { responded } = message
        return responded !== nextProps.message.responded
      }
      return false
    }
    return (
      reactions !== prevReactions ||
      isFullScreenVideoCall !== nextProps.isFullScreenVideoCall ||
      (!!message.publishing && !nextProps.message.publishing) ||
      shouldPlay !== nextProps.shouldPlay ||
      messageUuidToScaleAnimation !== nextProps.messageUuidToScaleAnimation ||
      data !== oldData ||
      nextProps.isBlocked !== isBlocked ||
      nextProps.isGroupAdmin !== isGroupAdmin ||
      nextProps.chatChannel !== chatChannel ||
      nextMessage?.uuid !== nextProps?.nextMessage?.uuid ||
      prevMessage?.uuid !== nextProps?.prevMessage?.uuid ||
      hasMessageResponse()
    )
  }

  public isSystemMessage = (): boolean => {
    const { message } = this.props
    return message.message_type === MessageType.System
  }

  public isCallStatusMessage = (): boolean => {
    const { message } = this.props
    return message.message_type === MessageType.Call
  }

  public isWave = (): boolean => {
    const { message } = this.props
    return message.message_type === MessageType.Wave
  }

  public isChatMessage = (): boolean => {
    if (this.isSystemMessage() || this.isCallStatusMessage() || this.isWave()) {
      return false
    }
    return true
  }

  public chatInfoText = (): string | null => {
    const { message, nextMessage } = this.props
    return createChatInfoText(message, nextMessage)
  }

  public chatTimeText = (): string | null => {
    const { message, nextMessage } = this.props
    return createChatIdleText(message, nextMessage)
  }

  public isSameSenderWithUpMsg = (): boolean => {
    const { message, nextMessage } = this.props
    return checkIsSameSenderWithUpMsg(message, nextMessage)
  }

  // public hasNextMessage = (): boolean => {
  //   const { message, prevMessage } = this.props
  //   return (
  //     !this.isSameSenderWithUpMsg() &&
  //     checkIsSameSenderWithDownMsg(message, prevMessage)
  //   )
  // }

  // public isLastMessage = (): boolean => {
  //   const { message, prevMessage } = this.props
  //   return (
  //     this.isSameSenderWithUpMsg() &&
  //     checkIsNotSameSenderWithDownMsg(message, prevMessage)
  //   )
  // }

  private onDismissSelectedMessagePress = () => {
    const { dismissSelectedMessage } = this.props
    dismissSelectedMessage()
  }

  public renderSystemMessages = (): React.ReactElement => {
    const { message, isGroup, me } = this.props
    if (message.message_type === MessageType.Wave) {
      const {
        isFullScreenVideoCall,
        isBlocked,
        showBlockAlert,
        isGroupAdmin,
        chatChannel,
      } = this.props
      const isSameSenderWithUpMsg = this.isSameSenderWithUpMsg()
      return (
        <WaveMessage
          message={message as Message}
          chatChannel={chatChannel}
          sameSender={isSameSenderWithUpMsg}
          isFullScreenVideoCall={!!isFullScreenVideoCall}
          myUuid={me.uuid}
          isBlocked={isBlocked}
          showBlockAlert={showBlockAlert}
          isGroupAdmin={isGroupAdmin}
        />
      )
    }
    const callStatusMessage = setCallStatusMessage(
      message.data,
      message.senderUsername || "",
      isGroup,
      message.sender === me.uuid,
      message?.action
    )
    const chatInfoText = this.chatInfoText()
    const chatTimeText = this.chatTimeText()
    return (
      <>
        {chatInfoText && (
          <ChatInfo
            text={chatInfoText}
            withBorder={false}
            withBgColor={false}
          />
        )}
        {!chatInfoText && chatTimeText && (
          <ChatInfo
            text={chatTimeText}
            withBorder={false}
            withBgColor={false}
          />
        )}
        {this.isSystemMessage() ? (
          <ChatInfo
            text={message.data}
            withBorder={false}
            withBgColor={false}
          />
        ) : this.isCallStatusMessage() ? (
          callStatusMessage && (
            <CallStatusMessage
              message={callStatusMessage}
              withBgColor={false}
            />
          )
        ) : null}
      </>
    )
  }

  render(): React.ReactNode {
    const {
      message,
      isFullScreenVideoCall,
      me,
      setFullScreenImage,
      requestPlay,
      shouldPlay,
      requestStop,
      scrollToReply,
      messageUuidToScaleAnimation,
      clearMessageUuidToScaleAnimation,
      isBlocked,
      showBlockAlert,
      isGroupAdmin,
      chatChannel,
      onUpdateReaction,
      dismissSelectedMessage,
    } = this.props

    const isSameSenderWithUpMsg = this.isSameSenderWithUpMsg()
    // const isFirstMessage = !isSameSenderWithUpMsg
    // const hasNextMessage = this.hasNextMessage()
    // const isLastMessage = this.isLastMessage()
    return (
      <TouchableWithoutFeedback onPress={this.onDismissSelectedMessagePress}>
        <MessageWrapper>
          {this.isChatMessage() ? (
            <ChatMessage
              message={message}
              sameSender={isSameSenderWithUpMsg}
              isFullScreenVideoCall={!!isFullScreenVideoCall}
              setFullScreenImage={setFullScreenImage}
              myUuid={me.uuid}
              requestPlay={requestPlay}
              shouldPlay={shouldPlay}
              requestStop={requestStop}
              scrollToReply={scrollToReply}
              messageUuidToScaleAnimation={messageUuidToScaleAnimation}
              clearMessageUuidToScaleAnimation={
                clearMessageUuidToScaleAnimation
              }
              isBlocked={isBlocked}
              showBlockAlert={showBlockAlert}
              isGroupAdmin={isGroupAdmin}
              chatChannel={chatChannel}
              onUpdateReaction={onUpdateReaction}
              dismissSelectedMessage={dismissSelectedMessage}
            />
          ) : (
            this.renderSystemMessages()
          )}
        </MessageWrapper>
      </TouchableWithoutFeedback>
    )
  }
}
// ChatMessageWrapper.whyDidYouRender = {
//   logOnDifferentValues: true,
//   customName: "ChatMessageWrapper",
//   diffNameColor: "red",
// }
export default React.memo(ChatMessageWrapper)
