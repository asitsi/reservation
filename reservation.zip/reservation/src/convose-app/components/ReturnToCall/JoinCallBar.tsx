import React from "react"
import { useSelector } from "react-redux"
import Ionicons from "react-native-vector-icons/Ionicons"

import { getParticipantsInCall, selectGroupCallInfo } from "convose-lib/chat"
import { color } from "convose-styles"

import { selectMyUuid } from "convose-lib/user"
import {
  Label,
  LiveContainer,
  PressableButtonWrapper,
  TextWrapper,
} from "./styled"
import { CallUsersTail } from "../CallUsersTail"
import { LiveIndicator } from "../LiveIndicator"

const callIconStyle = { transform: [{ translateX: -7 }] }
type JoinCallBarProps = {
  rejoinCall: () => void
  chatChannel?: string
}

const COUNT_OF_AVATARS_TO_SHOW = 3

const JoinCallBarComponent: React.FC<JoinCallBarProps> = ({
  rejoinCall,
  chatChannel,
}) => {
  const groupInfo = useSelector(selectGroupCallInfo(chatChannel || "")) || {}
  const myUuid = useSelector(selectMyUuid)
  const allUsers = getParticipantsInCall(groupInfo, "", [myUuid])
  const countOfUsers = allUsers.length
  const joinCall = () => {
    rejoinCall()
  }
  return countOfUsers > 0 ? (
    <PressableButtonWrapper onPress={joinCall}>
      <Ionicons
        name="call"
        size={14}
        color={color.white}
        style={callIconStyle}
      />
      <CallUsersTail
        participants={allUsers}
        avatarCountToShow={COUNT_OF_AVATARS_TO_SHOW}
        showUsersCount
        size={18}
        textColor="white"
        textSize={15}
        avatarBgColorCode="mainBlue"
        showRing
        ringColorCode="mainBlue"
        ringSize={2}
      />
      <TextWrapper>
        <Label italic>{"   Tap to join"}</Label>
      </TextWrapper>
      <LiveContainer>
        <LiveIndicator color="white" size={15} />
      </LiveContainer>
    </PressableButtonWrapper>
  ) : null
}
export default JoinCallBarComponent
