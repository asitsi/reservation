import styled from "styled-components/native"
import Animated from "react-native-reanimated"
import { CenteredText, Props, font } from "convose-styles"

export const Wrapper = styled(Animated.View)`
  width: 100%;
  border-top-width: 0.5px;
  border-top-color: ${(props: Props) => props.theme.reply.topBorder};
  flex-direction: row;
`
export const Field = styled.View`
  justify-content: center;
  align-items: flex-start;
  flex: 1;
  padding: 10px;
`
export const ActionField = styled(Field)`
  align-items: flex-end;
  padding: 0px;
`
export const DescriptionWrapper = styled.View`
  flex-direction: row;
  justify-content: flex-start;
`
export const DescriptionText = styled(CenteredText)`
  font-family: ${font.normal};
  font-size: 12px;
  color: ${(props: Props) => props.theme.main.text};
`
export const ReplyUser = styled(DescriptionText)`
  font-family: ${font.semiBold};
`
export const MessageText = styled(DescriptionText)`
  font-size: 11px;
  margin-left: -2px;
  color: ${(props: Props) => props.theme.chatInfo};
`
export const CloseButton = styled.TouchableOpacity`
  padding: 14px;
`
export const CloseWrapper = styled.View`
  background-color: ${(props: Props) => props.theme.reply.closeButton};
  padding: 2px;
  border-radius: 18px;
`
export const ActionsContainer = styled.View`
  flex-direction: row;
  justify-content: center;
  align-items: center;
`
export const Image = styled.Image`
  width: 30px;
  height: 30px;
  margin-right: 10px;
  border-radius: 5px;
`
