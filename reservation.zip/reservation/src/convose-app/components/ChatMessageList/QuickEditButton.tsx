import React, { PropsWithChildren, memo } from "react"
import { TouchableOpacity } from "react-native"
import {
  EditButtonCircle,
  EditButtonContainer,
  EditButtonTitle,
} from "./Styled"

type Props = {
  title?: string
  onPress?: () => void
}
const QuickEditButtonComponent: React.FC<PropsWithChildren<Props>> = ({
  children,
  onPress,
  title,
}) => {
  return (
    <TouchableOpacity onPress={onPress}>
      <EditButtonContainer>
        <EditButtonCircle>{children}</EditButtonCircle>
        <EditButtonTitle>{title}</EditButtonTitle>
      </EditButtonContainer>
    </TouchableOpacity>
  )
}

export const QuickEditButton = memo(QuickEditButtonComponent)
