import React from "react"
import { connect } from "react-redux"

import { UsersListAction } from "convose-lib/users-list"

import { navigationRef } from "../../RootNavigation"

type DispatchToProps = {
  applyQueuedNotifications: () => void
}
type AllProps = DispatchToProps

class NavigationWatcherComponent extends React.PureComponent<AllProps> {
  public stateListener!: () => void

  componentDidMount(): void {
    this.stateListener = navigationRef.addListener("state", () => {
      const { applyQueuedNotifications } = this.props
      applyQueuedNotifications()
    })
  }

  componentWillUnmount(): void {
    this.stateListener && this.stateListener()
  }

  render(): React.ReactNode {
    return null
  }
}

const mapDispatchToProps: DispatchToProps = {
  applyQueuedNotifications: UsersListAction.applyQueuedNotifications,
}

export const NavigationWatcher = React.memo(
  connect(null, mapDispatchToProps)(NavigationWatcherComponent)
)
