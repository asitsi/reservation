import styled from "styled-components/native"
import Animated from "react-native-reanimated"

import { CenteredText, Props, font } from "convose-styles"

export const CallProfileWrapper = styled(Animated.View)``
export const CallProfileRow = styled.View`
  flex-direction: row;
  justify-content: flex-start;
  align-items: center;
`
export const InCallUsersNumberText = styled(CenteredText)`
  color: ${(props: Props) => props.color || props.theme.main.text};
  font-size: ${(props: { size: number }) => props.size}px;
  font-family: ${font.normal};
`
