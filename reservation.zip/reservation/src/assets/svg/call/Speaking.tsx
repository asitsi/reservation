import React from "react"
import { Svg, Path } from "react-native-svg"
import { SvgProps } from "../types"

const SpeakingSvgComponent: React.FunctionComponent<SvgProps> = ({
  color,
  height = 15,
}) => {
  return (
    <Svg width={height} height={height} viewBox="0 0 15 15" fill="none">
      <Path
        d="M10.6362 10.4639C10.6362 10.4639 10.9043 8.77191 10.2641 6.84794C9.62385 4.92396 8.39548 3.72995 8.39548 3.72995"
        stroke={color || "#3F9AF7"}
        strokeWidth="1.3"
        strokeLinecap="round"
      />
      <Path
        d="M12.7515 11.3833C12.7515 11.3833 13.5543 8.80105 12.6296 6.02197C11.7048 3.2429 9.51483 1.65654 9.51483 1.65654"
        stroke={color || "#3F9AF7"}
        strokeWidth="1.3"
        strokeLinecap="round"
      />
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M7.22481 10.7005C5.98873 10.9593 4.31028 11.3107 3.36375 9.36784C3.3194 9.27679 4.23398 8.5111 5.14362 7.74955C6.04454 6.9953 6.94061 6.24511 6.89532 6.15848C5.12866 2.77875 3.83122 1.00404 1.73852 1.74205C-0.34542 2.7573 0.0736435 6.2639 1.87592 9.96331C2.65109 11.5545 3.52292 12.6096 4.44484 13.3492C6.27948 14.8208 9.33483 13.1962 8.74115 10.9205C8.60822 10.4109 8.00453 10.5373 7.22481 10.7005ZM3.87231 5.1736C4.23276 5.91348 4.12511 6.70808 3.63185 6.94838C3.1386 7.18869 2.44653 6.7837 2.08607 6.04382C1.72562 5.30393 1.83327 4.50933 2.32653 4.26903C2.81978 4.02873 3.51185 4.43372 3.87231 5.1736Z"
        fill={color || "#3F9AF7"}
      />
    </Svg>
  )
}

export const SpeakingSvg = React.memo(SpeakingSvgComponent)
