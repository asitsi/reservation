import { TouchableOpacity, View } from "react-native"
import styled from "styled-components/native"

import { CenteredText, color, font, Props } from "convose-styles"
import Animated from "react-native-reanimated"

export const getIconColor = (count: number, notification: boolean): string => {
  if (notification) {
    return color.white
  }

  return count > 0 ? color.black : color.darkGray
}
export const ItemContainer = styled.View``
export const ListItem = styled(View)`
  align-self: center;
  width: 100%;
  margin-bottom: 10px;
  margin-top: 10px;
`
export const Separator = styled.View`
  height: 1px;
  width: 98%;
  margin-left: 2%;
  background-color: ${(props: Props) => props.theme.addPerson.separator};
`

export const TouchableWrapper = styled(TouchableOpacity)`
  flex-direction: row;
  justify-content: center;
  align-items: center;
`

export const AvatarContainer = styled(View)`
  margin-right: 20px;
`

export const Body = styled(View)`
  flex: 1;
  flex-direction: column;
`

export const Section = styled(View)`
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  flex: 1;
`

export const UsernameBG = styled.View`
  background-color: ${(props: Props) =>
    props.color ? props.color : props.theme.main.background};
  border-radius: 15px;
  padding: 2px 8px;
  overflow: hidden;
`
export const Username = styled(CenteredText)`
  font-family: ${font.bold};
  font-size: 17px;
  color: ${(props: Props) => props.theme.main.chatBoxText};
  text-transform: capitalize;
`

export const BadgeView = styled(View)`
  justify-content: center;
  align-items: center;
`
export const EmptyCheck = styled.View`
  background-color: ${(props: Props) => props.theme.inviteToGroupCheckbox};
  width: 30px;
  height: 30px;
  border-radius: 30px;
`
export const CheckMarkContainer = styled(Animated.View)`
  width: 25px;
  aspect-ratio: 1;
  border-width: 2px;
  border-radius: 8px;
  align-items: center;
  justify-content: center;
`
