import { Animated, View } from "react-native"
import Ionicons from "react-native-vector-icons/Ionicons"
import styled from "styled-components/native"
import ReAnimated from "react-native-reanimated"

import { CenteredText, color, font, Props } from "convose-styles"
import { isAndroid } from "../../../../settings"

export const getIconColor = (count: number, notification: boolean): string => {
  if (notification) {
    return color.white
  }

  return count > 0 ? color.black : color.darkGray
}
export const SHADOW_BORDER_RADIUS = 20
type InboxContainerProps = {
  cardView: boolean
  padding: number
  bgColor?: string
  transparentBackground?: boolean
}

export const InboxContainer = styled(ReAnimated.View)`
  align-self: center;
  width: 100%;
  padding: ${(props: InboxContainerProps) => {
    if (props.cardView) {
      return `10px`
    }
    if (props.padding) {
      return `${props.padding}px`
    }
    return `5px 10px`
  }};
  ${(props: InboxContainerProps) =>
    props.cardView ? `border-radius: ${SHADOW_BORDER_RADIUS}px;` : ``}

  background: ${(props: Props & InboxContainerProps) => {
    if (props.transparentBackground) {
      return isAndroid
        ? props.theme.notificationChildren.androidTransparent
        : props.theme.notificationChildren.transparent
    }
    if (props.bgColor === "default") {
      return props.theme.main.chatBoxOnCall
    }
    return props.theme.main.background
  }};
`

export const NotificationContainer = styled(Animated.View)`
  background: ${(props: Props) => props.theme.notification};
  position: absolute;
  width: 95%;
  z-index: 999;
  align-self: center;
  border-radius: 90px;
  padding: 10px;
`

export const TouchableWrapper = styled.Pressable`
  flex-direction: row;
  justify-content: center;
  align-items: center;
`

export const AvatarBackground = styled.View`
  background-color: ${(props: Props & { bgColor: string }) =>
    props.bgColor === "default"
      ? props.theme.main.chatBoxBackground
      : props.bgColor};
  width: ${(props: { size: number }) => props.size}px;
  height: ${(props: { size: number }) => props.size}px;
  justify-content: center;
  align-items: center;
  border-radius: 16px;
`

export const Body = styled(View)`
  flex: 2;
  flex-direction: column;
  margin-left: 15px;
  padding: 3px 0px;
  max-height: 60px;
`

export const Section = styled(View)`
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  flex: 1;
  padding-right: 4px;
`

export const DateComponent = styled(CenteredText)`
  color: ${(props: Props) => props.theme.timeStamp};
  font-size: 14px;
  font-family: ${font.semiBold};
  opacity: 0.5;
  ${(props: { cardView: boolean }) =>
    props.cardView ? `margin-right: 3px;` : ``}
`

export const Username = styled(CenteredText)`
  color: ${(props: Props & { forceDefaultTextColor: boolean }) => {
    if (props.color && props.color !== "SystemDefault") {
      return props.color
    }
    return props.theme.main.text
  }};
  font-family: ${font.semiBold};
  font-size: ${(props: { fontSize?: number }) => props.fontSize || 18}px;
  text-transform: capitalize;
  max-width: 80%;
  padding-left: 1px;
  margin-top: -3px;
`
export const Description = styled(Username)`
  margin-left: 2px;
  text-transform: none;
`
export const TextMessage = styled(CenteredText)`
  color: ${(props: Props & { forceDefaultTextColor: boolean }) =>
    props.forceDefaultTextColor
      ? props.theme.main.text
      : props.theme.inboxConversationBox.newMessage};
  font-style: italic;
  font-family: ${(props: { newMessage: boolean }) =>
    props.newMessage ? font.semiBold : font.normal};
  font-size: ${(props: { fontSize?: number }) => props.fontSize || 16}px;
  max-width: 80%;
  flex-shrink: 1;
  padding-top: 1px;
`
export const StyledIcon = styled(Ionicons)`
  color: ${(props: Props & { forceDefaultTextColor: boolean }) =>
    props.forceDefaultTextColor
      ? props.theme.main.text
      : props.theme.inboxConversationBox.newMessage};
  margin-right: 5px;
`

export const GroupTextWrapper = styled(View)`
  width: 90%;
  flex-direction: row;
  justify-content: flex-start;
  align-items: center;
`

export const MediaMessageContainer = styled(View)`
  flex-direction: row;
  justify-content: flex-start;
  align-items: center;
`

export const BadgeView = styled(View)`
  justify-content: center;
  align-items: center;
  width: 11px;
  padding-bottom: 10px;
  ${(props: { cardView: boolean }) =>
    props.cardView ? `margin-right: 3px;` : ``}
`

export const GroupUserName = styled(CenteredText)`
  color: ${(props: Props) =>
    props.color && props.color !== "SystemDefault"
      ? props.color
      : props.theme.main.text};
  font-family: ${font.semiBold};
  font-size: 16px;
  margin-right: 9px;
  max-width: 40%;
`
export const WaveButtonContainer = styled.View``
