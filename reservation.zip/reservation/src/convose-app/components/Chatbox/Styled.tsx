import { TouchableOpacity, View } from "react-native"
import styled from "styled-components/native"
import Animated from "react-native-reanimated"

import { ThemeColor } from "convose-lib/user"
import { AVATAR_SIZE, CenteredText, Props, font } from "convose-styles"

const AnimatedTouchableOpacity =
  Animated.createAnimatedComponent(TouchableOpacity)

type ChatboxHeaderProps = {
  readonly themeColor: ThemeColor
  readonly bgColor?: string
}

export const BORDER_RADIUS = 25
const HEADER_SIZE = 88
export const CONTAINER_PADDING = 10
const JOIN_CALL_BUTTON_SIZE = 35

export const ChatboxWrapper = styled(AnimatedTouchableOpacity)`
  border-radius: ${BORDER_RADIUS}px;
  background-color: ${(props: Props) => props.theme.main.chatBoxBackground};
  margin-bottom: 25px;
  width: ${(props: { widthPercentage: number }) => props.widthPercentage}%;
  overflow: hidden;
`

export const ChatboxHeader = styled(View)`
  flex-direction: row;
  justify-content: flex-start;
  align-items: center;
  overflow: hidden;
  height: ${HEADER_SIZE}px;
  padding: ${CONTAINER_PADDING}px;
  padding-bottom: 5px;
  margin-left: 2px;
`
export const HeaderColorBox = styled(Animated.View)`
  width: 100%;
  height: 50px;
  position: absolute;
  background: ${(props: Props & ChatboxHeaderProps) => {
    if (props.bgColor) {
      return props.bgColor
    }
    return "transparent"
  }};
`
export const ChatboxBody = styled.View`
  width: 100%;
  padding: ${CONTAINER_PADDING}px;
  padding-top: 0px;
  flex-direction: column;
  justify-content: space-between;
`
const CHATBOX_AVATAR_SIZE = AVATAR_SIZE + 10
export const ChatboxAvatar = styled(View)`
  background-color: ${(props: Props) => props.theme.main.chatBoxBackground};
  width: ${CHATBOX_AVATAR_SIZE}px;
  height: ${CHATBOX_AVATAR_SIZE}px;
  border-radius: ${CHATBOX_AVATAR_SIZE}px;
  align-items: center;
  justify-content: center;
`

export const HeaderTextWrapper = styled(View)`
  flex-direction: column;
  margin-left: 15px;
  margin-bottom: ${(props: { isGroupCallChat: boolean }) =>
    !props.isGroupCallChat ? "40px" : undefined};
`

export const ChatboxHeaderText = styled(CenteredText)`
  color: ${(props: Props & ChatboxHeaderProps) => props.theme.main.chatBoxText};
  font-family: ${font.bold};
  font-size: 22px;
  line-height: 27px;
  width: 200px;
  text-transform: capitalize;
  padding-left: 2px;
`
export const UsernameContainer = styled.View`
  padding-top: 4px;
`
export const ChatboxSubheaderText = styled(CenteredText)`
  color: ${(props: Props & ChatboxHeaderProps) =>
    props.themeColor || props.theme.mainBlue};
  font-family: ${font.normal};
  font-size: 20px;
`

export const ChatboxInterests = styled(View)`
  flex-direction: row;
  justify-content: flex-start;
  flex-wrap: wrap;
  width: 100%;
  overflow: hidden;
  height: ${(props: { hasJoinCall: boolean; isUpcomingEvent: boolean }) => {
    if (props.isUpcomingEvent) {
      return 35
    }
    if (props.hasJoinCall) {
      return 80
    }
    return 120
  }}px;
`

export const JoinCallContainer = styled.View`
  flex-direction: row;
  justify-content: flex-start;
  align-items: center;
  width: 70%;
  align-self: flex-start;
  height: 40px;
`
export const GroupJoinButtonContainer = styled.View`
  margin-left: 5px;
`
export const JoinCallUsersDescriptionContainer = styled.View`
  flex-direction: row;
  align-items: center;
`

export const CallButtonWrapper = styled(TouchableOpacity)`
  padding: 5px 10px;
  padding-right: 14px;
  border-radius: ${JOIN_CALL_BUTTON_SIZE}px;
  background-color: ${(props: Props) => props.theme.mainBlue};
  justify-content: center;
  align-items: center;
  flex-direction: row;
`

export const JoinCallText = styled(CenteredText)`
  color: white;
  font-size: 16px;
  font-family: ${font.semiBold};
  margin-left: 5px;
`

export const JoinCallDescriptionContainer = styled.View`
  flex-direction: row;
  align-self: center;
  align-items: center;
  margin-left: ${CONTAINER_PADDING}px;
`

export const JoinCallDescriptionText = styled(CenteredText)`
  color: ${(props: Props) => props.theme.main.text};
  font-family: ${font.semiBold};
  font-size: 16px;
  padding-right: 5px;
  padding-left: 5px;
`
export const LiveIconContainer = styled.View``

export const Box = styled.View`
  width: 12px;
  height: 12px;
  position: absolute;
  bottom: 0px;
  left: 25px;
  z-index: 100;
`
export const LeftBox = styled(Box)`
  left: 0px;
  top: 38px;
`
export const TopBox = styled(Box)`
  top: 0px;
  left: 40px;
`

export const LeftLine = styled.View`
  position: absolute;
  background-color: ${(props: Props) => props.theme.main.text};
  height: ${(props: { height: number }) =>
    props.height ? props.height - 9 : 0}px;
  width: 1px;
  left: ${CONTAINER_PADDING - 5}px;
  top: 5px;
`
export const EmptyAvatar = styled(Animated.View)`
  height: ${(props: { size: number }) => props.size}px;
  aspect-ratio: 1;
  border-radius: ${(props: { size: number }) => props.size}px;
`
export const EmptyInterestLine = styled.View`
  flex-direction: row;
  width: 100%;
  margin-bottom: 5px;
  margin-left: 5px;
`
export const EmptyInterest = styled(Animated.View)`
  height: 25px;
  width: ${(props: { isBig: boolean }) => (props.isBig ? `50%` : `35%`)};
  border-radius: 30px;
  margin-right: 10px;
  margin-bottom: 10px;
`
export const WaveContainer = styled.View`
  position: absolute;
  right: ${CONTAINER_PADDING + 5}px;
  bottom: ${CONTAINER_PADDING + 5}px;
`
export const WaveGradientWrapper = styled.View`
  justify-content: center;
  align-content: center;
  align-items: center;
`
export const GradientWrapper = styled.View`
  position: absolute;
`
