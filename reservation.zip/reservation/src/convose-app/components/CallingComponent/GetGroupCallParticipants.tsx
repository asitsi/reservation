import React from "react"
import { useDispatch } from "react-redux"
import { uniq } from "lodash"

import { ChatUser } from "convose-lib/chat"
import { UsersListAction } from "convose-lib/users-list"
import { Peer } from "convose-lib/calling"

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const isString = (value: any): value is string => {
  return typeof value === "string"
}

type Props = {
  peers: Peer[]
  participants: ChatUser[]
  channel: string
}

const GetGroupCallParticipantsComponent: React.FC<Props> = ({
  peers,
  participants = [],
  channel,
}) => {
  const dispatch = useDispatch()
  const peersRawUuid: number[] = React.useMemo(
    () => peers.map((peer) => peer.rawAgoraUuid),
    [peers]
  )
  const getMultipleParticipantProfiles = React.useCallback(
    (uuids: string[], chatChannel: string) => {
      dispatch(
        UsersListAction.getMultipleParticipantProfiles(uuids, chatChannel)
      )
    },
    [dispatch]
  )
  React.useEffect(() => {
    const peerUsers = uniq(peers.map((msg) => msg.uuid))
      .filter((uuid) => uuid !== undefined)
      .filter(isString)
    const usersNotInParticipants = peerUsers.filter(
      (uid) => !participants.find((user) => user.uuid === uid)
    )
    if (usersNotInParticipants.length) {
      getMultipleParticipantProfiles(usersNotInParticipants, channel)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [peersRawUuid, channel])
  return null
}

export const GetGroupCallParticipants = React.memo(
  GetGroupCallParticipantsComponent
)
