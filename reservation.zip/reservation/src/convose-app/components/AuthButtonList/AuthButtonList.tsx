/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { Component } from "react"
import { Platform } from "react-native"
import { connect } from "react-redux"
import * as AppleAuthentication from "expo-apple-authentication"
import { GoogleSignin } from "@react-native-google-signin/google-signin"
import { LoginManager, AccessToken, Settings } from "react-native-fbsdk-next"

import _ from "lodash"
import { LoginType, selectUserFeature, User } from "convose-lib/user"
import { AuthAction, State } from "convose-lib"

import { googleSignInConfig } from "../../../../settings"
import {
  ButtonWrapper,
  CenterContent,
  SideContainer,
  Label,
  StyledEmailIcon,
  StyledAppleIcon,
  ButtonsContainer,
} from "./styled"
import * as RootNavigation from "../../RootNavigation"
import { convoseAlertRef } from "../../RootConvoseAlert"
import { GoogleIcon } from "../../../assets/Icons/components/GoogleIcon"
import { FacebookIcon } from "../../../assets/Icons/components/FacebookIcon"

type StateToPropsType = {
  readonly user: User
}

type DispatchToProps = {
  readonly authThirdParty: (response: any) => void
  readonly authThirdPartyRequest: () => void
  readonly authThirdPartyRequestCancel: () => void
}
type AutButtonScreenType = {
  loginOrSignUp: LoginType
  onAuthCompleted: (callback?: () => void) => void
  onHideComponent?: (callback?: () => void) => void
}
type AllProps = AutButtonScreenType & StateToPropsType & DispatchToProps
const isAndroid = Platform.OS === "android"

const GOOGLE_SIGN_IN_CANCEL_ERROR_CODE = isAndroid ? 12501 : "-5"

class AuthButtonListComponent extends Component<AllProps> {
  public shouldComponentUpdate(prevProps: AllProps): boolean {
    return !_.isEqual(this.props, prevProps)
  }

  public componentDidUpdate(prevProps: AllProps): void {
    const { user, onAuthCompleted } = this.props
    if (
      prevProps.user.uuid !== user.uuid ||
      prevProps.user.is_guest !== user.is_guest
    ) {
      onAuthCompleted()
    }
  }

  public readonly loginWithGoogle = async (): Promise<void> => {
    const { authThirdPartyRequest, authThirdPartyRequestCancel } = this.props
    GoogleSignin.configure(googleSignInConfig)
    try {
      authThirdPartyRequest()
      await GoogleSignin.hasPlayServices()
      const { idToken } = await GoogleSignin.signIn()
      const { authThirdParty } = this.props
      const json: { idToken: string | null | undefined } = {
        idToken,
      }
      authThirdParty(json)
    } catch ({ message, code, userInfo = {} }: any) {
      if (code !== GOOGLE_SIGN_IN_CANCEL_ERROR_CODE) {
        const iosUserInfo =
          userInfo !== null && typeof userInfo === "object"
            ? { NSLocalizedDescription: message, ...userInfo }
            : { NSLocalizedDescription: message }

        const errorMessage = isAndroid
          ? message
          : iosUserInfo.NSLocalizedDescription

        convoseAlertRef?.show({
          ioniconName: "logo-google",
          title: `Google Login`,
          description: `Google Login Error: ${errorMessage}`,
        })
      }
      authThirdPartyRequestCancel()
    }
  }

  public readonly loginWithFacebook = async (): Promise<void> => {
    const { authThirdPartyRequest, authThirdPartyRequestCancel } = this.props
    try {
      Settings.setAppID("853466218454989")
      Settings.initializeSDK()
      authThirdPartyRequest()
      const facebookLoginResponse = await LoginManager.logInWithPermissions([
        "email",
        "public_profile",
      ])
      if (facebookLoginResponse.isCancelled) {
        authThirdPartyRequestCancel()
        return
      }

      const data = await AccessToken.getCurrentAccessToken()
      if (!data) {
        throw Error("Something went wrong obtaining access token")
      }
      const response = await fetch(
        `https://graph.facebook.com/me?fields=name,email,picture.width(200).height(200)&access_token=${data.accessToken}`
      )
      const json: any = await response.json()
      json.accessToken = data.accessToken
      const { authThirdParty } = this.props
      authThirdParty(json)
    } catch ({ message }: any) {
      convoseAlertRef?.show({
        ioniconName: "logo-facebook",
        title: `Facebook Login`,
        description: `Facebook Login Error: ${message}`,
      })
      authThirdPartyRequestCancel()
    }
  }

  public readonly loginWithApple = async (): Promise<void> => {
    const { authThirdPartyRequest, authThirdPartyRequestCancel } = this.props
    try {
      authThirdPartyRequest()
      const credential = await AppleAuthentication.signInAsync({
        requestedScopes: [
          AppleAuthentication.AppleAuthenticationScope.FULL_NAME,
          AppleAuthentication.AppleAuthenticationScope.EMAIL,
        ],
      })
      const { authThirdParty } = this.props
      authThirdParty(credential)
      // signed in
    } catch (e: any) {
      authThirdPartyRequestCancel()
      if (e.code === "ERR_CANCELED") {
        // handle that the user canceled the sign-in flow
      } else {
        // handle other errors
      }
    }
  }

  public readonly loginWithEmail = async (): Promise<void> => {
    const { loginOrSignUp, onHideComponent } = this.props
    !!onHideComponent &&
      onHideComponent(() => {
        RootNavigation.navigate(loginOrSignUp || LoginType.Login, {})
      })
  }

  public render(): React.ReactNode {
    const { user, loginOrSignUp } = this.props
    if (!user.is_guest) {
      return null
    }
    const loginButtons = [
      {
        icon: <GoogleIcon height={23} />,
        type: "google",
        label: `with Google`,
        onPress: this.loginWithGoogle,
      },
      {
        icon: <FacebookIcon height={23} />,
        type: "facebook",
        label: `with Facebook`,
        onPress: this.loginWithFacebook,
      },
    ]
    if (
      Platform.OS === "ios" &&
      parseInt(Platform.Version.toString(), 10) >= 13
    ) {
      loginButtons.push({
        icon: <StyledAppleIcon height={22} />,
        type: "apple",
        label: `with Apple`,
        onPress: this.loginWithApple,
      })
    }
    if (loginOrSignUp === LoginType.Login) {
      loginButtons.push({
        icon: <StyledEmailIcon height={15} />,
        type: "email",
        label: `with Email`,
        onPress: this.loginWithEmail,
      })
    }

    return (
      <ButtonsContainer>
        {loginButtons.map((login, index) => (
          <ButtonWrapper
            key={login.type}
            onPress={login.onPress}
            noBottomMargin={index === loginButtons.length - 1}
          >
            <SideContainer>{login.icon}</SideContainer>
            <CenterContent>
              <Label>Continue {login.label}</Label>
            </CenterContent>
            <SideContainer />
          </ButtonWrapper>
        ))}
      </ButtonsContainer>
    )
  }
}

const mapStateToProps = (state: State): StateToPropsType => ({
  user: selectUserFeature(state),
})
const mapDispatchToProps = {
  authThirdParty: AuthAction.authThirdParty,
  authThirdPartyRequest: AuthAction.authThirdPartyRequest,
  authThirdPartyRequestCancel: AuthAction.authThirdPartyRequestCancel,
}
// AuthButtonListComponent.whyDidYouRender = {
//   logOnDifferentValues: false,
//   customName: "AuthButtonListComponent",
//   diffNameColor: "red",
// }

export const AuthButtonList: React.FunctionComponent<AutButtonScreenType> =
  connect(mapStateToProps, mapDispatchToProps)(AuthButtonListComponent)
