import { View } from "react-native"
import styled from "styled-components"
import Animated from "react-native-reanimated"

import { CenteredText, Props, font, statusBarHeight } from "convose-styles"
import { ToastPositions } from "convose-lib/toast"

export const ToastWrapper = styled(Animated.View)`
  top: ${(props: { position: ToastPositions; insetTop: number }) =>
    props.position === "top"
      ? `${statusBarHeight + 15}px`
      : `${props.insetTop + 200}px`};
  position: absolute;
  justify-content: center;
  align-items: center;
  width: 100%;
`

export const StyledToast = styled(View)`
  background-color: ${(props: Props) => props.theme.toast.background};
  justify-content: center;
  align-items: center;
  min-height: 50px;
  width: 90%;
  padding: 5px;
  padding-left: 11px;
  padding-right: 11px;
  border-radius: 6px;
  opacity: 0.8;
`

export const Message = styled(CenteredText)`
  color: ${(props: Props) => props.theme.toast.text};
  font-size: 18px;
  font-family: ${font.normal};
  text-align: center;
`
