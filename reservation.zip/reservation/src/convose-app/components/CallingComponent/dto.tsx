import { View } from "react-native"
import { OrderedMap } from "immutable"
import { ScrollView } from "react-native-gesture-handler"

import { AgoraUuid, AudioSetting, Peer } from "convose-lib/calling"
import { ChatUser } from "convose-lib/chat"
import { SafeAreaProps } from "convose-lib/generalTypes"
import { HandRaiseTypes } from "convose-lib/users-list"

export type CallingProps = {
  show: boolean
  isFullScreenVideoCall?: boolean
  audioSetting: AudioSetting
  toggleAudio: () => void
  toggleVideo: () => void
  toggleSpeaker: () => void
  endCall: ({ displayText }: { displayText: boolean }) => void
  unsetUnmuteAlert: () => void
  unmuteAlert: boolean
  peers: OrderedMap<AgoraUuid, Peer>
  me: ChatUser
  groupInfo: {
    audience: ReadonlyArray<ChatUser>
    broadcasters: ReadonlyArray<ChatUser>
  }
  isCaller: boolean
  channel: string
  isGroup: boolean
  muteRemoteUser: (muteCommand: string, name: string) => void
  participants: ChatUser[]
  isHeaderHide?: boolean
  isChatHide?: boolean
  videoCallFullScreenUid: number | null
  setVideoCallFullScreenUid: (videoCallFullScreenUid: number | null) => void
  setContainerRef?: (ref: View) => void
}
export type CallingComponentProps = CallingProps &
  SafeAreaProps & {
    myRaisedHandStatus: HandRaiseTypes | null
    isGroupAdmin: boolean
    isHandRaiseEnabled: boolean
    toggleHandRaise: () => void
  }

export type CallingButtonsProps = {
  isAudioEnabled: boolean
  isVideoEnabled: boolean
  isSpeakerActive: boolean
  toggleAudio: () => void
  toggleVideo: () => void
  toggleSpeaker: () => void
  endCall: () => void
  unmuteAlert: boolean
  unsetUnmuteAlert: () => void
  isGroup: boolean
  isLandscape?: boolean
  isGroupAdmin: boolean
  isHandRaiseEnabled: boolean
  toggleHandRaise: () => void
  myRaisedHandStatus: HandRaiseTypes | null
}

export type CallingUsersProps = {
  isCalling: boolean
  isHide?: boolean
  peers: OrderedMap<AgoraUuid, Peer>
  me: ChatUser
  groupInfo: {
    audience: ReadonlyArray<ChatUser>
    broadcasters: ReadonlyArray<ChatUser>
  }
  audioSetting: AudioSetting
  channel: string
  isGroup: boolean
  muteRemoteUser: (muteCommand: string, name: string) => void
  videoCallFullScreenUid?: number | null
  setUserScrollRef?: (ref: ScrollView) => void
  onUserScrollBeginDrag?: () => void
  onUserScrollEndDrag?: () => void
  participants: ChatUser[]
  isLandscape?: boolean
  setVideoCallFullScreenUid?: (videoCallFullScreenUid: number | null) => void
  isGroupAdmin: boolean
  isHandRaiseEnabled: boolean
}
