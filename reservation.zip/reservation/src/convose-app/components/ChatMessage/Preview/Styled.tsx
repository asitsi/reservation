import styled from "styled-components/native"
import FastImage from "react-native-fast-image"

import { CenteredText, Props, font } from "convose-styles"
import { calculateImageSize } from "convose-lib/utils"
import { messageBorderRadius } from "../Styled"

export const PreviewContainer = styled.TouchableOpacity`
  background-color: ${(props: Props) => props.theme.message.otherMessageBubble};
  border-bottom-left-radius: ${messageBorderRadius}px;
  border-bottom-right-radius: ${messageBorderRadius}px;
  width: 100%;
`
export const PreviewImage = styled(FastImage)`
  ${(props: { imageRatio: number | null }) =>
    props.imageRatio
      ? calculateImageSize({ ratio: props.imageRatio, maxHeight: 600 })
      : `width: 100%;
  height: 150px;`}
  width: 100%;
`
export const PreviewTitle = styled(CenteredText)`
  font-family: ${font.bold};
  color: ${(props: Props) => props.theme.main.text};
  padding: 12px;
  font-size: 15px;
  line-height: 17px;
  margin-bottom: -4px;
`
export const ButtonsContainer = styled.View`
  flex-direction: row;
  width: 65%;
  justify-content: space-evenly;
  position: absolute;
  align-self: center;
  padding: 10px 0px;
  border-radius: 15px;
  overflow: hidden;
`
export const ButtonsContainerBackground = styled.View`
  width: 100%;
  height: 70px;
  position: absolute;
  left: 0px;
  top: 0px;
  background-color: black;
  opacity: 0.7;
`
export const ActionButton = styled.TouchableOpacity``
