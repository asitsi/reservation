import styled from "styled-components/native"
import Animated from "react-native-reanimated"

import { CenteredText, Props, font } from "convose-styles"
import { CheckMarkSvg } from "../../../assets/svg/CheckMark"

export const marginHorizontal = 25
export const SelectContainer = styled.View`
  width: 100%;
  background-color: ${(props: Props) => props.theme.main.chatBoxBackground};
  border-radius: 9px;
  overflow: hidden;
`

export const SelectItemContainer = styled.TouchableOpacity`
  margin-left: ${marginHorizontal}px;
  padding: 12px 0px;
  border-width: 0.5px;
  border-color: transparent;
  border-bottom-color: ${(props: Props & { isLast: boolean }) =>
    props.isLast ? "transparent" : props.theme.main.chatBoxSkeletonLight};
  flex-direction: row;
  justify-content: space-between;
`
export const SelectItemText = styled(CenteredText)`
  font-family: ${font.normal};
  color: ${(props: Props) => props.theme.main.text};
  font-size: 18px;
`
export const StyledCheckMarkSvg = styled(CheckMarkSvg).attrs(
  (props: Props) => ({
    color: props.theme.main.text,
  })
)``

export const CheckMarkContainer = styled(Animated.View)`
  margin-right: ${marginHorizontal}px;
`
