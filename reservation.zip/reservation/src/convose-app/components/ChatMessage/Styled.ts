/* eslint-disable no-nested-ternary */
/* eslint-disable complexity */
import { Pressable, View, Image } from "react-native"
import { TouchableOpacity } from "react-native-gesture-handler"
import styled from "styled-components/native"
import Animated from "react-native-reanimated"
import Ionicons from "react-native-vector-icons/Ionicons"

import { MessageType, MEDIA_TYPES } from "convose-lib/chat"
import { CenteredText, color, font, Props } from "convose-styles"
import { calculateImageSize } from "convose-lib/utils"

export const messageBorderRadius = 20
const imageMessageBorderRadius = 10
const MESSAGE_WIDTH_PERCENTAGE = 75
export const MESSAGE_HORIZONTAL_MARGIN = 35
export const MESSAGE_BUBBLE_PADDING = 9

type borderProps = {
  myMessage: boolean
  ratio: number
  deleted: boolean
  hasReply: boolean
  isReply: boolean
  type: MessageType
}

type ImageProps = borderProps

export const MessageDate = styled(CenteredText)`
  color: ${(props: borderProps & Props) =>
    props.myMessage ? color.white : props.theme.main.text};
  bottom: 5px;
  font-size: 10px;
  position: absolute;
  right: 15px;
  font-family: ${font.normal};
`
export const MessageDateImage = styled(CenteredText)`
  color: ${(props: borderProps & Props) =>
    props.myMessage ? color.white : props.theme.main.text};
  font-size: 10px;
  margin-bottom: 5px;
  text-align: center;
  font-family: ${font.normal};
`
export const EmojiOnlyText = styled(CenteredText)`
  font-size: 32px;
`
export const MessageText = styled(CenteredText)`
  font-size: 14px;
  padding-horizontal: 4px;
  color: ${(props: borderProps & Props) => {
    if (props.isReply) {
      return props.theme.message.replyText
    }
    if (props.deleted) {
      return props.theme.message.deletedText
    }
    if (props.myMessage) {
      return color.white
    }
    return props.theme.main.text
  }};
  font-family: ${font.normal};
  line-height: 19.5px;
`
const calculateGroupMessageMargin = (props: borderProps) => {
  if (props.myMessage) {
    return ``
  }
  return `
  margin-left: ${props.hasReply ? 0 : MESSAGE_HORIZONTAL_MARGIN}px;
  `
}

export const MessageContent = styled.View`
  align-self: ${(props: { myMessage: boolean }) =>
    props.myMessage ? "flex-end" : "flex-start"};
  max-width: ${MESSAGE_WIDTH_PERCENTAGE}%;
  margin-bottom: 2px;
  ${(props: borderProps) => calculateGroupMessageMargin(props)};
  ${(props: { hasPreview: boolean }) =>
    props.hasPreview ? `width: ${MESSAGE_WIDTH_PERCENTAGE}%;` : ``}
`
export const EmojiMessage = styled(View)``

export const MessageBubbleContainer = styled(View)`
  background: ${(props: borderProps & Props) => {
    if (props.deleted) {
      return "transparent"
    }
    if (!MEDIA_TYPES.includes(props.type)) {
      return props.myMessage
        ? props.theme.mainBlue
        : props.theme.message.otherMessageBubble
    }
    return "transparent"
  }};
  ${(props: borderProps & Props) => {
    if (props.deleted || MEDIA_TYPES.includes(props.type)) {
      return `border-width: 1px;
      border-color: ${props.theme.message.deletedTextBorder};`
    }
    return ``
  }};
  border-radius: ${(props: borderProps) =>
    MEDIA_TYPES.includes(props.type)
      ? imageMessageBorderRadius
      : messageBorderRadius}px;
  padding: ${(props: borderProps) =>
    MEDIA_TYPES.includes(props.type) ? 0 : MESSAGE_BUBBLE_PADDING}px;
  opacity: ${(props: { publishing: boolean }) => (props.publishing ? 0.3 : 1)};
  overflow: hidden;
  ${(props: { hasPreview: boolean }) =>
    props.hasPreview
      ? `border-bottom-right-radius: 0px;
  border-bottom-left-radius: 0px;`
      : ``}
`

export const StyledImage = styled(Image)`
  ${(props: ImageProps) => calculateImageSize(props)};
  resize-mode: contain;
`
export const StyledImageContainer = styled(Animated.View)`
  ${(props: ImageProps) => calculateImageSize(props)};
  overflow: hidden;
`
export const MentionText = styled(CenteredText)`
  color: ${(props: Props) =>
    props.color ? props.color : props.theme.main.text};
  ${(props: Props) => props.color && `background: ${props.color}80`};
`

export const ImageWrapper = styled(Pressable)`
  overflow: hidden;
`
export const AvatarContainer = styled(TouchableOpacity)`
  width: 32px;
  height: 36px;
  margin-bottom: -10px;
`
export const ChatMessageUsernameContainer = styled(TouchableOpacity)``
export const UserWrapper = styled(View)`
  flex-direction: row;
  justify-content: flex-start;
  align-items: center;
  padding-top: 5px;
`

export const Username = styled(CenteredText)`
  color: ${(props: Props) =>
    props.color ? props.color : props.theme.chatInfo};
  font-family: ${font.semiBold};
  font-size: 15px;
  padding-left: 5px;
  padding-top: 5px;
`
export const Null = styled.View`
  width: 20px;
  height: 20px;
  background-color: red;
`
export const NullUsername = styled.View`
  width: 30px;
  height: 15px;
  background-color: green;
`
export const NullAudio = styled.View`
  width: 60px;
  height: 40px;
  background-color: yellow;
  margin-horizontal: 14px;
`
export const MessageContainer = styled.View``
export const ReactionsContainer = styled.View`
  flex-direction: row;
  width: ${MESSAGE_WIDTH_PERCENTAGE}%;
  flex-wrap: wrap;
  ${(props: { myMessage: boolean; hasReply: boolean }) =>
    props.myMessage || props.hasReply ? `` : `margin-left: 35px;`};
  bottom: 10px;
  align-self: ${(props: { myMessage: boolean }) =>
    props.myMessage ? "flex-end" : "flex-start"};
  justify-content: ${(props: { myMessage: boolean }) =>
    props.myMessage ? "flex-end" : "flex-start"};
  margin-bottom: -7px;
`
type ReactionType = {
  myReaction: boolean
}
const AnimatedTouchableOpacity =
  Animated.createAnimatedComponent(TouchableOpacity)
export const ReactionContainer = styled(AnimatedTouchableOpacity)`
  background-color: ${(props: Props & ReactionType) =>
    props.myReaction
      ? props.theme.mainBlue
      : props.theme.message.otherMessageBubble};
  border-radius: 15px;
  justify-content: center;
  flex-direction: row;
  padding: 3px 7px;
  border-color: ${(props: Props & ReactionType) =>
    props.myReaction ? "transparent" : props.theme.statusBar};
  border-width: 1px;
  align-items: center;
`
export const ReactText = styled(CenteredText)`
  font-family: ${font.normal};
  padding-left: ${(props: { count: boolean }) => (props.count ? 7 : 0)}px;
  font-size: 13px;
  color: ${(props: Props & ReactionType) =>
    props.myReaction ? color.white : props.theme.main.text};
`
const ReactionEmoji = Animated.createAnimatedComponent(ReactText)
export const StyledReactionEmoji = styled(ReactionEmoji)``
export const SwipeView = styled.View`
  width: 50px;
`
export const StyledIonicons = styled(Ionicons)`
  color: ${(props: Props) => props.theme.main.text};
`

export const MessageReplyContainer = styled(Animated.View)`
  justify-content: center;
  width: 100%;
`
export const ReplyArrowContainer = styled(Animated.View)`
  background-color: ${(props: Props) => props.theme.message.loadingMessage};
  padding: 5px;
  border-radius: 40px;
`
