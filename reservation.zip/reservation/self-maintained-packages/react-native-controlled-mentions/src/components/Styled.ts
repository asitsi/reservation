/* eslint-disable import/no-extraneous-dependencies */
import MaterialCommunityIcons from "react-native-vector-icons/MaterialCommunityIcons"
import styled from "styled-components"
import { TouchableOpacity, View } from "react-native"

const MARGIN_BETWEEN_ELEMENTS = 10
const ICONS_SIZE = 20

export const IconWrapper = styled(TouchableOpacity)`
  justify-content: flex-end;
  align-items: center;
  margin: 2px ${MARGIN_BETWEEN_ELEMENTS}px;
  width: 30px;
`

export const EmoticonPickerWrapper = styled(IconWrapper)`
  margin: 3px 3px 3px 0px;
`

export const EmoticonPickerIcon = styled(MaterialCommunityIcons)`
  color: ${(props) => props.theme.mainBlue};
  font-size: ${ICONS_SIZE}px;
`

export const InputWrapper = styled(View)`
  background: ${(props) => props.theme.textInput.background};
  overflow: hidden;
  flex-direction: row;
  border-radius: 30px;
  align-items: center;
`
