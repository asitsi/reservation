export type SvgProps = {
  color?: string
  height?: number
}
