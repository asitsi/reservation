import { Props, font } from "convose-styles"
import Animated from "react-native-reanimated"
import styled from "styled-components/native"

type PartialProps = Partial<Props>
type KnowledgeLevelType = PartialProps & { active: boolean }

export const KnowledgeLevelContainer = styled.View`
  flex-direction: column;
  align-items: flex-start;
  margin-bottom: 30px;
  width: 55px;
`

export const KnowledgeLevelBubble = styled(Animated.View)`
  aspect-ratio: 1;
  border-radius: 45px;
`

export const KnowledgeLevelTitleContainer = styled(Animated.View)`
  width: 150px;
  position: absolute;
  left: 20px;
  transform: rotateZ(45deg) translateX(-22px) translateY(53px);
`
export const KnowledgeLevelTitle = styled.Text`
  font-family: ${(props: KnowledgeLevelType) =>
    props.active ? font.bold : font.semiBold};
  color: ${(props: Props) => props.theme.main.text};
  include-font-padding: false;
  text-align-vertical: center;
`
export const KnowledgeContainer = styled.View`
  flex-direction: row;
  padding-right: 20px;
  padding-left: 31px;
  margin-top: 20px;
  margin-bottom: 90px;
  align-items: center;
`
