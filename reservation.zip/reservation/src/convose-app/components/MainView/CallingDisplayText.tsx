import React from "react"
import { useSelector } from "react-redux"
import { FadeIn, FadeOut } from "react-native-reanimated"

import { selectCallingDisplayText } from "convose-lib/calling"
import { DisplayTextModal, ModalContent } from "./Styled"

const CallingDisplayTextComponent: React.FC = () => {
  const callingDisplayText = useSelector(selectCallingDisplayText)
  return callingDisplayText ? (
    <DisplayTextModal entering={FadeIn} exiting={FadeOut}>
      <ModalContent>{callingDisplayText}</ModalContent>
    </DisplayTextModal>
  ) : null
}

export const CallingDisplayText = React.memo(CallingDisplayTextComponent)
