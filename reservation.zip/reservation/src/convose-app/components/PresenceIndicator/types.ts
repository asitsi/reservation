export type IndicatorLocations =
  | "chatBox"
  | "inbox"
  | "chat"
  | "chatMenu"
  | "chatBoxNear"
