import React, { useEffect } from "react"
import { ViewStyle } from "react-native"
import Animated, {
  AnimatedStyle,
  cancelAnimation,
  interpolateColor,
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withTiming,
} from "react-native-reanimated"
import { useTheme } from "styled-components"

type StartAnimation = () => void
type StopAnimation = () => void

export const useSkeleton = (
  lightColor?: string,
  darkColor?: string
): [AnimatedStyle, StartAnimation, StopAnimation] => {
  const theme = useTheme()
  const loadingColor = useSharedValue(0)
  const {
    message: { loadingMessageDark, loadingMessage },
  } = theme
  const animatedStyles = useAnimatedStyle(() => {
    return {
      backgroundColor: interpolateColor(
        loadingColor.value,
        [0, 1],
        [lightColor || loadingMessage, darkColor || loadingMessageDark]
      ),
    }
  })
  const stopLoading = () => {
    cancelAnimation(loadingColor)
  }
  const startLoading = () => {
    loadingColor.value = withRepeat(withTiming(1, { duration: 400 }), -1, true)
  }
  return [animatedStyles, startLoading, stopLoading]
}

type Props = {
  style?: ViewStyle
}
const SkeletonComponent: React.FC<Props> = ({ style }) => {
  const [animatedStyles, startLoading, stopLoading] = useSkeleton()
  useEffect(() => {
    startLoading()
    return () => {
      stopLoading()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])
  // eslint-disable-next-line react-perf/jsx-no-new-array-as-prop
  return <Animated.View style={[style, animatedStyles]} />
}

export const Skeleton = React.memo(SkeletonComponent)
