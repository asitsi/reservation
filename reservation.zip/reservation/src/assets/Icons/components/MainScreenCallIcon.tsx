import React from "react"
import { Svg, Path } from "react-native-svg"

import { SvgProps } from "../../svg/types"
import { getRatio, getWidth } from "../../svg/utils"

const defaultHeight = 34
const defaultWidth = 31
const ratio = getRatio(defaultHeight, defaultWidth)

const MainScreenCallIcon: React.FC<SvgProps> = ({ color, height = 34 }) => {
  const svgHeight = height || defaultHeight
  const svgWidth = height ? getWidth(ratio, height) : defaultWidth
  return (
    <Svg width={svgWidth} height={svgHeight} viewBox="0 0 31 34" fill="none">
      <Path
        d="M2.81583 5.87395C4.14533 4.73744 6.01558 4.15754 7.93383 4.25158C8.86788 4.29637 9.74283 4.71848 10.358 5.41829L12.4832 7.8378C13.2407 8.70041 13.6349 9.82141 13.5838 10.9675C13.5326 12.1136 13.0401 13.1965 12.2086 13.9908L10.9998 15.1467C10.4991 15.6237 10.4001 16.22 10.6199 16.6321C11.4055 18.1066 12.7955 19.6378 14.1786 20.5994C14.5905 20.8874 15.2316 20.8457 15.7705 20.3682L16.4472 19.7685C16.8912 19.3753 17.4093 19.0741 17.9711 18.8823C18.5329 18.6906 19.1272 18.6123 19.7194 18.6519C20.3116 18.6915 20.8898 18.8482 21.4203 19.113C21.9508 19.3777 22.4229 19.7452 22.8091 20.1939L24.7252 22.4173C25.3516 23.1458 25.6242 24.1108 25.4756 25.0589C25.1776 26.9423 24.2082 28.6082 22.8093 29.6259C21.3878 30.6591 19.5494 30.9981 17.6687 30.2293C14.691 29.0139 10.9353 26.7152 7.08318 22.396C3.18092 18.0178 1.6 13.9417 1.04894 10.7764C0.696212 8.75113 1.46285 7.02973 2.81583 5.87395Z"
        fill="white"
        stroke={color || "#19AAEB"}
        strokeWidth="0.5"
      />
    </Svg>
  )
}

export default MainScreenCallIcon
