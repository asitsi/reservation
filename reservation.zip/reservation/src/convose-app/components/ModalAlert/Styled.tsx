import styled from "styled-components/native"
import Animated from "react-native-reanimated"
import { CenteredText, Props, color, font } from "convose-styles"
import { TouchableWithoutFeedback } from "react-native"

export const Wrapper = styled.View`
  z-index: ${Number.MAX_VALUE};
  justify-content: center;
  position: absolute;
  width: 100%;
  height: 100%;
`
export const BackgroundEmptyViewContainer = styled(TouchableWithoutFeedback)`
  top: 0px;
  left: 0px;
`
export const BackgroundEmptyView = styled(Animated.View)`
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.8);
`
export const ModalContainer = styled(Animated.View)`
  background-color: ${(props: Props) => props.theme.main.background};
  width: 70%;
  position: absolute;
  align-self: center;
  border-radius: 20px;
`
export const TitleDescriptionContainer = styled.View`
  justify-content: center;
  width: 100%;
  align-items: center;
  padding: 20px;
`
export const ModalTitle = styled(CenteredText)`
  font-family: ${font.bold};
  font-size: 20px;
  color: ${(props: Props) => props.theme.main.text};
  text-align: center;
`
export const ModalDescription = styled(CenteredText)`
  font-family: ${font.medium};
  font-size: 15px;
  color: ${(props: Props) => props.theme.main.text};
  padding-top: 5px;
  text-align: center;
`
export const ButtonsContainer = styled.View``
export const StyledPressable = styled.Pressable`
  border-top-width: 1px;
  border-top-color: ${color.midgray};
  justify-content: center;
  align-items: center;
`
export const ButtonText = styled(CenteredText)`
  font-family: ${(props: { primaryChoice: boolean }) =>
    props.primaryChoice ? font.bold : font.normal};
  font-size: 16px;
  padding: 10px 20px;
  color: ${(props: Props & { warning: boolean }) =>
    props.warning ? color.red : props.theme.mainBlue};
`
