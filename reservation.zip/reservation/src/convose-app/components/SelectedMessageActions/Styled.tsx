import styled from "styled-components/native"
import Ionicons from "react-native-vector-icons/Ionicons"
import { CenteredText, Props, color, font } from "convose-styles"
import Animated from "react-native-reanimated"

export const PressableDismiss = styled.Pressable`
  justify-content: center;
  width: 100%;
  height: 100%;
  align-items: center;
  position: absolute;
  top: 0;
  left: 0;
`
type IconProps = Props & { size: number }
export const OptionIcon = styled(Ionicons)`
  color: ${(props: Props & { disable: boolean; warn: boolean }) => {
    if (props.disable) {
      return props.theme.message.deletedText
    }
    if (props.warn) {
      return color.red
    }
    return props.theme.main.text
  }};
  width: ${(props: IconProps) => props.size}px;
  height: ${(props: IconProps) => props.size}px;
`
export const OptionTitle = styled(CenteredText)`
  color: ${(props: Props & { disable: boolean; warn: boolean }) => {
    if (props.disable) {
      return props.theme.message.deletedText
    }
    if (props.warn) {
      return color.red
    }
    return props.theme.main.text
  }};
  font-family: ${font.normal};
  font-size: 16px;
  text-align: center;
`
export const StyledTouchableOpacity = styled.TouchableOpacity`
  flex-direction: row;
  padding: 10px 10px;
  width: 100%;
  align-items: center;
  justify-content: space-between;
  border-bottom-width: 1px;
  border-bottom-color: ${(props: Props & { isLast: boolean }) =>
    props.isLast ? "transparent" : props.theme.main.chatBoxSkeletonLight};
`
export const OptionsContainer = styled(Animated.View)`
  background-color: ${(props: Props) => props.theme.main.background};
  justify-content: center;
  align-items: center;
  width: 200px;
  border-radius: 15px;
  align-self: center;
  overflow: hidden;
`

export const EmojisContainer = styled(Animated.View)`
  flex-direction: row;
  background-color: ${(props: Props) => props.theme.main.background};
  justify-content: center;
  align-self: center;
  border-radius: 30px;
  padding: 5px 10px;
  overflow: hidden;
  margin-bottom: 10px;
`
export const EmojiItem = styled.TouchableOpacity`
  margin: 0px 5px;
`
export const EmojiIcon = styled(OptionTitle)`
  font-size: 30px;
`
