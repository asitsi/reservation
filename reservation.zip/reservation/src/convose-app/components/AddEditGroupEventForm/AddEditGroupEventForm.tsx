import React, { useCallback, useEffect, useState } from "react"
import { format, isSameDay } from "date-fns"
import DatePicker from "react-native-date-picker"
import {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
  interpolateColor,
  interpolate,
} from "react-native-reanimated"

import {
  EventInputType,
  EventRecurrence,
  repeatsArray,
} from "convose-lib/users-list"

import { convertDateToInformalText } from "convose-lib/utils"
import { color } from "convose-styles"

import { useKeyboard } from "convose-lib/utils/useKeyboard"
import { modalAlertRef } from "../../RootConvoseAlert"
import {
  StyledInput,
  ErrorText,
  FieldTitle,
  FormContainer,
  InputsContainer,
  PressableField,
} from "./Styled"
import { PrimaryButton } from "../PrimaryButton"

type Props = {
  type: "edit" | "add"
  onPress: (event: EventInputType) => void
} & Partial<EventInputType>

const AddEditGroupEventFormComponent: React.FC<Props> = ({
  type,
  onPress,
  date,
  name,
  recurrence,
  time,
}) => {
  const [keyboardHeight] = useKeyboard()
  const formattedTimeDate = `${date} ${time}.000Z`
  const [chosenDate, setChosenDate] = useState(
    date ? new Date(formattedTimeDate) : new Date()
  )
  const [chosenName, setChosenName] = useState(name || "")
  const [nameError, setNameError] = useState("")
  const [chosenRecurrence, setChosenRecurrence] = useState<EventRecurrence>(
    recurrence || "once"
  )
  const [openDatePickerType, setOpenDatePickerType] = useState<
    "date" | "time" | null
  >(null)
  const hasErrorOffset = useSharedValue(nameError ? 1 : 0)

  const errorStyle = useAnimatedStyle(() => ({
    height: interpolate(hasErrorOffset.value, [0, 1], [0, 15]),
  }))
  const boxBorderStyle = useAnimatedStyle(() => ({
    borderColor: interpolateColor(
      hasErrorOffset.value,
      [0, 1],
      ["transparent", color.red]
    ),
  }))
  useEffect(() => {
    hasErrorOffset.value = withTiming(nameError ? 1 : 0, { duration: 200 })
  }, [nameError, hasErrorOffset])

  useEffect(() => {
    if (nameError && chosenName.length !== 0) {
      setNameError("")
    }
  }, [chosenName, nameError])

  const formContainerStyle = useAnimatedStyle(() => ({
    paddingBottom: withTiming(keyboardHeight, { duration: 100 }),
  }))

  const onDatePress = useCallback(() => {
    setOpenDatePickerType("date")
  }, [])
  const onTimePress = useCallback(() => {
    setOpenDatePickerType("time")
  }, [])
  const closeDatePicker = useCallback(() => {
    setOpenDatePickerType(null)
  }, [])

  const getRepeatLabel = (repeatOption: EventRecurrence) => {
    return repeatOption === "once" ? "does not repeat" : repeatOption
  }
  const onRepeatsPress = useCallback(() => {
    modalAlertRef?.show({
      title: "How often should it repeat",
      buttons: repeatsArray.map((repeatOption) => ({
        title: getRepeatLabel(repeatOption),
        onPress: () => setChosenRecurrence(repeatOption),
        type: "default",
        primaryChoice: repeatOption === chosenRecurrence,
      })),
    })
  }, [chosenRecurrence])

  const onConfirmDatePicker = useCallback(
    (value: Date) => {
      if (openDatePickerType === "date" || openDatePickerType === "time") {
        setChosenDate(value)
      }
      setOpenDatePickerType(null)
    },
    [openDatePickerType]
  )

  const handleOnPress = () => {
    if (!chosenName) {
      setNameError("Event must have a name!")
      return
    }
    onPress({
      date: chosenDate,
      name: chosenName,
      recurrence: chosenRecurrence,
      time: chosenDate,
    })
  }
  const getMinimumTime = () => {
    const now = new Date()
    if (openDatePickerType === "date") {
      return now
    }
    if (isSameDay(now, chosenDate)) {
      return now
    }
    return undefined
  }

  return (
    <FormContainer style={formContainerStyle}>
      <DatePicker
        date={chosenDate}
        open={openDatePickerType !== null}
        modal
        onConfirm={onConfirmDatePicker}
        onCancel={closeDatePicker}
        mode={openDatePickerType || "datetime"}
        minimumDate={getMinimumTime()}
      />
      <InputsContainer>
        <StyledInput
          style={boxBorderStyle}
          placeholder="Name of event"
          isFirst
          value={chosenName}
          onChangeText={setChosenName}
          maxLength={60}
        />
        <ErrorText style={errorStyle}>{nameError}</ErrorText>
        <PressableField onPress={onDatePress}>
          <FieldTitle>Date:</FieldTitle>
          <FieldTitle>
            {/* {format(chosenDate, "ddd, DD/MMM").toString()} */}
            {convertDateToInformalText({
              fullDate: chosenDate,
              hideTime: true,
            })}
          </FieldTitle>
        </PressableField>
        <PressableField onPress={onTimePress}>
          <FieldTitle>Time:</FieldTitle>
          <FieldTitle>{format(chosenDate, "hh:mma").toString()}</FieldTitle>
        </PressableField>
        <PressableField isLast onPress={onRepeatsPress}>
          <FieldTitle>Repeats:</FieldTitle>
          <FieldTitle>{getRepeatLabel(chosenRecurrence)}</FieldTitle>
        </PressableField>
      </InputsContainer>
      <PrimaryButton
        label={type === "add" ? "Create & Share" : "Save"}
        onPress={handleOnPress}
      />
    </FormContainer>
  )
}

export const AddEditGroupEventForm = React.memo(AddEditGroupEventFormComponent)
