import React, { useCallback, useEffect } from "react"
import {
  interpolate,
  interpolateColor,
  runOnJS,
  useAnimatedStyle,
  useSharedValue,
  withTiming,
} from "react-native-reanimated"
import Ionicons from "react-native-vector-icons/Ionicons"

import { color, hardShadow } from "convose-styles"
import { useMainBlue } from "convose-lib/utils/useMainBlue"
import { Button, ButtonContainer, CallButtonWrapper } from "./Styled"

type Props = {
  onPress?: () => void
  isCalling?: boolean
  onEndCall?: () => void
  size?: number
  hasShadow?: boolean
}
enum callingValues {
  calling = 0,
  notCalling = 1,
}

const CallButtonComponent: React.FC<Props> = ({
  onPress,
  isCalling = true,
  onEndCall,
  size = 70,
  hasShadow,
}) => {
  const mainBlue = useMainBlue()
  const getAnimationValue = useCallback(
    () => (isCalling ? callingValues.calling : callingValues.notCalling),
    [isCalling]
  )
  const bgColorOffset = useSharedValue(getAnimationValue())
  const rotateOffset = useSharedValue(getAnimationValue())

  const buttonStyle = useAnimatedStyle(() => ({
    backgroundColor: interpolateColor(
      bgColorOffset.value,
      [0, 1],
      [color.red, mainBlue]
    ),
    transform: [
      { rotate: `${interpolate(rotateOffset.value, [0, 1], [135, 0])}deg` },
    ],
  }))

  useEffect(() => {
    rotateOffset.value = withTiming(getAnimationValue(), { duration: 300 })
    bgColorOffset.value = withTiming(
      getAnimationValue(),
      { duration: 700 },
      () => {
        if (!isCalling) {
          onEndCall && runOnJS(onEndCall)()
        }
      }
    )
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isCalling])

  return (
    // eslint-disable-next-line react-perf/jsx-no-new-array-as-prop
    <CallButtonWrapper style={[hasShadow && hardShadow]} size={size}>
      <ButtonContainer onPress={onPress} size={size}>
        <Button size={size} style={buttonStyle}>
          <Ionicons name="call" size={size * 0.5} color="white" />
        </Button>
      </ButtonContainer>
    </CallButtonWrapper>
  )
}

export const CallButton = React.memo(CallButtonComponent)
