import React from "react"
import { Svg, Path, G } from "react-native-svg"
import { SvgProps } from "../../svg/types"

export const FacebookIcon: React.FC<SvgProps> = ({ height = 24 }) => {
  return (
    <Svg
      fillRule="evenodd"
      clipRule="evenodd"
      viewBox="0 0 509 509"
      width={height}
      height={height}
    >
      <G fillRule="nonzero">
        <Path
          fill="#0866FF"
          d="M509 254.5C509 113.94 395.06 0 254.5 0S0 113.94 0 254.5C0 373.86 82.17 474 193.02 501.51V332.27h-52.48V254.5h52.48v-33.51c0-86.63 39.2-126.78 124.24-126.78 16.13 0 43.95 3.17 55.33 6.33v70.5c-6.01-.63-16.44-.95-29.4-.95-41.73 0-57.86 15.81-57.86 56.91v27.5h83.13l-14.28 77.77h-68.85v174.87C411.35 491.92 509 384.62 509 254.5z"
        />
        <Path
          fill="#fff"
          d="M354.18 332.27l14.28-77.77h-83.13V227c0-41.1 16.13-56.91 57.86-56.91 12.96 0 23.39.32 29.4.95v-70.5c-11.38-3.16-39.2-6.33-55.33-6.33-85.04 0-124.24 40.16-124.24 126.78v33.51h-52.48v77.77h52.48v169.24c19.69 4.88 40.28 7.49 61.48 7.49 10.44 0 20.72-.64 30.83-1.86V332.27h68.85z"
        />
      </G>
    </Svg>
  )
}
