/* eslint-disable complexity */
import { Dimensions, TouchableOpacity } from "react-native"
import styled from "styled-components/native"
import Ionicons from "react-native-vector-icons/Ionicons"

import { CenteredText, color, font, Props } from "convose-styles"
import FastImage from "react-native-fast-image"
import Animated from "react-native-reanimated"

// Audio
export const AudioMessageTimer = styled(CenteredText)`
  font-family: ${font.normal};
  color: ${(props: Props & { myMessage: boolean }) =>
    props.myMessage ? color.white : props.theme.message.audioMessageDuration};
  font-size: 13px;
  margin-left: 10px;
  width: 35px;
  text-align: center;
`

export const AudioMessageWrapper = styled(TouchableOpacity)`
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  padding: 0 15px;
  width: 100%;
  height: 40px;
`
export const ButtonContainer = styled.View`
  margin-right: 10px;
  width: 25px;
`
export const AudioIconsWrapper = styled(TouchableOpacity)`
  margin-left: -5px;
`

///
export const StyledIcon = styled(Ionicons)`
  color: ${(props: Props & { isText: boolean }) =>
    props.isText
      ? props.theme.message.replyText
      : props.theme.message.replyDetails};
`
const translateY = 25
export const ReplyWrapper = styled.View`
  justify-content: center;
  align-items: ${(props: { myMessage: boolean }) =>
    props.myMessage ? "flex-end" : "flex-start"};
  margin-top: ${(props: { myMessage: boolean; sameSender: boolean }) => {
    if (!props.myMessage) {
      if (props.sameSender) {
        return -translateY
      }
      return -(translateY + 20)
    }
    return -(translateY - 10)
  }}px;
  margin-left: 35px;
`
export const RepliedUserDetailsContainer = styled.View`
  flex-direction: row;
  justify-content: flex-end;
  align-items: center;
  transform: translateY(${translateY + 4}px);
  margin-bottom: 5px;
  padding-right: 9px;
`
export const RepliedUserDetailsText = styled(CenteredText)`
  color: ${(props: Props & { textColor?: string }) =>
    props.textColor || props.theme.message.replyDetails};
  font-family: ${font.normal};
  font-size: 12px;
  text-transform: capitalize;
`
export const RepliedMessageContainer = styled.View`
  background-color: ${(props: Props) => props.theme.message.replyBubble};
  padding: 9px;
  justify-content: center;
  align-items: flex-end;
  border-radius: 20px;
  padding-bottom: 30px;
  transform: translateY(${translateY}px);
  max-width: 70%;
  opacity: ${(props: { publishing: boolean }) => (props.publishing ? 0.3 : 1)};
`
export const RepliedMessageText = styled(CenteredText)`
  color: ${(props: Props) => props.theme.message.replyText};
  font-family: ${(props: { isAttachment: boolean }) =>
    props.isAttachment ? font.italic : font.normal};
  font-size: 14px;
`

export const ReplyImageContainer = styled.View`
  transform: translateY(${translateY}px);
  border-radius: 15px;
  overflow: hidden;
  opacity: ${(props: { publishing: boolean }) =>
    props.publishing ? 0.3 : 0.6};
`

export const ReplyImage = styled(FastImage)`
  width: ${(props: { ratio: number; width: number }) => props.width}px;
  aspect-ratio: ${(props: { ratio: number; width: number }) => props.ratio};
`

export const AttachmentContainer = styled.View`
  flex-direction: row;
`
export const SliderContainer = styled.View`
  flex: 1;
`
const AnimatedTouchableOpacity =
  Animated.createAnimatedComponent(TouchableOpacity)
const windowWidth = Dimensions.get("window").width

export const VideoMessageContainer = styled(AnimatedTouchableOpacity)`
  width: ${windowWidth * 0.65}px;
  height: ${windowWidth * 0.5}px;
  justify-content: center;
  align-items: center;
`
export const VideoMessageInnerWrapper = styled.View`
  width: 100%;
  height: 100%;
  justify-content: center;
  align-items: center;
`
export const PlayIconContainer = styled.View`
  position: absolute;
  align-self: center;
`
export const PlayIconBackground = styled.View`
  height: 70px;
  aspect-ratio: 1;
  position: absolute;
  background-color: black;
  opacity: 0.7;
  border-radius: 15px;
`
