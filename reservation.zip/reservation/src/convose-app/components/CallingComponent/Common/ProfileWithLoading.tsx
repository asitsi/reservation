import React from "react"
import { FastImageProps } from "react-native-fast-image"
import { AVATAR_SIZE, StyledImage } from "./Styled"
import { Skeleton } from "../../Skeleton"

type Props = FastImageProps & {
  isLoading?: boolean
}

export const ProfileComponent: React.FC<Props> = (props) => {
  const { isLoading } = props
  if (isLoading) {
    return (
      <Skeleton
        // eslint-disable-next-line react-perf/jsx-no-new-object-as-prop
        style={{
          width: AVATAR_SIZE,
          aspectRatio: 1,
          borderRadius: AVATAR_SIZE,
        }}
      />
    )
  }
  // eslint-disable-next-line react/jsx-props-no-spreading
  return <StyledImage {...props} />
}

export const Profile = React.memo(ProfileComponent)
