import styled from "styled-components/native"

export const BlackScreen = styled.View`
  background-color: black;
  width: 100%;
  height: 100%;
  position: absolute;
  z-index: ${Number.MAX_SAFE_INTEGER};
  elevation: ${Number.MAX_SAFE_INTEGER};
`
