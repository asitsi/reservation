import React from "react"

import { Container } from "./Styled"
import { BlueMaterialIndicator } from "../MaterialIndicator"

type ConvoseLoadingProps = {
  isShowing: boolean
  noDarkBackground?: boolean
}
const ConvoseLoadingComponent: React.FunctionComponent<ConvoseLoadingProps> = ({
  isShowing,
  noDarkBackground,
}) => {
  if (!isShowing) {
    return null
  }
  return (
    <Container noDarkBackground={noDarkBackground}>
      <BlueMaterialIndicator />
    </Container>
  )
}
// ConvoseLoadingComponent.whyDidYouRender = {
//   logOnDifferentValues: false,
//   customName: "ConvoseLoadingComponent",
//   diffNameColor: "red",
// }

export const ConvoseLoading = React.memo(ConvoseLoadingComponent)
export const BlueLoading = BlueMaterialIndicator
