import { CenteredText, font } from "convose-styles"
import styled from "styled-components/native"

// import { Props } from "convose-styles"

export const FooterContainer = styled.View`
  margin-top: 10px;
`

export const GroupNameContainer = styled.View`
  width: 100%;
  margin-bottom: 10px;
`
export const InviteToGroupContainer = styled.View``
export const InviteToGroupIconContainer = styled.View`
  position: absolute;
  right: 10px;
`
export const IconButtonContainer = styled.View`
  opacity: ${(props: { pressed: boolean }) => (props.pressed ? 0.4 : 1)};
`
export const InviteToGroupTitle = styled(CenteredText)`
  font-family: ${font.semiBold};
  font-size: 22px;
  line-height: 32px;
  text-align: center;
`
