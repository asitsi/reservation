import React, { useCallback, useEffect, useState } from "react"
import { TextStyle } from "react-native"
import { useTheme } from "styled-components"
import { setAdjustNothing, setAdjustResize } from "rn-android-keyboard-adjust"

import { GROUP_NAME_MAX_LENGTH } from "convose-styles"
import { GroupNameContainer } from "./Styled"
import { UsernameInput } from "../inputs"

const style: TextStyle = {
  fontSize: 18,
  // width: "100%",
  lineHeight: 25,
}
export const DEFAULT_GROUP_NAME = "New Group"
export const PLACEHOLDER = "New Group Name"
type Props = {
  setName: (name: string) => void
}
const GroupNameComponent: React.FC<Props> = ({ setName }) => {
  const theme = useTheme()
  const [groupName, setGroupName] = useState("")
  useEffect(() => {
    setAdjustNothing()
    return () => {
      setAdjustResize()
    }
  }, [])

  const onSubmit = useCallback(() => {
    setName(groupName || DEFAULT_GROUP_NAME)
    if (!groupName) {
      setGroupName(DEFAULT_GROUP_NAME)
    }
  }, [groupName, setName])
  const onChangeText = useCallback((text: string) => {
    setGroupName(text)
  }, [])
  return (
    <GroupNameContainer>
      <UsernameInput
        value={groupName}
        onChangeText={onChangeText}
        onBlur={onSubmit}
        onSubmitEditing={onSubmit}
        color={theme.main.text}
        placeholder={PLACEHOLDER}
        onBlurMessage="Name saved!"
        maxLength={GROUP_NAME_MAX_LENGTH}
        numberOfLines={1}
        multiline={false}
        allowFontScaling
        maxFontSizeMultiplier={1}
        // eslint-disable-next-line react-perf/jsx-no-new-array-as-prop
        style={[
          style,
          {
            minWidth: !groupName ? 170 : undefined,
          },
        ]}
        textAlign="center"
        placeholderTextColor={theme.interests.input.placeholder}
      />
    </GroupNameContainer>
  )
}

export const GroupName = GroupNameComponent
