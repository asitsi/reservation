import React, { useEffect } from "react"
import { Svg, Path } from "react-native-svg"
import Animated, {
  interpolateColor,
  useAnimatedProps,
  useSharedValue,
  withTiming,
} from "react-native-reanimated"

const AnimatedPath = Animated.createAnimatedComponent(Path)

type Props = {
  isActive: boolean
  activeColor: string
  inActiveColor: string
  height?: number
}
const AnimatedPhoneSvgComponent: React.FunctionComponent<Props> = ({
  height = 26,
  activeColor,
  inActiveColor,
  isActive,
}) => {
  const fillValue = useSharedValue(Number(isActive))
  const animatedProps = useAnimatedProps(() => {
    const fillColor = interpolateColor(
      fillValue.value,
      [0, 1],
      [inActiveColor, activeColor]
    )
    return {
      fill: fillColor,
    }
  }, [])
  useEffect(() => {
    fillValue.value = withTiming(Number(isActive), { duration: 300 })
  }, [fillValue, isActive])
  return (
    <Svg width={height} height={height} viewBox="0 0 26 26" fill="none">
      <AnimatedPath
        d="M1.77294 2.50349C3.00442 1.30972 4.79924 0.627557 6.68236 0.602006C7.59924 0.588589 8.4814 0.948069 9.12635 1.59525L11.3546 3.8329C12.1488 4.63069 12.6033 5.70362 12.6235 6.82841C12.6437 7.95319 12.228 9.04319 11.4629 9.87155L10.3507 11.0769C9.89001 11.5744 9.82968 12.164 10.07 12.5539C10.9293 13.9488 12.3835 15.3621 13.796 16.2185C14.2168 16.4751 14.8417 16.395 15.3398 15.8947L15.9653 15.2662C16.3758 14.8542 16.8643 14.5276 17.4024 14.3056C17.9405 14.0835 18.5173 13.9704 19.0993 13.9729C19.6813 13.9753 20.2568 14.0933 20.7922 14.3199C21.3276 14.5464 21.8122 14.8771 22.2177 15.2926L24.2292 17.3512C24.8869 18.0257 25.2128 18.9535 25.1255 19.8904C24.9493 21.752 24.1027 23.4417 22.7959 24.5235C21.4681 25.6218 19.6897 26.0662 17.8019 25.4291C14.8133 24.4222 10.9967 22.4027 6.96201 18.4117C2.87459 14.3661 1.07754 10.4737 0.344209 7.4097C-0.125132 5.44925 0.519644 3.71756 1.77294 2.50349Z"
        animatedProps={animatedProps}
      />
    </Svg>
  )
}

export const AnimatedPhoneSvg = React.memo(AnimatedPhoneSvgComponent)
