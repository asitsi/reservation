import React, { PropsWithChildren, memo, useCallback } from "react"
import { Dimensions } from "react-native"
import {
  Gesture,
  GestureDetector,
  GestureType,
} from "react-native-gesture-handler"
import {
  SharedValue,
  runOnJS,
  useSharedValue,
  withDecay,
  withDelay,
  withTiming,
} from "react-native-reanimated"
import { useDispatch, useSelector } from "react-redux"

import { CallingAction } from "convose-lib/calling"
import { LoginType, selectIsGuest } from "convose-lib/user"
import { useKeyboard } from "convose-lib/utils/useKeyboard"
import { selectScreenOrientation } from "convose-lib/app"
import { logEvent } from "convose-lib/services/analytics/amplitude"

import { convoseAlertRef } from "../../RootConvoseAlert"
import { AuthButtonList } from "../AuthButtonList"
import { ContentIcon } from "../../screens/chat/Icons/ContentIcon"

const hideConvoseAlert = (callback?: () => void) => {
  convoseAlertRef?.setState({
    isVisible: false,
  })
  callback && callback()
}
const SingInAlert = () => {
  convoseAlertRef?.show({
    canDismiss: true,
    icon: <ContentIcon />,
    title: "Signin to skip to new calls",
    description: (
      <AuthButtonList
        loginOrSignUp={LoginType.SignUp}
        onAuthCompleted={hideConvoseAlert}
        onHideComponent={hideConvoseAlert}
      />
    ),
    buttons: null,
  })
}

export const START_NEW_CALL_OFFSET = 100
export const ACTIVE_Y_OFFSET = 5
export const FAIL_X_OFFSET = 5
const VELOCITY_SLIDE_DOWN_LIMIT = 1200

type Props = {
  isInCallingChat: boolean
  contentOffsetY: SharedValue<number>
  endCall: ({ displayText }: { displayText: boolean }) => void
  panGestureRef: React.MutableRefObject<GestureType>
  setBounces: (enabled: boolean) => void
  setChatTranslateYOffset: (value: number) => void
  hideSwipeCallOnboarding: () => void
  setStopScroll: (enabled: boolean) => void
}
const SCROLL_Y_OFFSET = 10
const SwipeToNextCallComponent: React.FC<PropsWithChildren<Props>> = ({
  isInCallingChat,
  contentOffsetY,
  endCall,
  children,
  panGestureRef,
  setBounces,
  setChatTranslateYOffset,
  hideSwipeCallOnboarding,
  setStopScroll,
}) => {
  const dimension = Dimensions.get("screen")
  const dispatch = useDispatch()
  const [keyboardHeight] = useKeyboard()
  const isGuest = useSelector(selectIsGuest)
  const orientation = useSelector(selectScreenOrientation)
  const startQuickCall = useCallback(() => {
    dispatch(CallingAction.startQuickCall())
  }, [dispatch])

  const featureBlocked = useSharedValue(false)
  const touchStart = useSharedValue(0)

  const gesture = Gesture.Pan()
    .activeOffsetY([-ACTIVE_Y_OFFSET, ACTIVE_Y_OFFSET])
    .failOffsetX([-FAIL_X_OFFSET, FAIL_X_OFFSET])
    .onTouchesDown((event) => {
      touchStart.value = event.allTouches[0].absoluteY
    })
    .onTouchesMove((event, state) => {
      if (
        !isInCallingChat ||
        keyboardHeight > 0 ||
        contentOffsetY.value > SCROLL_Y_OFFSET ||
        touchStart.value < event.allTouches[0].absoluteY ||
        orientation !== "PORTRAIT"
      ) {
        state.fail()
        return
      }
      if (
        isGuest &&
        Math.floor(touchStart.value - event.allTouches[0].absoluteY) >
          START_NEW_CALL_OFFSET - 20
      ) {
        state.fail()
        runOnJS(SingInAlert)()
        featureBlocked.value = true
        return
      }
      if (contentOffsetY.value <= 0) {
        setBounces(false)
      }
      setStopScroll(true)
      state.activate()
    })
    .onUpdate(({ translationY }) => {
      setChatTranslateYOffset(translationY)
    })
    .onEnd((event) => {
      setStopScroll(false)
      if (event.velocityY > VELOCITY_SLIDE_DOWN_LIMIT) {
        setChatTranslateYOffset(
          withDecay({
            velocity: -event.velocityY,
            clamp: [0, -dimension.height],
          })
        )
        return
      }
      if (Math.abs(event.translationY) > START_NEW_CALL_OFFSET && !isGuest) {
        !__DEV__ && runOnJS(logEvent)("swipe_to_skip_call")
        runOnJS(endCall)({ displayText: true })
        runOnJS(startQuickCall)()
        runOnJS(hideSwipeCallOnboarding)()
        setChatTranslateYOffset(
          withTiming(-dimension.height, { duration: 100 })
        )
      } else if (featureBlocked.value) {
        setChatTranslateYOffset(
          withDelay(1000, withTiming(0, { duration: 300 }))
        )
        featureBlocked.value = false
      } else {
        setChatTranslateYOffset(withTiming(0, { duration: 100 }))
      }
      touchStart.value = 0
      setBounces(true)
    })
    .withRef(panGestureRef)
  return <GestureDetector gesture={gesture}>{children}</GestureDetector>
}

export const SwipeToNextCall = memo(SwipeToNextCallComponent)
