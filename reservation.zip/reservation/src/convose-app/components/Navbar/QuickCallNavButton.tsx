import React, { useEffect } from "react"
import { useDispatch, useSelector } from "react-redux"
import Animated, {
  interpolate,
  interpolateColor,
  useAnimatedStyle,
  useSharedValue,
  withTiming,
} from "react-native-reanimated"

import { CallingAction, selectIsSeekingQuickCall } from "convose-lib/calling"
import { LoginType, selectIsGuest } from "convose-lib/user"
import { useIsInCall } from "convose-lib/calling/hooks"
import { useMainBlue } from "convose-lib/utils/useMainBlue"
import { color } from "convose-styles"
import { Pressable } from "react-native"
import { convoseAlertRef } from "../../RootConvoseAlert"
import {
  NavActionTitleNoColor,
  QuickCallNavContainer,
  StyledAnimatedIonicons,
} from "./Styled"
import { AuthButtonList } from "../AuthButtonList"

type Props = {
  onPress?: () => void
}
const QuickCallNavButtonComponent: React.FC<Props> = ({ onPress }) => {
  const mainBlue = useMainBlue()
  const dispatch = useDispatch()
  const isSeekingQuickCall = useSelector(selectIsSeekingQuickCall)
  const isGuest = useSelector(selectIsGuest)
  const isInCall = useIsInCall()

  const isSeekingOffset = useSharedValue(Number(isSeekingQuickCall))

  const titleStyle = useAnimatedStyle(() => ({
    color: interpolateColor(
      isSeekingOffset.value,
      [0, 1],
      [mainBlue, color.red]
    ),
  }))
  const containerStyle = useAnimatedStyle(() => ({
    transform: [
      { rotate: `${interpolate(isSeekingOffset.value, [0, 1], [0, 135])}deg` },
    ],
  }))
  const iconStyle = useAnimatedStyle(() => ({
    color: interpolateColor(
      isSeekingOffset.value,
      [0, 1],
      [mainBlue, color.red]
    ),
  }))

  useEffect(() => {
    isSeekingOffset.value = withTiming(Number(isSeekingQuickCall), {
      duration: 300,
    })
  }, [isSeekingOffset, isSeekingQuickCall])

  const cancelQuickCall = React.useCallback(() => {
    dispatch(CallingAction.cancelQuickCall())
  }, [dispatch])
  const startQuickCall = React.useCallback(() => {
    dispatch(CallingAction.startQuickCall())
  }, [dispatch])

  const hideConvoseAlert = (callback?: () => void) => {
    convoseAlertRef?.setState({
      isVisible: false,
    })
    callback && callback()
  }
  const onCallPress = () => {
    requestAnimationFrame(() => {
      onPress && onPress()
      if (isInCall) {
        convoseAlertRef?.show({
          ioniconName: "call",
          title: "You are in a call",
          description: "You cannot start a quick call while you are in a call",
        })
        return
      }
      if (isGuest) {
        convoseAlertRef?.show({
          ioniconName: "log-in",
          title: "Sign in to be able to start a quick call",
          description: (
            <AuthButtonList
              loginOrSignUp={LoginType.SignUp}
              onAuthCompleted={hideConvoseAlert}
              onHideComponent={hideConvoseAlert}
            />
          ),
          buttons: null,
        })
        return
      }
      if (isSeekingQuickCall) {
        cancelQuickCall()
      } else {
        startQuickCall()
      }
    })
  }
  return (
    <Pressable onPress={onCallPress}>
      {({ pressed }) => (
        <QuickCallNavContainer pressed={pressed}>
          <Animated.View style={containerStyle}>
            <StyledAnimatedIonicons name="call" size={27} style={iconStyle} />
          </Animated.View>
          <NavActionTitleNoColor style={titleStyle}>
            {isSeekingQuickCall ? "End call" : "New group call"}
          </NavActionTitleNoColor>
        </QuickCallNavContainer>
      )}
    </Pressable>
  )
}

export const QuickCallNavButton = React.memo(QuickCallNavButtonComponent)
