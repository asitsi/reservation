import React, { useEffect, useState } from "react"
import { Image } from "react-native"
import { SlideInLeft, SlideOutRight } from "react-native-reanimated"
import { useSelector } from "react-redux"
import axios from "axios"

import { selectToken } from "convose-lib/user"
import { EmptyImage, StyledImage } from "./Styled"

const duration = 1500

type AvatarType = {
  avatar: string
}
const Avatar: React.FC<AvatarType> = ({ avatar }) => {
  if (!avatar) {
    return <EmptyImage />
  }
  return (
    <StyledImage
      entering={SlideInLeft.duration(200)}
      exiting={SlideOutRight.duration(200)}
      // eslint-disable-next-line react-perf/jsx-no-new-object-as-prop
      source={{ uri: avatar }}
    />
  )
}

const RandomAvatarComponent: React.FC = () => {
  const [allAvatars, setAllAvatars] = useState<string[]>()
  const [avatar, setAvatar] = useState<string>()
  const currentAvatarRef = React.useRef(1)
  const token = useSelector(selectToken)

  useEffect(() => {
    axios
      .get("https://api.convose.com/default_avatars", {
        headers: {
          Authorization: token,
        },
      })
      .then((res) => {
        const userAvatars = res.data.avatars as string[]
        setAllAvatars(userAvatars)
        setAvatar(userAvatars[0])
        Promise.all(userAvatars.map((image) => Image.prefetch(image)))
          .then()
          .catch()
      })
  }, [token])

  React.useEffect(() => {
    if (allAvatars?.length) {
      const interval = setInterval(() => {
        setAvatar(allAvatars[currentAvatarRef.current])
        if (currentAvatarRef.current >= allAvatars.length - 1) {
          currentAvatarRef.current = 0
        } else {
          currentAvatarRef.current += 1
        }
      }, duration)
      return () => clearInterval(interval)
    }
    return () => null
  }, [allAvatars])

  if (avatar) {
    return <Avatar key={avatar} avatar={avatar} />
  }
  return null
}

export const RandomAvatar = React.memo(RandomAvatarComponent)
