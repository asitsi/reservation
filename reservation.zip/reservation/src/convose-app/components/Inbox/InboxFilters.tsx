import React, { useCallback, useMemo } from "react"
import { useDispatch, useSelector } from "react-redux"

import {
  InboxOrderType,
  UsersListAction,
  selectInboxFilterBadgeNumber,
  selectInboxOrder,
} from "convose-lib/users-list"
import { FilterButtonItemType, FilterButtonSet } from "../FilterButtonSet"

type Props = {
  onFilterChanged?: () => void
}
const InboxFiltersComponent: React.FC<Props> = ({ onFilterChanged }) => {
  const dispatch = useDispatch()
  const inboxOrder = useSelector(selectInboxOrder)
  const inboxFilterBadgeNumber = useSelector(selectInboxFilterBadgeNumber)

  const setInboxOrder = useCallback(
    (newInboxOrder: InboxOrderType) => {
      onFilterChanged && onFilterChanged()
      dispatch(UsersListAction.setInboxOrder(newInboxOrder))
    },
    [dispatch, onFilterChanged]
  )

  // eslint-disable-next-line react-perf/jsx-no-new-array-as-prop
  const filterButtonItems: FilterButtonItemType[] = useMemo(
    () => [
      {
        id: "Newest",
        name: "Newest",
        isSelected: inboxOrder === "Newest",
        onPress: setInboxOrder,
        showBadgeNumber: true,
      },
      {
        id: "Unread msgs",
        name: "Unread",
        isSelected: inboxOrder === "Unread msgs",
        onPress: setInboxOrder,
        showBadgeNumber: true,
      },
      {
        id: "Groups",
        name: "Groups",
        isSelected: inboxOrder === "Groups",
        onPress: setInboxOrder,
      },
    ],
    [inboxOrder, setInboxOrder]
  )

  return (
    <FilterButtonSet
      items={filterButtonItems}
      badgeNumber={inboxFilterBadgeNumber}
    />
  )
}

export const InboxFilters = React.memo(InboxFiltersComponent)
