import { Image, View } from "react-native"
import styled from "styled-components/native"
import Ionicons from "react-native-vector-icons/Ionicons"
import Animated from "react-native-reanimated"

import { CenteredText, color, font, Props } from "convose-styles"
import { SearchInterests } from "../../components/SearchInterests"

export const InterestsWrapper = styled(View)`
  background: ${(props: Props) => props.theme.main.background};
  flex-direction: column;
  padding-left: 12px;
  padding-right: 12px;
`

export const InterestsLabel = styled(CenteredText)`
  font-family: ${font.light};
  font-size: 15px;
  color: ${(props: Props) => props.theme.main.text};
  margin-bottom: 10px;
`

export const InterestsListContainer = styled(Animated.View)`
  flex-direction: row;
  flex-wrap: wrap;
  justify-content: flex-start;
  align-items: flex-start;
  align-self: flex-start;
`

// NO INTEREST VIEW
export const NoInterestsView = styled(Animated.View)`
  flex-direction: column;
  justify-content: flex-start;
  align-items: center;
  align-self: center;
`

export const NoInterestsImage = styled(Image)`
  width: 236.91px;
  height: 259px;
  align-self: center;
  resize-mode: contain;
`

export const NoInterestText = styled(CenteredText)`
  font-family: ${font.normal};
  font-size: 12px;
  align-self: center;
  letter-spacing: 0.43px;
  text-align: center;
  color: ${color.myInterests.gray};
  margin: 0px 30px;
  margin-top: 5px;
`

// ADD INTEREST BUTTON
export const AddInterestButton = styled(SearchInterests)`
  margin: 6px;
  margin-top: ${(props: { length: boolean }) =>
    props.length ? "6px" : "20px"};
  align-self: center;
  z-index: -1;
`

export const ButtonLabel = styled(CenteredText)`
  font-family: ${font.light};
  font-size: 16px;
  text-align: center;
  color: ${color.white};
`
export const NoInterestsImageContainer = styled.View`
  width: 100%;
  justify-content: space-around;
  align-items: center;
  margin-top: 20px;
  padding: 0px 30px;
  flex-direction: row;
`
type IconContainerProps = Props & { stepUp: boolean }
export const IconContainer = styled(View)`
  ${(props: IconContainerProps) =>
    props.stepUp
      ? `margin-bottom: 50px;`
      : `
    `}
`
export const InterestContainer = styled(NoInterestsView)`
  width: 100%;
`
export const SavingContainer = styled.View`
  z-index: 2;
  align-self: center;
  justify-content: center;
  align-items: center;
  margin-vertical: 10px;
`
export const SavingText = styled(CenteredText)`
  font-family: ${font.semiBold};
  color: ${(props: Props) => props.theme.mainBlue};
`

export const SortingOnboardingContainer = styled(Animated.View)`
  position: absolute;
  top: 95px;
  z-index: 10;
`
export const SortingOnboardingBoxPointer = styled(Animated.View)`
  background-color: ${(props: Props) => props.theme.mainBlue};
  width: 20px;
  aspect-ratio: 1;
  position: absolute;
  transform: rotate(45deg);
  left: 35px;
  top: 5px;
  z-index: 1;
`
export const SortingOnboardingBox = styled(Animated.View)`
  background-color: ${(props: Props) => props.theme.mainBlue};
  padding: 20px;
  width: 240px;
  align-items: center;
  border-radius: 20px;
  margin-top: 15px;
`
export const SortingDescription = styled(CenteredText)`
  color: ${color.white};
  font-family: ${font.medium};
  text-align: center;
`
export const CloseAndShapesContainer = styled.View`
  width: 100%;
  min-height: 30px;
  margin-bottom: 10px;
`
export const StyledIcon = styled(Ionicons)`
  color: ${color.white};
  z-index: 10;
`
export const CloseButton = styled.TouchableOpacity`
  position: absolute;
  right: -7px;
  top: -7px;
  width: 30;
  aspect-ratio: 1;
  align-items: center;
  justify-content: center;
`
export const EmptyBoxContainer = styled.View`
  flex-direction: row;
  flex-wrap: wrap;
  margin-top: 5px;
`
export const EmptyBox = styled.View`
  background-color: ${(props: { color: string }) => props.color};
  border-width: 1px;
  border-color: black;
  height: 25px;
  border-radius: 15px;
  margin-right: 5px;
  margin-bottom: 5px;
  ${(props: { isLast: boolean }) =>
    props.isLast ? `transform: rotate(-10deg);` : ``}
`
