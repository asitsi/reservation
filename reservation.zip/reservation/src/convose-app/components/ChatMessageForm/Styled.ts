import {
  TouchableOpacity,
  View,
  Pressable,
  ViewStyle,
  TextInput,
  Platform,
} from "react-native"
import styled from "styled-components"
import Ionicons from "react-native-vector-icons/Ionicons"
import Animated from "react-native-reanimated"

import { CenteredText, Props, font, width } from "convose-styles"
// import { MentionInput } from "../../../../self-maintained-packages/react-native-controlled-mentions/src"

const isAndroid = Platform.OS === "android"

export const ICONS_SIZE = 20
const MARGIN_BETWEEN_ELEMENTS = 10
const ICON_WRAPPER_SIZE = 39
const MARGIN_SIZE = 8
export const InputStyle: ViewStyle = {
  flex: 1,
  alignSelf: "center",
  marginVertical: MARGIN_SIZE,
}
type InsetTypes = {
  insetBottom?: number
  showEmoticons?: boolean
  isInCallingChat?: boolean
}
type ChatInputWrapperProps = {
  insetLeft: number
  isLandscapeRight: boolean
  isLandscapeLeft: boolean
  fullWidthInput: boolean
}
export const ChatInputWrapper = styled(Animated.View)`
  ${(props: ChatInputWrapperProps) => {
    if (props.isLandscapeLeft || props.isLandscapeRight) {
      return props.fullWidthInput ? `width: 80%;` : `width: 25%;`
    }
    return ``
  }}
  margin-left: ${(props: ChatInputWrapperProps) => {
    if (props.isLandscapeLeft) {
      return props.insetLeft + 9
    }
    if (props.isLandscapeRight) {
      return 9
    }
    return 0
  }}px;
  background-color: ${(props: Props & { transparentBackground: boolean }) =>
    props.transparentBackground ? "transparent" : props.theme.main.background};
`

export const ChatInputBarView = styled(Animated.View)`
  align-content: center;
  background: ${(props: Props & { transparentBackground: boolean }) =>
    props.transparentBackground ? "transparent" : props.theme.statusBar};
  bottom: 0px;
  flex-direction: row;
  flex-wrap: nowrap;
  justify-content: center;
  position: relative;
  width: 100%;
  z-index: 1;
`

export const StyledInput = styled(TextInput)`
  flex: 1;
  font-size: 15px;
  min-height: ${ICON_WRAPPER_SIZE}px;
  padding: 4px 15px;
  padding-top: ${isAndroid ? 4 : 9}px;
  max-width: ${width}px;
  max-height: 150px;
  font-family: ${font.normal};
  include-font-padding: false;
  include-font-padding: false;
  text-align-vertical: center;
  color: ${(props: Props) => props.theme.textInput.color};
  background: ${(props: Props) => props.theme.textInput.background};
  overflow: hidden;
  flex-direction: row;
  border-radius: 30px;
  align-items: center;
  align-self: center;
  margin-vertical: ${MARGIN_SIZE}px;
`

export const IconButtonPressable = styled(Pressable)`
  justify-content: flex-end;
  align-items: center;
  padding-vertical: ${MARGIN_SIZE}px;
`

export const IconWrapper = styled(View)`
  justify-content: center;
  align-items: center;
  width: ${ICON_WRAPPER_SIZE}px;
  height: ${ICON_WRAPPER_SIZE}px;
  border-radius: ${ICON_WRAPPER_SIZE}px;
  margin-horizontal: 4px;
  background-color: ${(props: Props & { pressed: boolean }) =>
    props.pressed ? props.theme.buttonOnPress : "transparent"};
`

export const MarginRight = styled(View)`
  margin-right: ${MARGIN_BETWEEN_ELEMENTS}px;
`

export const Icon = styled(Ionicons)`
  color: ${(props: Props) =>
    props.color ? props.color : props.theme.mainBlue};
  font-size: ${(props: { shadow: boolean }) =>
    props.shadow ? ICONS_SIZE + 4 : ICONS_SIZE}px;
  align-self: center;
  ${(props: { shadow: boolean }) => props.shadow && `position: absolute;`}
`

export const TimerText = styled(TextInput)`
  min-width: 24px;
  font-size: 24px;
  color: ${(props: Props) => props.theme.main.text};
  font-family: ${font.light};
`

export const ExtraTimerText = styled(TextInput)`
  min-width: 15px;
  padding-top: 4px;
  font-size: 15px;
  color: ${(props: Props) => props.theme.main.text};
  font-family: ${font.light};
`

export const AudioFormWrapper = styled(Animated.View)`
  position: absolute;
  bottom: ${(props: { keyboardPadding: number }) =>
    props.keyboardPadding || 0}px;
  width: 100%;
  height: ${(props: InsetTypes) =>
    props.insetBottom ? props.insetBottom + 90 : 90}px;
  background-color: ${(props: Props) => props.theme.main.chatBox};
  flex-direction: row;
  align-items: center;
  justify-content: space-evenly;
  flex-wrap: nowrap;
  flex: 1;
  z-index: 100;
  padding-bottom: ${(props: InsetTypes) => props.insetBottom || 0}px;
`

export const CircleButton = styled(TouchableOpacity)`
  border-radius: 50px;
  height: 40px;
  width: 40px;
  padding: 5px;
  justify-content: center;
  align-items: center;
  text-align-vertical: bottom;
`
export const SquareButton = styled(TouchableOpacity)`
  border-radius: 50px;
  min-width: 100px;
  min-height: 60px;
  padding-vertical: 15px;
  padding-horizontal: 35px;
  justify-content: center;
  align-items: center;
  text-align-vertical: bottom;
`

export const RecordingIndicatorWrapper = styled(View)`
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  margin: 0px 5px;
  width: 70px;
`

export const SearcherWrapper = styled(View)`
  background: ${(props: Props) => props.theme.main.chatBox};
  margin-top: 5px;
  max-height: 200px;
  border-radius: 15px;
  bottom: 5px;
  padding: 5px;
  position: absolute;
  bottom: 40px;
`
export const SearchRow = styled(View)`
  flex-direction: row;
  margin: 10px;
`
export const SearchIcon = styled(View)`
  width: 30px;
`
export const SearchWord = styled(View)`
  align-items: center;
  justify-content: center;
  margin-left: 10px;
`

export const SearchText = styled(CenteredText)`
  color: ${(props: Props) =>
    props.color ? props.color : props.theme.main.text};
  font-size: 18px;
  font-family: ${font.semiBold};
`
export const LeftPanelContainer = styled(Animated.View)`
  flex-direction: row;
  align-items: flex-end;
  justify-content: center;
  margin-left: 5px;
`
export const LeftPanelFullPanelContainer = styled(Animated.View)`
  flex-direction: row;
`
export const RightPanelContainer = styled.View`
  /* margin-right: ${MARGIN_BETWEEN_ELEMENTS / 2}px;
  margin-left: ${MARGIN_BETWEEN_ELEMENTS / 2}px; */
  width: ${ICON_WRAPPER_SIZE + 15}px;
  justify-content: flex-end;
`
export const SendContainer = styled.View`
  position: absolute;
  right: 0px;
  left: 0px;
`
type ChosenImageType = {
  ratio: number
}
const chosenImageHeight = 200
export const ChosenImageContainer = styled.View`
  margin-bottom: 29px;
`

export const ChosenImage = styled.Image`
  height: ${chosenImageHeight}px;
  aspect-ratio: ${(props: ChosenImageType) => props.ratio};
  border-radius: 10px;
`
