import React, { FunctionComponent } from "react"
import { Alert, Share, ViewStyle } from "react-native"
import { connect } from "react-redux"
import { useNavigation } from "@react-navigation/native"
import { withSafeAreaInsets } from "react-native-safe-area-context"
import * as FileSystem from "expo-file-system"

import { Routes } from "convose-lib/router"
import { State } from "convose-lib/store"
import { selectUnreadCountFeature } from "convose-lib/users-list"
import { OnboardingAction, selectAddInterestExplainer } from "convose-lib"
import { selectIsGuest } from "convose-lib/user"
import { SafeAreaProps } from "convose-lib/generalTypes"
import { useMainBlue } from "convose-lib/utils/useMainBlue"
import InboxIcon from "../../../assets/Icons/components/InboxIcon"
import {
  NavActionContainer,
  NavActionTitle,
  NavbarView,
  PLUS_INTERESTS_TRANSFORM,
  SearchInterestsButton,
  Styles,
} from "./Styled"
import { Explainer } from "../../components/Explainer"
import { IconBadge } from "../../components/IconBadge"
import ProfileIcon from "../../../assets/Icons/components/ProfileIcon"
import { ExplainerIcons } from "./ExplainerIcons"
import { GradientEffect } from "./GradientEffect"
import { NavButton } from "./NavButton"
import { enableAgoraLog } from "../../../../settings"
import { QuickCallNavButton } from "./QuickCallNavButton"

type DispatchToProps = {
  readonly hideAddInterestExplainer: () => void
}
type NavbarProps = {
  readonly unreadMessagesCount: number
  readonly showingAddInterestExplainer: boolean
  readonly isGuest: boolean
}
type AllProps = NavbarProps & DispatchToProps & SafeAreaProps
type Nav = {
  navigate: (value: string) => void
}

const wrapperStyle: ViewStyle = {
  paddingRight: "21%",
  paddingLeft: "21%",
}
const ICON_HEIGHT_BASE = 22

type ActionTitleProps = {
  isGuest: boolean
}
const ActionTitle: React.FC<React.PropsWithChildren<ActionTitleProps>> = ({
  isGuest,
  children,
}) => {
  if (!isGuest) {
    return null
  }
  return <NavActionTitle>{children}</NavActionTitle>
}
export const NavbarComponent: FunctionComponent<AllProps> = ({
  unreadMessagesCount,
  showingAddInterestExplainer,
  isGuest,
  hideAddInterestExplainer,
  insets,
}) => {
  const navigation = useNavigation<Nav>()
  const mainBlue = useMainBlue()
  const tryHideExplainer = (): void => {
    if (showingAddInterestExplainer) {
      hideAddInterestExplainer()
    }
  }
  const navigateToProfile = () => {
    requestAnimationFrame(() => {
      tryHideExplainer()
      navigation.navigate(Routes.Profile)
    })
  }
  const navigateToInbox = () => {
    requestAnimationFrame(() => {
      tryHideExplainer()
      navigation.navigate(Routes.Inbox)
    })
  }

  const getIconSize = React.useCallback(() => {
    if (isGuest) {
      return ICON_HEIGHT_BASE
    }
    return ICON_HEIGHT_BASE + 2
  }, [isGuest])

  const insetsBottom = insets?.bottom || 0
  const onAddInterestsPress = async () => {
    if (!enableAgoraLog) {
      return
    }
    const logDir = `${FileSystem.cacheDirectory}`
    const regex = /agorasdk/i
    const res = await FileSystem.readDirectoryAsync(logDir)
    const agoraFiles = res.filter((file) => regex.test(file))
    if (agoraFiles.length) {
      Alert.alert(
        "Select file",
        undefined,
        [
          {
            text: "Cancel",
            style: "cancel",
          },
          ...agoraFiles.map((file) => ({
            text: file,
            onPress: () =>
              Share.share({ url: logDir + file, message: "agora" })
                .then()
                .catch(),
          })),
          {
            text: "Delete all",
            style: "destructive",
            onPress: () => {
              const deletes = agoraFiles.map((fileName) => {
                const url = logDir + fileName
                return FileSystem.deleteAsync(url)
              })
              Promise.all(deletes).then().catch()
            },
          },
        ],
        { cancelable: true }
      )
    } else {
      Alert.alert("No sdk log found", undefined)
    }
  }

  return (
    <>
      <Explainer
        explanation="Add languages, locations, skills, hobbies, etc here to find interesting people."
        isShowing={showingAddInterestExplainer}
        iconComponent={<ExplainerIcons />}
        bottomPosition={PLUS_INTERESTS_TRANSFORM + 50 + insetsBottom}
        onClosePress={tryHideExplainer}
        wrapperStyle={wrapperStyle}
      />
      <GradientEffect bottomInset={insetsBottom} pointerEvents="none" />
      <NavbarView bottomInset={insetsBottom} pointerEvents="box-none">
        <SearchInterestsButton
          bottomInset={insetsBottom}
          style={Styles.searchInterestShadow}
          onLongPress={onAddInterestsPress}
          delayLongPress={5000}
        />
        <NavButton onPress={navigateToProfile}>
          <NavActionContainer>
            <ProfileIcon height={getIconSize()} color={mainBlue} />
            <ActionTitle isGuest={isGuest}>
              {isGuest ? "Sign in" : "Profile"}
            </ActionTitle>
          </NavActionContainer>
        </NavButton>
        <QuickCallNavButton onPress={tryHideExplainer} />
        {unreadMessagesCount > 0 ? (
          <NavButton onPress={navigateToInbox}>
            <NavActionContainer>
              <IconBadge height={17} width={17} withBorder>
                <InboxIcon height={getIconSize()} color={mainBlue} />
              </IconBadge>
              <ActionTitle isGuest={isGuest}>Inbox</ActionTitle>
            </NavActionContainer>
          </NavButton>
        ) : (
          <NavButton onPress={navigateToInbox}>
            <NavActionContainer>
              <InboxIcon height={getIconSize()} color={mainBlue} />
              <ActionTitle isGuest={isGuest}>Inbox</ActionTitle>
            </NavActionContainer>
          </NavButton>
        )}
      </NavbarView>
    </>
  )
}

const mapStateToProps = (state: State) => ({
  unreadMessagesCount: selectUnreadCountFeature(state),
  // showPopup: selectShowPopup(state),
  showingAddInterestExplainer: selectAddInterestExplainer(state),
  isGuest: selectIsGuest(state),
})

export const Navbar = connect(mapStateToProps, {
  hideAddInterestExplainer: OnboardingAction.hideAddInterestExplainer,
})(withSafeAreaInsets(NavbarComponent))
