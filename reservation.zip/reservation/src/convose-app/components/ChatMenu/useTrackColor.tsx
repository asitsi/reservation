import React from "react"
import { useSelector } from "react-redux"

import { selectIsDarkMode } from "convose-lib/app"

import { trackColorDark, trackColorLight } from "./Styled"

export const useTrackColor = () => {
  const isDarkMode = useSelector(selectIsDarkMode)
  const [trackColor, setTrackColor] = React.useState(
    isDarkMode ? trackColorDark : trackColorLight
  )
  React.useEffect(() => {
    if (isDarkMode) {
      setTrackColor(trackColorDark)
    } else {
      setTrackColor(trackColorLight)
    }
  }, [isDarkMode])
  return trackColor
}
