import React from "react"
import { Svg, Path } from "react-native-svg"
import { SvgProps } from "./types"
import { getRatio, getWidth } from "./utils"

const defaultHeight = 33
const defaultWidth = 26
const ratio = getRatio(defaultHeight, defaultWidth)

export const LocationSvg: React.FunctionComponent<SvgProps> = ({
  color,
  height,
}) => {
  const svgHeight = height || defaultHeight
  const svgWidth = height ? getWidth(ratio, height) : defaultWidth
  return (
    <Svg width={svgWidth} height={svgHeight} viewBox="0 0 26 33" fill="none">
      <Path
        d="M13 1C9.81856 1.00369 6.76849 2.24658 4.51887 4.45603C2.26925 6.66548 1.00377 9.66108 1.00001 12.7857C0.996202 15.3392 1.84545 17.8233 3.41746 19.8571C3.41746 19.8571 3.74474 20.2804 3.79819 20.3414L13 31L22.2062 20.3361C22.2542 20.2793 22.5825 19.8571 22.5825 19.8571L22.5836 19.8539C24.1549 17.821 25.0037 15.338 25 12.7857C24.9962 9.66108 23.7307 6.66548 21.4811 4.45603C19.2315 2.24658 16.1814 1.00369 13 1ZM13 17.0714C12.137 17.0714 11.2933 16.8201 10.5757 16.3492C9.8581 15.8782 9.2988 15.2089 8.96853 14.4258C8.63826 13.6427 8.55184 12.781 8.72021 11.9496C8.88859 11.1183 9.30418 10.3546 9.91445 9.75526C10.5247 9.15589 11.3022 8.74771 12.1487 8.58235C12.9952 8.41698 13.8725 8.50185 14.6699 8.82623C15.4672 9.15061 16.1487 9.69992 16.6282 10.4047C17.1077 11.1095 17.3636 11.9381 17.3636 12.7857C17.3622 13.9219 16.902 15.0112 16.084 15.8146C15.2659 16.618 14.1569 17.07 13 17.0714Z"
        fill={color || "#FF7979"}
        stroke="black"
        strokeWidth="1.5"
      />
    </Svg>
  )
}
