import React from "react"
import { Svg, Path } from "react-native-svg"
import { SvgProps } from "../../svg/types"
import { getRatio, getWidth } from "../../svg/utils"

const defaultHeight = 17
const defaultWidth = 14
const ratio = getRatio(defaultHeight, defaultWidth)

const SimpleEditIcon: React.FC<SvgProps> = ({ color, height = 24 }) => {
  const svgHeight = height || defaultHeight
  const svgWidth = height ? getWidth(ratio, height) : defaultWidth
  return (
    <Svg width={svgWidth} height={svgHeight} viewBox="0 0 14 17" fill="none">
      <Path
        d="M0.115558 12.7385C0.0300373 12.2153 0.155809 11.6794 0.465226 11.2488L7.38156 1.62411C8.02614 0.727122 9.27583 0.522501 10.1728 1.16708L12.3957 2.76446C13.2927 3.40904 13.4973 4.65873 12.8528 5.55572L5.93121 15.1877C5.62488 15.614 5.16324 15.9028 4.64589 15.9917L1.75018 16.4894C1.20271 16.5836 0.683458 16.2134 0.593861 15.6652L0.115558 12.7385Z"
        fill={color || "white"}
      />
    </Svg>
  )
}

export default SimpleEditIcon
