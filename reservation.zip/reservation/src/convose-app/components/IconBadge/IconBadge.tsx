/* eslint-disable react-perf/jsx-no-new-object-as-prop */
import * as React from "react"
import { View } from "react-native"
import { isNumber } from "lodash"

import { StyledBadge } from "./Styled"
import { Badge } from "./Badge"

type IconBadgeProps = {
  readonly fontSize?: number
  readonly height?: number
  readonly inboxIndicator?: boolean
  readonly text?: string
  readonly width?: number
  readonly withBorder?: boolean
  useMainBlue?: boolean
}

function getTextToRender(num: number): string {
  if (num > 9) {
    return "9+"
  }
  return `${num}`
}

export const IconBadge: React.FC<React.PropsWithChildren<IconBadgeProps>> = ({
  children,
  fontSize = 9,
  height = 15,
  inboxIndicator = true,
  text = "",
  width = 15,
  withBorder = false,
  useMainBlue,
}) => {
  const isTextNumber = text && isNumber(Number(text))
  const textToRender = !isTextNumber ? text : getTextToRender(Number(text))
  return (
    <View>
      {children}
      <Badge
        height={height}
        width={width}
        inboxIndicator={inboxIndicator}
        withBorder={withBorder}
        useMainBlue={useMainBlue}
      >
        <StyledBadge style={{ fontSize }}>{textToRender}</StyledBadge>
      </Badge>
    </View>
  )
}
