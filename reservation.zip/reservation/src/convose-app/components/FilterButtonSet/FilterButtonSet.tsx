/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { useMemo } from "react"
import { ViewStyle } from "react-native"
import { ZoomIn, ZoomOut } from "react-native-reanimated"

import {
  BadgeContainer,
  BadgeNumber,
  FilterButton,
  FilterButtonSetContainer,
  FilterButtonText,
} from "./Styles"

export type FilterButtonItemType = {
  id: any
  name: string
  isSelected: boolean
  onPress: (id: any) => void
  showBadgeNumber?: boolean
}

type Props = {
  items: Array<FilterButtonItemType>
  style?: ViewStyle
  badgeNumber?: number
}

const FilterButtonSetComponent: React.FC<Props> = ({
  items,
  style,
  badgeNumber,
}) => {
  const badgeNumberToShow = useMemo(
    () => (badgeNumber && badgeNumber > 9 ? "+9" : badgeNumber),
    [badgeNumber]
  )
  return (
    <FilterButtonSetContainer style={style}>
      {items.map((item) => (
        <FilterButton
          key={item.id}
          selected={item.isSelected}
          onPress={() => item.onPress(item.id)}
        >
          <FilterButtonText selected={item.isSelected}>
            {item.name}
          </FilterButtonText>
          {!!badgeNumberToShow && item.showBadgeNumber && (
            <BadgeContainer
              entering={ZoomIn.duration(150)}
              exiting={ZoomOut.duration(150)}
            >
              <BadgeNumber>{badgeNumberToShow}</BadgeNumber>
            </BadgeContainer>
          )}
        </FilterButton>
      ))}
    </FilterButtonSetContainer>
  )
}

export const FilterButtonSet = React.memo(FilterButtonSetComponent)
