import React, { FunctionComponent } from "react"
import { TouchableOpacityProps } from "react-native"
import { connect } from "react-redux"
import { State } from "convose-lib/store"

import { InterestsAction } from "convose-lib/interests"
import { Routes } from "convose-lib/router"
import { DEFAULT_HIT_SLOP } from "convose-lib/utils"
import { color } from "convose-styles"
import { OnboardingAction, selectAddInterestExplainer } from "convose-lib"
import { NavigationProps } from "convose-app/router"
import { ButtonWrapper, Label } from "./Styled"
import * as RootNavigation from "../../RootNavigation"
import PlusIcon from "../../../assets/Icons/components/PlusIcon"

type DispatchToProps = {
  readonly searchInterests: (text: string) => void
  readonly hideAddInterestExplainer: () => void
}
type ComponentProps = {
  readonly showingAddInterestExplainer: boolean
  readonly onPressAddInterests?: () => void
}
type SearchInterestsProps = TouchableOpacityProps &
  DispatchToProps &
  NavigationProps &
  ComponentProps

export const SearchInterestsComponent: FunctionComponent<
  SearchInterestsProps
> = ({
  searchInterests,
  hideAddInterestExplainer,
  showingAddInterestExplainer,
  onPressAddInterests,
  ...touchableOpacityProps
}) => {
  const openInterestsList = () => {
    if (showingAddInterestExplainer) {
      hideAddInterestExplainer()
    }
    onPressAddInterests && onPressAddInterests()
    searchInterests("")
    RootNavigation.navigate(Routes.Interests, {})
  }

  return (
    <ButtonWrapper
      onPress={openInterestsList}
      hitSlop={DEFAULT_HIT_SLOP}
      // eslint-disable-next-line react/jsx-props-no-spreading
      {...touchableOpacityProps}
    >
      <PlusIcon height={15} color={color.white} />
      <Label>Interests</Label>
    </ButtonWrapper>
  )
}
const mapStateToProps = (state: State) => ({
  showingAddInterestExplainer: selectAddInterestExplainer(state),
})
const mapDispatchToProps: DispatchToProps = {
  searchInterests: InterestsAction.searchInterests,
  hideAddInterestExplainer: OnboardingAction.hideAddInterestExplainer,
}

export const SearchInterests = connect(
  mapStateToProps,
  mapDispatchToProps
)(SearchInterestsComponent)
