import React from "react"
import { useSelector } from "react-redux"

import { selectIsDarkMode } from "convose-lib/app"
import SettingsGear from "../../../assets/Icons/components/SettingsGear"

type Props = {
  height?: number
}
const SettingIconComponent: React.FC<Props> = ({ height }) => {
  const isDarkMode = useSelector(selectIsDarkMode)
  return <SettingsGear height={height} color={isDarkMode ? "white" : "black"} />
}

export const SettingIcon = React.memo(SettingIconComponent)
