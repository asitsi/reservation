import { ScrollView } from "react-native-gesture-handler"
import Animated from "react-native-reanimated"
import styled from "styled-components/native"

import { Props } from "convose-styles"

export const Container = styled.View``
export const ScrollContainer = styled(ScrollView)``

export const InterestsContainer = styled(Animated.View)`
  padding-top: 10px;
  flex-direction: row;
  justify-content: center;
  flex-wrap: wrap;
  width: 100%;
  overflow: hidden;
  ${(props: { hasGradient: boolean }) =>
    props.hasGradient && `padding-bottom: 50px;`}
`

export const GradientContainer = styled.View`
  height: 40px;
  width: 100%;
  position: absolute;
  bottom: 0px;
  left: 0px;
  z-index: 10;
`

export const ChatMenuUserInterests = styled.View`
  padding-horizontal: ${(props: { insetHorizontal: number }) =>
    props.insetHorizontal}px;
  padding-top: 10px;
`
export const EditButtonContainer = styled.View`
  justify-content: center;
  height: 38px;
`
export const ExpandButton = styled(Animated.View)`
  height: 30px;
  aspect-ratio: 1;
  border-radius: 30px;
  background-color: ${(props: Props) => props.theme.mainBlue};
  justify-content: center;
  align-items: center;
  padding-top: 3px;
  padding-left: 1px;
`
