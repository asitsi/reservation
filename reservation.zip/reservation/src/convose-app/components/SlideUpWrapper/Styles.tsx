import { Dimensions } from "react-native"
import Animated from "react-native-reanimated"
import styled from "styled-components/native"

import { Props } from "convose-styles"

const { height } = Dimensions.get("window")
type PartialProps = Partial<Props>
const PADDING = 15
export const PADDING_TOP = PADDING + 20

export const Wrapper = styled.View`
  flex: 1;
  justify-content: flex-end;
  align-items: center;
  position: absolute;
  width: 100%;
  height: 100%;
  z-index: 1000;
  elevation: 1000;
`
type PillProps = PartialProps & {
  top?: number
  bottom?: number
}
export const Pill = styled.View`
  position: absolute;
  ${(props: PillProps) => props.top && `top:${props.top}px`};
  ${(props: PillProps) => props.bottom && `bottom:${props.bottom}px`};
  background-color: ${(props: PillProps) => props.theme.slideUp.pill};
  width: 30px;
  height: 4.5px;
  border-radius: 4px;
  align-self: center;
`
type ContainerProps = {
  insetBottom: number
  insetTop: number
  isFullScreen: boolean
} & PartialProps

export const Container = styled(Animated.View)`
  background-color: ${(props: ContainerProps) => props.theme.main.background};
  border-top-left-radius: 14px;
  border-top-right-radius: 14px;
  flex-direction: column;
  justify-content: flex-start;
  align-items: center;
  width: 100%;
  z-index: 10;
  ${(props: ContainerProps & { negativeMarginBottom: number }) =>
    props.isFullScreen && `height:${height - props.insetTop - 20}px;`}
  max-height: ${(props: ContainerProps) => height - props.insetTop - 20}px;
`
export const BackgroundEmptyView = styled(Animated.View)`
  width: 100%;
  height: 100%;
  position: absolute;
  top: 0px;
  left: 0px;
  right: 0px;
  bottom: 0px;
  background-color: ${(props: PartialProps & { useDarkBackground: boolean }) =>
    props.useDarkBackground
      ? props.theme.slideUp.backgroundDark
      : props.theme.slideUp.background};
`

export const ScrollViewWrapper = styled(Animated.View)`
  width: 100%;
  border-top-left-radius: 14px;
  border-top-right-radius: 14px;
  overflow: hidden;
  padding: ${PADDING}px;
  padding-top: ${PADDING_TOP}px;
  padding-bottom: ${(props: ContainerProps) => props.insetBottom + PADDING}px;
`
export const UserThemeBanner = styled(Animated.View)`
  background-color: ${(props: { bgColor: string }) =>
    props.bgColor || "transparent"};
  height: 120px;
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  border-top-right-radius: 14px;
  border-top-left-radius: 14px;
`
