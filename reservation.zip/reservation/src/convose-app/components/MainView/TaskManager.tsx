import React from "react"
import * as TaskManager from "expo-task-manager"
import * as Notifications from "expo-notifications"
import { connect } from "react-redux"
import { State } from "convose-lib"
import { selectMyUuid } from "convose-lib/user"
import {
  ChatAction,
  ChatMessageTypes,
  ChatSubscriptionMessage,
  Message,
  convertToHistory,
} from "convose-lib/chat"
import { Platform, AppState } from "react-native"

const BACKGROUND_NOTIFICATION_TASK = "BACKGROUND-NOTIFICATION-TASK"

const isAndroid = Platform.OS === "android"

const isNotificationTaskRegistered = (): boolean => {
  return TaskManager.isTaskDefined(BACKGROUND_NOTIFICATION_TASK)
}
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const isResponseValid = (message: any, chat: any) => {
  if (
    typeof message !== "object" ||
    !chat ||
    Object.keys(message).length <= 0
  ) {
    return false
  }
  return true
}
const invalidDataResponse = {
  message: null,
  chatChannel: null,
}
const parseMessage = (
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  data: any,
  myUuid: string
): {
  message: Message | null
  chatChannel: string | null
} => {
  if (isAndroid) {
    const cleanData = {
      ...{ notification: { data: { body: "" } } },
      ...(typeof data === "object" ? data : {}),
    }
    const response = {
      ...{ chat: "", message: {} },
      ...JSON.parse(cleanData.notification.data.body),
    }
    const { chat, message } = response
    if (isResponseValid(message, chat)) {
      return invalidDataResponse
    }
    return {
      message: convertToHistory(message, myUuid),
      chatChannel: chat,
    }
  }
  const cleanData = { ...{ body: {} }, ...data }
  const { chat = "", message = {} } = cleanData.body
  if (isResponseValid(message, chat)) {
    return invalidDataResponse
  }
  return {
    message: convertToHistory(message, myUuid),
    chatChannel: chat,
  }
}

type DispatchToProps = {
  updateChat: (message: ChatSubscriptionMessage) => void
}
type StateToProps = {
  readonly myUuid: string
}
type Props = DispatchToProps & StateToProps

class TaskManagerHandlerComponent extends React.PureComponent<Props> {
  public badgeNumber = 0

  componentDidMount(): void {
    this.registerNotificationTask()
    AppState.addEventListener("change", (state) => {
      if (state === "active") {
        this.badgeNumber = 0
        Notifications.setBadgeCountAsync(this.badgeNumber)
      }
    })
  }

  componentDidUpdate(): void {
    this.registerNotificationTask()
  }

  updateMessage = (message: ChatSubscriptionMessage): void => {
    const { updateChat } = this.props
    updateChat(message)
    if (!isAndroid) {
      this.badgeNumber += 1
      Notifications.setBadgeCountAsync(this.badgeNumber)
    }
  }

  registerNotificationTask = () => {
    const { myUuid } = this.props

    if (!isNotificationTaskRegistered()) {
      TaskManager.defineTask(
        BACKGROUND_NOTIFICATION_TASK,
        ({ data, error }) => {
          if (!error) {
            const { chatChannel, message } = parseMessage(data, myUuid)
            if (
              chatChannel &&
              message &&
              ChatMessageTypes.includes(message.message_type)
            ) {
              this.updateMessage({
                message,
                chatChannel,
              })
            }
          }
        }
      )
      Notifications.registerTaskAsync(BACKGROUND_NOTIFICATION_TASK)
    }
  }

  render(): React.ReactNode {
    return null
  }
}

const mapStateToProps = (state: State) => {
  return {
    myUuid: selectMyUuid(state),
  }
}
const mapDispatchToProps: DispatchToProps = {
  updateChat: ChatAction.updateChatWithNewMessage,
}

export const TaskManagerHandler = connect(
  mapStateToProps,
  mapDispatchToProps
)(TaskManagerHandlerComponent)
